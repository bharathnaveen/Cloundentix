
angular
    .module('cloudentixApp')
	.controller('listofattestation', Listof_attestation)

	  .run(
      ['$rootScope', '$state', '$stateParams',
        function($rootScope, $state, $stateParams) {
                
          $rootScope.$state = $state;
          $rootScope.$stateParams = $stateParams;
        }
      ]
    )
    .config(
      ['$stateProvider', '$urlRouterProvider',
        function($stateProvider, $urlRouterProvider) {

          $urlRouterProvider
          $stateProvider

			
          .state('attestation.selfattestation', {
              url: '/selfattestation',
             controller: function($scope) {

              },
              templateUrl: 'attestation/sub-selfattestation/selfattestation.html',
              data: {
				  'selectedTab': 0
				}
            })
       .state('attestation.historyattestation', {
              url: '/historyattestation',
              onEnter: function() {
                void 0;
              },
              controller: function($scope) {

              },
              templateUrl: 'attestation/sub-historyattestation/historyattestation.html',
              data: {
				  'selectedTab': 2
				}
            });
		}
      ]
    );
    Listof_attestation.$inject = ['$scope', '$log', '$location', '$window', '$http', '$state'];
		function Listof_attestation($scope, $log, $location, $window, $http, $state) {
			var attestationtabs = [
          { title: 'Self Attestation', tabLink: "attestation.selfattestation"},
		  { title: 'History Attestation', tabLink: "attestation.historyattestation"}
        ],
		 selected = null,
        previous = null;
		$scope.attestationtabs = attestationtabs;
		$scope.selectedIndex = $state.current.data.selectedTab;
		//$scope.selectedIndex = 0;
		/* $scope.attestationtabs = [];
		 attestationtabs.push (
          { title: 'Self Attestion', tabLink: "attestation.selfattestion"},
		  { title: 'Pending Attestation', tabLink: "attestation.pendingattestation"},
		  { title: 'History Attestation', tabLink: "attestation.historyattestation"}
        );
		console.log(attestationtabs);
		//$scope.attestationtabs = attestationtabs;*/
	}