angular
    .module('cloudentixApp')
	 .controller('dashboardController', dashboardCtrl)
	 .controller('dashboardaccesspolicyviolationissue', dashboardaccesspolicyviolationissueCtrl)
	 .controller('dashboarduserprovisioningissue', dashboarduserprovisioningissueissueCtrl)
	 .controller('dashboardaccesspolicyevaluationissue', dashboardaccesspolicyevaluationissueCtrl)
	 .controller('dashboardapprovalpolicyevaluationissue', dashboardapprovalpolicyevaluationissueCtrl)
	 dashboardCtrl.$inject = ['$rootScope', '$mdEditDialog', '$q', '$scope', '$timeout', '$http', '$state', '$interval', '$filter', 'SessionService'];
	 dashboardaccesspolicyviolationissueCtrl.$inject = ['$rootScope', '$scope', '$http', 'SessionService'];
	 dashboarduserprovisioningissueissueCtrl.$inject = ['$rootScope', '$mdEditDialog', '$q', '$scope', '$timeout', '$http', 'SessionService'];
	 dashboardaccesspolicyevaluationissueCtrl.$inject = ['$rootScope', '$mdEditDialog', '$q', '$scope', '$timeout', '$http', 'SessionService'];
	 dashboardapprovalpolicyevaluationissueCtrl.$inject = ['$rootScope', '$mdEditDialog', '$q', '$scope', '$timeout', '$http', 'SessionService'];
	  function dashboardCtrl($rootScope, $mdEditDialog, $q, $scope, $timeout, $http, $state, $interval, $filter, SessionService) {
          var tick = function() {
				var date = new Date();
				 var hours = date.getHours();
    //$scope.clock = Date.now();
	$scope.clock= $filter('date')(new Date(), 'HH:mm');
	  $scope.format=hours >= 12 ? 'PM' : 'AM';
  }
  tick();
  $interval(tick, 1000);
        
        var baseUrl = sessionStorage.getItem("WS_BASE_URL");
		var userid = localStorage.getItem("userid");
		 $scope.dashboard = function(){
		  var checkResourceURL = baseUrl + '/resources?check=true';
			var config = {
				//url:"dashboard/data.json",
				url:checkResourceURL,
				method: "GET",
				headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
				}
			}
			   
			$http(config)
			.success(function(response) {
				if (response.data.login[0].trusted == 'N' || response.data.login[0].untrusted == 'N') {
                    if (response.data.login[0].trusted == 'N' && response.data.login[0].untrusted == 'N') {
                       $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure trusted and untrusted resources");
                    } else {
                        if (response.data.login[0].trusted == 'N') {
                            $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure the trusted resource");
                        } else if (response.data.login[0].untrusted === 'N') {
                            $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure an untrusted resource");
                        }
                    }
                }
                else if(response.data.login[0].trusted == 'Y' && response.data.login[0].untrusted == 'Y') {
	  //$rootScope.loaderCurrentStatus = 'true';
	  //$scope.accesspolicyviolation();
	  //$scope.accesspolicyevaluation();
	 // $scope.newprovisionedusersCloudentix();
	 // $scope.newprovisionedusersTarget();
	  $scope.myaccessrequestpending();
	  $scope.requestpending();
	  $scope.attestationpending();
	  $scope.totalusers();
	  $scope.totalresource();
	  $scope.resourcestatus();
	  $scope.recentactivity();
	  //$scope.userpasswordexpire();
	  $scope.useraccountexpire();
		
		/*
		*This method used for display the User provisioning issues report in a new tab. 
		*It function works on when the value is greater than 0.
		*if approval user provisioning issue value 0 means its shows a toast message.
		*/
		$scope.userprovisioningissue = function (){
			if($scope.dashboardRecords[0].userprovissue.value > 0){
			$state.go("userprovisioningissue");
			$scope.addTab('Userprovision_is..','userprovisioningissue');
			}else{
			$scope.toastMessage('toast-info','No user provisioning issues found');
			}
		}
		/*
		*This method used for display the access policy evaluations report in a new tab. 
		*It function works on when the value is greater than 0.
		*if access policy evaluations value 0 means its shows a toast message.
		*/
		
		/*
		*This method used for display the approval policy evaluations report in a new tab. 
		*It function works on when the value is greater than 0.
		*if approval policy evaluations value 0 means its shows a toast message.
		*/
		$scope.approvalpolicyevaluation = function (){
			if($scope.dashboardRecords[0].appevalissue.value > 0){
			$state.go("approvalpolicyevaluationissue");
			$scope.addTab('Appolicy_evalua..','approvalpolicyevaluationissue');
			}else{
			$scope.toastMessage('toast-info','No approval policy evaluations issues found');
			}
		}
		
		/*
		*This method used for display the request pending approval page in a new tab. 
		*It function works on when the value is greater than 0.
		*if request pending approval value 0 means its shows a toast message.
		*/
		$scope.requestpendingapprovalfun = function (){
			if($scope.dashboardRecords[0].numofreqpend.value > 0){
			$state.go("myCloudentix.pendingapproval");
			$scope.addTab('Pending Approval','myCloudentix.pendingapproval');
			}else{
			$scope.toastMessage('toast-info','No request pending approval found');
			}
		}
		
		/*
		*This method used for display the request pending approval page in a new tab. 
		*It function works on when the value is greater than 0.
		*if request pending approval value 0 means its shows a toast message.
		*/
		$scope.requestpendingattestfun = function (){
			if($scope.dashboardRecords[0].rolependingformyattest.value > 0){
			$state.go("attestation.selfattestation");
			$scope.addTab('Self Attestation','attestation.selfattestation');
			}else{
			$scope.toastMessage('toast-info','No pending attestations available');
			}
		}
				}
			});
            
           
	  }

	  $scope.recentactivity = function (){
        $scope.activated = true;
        $scope.determinateValue = 30;
       var dashboardURL = baseUrl + '/dashboard/recentactivity';
       var userid = localStorage.getItem("userid");
var config = {
    //url:"dashboard/data.json",
    url:dashboardURL,
    method: "GET",
    headers: {
        "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
        "cdt-userid": userid
    }
}
$http(config)
.then(function success(response){
             $scope.activated = false;
             $scope.status = response.data.message;
             $scope.recentactivityvalue = [];
                                 angular.forEach(response.data.records, function(value, key) {
                $scope.recentactivityvalue.push({'date': value['date'],'recentactivitiy': value['recentactivitiy']});
                angular.forEach(value['recentactivitiy'], function(values, keys) {
                    if(values["module"] == 'login' || values["module"] == 'logout') {
                        $scope.recentactivityvalue[key]["recentactivitiy"][keys].icon = 'account_circle';
                    } else if(values["module"] == 'resource') {
                        $scope.recentactivityvalue[key]["recentactivitiy"][keys].icon = 'language';
                    } else if(values["module"] == 'user') {
                        $scope.recentactivityvalue[key]["recentactivitiy"][keys].icon = 'supervisor_account';
                    } else if(values["module"] == 'access policy') {
                        $scope.recentactivityvalue[key]["recentactivitiy"][keys].icon = 'verified_user';
                    } else if(values["module"] == 'approval policy') {
                        $scope.recentactivityvalue[key]["recentactivitiy"][keys].icon = 'spellcheck';
                    } else if(values["module"] == 'attestation') {
                        $scope.recentactivityvalue[key]["recentactivitiy"][keys].icon = 'done_all';
                    } else if(values["module"] == 'access request') {
                        $scope.recentactivityvalue[key]["recentactivitiy"][keys].icon = 'cloud_queue';
                    } else if(values["module"] == 'user attribute') {
                        $scope.recentactivityvalue[key]["recentactivitiy"][keys].icon = 'computer';
                    } else if(values["module"] == 'job scheduler') {
                        $scope.recentactivityvalue[key]["recentactivitiy"][keys].icon = 'schedule';
                    }
                });
            });
                   // console.log($scope.recentactivityvalue2)
                    
            if($scope.adexpirenotifyvalue > 0){
    //$state.go("accesspolicyevaluationissue");
    //$scope.addTab('Acpolicy_evalua..','accesslpolicyevaluationissue');
    }else{
    //$scope.toastMessage('toast-info','No access policy evaluations issues found');
    }
        },function error(response){
             $scope.activated = false;
    });
}  
	   
  $scope.refreshDashboard = function(){
		$scope.dashboard();
		}
		 $scope.dashboard();
        $scope.accesspolicyviolation = function (){
                $scope.activated = true;
                $scope.determinateValue = 30;
               var dashboardURL = baseUrl + '/dashboard/acpviolation';
		var config = {
			//url:"dashboard/data.json",
			url:dashboardURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
			}
		}
		$http(config)
		.then(function success(response){
                     $scope.activated = false;
                    $scope.accesspolicyviolationvalue = response.data.records[0].value;
                },function error(response){
                     $scope.activated = false;
        });
			/*if($scope.dashboardRecords[0].acpviolationissue.value > 0){
                localStorage.setItem('selectedReportkey', '1');
                localStorage.setItem('selectedReporttitle', 'Access Policy Violation Report');
                $state.go("reportView");
                $scope.addTab('Report: View','reportView');
			}else{
			$scope.toastMessage('toast-info','No access policy violations found');
			}*/
		}     
        $scope.accesspolicyevaluation = function (){
                $scope.activated = true;
                $scope.determinateValue = 30;
               var dashboardURL = baseUrl + '/dashboard/acpevalissue';
		var config = {
			//url:"dashboard/data.json",
			url:dashboardURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
			}
		}
		$http(config)
		.then(function success(response){
                     $scope.activated = false;
                    $scope.accesspolicyevaluationvalue = response.data.records[0].value;
                    
                    if($scope.accesspolicyevaluationvalue > 0){
			$state.go("accesspolicyevaluationissue");
			$scope.addTab('Acpolicy_evalua..','accesslpolicyevaluationissue');
			}else{
			//$scope.toastMessage('toast-info','No access policy evaluations issues found');
			}
                },function error(response){
                     $scope.activated = false;
            });
		}   

        $scope.newprovisionedusersCloudentix = function (){
                $scope.activated = true;
                $scope.determinateValue = 30;
               var dashboardURL = baseUrl + '/dashboard/newprovusercloudentix';
		var config = {
			//url:"dashboard/data.json",
			url:dashboardURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
			}
		}
		$http(config)
		.then(function success(response){
                     $scope.activated = false;
                    $scope.usercloudentix = response.data.records[0].value;
                    
                    if($scope.usercloudentix > 0){
			//$state.go("accesspolicyevaluationissue");
			//$scope.addTab('Acpolicy_evalua..','accesslpolicyevaluationissue');
			}else{
			//$scope.toastMessage('toast-info','No access policy evaluations issues found');
			}
                },function error(response){
                     $scope.activated = false;
            });
		}       

        $scope.newprovisionedusersTarget = function (){
                $scope.activated = true;
                $scope.determinateValue = 30;
               var dashboardURL = baseUrl + '/dashboard/newprovusertarget';
		var config = {
			//url:"dashboard/data.json",
			url:dashboardURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
			}
		}
		$http(config)
		.then(function success(response){
                     $scope.activated = false;
                    $scope.usertarget = response.data.records[0].value;
                    
                    if($scope.usertarget > 0){
			//$state.go("accesspolicyevaluationissue");
			//$scope.addTab('Acpolicy_evalua..','accesslpolicyevaluationissue');
			}else{
			//$scope.toastMessage('toast-info','No access policy evaluations issues found');
			}
                },function error(response){
                     $scope.activated = false;
            });
		}     
        
        $scope.myaccessrequestpending = function (){
                $scope.activated = true;
                $scope.determinateValue = 30;
               var dashboardURL = baseUrl + '/dashboard/myaccessrequestpending';
               var userid = localStorage.getItem("userid");
		var config = {
			//url:"dashboard/data.json",
			url:dashboardURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                "cdt-userid":userid
			}
		}
		$http(config)
		.then(function success(response){
                     $scope.activated = false;
                    $scope.myaccessrequestpendingvalue = response.data.records[0].myaccessrequestpending.value;
                    
                    if($scope.myaccessrequestpendingvalue > 0){
			//$state.go("accesspolicyevaluationissue");
			//$scope.addTab('Acpolicy_evalua..','accesslpolicyevaluationissue');
			}else{
			//$scope.toastMessage('toast-info','No access policy evaluations issues found');
			}
                },function error(response){
                     $scope.activated = false;
            });
		}   
        $scope.requestpending = function (){
                $scope.activated = true;
                $scope.determinateValue = 30;
               var dashboardURL = baseUrl + '/dashboard/requestpendingforapproval';
               var userid = localStorage.getItem("userid");
		var config = {
			//url:"dashboard/data.json",
			url:dashboardURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                "cdt-userid":userid
			}
		}
		$http(config)
		.then(function success(response){
                     $scope.activated = false;
                    $scope.requestpendingvalue = response.data.records[0].reqpending.value;
                    
                    if($scope.requestpendingvalue > 0){
			//$state.go("accesspolicyevaluationissue");
			//$scope.addTab('Acpolicy_evalua..','accesslpolicyevaluationissue');
			}else{
			//$scope.toastMessage('toast-info','No access policy evaluations issues found');
			}
                },function error(response){
                     $scope.activated = false;
            });
		}    
        
        $scope.attestationpending = function (){
                $scope.activated = true;
                $scope.determinateValue = 30;
               var dashboardURL = baseUrl + '/dashboard/pendingattest';
               var userid = localStorage.getItem("userid");
		var config = {
			//url:"dashboard/data.json",
			url:dashboardURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                "cdt-userid":userid
			}
		}
		$http(config)
		.then(function success(response){
                     $scope.activated = false;
                    $scope.attestpendingvalue = response.data.records[0].rolependingformyattest.value;
                    
                    if($scope.attestpendingvalue > 0){
			//$state.go("accesspolicyevaluationissue");
			//$scope.addTab('Acpolicy_evalua..','accesslpolicyevaluationissue');
			}else{
			//$scope.toastMessage('toast-info','No access policy evaluations issues found');
			}
                },function error(response){
                     $scope.activated = false;
            });
		}     

        $scope.totalusers = function (){
                $scope.activated = true;
                $scope.determinateValue = 30;
               var dashboardURL = baseUrl + '/dashboard/numofusers';
               //var userid = localStorage.getItem("userid");
		var config = {
			//url:"dashboard/data.json",
			url:dashboardURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
               
			}
		}
		$http(config)
		.then(function success(response){
                     $scope.activated = false;
                    $scope.totalusersvalue = response.data.records[0].value;
                    
                    if($scope.totalusersvalue > 0){
			//$state.go("accesspolicyevaluationissue");
			//$scope.addTab('Acpolicy_evalua..','accesslpolicyevaluationissue');
			}else{
			//$scope.toastMessage('toast-info','No access policy evaluations issues found');
			}
                },function error(response){
                     $scope.activated = false;
            });
		}      
        
        $scope.userpasswordexpire = function (){
                $scope.activated = true;
                $scope.determinateValue = 30;
               var dashboardURL = baseUrl + '/dashboard/userpwdexpire';
               //var userid = localStorage.getItem("userid");
		var config = {
			//url:"dashboard/data.json",
			url:dashboardURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
               
			}
		}
		$http(config)
		.then(function success(response){
                     $scope.activated = false;
                    $scope.userpasswordexpirevalue = response.data.records[0].value;
                    
                    if($scope.userpasswordexpirevalue > 0){
			//$state.go("accesspolicyevaluationissue");
			//$scope.addTab('Acpolicy_evalua..','accesslpolicyevaluationissue');
			}else{
			//$scope.toastMessage('toast-info','No access policy evaluations issues found');
			}
                },function error(response){
                     $scope.activated = false;
            });
		}

        $scope.useraccountexpire = function (){
                $scope.activated = true;
                $scope.determinateValue = 30;
               var dashboardURL = baseUrl + '/dashboard/useraccountexpire';
               //var userid = localStorage.getItem("userid");
		var config = {
			//url:"dashboard/data.json",
			url:dashboardURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
               
			}
		}
		$http(config)
		.then(function success(response){
                     $scope.activated = false;
                    $scope.useraccountexpirevalue = response.data.records[0].value;
                    
                    if($scope.useraccountexpirevalue > 0){
			//$state.go("accesspolicyevaluationissue");
			//$scope.addTab('Acpolicy_evalua..','accesslpolicyevaluationissue');
			}else{
			//$scope.toastMessage('toast-info','No access policy evaluations issues found');
			}
                },function error(response){
                     $scope.activated = false;
            });
		}      

        $scope.totalresource = function (){
                $scope.activated = true;
                $scope.determinateValue = 30;
               var dashboardURL = baseUrl + '/dashboard/numofresources';
               //var userid = localStorage.getItem("userid");
		var config = {
			//url:"dashboard/data.json",
			url:dashboardURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
               
			}
		}
		$http(config)
		.then(function success(response){
                     $scope.activated = false;
                    $scope.totalresourcevalue = response.data.records[0].value;
                    if($scope.totalresourcevalue > 0){
			//$state.go("accesspolicyevaluationissue");
			//$scope.addTab('Acpolicy_evalua..','accesslpolicyevaluationissue');
			}else{
			//$scope.toastMessage('toast-info','No access policy evaluations issues found');
			}
                },function error(response){
                     $scope.activated = false;
            });
		}   

        $scope.resourcestatus = function (){
                $scope.activated = true;
                $scope.determinateValue = 30;
               var dashboardURL = baseUrl + '/dashboard/userstatus';
               var userid = localStorage.getItem("userid");
		var config = {
			//url:"dashboard/data.json",
			url:dashboardURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
               "cdt-userid": userid
			}
		}
		$http(config)
		.then(function success(response){
                     $scope.activated = false;
                    $scope.totalresourcestatusvalue = [];
                     angular.forEach(response.data.records, function(value, key) {
                                $scope.totalresourcestatusvalue.push({'resourcename': value['rescname'], 'status': value['status']});
                            });
                },function error(response){
                     $scope.activated = false;
            });
		}         
  }

function dashboardaccesspolicyviolationissueCtrl($rootScope, $scope, $http, SessionService){
         
            var baseUrl = sessionStorage.getItem("WS_BASE_URL");
            var checkResourceURL = baseUrl + '/resources?check=true';
			var config = {
				//url:"dashboard/data.json",
				url:checkResourceURL,
				method: "GET",
				headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
				}
			}
			   
			$http(config)
			.success(function(response) {
				if (response.data.login[0].trusted == 'N' || response.data.login[0].untrusted == 'N') {
                    if (response.data.login[0].trusted == 'N' && response.data.login[0].untrusted == 'N') {
                       $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure trusted and untrusted resources");
                    } else {
                        if (response.data.login[0].trusted == 'N') {
                            $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure the trusted resource");
                        } else if (response.data.login[0].untrusted === 'N') {
                            $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure an untrusted resource");
                        }
                    }
                }
                else if(response.data.login[0].trusted == 'Y' && response.data.login[0].untrusted == 'Y') {
                    'use strict';
                    $rootScope.loaderCurrentStatus = 'true';
                    $scope.selected = [];
                    $scope.limitOptions = [10, 25, 50, 100];
                    $scope.options = {
                        rowSelection: false,
                        multiSelect: false,
                        autoSelect: true,
                        decapitate: false,
                        largeEditDialog: true,
                        boundaryLinks: true,
                        limitSelect: true,
                        pageSelect: true
                    };
                    $scope.query = {
                        order: 'name',
                        limit: 10,
                        page: 1
                    };
                    $scope.toggleLimitOptions = function () {
                    $scope.limitOptions = $scope.limitOptions ? undefined : [10, 25, 50, 100];
                };
                $scope.getTypes = function () {
                    return ['Candy', 'Ice cream', 'Other', 'Pastry'];
                };
                $scope.logItem = function (item) {
                    void 0;
                };
                $scope.logOrder = function (order) {
                    void 0;
                };
                  
                $scope.logPagination = function (page, limit) {
                    void 0;
                    void 0;
                }
                    var accesspolicy = baseUrl + '/reports/accesspolicyviolation';

                    var config = {
                        url: accesspolicy,
                        method: "GET",
                        headers: {
                            "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                        }
                    };
                    $http(config).success(function(response) {  
                        $scope.reportsResponse = response.type;
                        $rootScope.loaderCurrentStatus = 'false';
                        if(response.type === "success") { 
                            $scope.accesspolicydata = [];
                            angular.forEach(response.records[0].accesspolviorecords, function(value, key) {
                                $scope.accesspolicydata.push({'username': value['username'], 'resourcename': value['rscname'], 'rolename': value['rolename'], 'remarks': value['remarks']});
                            });
                        } else {
                           $scope.reportsErrorMessage = response.message;        
                        }            
                       
                    }).error(function(data) {
                        void 0;        
                    });	
                            }
                        });			
         }
   function dashboarduserprovisioningissueissueCtrl($rootScope, $mdEditDialog, $q, $scope, $timeout, $http, SessionService) {
   
    $scope.limitOptions = [10, 25, 50, 100];
  
  $scope.options = {
    rowSelection: false,
    multiSelect: false,
    autoSelect: false,
    decapitate: false,
    largeEditDialog: false,
    boundaryLinks: false,
    limitSelect: true,
    pageSelect: true
  };
  
  $scope.query = {
    order: 'name',
    limit: 10,
    page: 1
  };
		var userprovisioningissueURL = $rootScope.dashboardRecords[0].userprovissue.uri_data.uri;
		var userprovisioningissueMethod = $rootScope.dashboardRecords[0].userprovissue.uri_data.method;
		//console.log(approvalpolicyviolationsURL);
		
		var config = {
			//url:"dashboard/data.json",
			url:userprovisioningissueURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
				
			}
		}
		   
		$http(config)
		.success(function(response){ 
		$scope.userResponse = response.type;
		//console.log(response.records[0].appevalrecords)
		$scope.userprovisioningissueList = [];
		angular.forEach(response.records[0].appevalrecords, function(value, key) {
				$scope.userprovisioningissueList.push({"username" : value["username"],"rolename" : value["rolename"],"resourcename" : value["resourcename"],"remarks" : value["remarks"]});
			});
		});
		}
		/*End*/
		function dashboardaccesspolicyevaluationissueCtrl($rootScope, $mdEditDialog, $q, $scope, $timeout, $http, SessionService) {
		
		 $scope.limitOptions = [10, 25, 50, 100];
  
  $scope.options = {
    rowSelection: false,
    multiSelect: false,
    autoSelect: false,
    decapitate: false,
    largeEditDialog: false,
    boundaryLinks: false,
    limitSelect: true,
    pageSelect: true
  };
  
  $scope.query = {
    order: 'name',
    limit: 10,
    page: 1
  };
		var accesspolicyevaluationURL = $rootScope.dashboardRecords[0].acpevalissue.uri_data.uri;
		var accesspolicyevaluationMethod = $rootScope.dashboardRecords[0].acpevalissue.uri_data.method;
		//console.log(approvalpolicyviolationsURL);
		
		var config = {
			//url:"dashboard/data.json",
			url:accesspolicyevaluationURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
				
			}
		}
		   
		$http(config)
		.success(function(response){ 
		$scope.userResponse = response.type;
		//console.log(response.records[0].appevalrecords)
		$scope.accesspolicyevaluationList = [];
		angular.forEach(response.records[0].acpevalrecords, function(value, key) {
				$scope.accesspolicyevaluationList.push({"username" : value["username"],"resourcename" : value["resourcename"],"remarks" : value["error"]});
			});
		});
		}
		 
function dashboardapprovalpolicyevaluationissueCtrl($rootScope, $mdEditDialog, $q, $scope, $timeout, $http, SessionService) {
   
    $scope.limitOptions = [10, 25, 50, 100];
  
  $scope.options = {
    rowSelection: false,
    multiSelect: false,
    autoSelect: false,
    decapitate: false,
    largeEditDialog: false,
    boundaryLinks: false,
    limitSelect: true,
    pageSelect: true
  };
  
  $scope.query = {
    order: 'name',
    limit: 10,
    page: 1
  };
		var approvalpolicyevaluationURL = $rootScope.dashboardRecords[0].appevalissue.uri_data.uri;
		var approvalpolicyevaluationMethod = $rootScope.dashboardRecords[0].appevalissue.uri_data.method;
		//console.log(approvalpolicyviolationsURL);
		
		var config = {
			//url:"dashboard/data.json",
			url:approvalpolicyevaluationURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
				
			}
		}
		   
		$http(config)
		.success(function(response){ 
		$scope.userResponse = response.type;
		//console.log(response.records[0].appevalrecords)
		$scope.approvalpolicyevaluationList = [];
		angular.forEach(response.records[0].appevalrecords, function(value, key) {
				$scope.approvalpolicyevaluationList.push({"username" : value["username"],"rolename" : value["rolename"],"resourcename" : value["resourcename"],"remarks" : value["remarks"]});
			});
		});
		}
		