angular
    .module('cloudentixApp')
	.controller('historyattestation', HistoryAttestation)
	HistoryAttestation.$inject = ['$rootScope', '$scope', '$log', '$location', '$window', '$http', '$timeout', '$filter', 'SessionService'];	
	function HistoryAttestation($rootScope, $scope, $log, $location, $window, $http, $timeout, $filter, SessionService) { 
		var baseUrl = sessionStorage.getItem("WS_BASE_URL");
	'use strict';
		$rootScope.loaderCurrentStatus = 'true';
		$scope.historyAttestationErrorMessage = '';
		$scope.selected = [];
		$scope.limitOptions = [10, 25, 50, 100];
	  
	  $scope.options = {
		rowSelection: false,
		multiSelect: false,
		autoSelect: true,
		decapitate: false,
		largeEditDialog: true,
		boundaryLinks: true,
		limitSelect: true,
		pageSelect: true
	  };
	  
	  $scope.query = {
		order: 'name',
		limit: 10,
		page: 1,
		filter: ''
	  }; 
	  $scope.loadHistoryAttest = function() {
			$scope.historyuserid = localStorage.getItem("userid");
			var historyAttestURL = baseUrl +'/attestations';
			var config = {
				url: historyAttestURL,
				method: "GET",
				headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
					"cdt-guid" : $scope.historyuserid
				}
			}
			$http(config).success(function(response) {
				$scope.attestationResponse = response.type;
				$scope.cloud_historyattestation = [];
				$scope.duplicateHistoryattestation = [];
				$rootScope.loaderCurrentStatus = 'false';
				if (response.type == "success") {
					$scope.cloud_historyattestation = response.records[0].attesthistory;
					$scope.duplicateHistoryattestation = angular.copy($scope.cloud_historyattestation);
				} else {
					$scope.historyAttestationErrorMessage = response.message;
				}
			})
			.error(function(response) {
					 $rootScope.loaderCurrentStatus = 'false';
 $scope.errorHandler(response.config.url,response.status);  
			});
	  }
	  $scope.$watch('query.filter', function (newValue, oldValue) {
		if(newValue == '') {
			$scope.cloud_historyattestation = $scope.duplicateHistoryattestation;
		}
		if(newValue){
			$scope.items = $filter('filter')($scope.duplicateHistoryattestation, newValue);
			$scope.cloud_historyattestation = $scope.items;
		}
	});
	$scope.toggleLimitOptions = function () {
    $scope.limitOptions = $scope.limitOptions ? undefined : [10, 25, 50, 100];
  };
  
	  $scope.getTypes = function () {
		return ['Candy', 'Ice cream', 'Other', 'Pastry'];
	  };
	  
	  $scope.loadHistoryStuff = function () {
		$scope.promise = $timeout(function () {
		  $scope.loadHistoryAttest();
		}, 100);
	  }
	  
	  $scope.logItem = function (item) {
		void 0;
	  };
	  
	  $scope.logOrder = function (order) {
		void 0;
	  };
	  
	  $scope.logPagination = function (page, limit) {
		void 0;
		void 0;
	  }
	$scope.loadHistoryAttest();
	}
	