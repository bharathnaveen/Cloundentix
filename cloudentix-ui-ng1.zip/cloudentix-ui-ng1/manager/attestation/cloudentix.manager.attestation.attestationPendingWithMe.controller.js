angular
    .module('cloudentixApp')
	.controller('pendingattestation', PendingAttestation)
	PendingAttestation.$inject = ['$rootScope', '$scope', '$log', '$location', '$window', '$http', '$mdDialog', '$mdMedia', '$mdToast', '$document', '$route', '$timeout', '$filter', 'SessionService'];    	
	function PendingAttestation($rootScope, $scope, $log, $location, $window, $http, $mdDialog, $mdMedia, $mdToast, $document, $route, $timeout, SessionService) { 
		var baseUrl = sessionStorage.getItem("WS_BASE_URL");
		'use strict';
		$rootScope.loaderCurrentStatus = 'true';
		$scope.selected = [];
		$scope.pendingAttestationErrorMessage = '';
		$scope.limitOptions = [10, 25, 50, 100];
		$scope.options = {
			rowSelection: false,
			multiSelect: false,
			autoSelect: true,
			decapitate: false,
			largeEditDialog: true,
			boundaryLinks: true,
			limitSelect: true,
			pageSelect: true
		};
		$scope.query = {
			order: 'name',
			limit: 10,
			page: 1
		};
		$scope.loadPendingAttet = function() {
		var pendingAttestURL = baseUrl + '/attestations/pendingattest';
			var config = {
				url: pendingAttestURL,
				method: "GET",
				headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
				}
			}
			$http(config).success(function(response) {
				$scope.attestationResponse = response.type;
				$scope.cloud_pendingattestation = [];
				$rootScope.loaderCurrentStatus = 'false';
				if (response.type == "success") {
					$scope.cloud_pendingattestation = response.records[0].listpendingattest;
				} else {
					 $scope.pendingAttestationErrorMessage = response.message;
				}
			})
			.error(function(response) {
					 $rootScope.loaderCurrentStatus = 'false';
 $scope.errorHandler(response.config.url,response.status);  
			});
		}
		 $scope.toggleLimitOptions = function () {
			$scope.limitOptions = $scope.limitOptions ? undefined : [10, 25, 50, 100];
		};
  
		$scope.getTypes = function () {
			return ['Candy', 'Ice cream', 'Other', 'Pastry'];
		};
	  
		$scope.loadPendingStuff = function () {
			$scope.promise = $timeout(function () {
				$scope.loadPendingAttet();
			}, 100);
		}
	  
	  $scope.logItem = function (item) {
		void 0;
	  };
	  
	  $scope.logOrder = function (order) {
		void 0;
	  };
	  
	  $scope.logPagination = function (page, limit) {
		void 0;
		void 0;
	  }
	  $scope.loadPendingAttet();
	}
	