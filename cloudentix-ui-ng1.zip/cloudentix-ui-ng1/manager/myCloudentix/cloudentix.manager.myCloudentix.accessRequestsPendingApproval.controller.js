
    
angular.module('cloudentixApp')  
.controller('pendingapproval', pendingapproval);
pendingapproval.$inject = ['$mdEditDialog', '$q', '$scope', '$timeout', '$http', '$mdDialog', '$mdMedia', '$mdToast', '$attrs', '$rootScope', '$filter', '$location', '$routeParams', '$route', 'SessionService'];

function pendingapproval($mdEditDialog, $q, $scope, $timeout, $http,  $mdDialog, $mdMedia, $mdToast, $attrs, $rootScope, $filter, $location, $routeParams, $route, SessionService) {
var baseUrl = sessionStorage.getItem("WS_BASE_URL");
var checkResourceURL = baseUrl + '/resources?check=true';
   var config = {
     //url:"dashboard/data.json",
     url:checkResourceURL,
     method: "GET",
     headers: {
       "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
     }
   }
      
   $http(config)
   .success(function(response) {
                if(response.type === 'success'){
     if (response.data.login[0].trusted == 'N' || response.data.login[0].untrusted == 'N') {
                 if (response.data.login[0].trusted == 'N' && response.data.login[0].untrusted == 'N') {
                    $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure trusted and untrusted resources");
                 } else {
                     if (response.data.login[0].trusted == 'N') {
                         $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure the trusted resource");
                     } else if (response.data.login[0].untrusted === 'N') {
                         $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure an untrusted resource");
                     }
                 }
             }
             else if(response.data.login[0].trusted == 'Y' && response.data.login[0].untrusted == 'Y') {
var userid = localStorage.getItem("userid");
'use strict';
$rootScope.loaderCurrentStatus = 'true';
$scope.selected = [];
$scope.limitOptions = [10, 25, 50, 100];

$scope.options = {
 rowSelection: true,
 multiSelect: false,
 autoSelect: true,
 decapitate: false,
 largeEditDialog: true,
 boundaryLinks: true,
 limitSelect: true,
 pageSelect: true
};

$scope.query = {
 order: 'name',
 limit: 10,
 page: 1,
filter: ''
};

 //var getToken = (document.location.search).replace("?", "");
 var getToken = ($location.search());
// var decoded_Token = decodeURIComponent(getToken);
 //var getCompatibleToken = getToken.split("&");
if(getToken.status == undefined){
//console.log('null');
}else{
//console.log(getToken)
}   

$scope.emailApprove = function(){
void 0
$rootScope.loaderCurrentStatus = 'false';
if(getToken.status == 'A'){
$scope.type = 'Approval Reason';
}else{
$scope.type = 'Rejection Reason';
}
}
$scope.emailerror = '';
$scope.emailApprovalFormSubmit = function(reason){
         void 0
          $rootScope.loaderCurrentStatus = 'true';
      var approveURL = baseUrl + '/requestaccess/approvereject';
  var config = {
   url: approveURL,
   method: "GET",
   headers: {
     "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
     "cdt-loginguid":getToken.mgrid,
     "cdt-roleid":getToken.roleid,
     "cdt-guid":getToken.userid,
     "cdt-rscid":getToken.rscid,
     "cdt-status":getToken.status,
     "cdt-remark":reason,
           
   }
 }
     $http(config).then(function success(response){
     $rootScope.loaderCurrentStatus = 'false';
   //alert(response.message)
   //console.log(response.message)
   if(response.data.type == "success"){
   $scope.toastMessage('toast-success',response.data.message);
          $scope.emailBased = false;
         $scope.loadData();
         
         
   }if(response.data.type == "error"){
   $scope.toastMessage('toast-error',response.data.message);
         $scope.emailerror = response.data.message;
   }
     
     },function error(response){
     $rootScope.loaderCurrentStatus = 'false';
$scope.errorHandler(response.config.url,response.status);
     });
    
}
//console.log(getCompatibleToken[1]);
$scope.loadData = function () {
 //$scope.pendingLists = [];
 var pendingListURL = baseUrl + '/requestaccess/requesteduserdetails';
 
 var config = {
   url: pendingListURL,
   method: "GET",
   headers: {
     "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
     "cdt-guid":userid,
   }
 }
    
 $http(config)
 .then(function success(response){ 
 $scope.userResponse = response.data.type;
 $rootScope.loaderCurrentStatus = 'false';
   $scope.pendingList = [];
   $scope.duplicatependingList = [];
    if(response.data.type == "success"){
     angular.forEach(response.data.records[0].requesteruserdetails, function(value, key) {
       $scope.pendingList.push({"requestername" : value["requestername"],"rescname" : value["rescname"],"rolename" : value["rolename"],"guid" : value["guid"],"roleid" : value["roleid"],"rescid" : value["rescid"]});
     });
     $scope.duplicatependingList = angular.copy($scope.pendingList);
   }else{
   $scope.userErrorMessage = response.data.message;
   }
 },function error(response){
     $rootScope.loaderCurrentStatus = 'false';
     $scope.errorHandler(response.config.url,response.status);
     });
};
$scope.$watch('query.filter', function (newValue, oldValue) {
   if(newValue == '') {
     $scope.pendingList = $scope.duplicatependingList;
   }
   if(newValue){
     $scope.items = $filter('filter')($scope.duplicatependingList, newValue);
     $scope.pendingList = $scope.items;
   }
});
//$scope.isDisabled=true;
$scope.approve = function (event, pendingList) {
 event.stopPropagation(); // in case autoselect is enabled
 
 var editDialog = {
   modelValue: pendingList.approve,
   placeholder: 'Please Provide a reason',
   save: function (input) {
     if(input.$modelValue == null) {
       input.$invalid = true;
       return $q.reject();
     }
     /*if(input.$modelValue === 'Bernie Sanders') {
       return pendingList.approveComment = 'FEEL THE BERN!'
     }*/
     pendingList.approveComment = input.$modelValue;
 $rootScope.loaderCurrentStatus = 'true';
     var userid = localStorage.getItem("userid");
 var approveURL = baseUrl + '/requestaccess/approvereject';
  var config = {
   url: approveURL,
   method: "PUT",
   headers: {
     "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
     "cdt-loginguid":userid,
     "cdt-roleid":pendingList.roleid,
     "cdt-guid":pendingList.guid,
     "cdt-rscid":pendingList.rescid,
     "cdt-status":"A",
     "cdt-remark":input.$modelValue,
           
   }
 }
    
 $http(config)
 .then(function success(response){ 
   $mdDialog.hide();
   $rootScope.loaderCurrentStatus = 'false';
   //alert(response.message)
   //console.log(response.message)
   if(response.data.type == "success"){
   $scope.toastMessage('toast-success',response.data.message);
   }if(response.data.type == "error"){
   $scope.toastMessage('toast-error',response.data.message);
   }
   $scope.loadData();
    //
   
   },function error(response){
         $rootScope.loaderCurrentStatus = 'false';
$scope.errorHandler(response.config.url,response.status);
         });
   },
   targetEvent: event,
   title: 'Access Request: Approval',
 clickOutsideToClose: false,
 escToClose: false,
 
   validators: {
 
     //'md-minlength': 5,
     'md-maxlength': 100,
 //'minlength':5,
 'maxlength':100,
 'required':'yes',
   },
 messages: {

 //'minlength':'Reason too short',
  //'required':'Approval reason is quired ',
 }
 };
 
 var promise;
 
 if($scope.options.largeEditDialog) {
   promise = $mdEditDialog.large(editDialog);
  //console.log(pendingList.roleid, 'was ');
 } else {
   promise = $mdEditDialog.small(editDialog);
 }
 
 promise.then(function (ctrl) {
   var input = ctrl.getInput();
   //alert(input)
  void 0;
   input.$viewChangeListeners.push(function () {
     input.$setValidity('test', input.$modelValue !== 'test');
   });
 });
};  


$scope.reject = function (event, pendingList) {
var userid = localStorage.getItem("userid");
 event.stopPropagation(); // in case autoselect is enabled
 
 var editDialog = {
   modelValue: pendingList.reject,
   placeholder: 'Please Provide a reason',
   save: function (input) {
     if(input.$modelValue ==null) {
       input.$invalid = true;
       return $q.reject();
     }/*
     if(input.$modelValue === 'Bernie Sanders') {
       return pendingList.comment1 = 'FEEL THE BERN!'
     }*/
 
     pendingList.comment1 = input.$modelValue;
 $rootScope.loaderCurrentStatus = 'true';
     var userid = localStorage.getItem("userid");
 var rejectURL = baseUrl + '/requestaccess/approvereject';
    var config = {
   url: rejectURL,
   method: "PUT",
   headers: {
     "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
     "cdt-loginguid":userid,
     "cdt-roleid":pendingList.roleid,
     "cdt-guid":pendingList.guid,
     "cdt-rscid":pendingList.rescid,
     "cdt-status":"R",
     "cdt-remark":input.$modelValue,
   }
 }
    
 $http(config)
 .then(function success(response){ 
   $mdDialog.hide();
   $rootScope.loaderCurrentStatus = 'false';
   //alert(response.message)
   if(response.data.type == "success"){
   $scope.toastMessage('toast-success',response.data.message);
   }if(response.data.type == "error"){
   $scope.toastMessage('toast-error',response.data.message);
   }
   $scope.loadData();
    
   
   },function error(response){
         $rootScope.loaderCurrentStatus = 'false';
$scope.errorHandler(response.config.url,response.status);
         });
   },
   targetEvent: event,
   title: 'Access Request: Rejected',
 clickOutsideToClose: false,
 escToClose: false,
   validators: {
     //'md-minlength': 5,
     'md-maxlength': 100,
 //'minlength':5,
 'maxlength':100,
 'touched':true, 'required':'yes',
   },
 messages: {

 //'minlength':'Reason too short',
  //'required':'Approval reason is quired ',
 }
 };
 
 var promise;
 
 if($scope.options.largeEditDialog) {
   promise = $mdEditDialog.large(editDialog);
 } else {
   promise = $mdEditDialog.small(editDialog);
 }
 
 promise.then(function (ctrl) {
   var input = ctrl.getInput();
   
   input.$viewChangeListeners.push(function () {
     input.$setValidity('test', input.$modelValue !== 'test');
   });
 });
};

$scope.toggleLimitOptions = function () {
 $scope.limitOptions = $scope.limitOptions ? undefined : [10, 25, 50, 100];
};

$scope.getTypes = function () {
 return ['Candy', 'Ice cream', 'Other', 'Pastry'];
};

$scope.loadStuff = function () {
 $scope.promise = $timeout(function () {
   $scope.loadData();
 }, 100);
}

$scope.logItem = function (pendingList) {
 void 0;
 void 0;
};

$scope.logOrder = function (order) {
 void 0;
};

$scope.logPagination = function (page, limit) {
 void 0;
 void 0;
}
var userid = localStorage.getItem("userid");
if(getToken.status == undefined){
void 0;
$scope.emailBased = false;
 $scope.loadData();
}else{
if(getToken.mgrid === userid){
void 0;
$scope.emailBased = true;
$scope.emailApprove();
}else{
 $scope.emailBased = false;
 void 0;
 $scope.loadData();
}
}   

     }
              }else {
 $rootScope.loaderCurrentStatus = 'false';
$scope.errorHandler(response.message,response.status);

 }
   });

};

