angular
    .module('cloudentixApp')
	 .controller('myCloudentix', myCloudentix)
	 .controller('DialogCtrl', DialogCtrl)
	 myCloudentix.$inject = ['$mdEditDialog', '$q', '$scope', '$timeout', '$http',  '$mdDialog', '$mdMedia', '$mdToast','$rootScope', '$filter', 'SessionService'];
	 DialogCtrl.$inject = ['$timeout', '$q', '$http', '$scope', '$mdDialog', '$rootScope', '$mdToast', 'SessionService'];
	 var baseUrl = sessionStorage.getItem("WS_BASE_URL");
  function myCloudentix($mdEditDialog, $q, $scope, $timeout, $http,  $mdDialog, $mdMedia, $mdToast,$rootScope, $filter, SessionService) {
	   var userid = localStorage.getItem("userid");
	   var baseUrl = sessionStorage.getItem("WS_BASE_URL");
	 var checkResourceURL = baseUrl + '/resources?check=true';
			var config = {
				//url:"dashboard/data.json",
				url:checkResourceURL,
				method: "GET",
				headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
				}
			}
			   
			$http(config)
			.success(function(response) {
            if(response.type === 'success'){
				if (response.data.login[0].trusted == 'N' || response.data.login[0].untrusted == 'N') {
                    if (response.data.login[0].trusted == 'N' && response.data.login[0].untrusted == 'N') {
                       $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure trusted and untrusted resources");
                    } else {
                        if (response.data.login[0].trusted == 'N') {
                            $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure the trusted resource");
                        } else if (response.data.login[0].untrusted === 'N') {
                            $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure an untrusted resource");
                        }
                    }
                }
                else if(response.data.login[0].trusted == 'Y' && response.data.login[0].untrusted == 'Y') { 
  'use strict';
  $rootScope.loaderCurrentStatus = 'true';
  $scope.selected = [];
  $scope.limitOptions = [10, 25, 50, 100];
  
  $scope.options = {
    rowSelection: true,
    multiSelect: false,
    autoSelect: true,
    decapitate: false,
    largeEditDialog: true,
    boundaryLinks: true,
    limitSelect: true,
    pageSelect: true
  };
  
  $scope.query = {
    order: 'name',
    limit: 10,
    page: 1,
	filter: ''
  };
  $rootScope.loadRequestAccessAdmin = function () {
		//$scope.desserts = [];
		var requestAccessURL = baseUrl + '/requestaccess';
		var config = {
			url: requestAccessURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
				"cdt-userid":userid,
			}
		}
		   
		$http(config)
		.then(function success(response){ 
		$scope.userResponse = response.data.type;
		$rootScope.loaderCurrentStatus = 'false';
		$scope.attributesList = [];
		$scope.duplicateattributesList = [];
			if(response.data.type == "success"){
				angular.forEach(response.data.records[0].listaccessrequest, function(value, key) {
					$scope.attributesList.push({"resname" : value["resname"],"rolename" : value["rolename"],"reqstatus" : value["reqstatus"],"reqid" : value["reqid"],"remarks" : value["remarks"]});
				});
				$scope.duplicateattributesList = angular.copy($scope.attributesList);
			}else{
			$scope.userErrorMessage = response.data.message;
			}
			
		},function error(response){
            $rootScope.loaderCurrentStatus = 'false';
 $scope.errorHandler(response.config.url,response.status);
            });
  };
   $scope.$watch('query.filter', function (newValue, oldValue) {
			if(newValue == '') {
				$scope.attributesList = $scope.duplicateattributesList;
			}
			if(newValue){
				$scope.items = $filter('filter')($scope.duplicateattributesList, newValue);
				$scope.attributesList = $scope.items;
			}
		});
  $scope.showApprovalLevel = function($mdOpenMenu, ev, id) {
	  var requestAccessURL = baseUrl + '/requestaccess/remarks';
		var config = {
			url: requestAccessURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
				"cdt-reqid":id,
			}
		}
		   
		$http(config)
		.then(function success(response){ 
		$scope.approveLevelList = [];
			if(response.data.type == "success"){
				angular.forEach(response.data.records[0].getremarks, function(value, key) {
					$scope.approveLevelList.push({"approver" : value["approver"],"status" : value["status"],"remarks" : value["remarks"]});
				});
				$timeout(function() {
					$mdOpenMenu(ev);
				}, 1000);
			}
		},function error(response){
            $rootScope.loaderCurrentStatus = 'false';
 $scope.errorHandler(response.config.url,response.status);
            });

    };
  $scope.editComment = function (event, dessert) {
    event.stopPropagation(); // in case autoselect is enabled
    
    var editDialog = {
      modelValue: dessert.text,
      placeholder: 'Add a comment',
      save: function (input) {
        if(input.$modelValue === 'Donald Trump') {
          input.$invalid = true;
          return $q.reject();
        }
        if(input.$modelValue === 'Bernie Sanders') {
          return dessert.comment = 'FEEL THE BERN!'
        }
        dessert.text = input.$modelValue;
      },
      targetEvent: event,
      title: 'Add a comment',
      validators: {
        'md-maxlength': 30
      }
    };
    
    var promise;
    
    if($scope.options.largeEditDialog) {
      promise = $mdEditDialog.large(editDialog);
    } else {
      promise = $mdEditDialog.small(editDialog);
    }
    
    promise.then(function (ctrl) {
      var input = ctrl.getInput();
      
      input.$viewChangeListeners.push(function () {
        input.$setValidity('test', input.$modelValue !== 'test');
      });
    });
  };
  $scope.loadStuff = function () {
    $scope.promise = $timeout(function () {
      $rootScope.loadRequestAccessAdmin();
    }, 100);
  }
	$scope.requestAccess = function($event,$scope) {
		$mdDialog.show({
			controller: 'DialogCtrl',
			controllerAs: 'ctrl',
			templateUrl: 'myCloudentix/sub-myCloudentix/modal.html',
			parent: angular.element(document.body),
			targetEvent: $event,
			clickOutsideToClose:false
		})
	}	
	$rootScope.loadRequestAccessAdmin();
				}
                 }else {
    $rootScope.loaderCurrentStatus = 'false';
 $scope.errorHandler(response.message,response.status);
 
    }
			});
  }

  
  // modal
	function DialogCtrl ($timeout, $q, $http, $scope, $mdDialog, $rootScope, $mdToast, SessionService) {	
		var listResourcesURL = baseUrl + '/listresources';
		
		var config = {
			url:listResourcesURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
			}
		}
		    $scope.resourceList = [];
		$http(config)
		.then(function success(response){ 
			  //alert(response.records[0].rscDetails[0].rescName)
			angular.forEach(response.data.records[0].rscdetails, function(value, key) {
			//console.log(value["rescName"]);
				$scope.resourceList.push({"rescId" : value["rescid"],"rescName" : value["rescname"]});
			});
			},function error(response){
            $rootScope.loaderCurrentStatus = 'false';
            $scope.errorHandler(response.config.url,response.status);
            });

	 	
$scope.getroles = function(rscid) {
$scope.roleList = [];	
$scope.disable = true;
$scope.responseerrormessage = "";
 var userid = localStorage.getItem("userid");
$scope.resource_id = rscid;
var listRoleURL = baseUrl + '/requestaccess/roles'
var config = {
			url: listRoleURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
				"cdt-guid":userid,
				"cdt-rscid":rscid,
			}
		}
		   
		$http(config)
		.then(function success(response){ 
		$scope.Response = response.data.type;
		if(response.data.type == "error"){
			//alert(response.message);
			$scope.roleList = [];
            $scope.disable = true;
			$scope.responseerrormessage = response.data.message;
			}
			 if(response.data.type == "success"){
              //alert(response.records[0].availbleResourceRoles[0].lookupkey)
			angular.forEach(response.data.records[0].availbleresourceroles, function(value, key) {
			//console.log(value["rescName"]);
				$scope.roleList.push({"lookupkey" : value["lookupkey"],"lookupvalue" : value["lookupvalue"]});
			});
			}
			
			},function error(response){
            $rootScope.loaderCurrentStatus = 'false';
 $scope.errorHandler(response.config.url,response.status);
            });

//console.log(roleList);
	//$scope.resource_id = rscid;
	
  }
  $scope.roleSelect = function(){
   $scope.disable = false;
  }
var self = this;
		
	self.cancel = function($event) {
      $mdDialog.cancel();
	  //$scope.toastMessage('toast-success','fsfs');
    }
    self.finish = function($event) {
	$scope.isLoading = true;
	 var userid = localStorage.getItem("userid");
	//console.log($scope.resource_id);
	//console.log($scope.role.lookupkey);
	var requestURL = baseUrl + '/requestaccess';
      var config = {
			url: requestURL,
			method: "POST",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
				"cdt-userid":userid,
				"cdt-rscid":$scope.resource_id,
				"cdt-roleid":$scope.role.lookupkey,
			}
		}
		   
		$http(config)
		.then(function success(response){ 
			$scope.isLoading = false;
			var icon;
			if(response.data.type == 'success'){
				icon = 'done';
				$mdDialog.hide();
			}  else if(response.data.type == 'error'){
				icon = 'error_outline';
				$scope.responseerrormessage = response.data.message;
			} else if(response.data.type == 'warn'){
				icon = 'warning';
				$scope.responseerrormessage = response.data.message;
			} else{
				icon = 'info_outline';
			}
			$mdToast.show({
				template : '<md-toast class="md-toast toast-'+response.data.type+'"><div class="md-toast-content"><i class="material-icons">'+icon+'</i>&nbsp;&nbsp; '+ response.data.message + '!</div></md-toast>',
				hideDelay: 3000,
				position: 'top right'
			});
			$rootScope.loadRequestAccessAdmin();
        },function error(response){
            $rootScope.loaderCurrentStatus = 'false';
			$scope.errorHandler(response.config.url,response.status);
        }); 
    };	
}

	