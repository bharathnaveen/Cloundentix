// /*
/*
/*
/*
/*
/*
 * Cloudentix Core JavaScript Library v1.0
 * http://cloudentix.com/
 *
 * Copyright 2016, Sennovate, Inc.
 * Released under the MIT license
 * http://sennovate.com/license
 *
 * Author : Kannan
 * Last Updated On : 2016-08-04
 */
angular
    .module('cloudentixApp')
    /*
        view user begins:
        *we defined getuserInformation name of controller function
        *then injected needful directives in that controller function
    */
    .controller('getuserInformation', getuserinformation)
    getuserinformation.$inject = ['$rootScope', '$scope', '$log', '$location', '$window', '$http', '$mdDialog', '$mdMedia', '$mdToast', '$document', '$route', '$timeout', 'SessionService'];
    function getuserinformation($rootScope, $scope, $log, $location, $window, $http, $mdDialog, $mdMedia, $mdToast, $document, $route, $timeout, SessionService) {
        var baseUrl = sessionStorage.getItem("WS_BASE_URL");
        /* base Url for list resource */
        $scope.selectedTabs.selectedIndex = 0;
        //console.log($scope.selectedIndex);
        var checkResourceURL = baseUrl + '/resources?check=true';
		var config = {
			url: checkResourceURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
			}
		}
        $http(config)
		.success(function(response) {
            if(response.type == 'success') {
             /*  check two resources (trusted and untrusted)available in if not it is navigated to add resource */
                if (response.data.login[0].trusted == 'N' || response.data.login[0].untrusted == 'N') {
                    if (response.data.login[0].trusted == 'N' && response.data.login[0].untrusted == 'N') {
                           $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure trusted and untrusted resources");
                    } else {
                        if (response.data.login[0].trusted == 'N') {
                                $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure the trusted resource");
                        } else if (response.data.login[0].untrusted === 'N') {
                                $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure an untrusted resource");
                        }
                    }
                }
                /* if two resources (trusted and untrusted) is configured then proceeds*/
                else if(response.data.login[0].trusted == 'Y' && response.data.login[0].untrusted == 'Y') {
                    /* loader will be start */ 
                    $rootScope.loaderCurrentStatus = 'true';
                    var userGuid = localStorage.getItem('userGuid');
                    localStorage.setItem('putuserresource', '');
                    var viewUserUrl = baseUrl + '/users/viewuser';
                    $scope.loadData = function () {
                        var config = {
                            url: viewUserUrl,
                            method: "GET",
                            headers: {
                                "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                                "cdt-guid": userGuid
                            }
                        }
                        $http(config)
                        .success(function(response) {
                            var userkey, userorder;			
                            $scope.roles = [];
                            $rootScope.loaderCurrentStatus = 'false';
                            $scope.viewuserMessage = response.type;
                            /* it will retrieve all information of a user */
                            if(response.type == 'success') {
                                
                                $scope.viewuserInformation = [];
                                angular.forEach(response.records[0].truseteduserdetails[0].userinformation, function(value, key) {
                                    userorder = parseInt(value["colorder"]);
                                    userkey = value["colname"].replace(/_/g," ");
                                    $scope.viewuserInformation.push({'userkey': userkey,'uservalue': value["colvalue"], 'userorder': userorder}); 
                                });
                                for(var i=0;i<response.records[0].truseteduserdetails[0].userrole.length;i++) {
                                    if (response.records[0].truseteduserdetails[0].userrole[i] == undefined || response.records[0].truseteduserdetails[0].userrole[i] == '') {
                                        localStorage.setItem('viewrole', '');
                                    } else {
                                        $scope.roles.push(response.records[0].truseteduserdetails[0].userrole[i].rolename);
                                    }
                                }
                                localStorage.setItem('viewrole', $scope.roles);
                                if(response.records[0].untruseteduserdetails == undefined || response.records[0].untruseteduserdetails == '') {
                                    localStorage.setItem('putuserresource', '');
                                } else {
                                    localStorage.setItem('putuserresource', JSON.stringify(response.records[0].untruseteduserdetails));
                                } 
                            } else {
                                localStorage.setItem('viewrole', '');
                                localStorage.setItem('putuserresource', '');
                                $scope.viewusererrorMessage = response.message;
                            }
                        });
                    };
                    $scope.loadData();
                }
            } else {
                $rootScope.loaderCurrentStatus = 'false';
                $scope.errorHandler(response.message,response.status);
            }
		});
    };