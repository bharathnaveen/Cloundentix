angular
    .module('cloudentixApp')
  .controller('listusers', listusers)
  listusers.$inject = ['$rootScope', '$scope', '$log', '$location', '$window', '$http', '$mdDialog', '$mdMedia', '$mdToast', '$document', '$route', '$timeout', '$state', '$filter', 'SessionService'];
	 var baseUrl = sessionStorage.getItem("WS_BASE_URL");
  function listusers($rootScope, $scope, $log, $location, $window, $http, $mdDialog, $mdMedia, $mdToast, $document, $route, $timeout, $state, $filter, SessionService) {
  'use strict';
  $rootScope.loaderCurrentStatus = 'true';
  $scope.selected = [];
  $scope.limitOptions = [10, 25, 50, 100];
  
  $scope.options = {
    rowSelection: false,
    multiSelect: false,
    autoSelect: true,
    decapitate: false,
    largeEditDialog: true,
    boundaryLinks: true,
    limitSelect: true,
    pageSelect: true
  };
  
  $scope.query = {
    order: 'name',
    limit: 10,
    page: 1,
	filter: ''
  };
 $scope.loadData = function () {
	var listUser = baseUrl + '/users';
	var userid = localStorage.getItem("userid");
    var config = {
         url: listUser,
         method: "GET",
         headers: {
                 "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                 "cdt-loginguid": userid
         }
	}
		   
	$http(config)
	.then(function success(response) {
		$rootScope.loaderCurrentStatus = 'false';
		$scope.userResponse = response.data.type;
		if(response.data.type == 'success') {
			$scope.userList = [];
			$scope.duplicateUserList = [];
			angular.forEach(response.data.records[0].listusers, function(value, key) {
				$scope.userList.push({"guid" : value["guid"],"userName" : value["username"],"ntwuserid" : value["ntwuserid"],"emailid" : value["emailid"],"employeeId" : value["employeeid"],"managerName" : value["managername"],"statusFlag" : value["statusflag"]});
				//$scope.userList1.push({"guid" : value["guid"],"userName" : value["username"],"ntwuserid" : value["ntwuserid"],"emailid" : value["emailid"],"employeeId" : value["employeeid"],"managerName" : value["managername"],"statusFlag" : value["statusflag"]});
			});
			 $scope.duplicateUserList = angular.copy($scope.userList);
		}	
		else {
			$scope.userErrorMessage = response.data.message;
		}		
	},function error(response){
     $rootScope.loaderCurrentStatus = 'false';
 $scope.errorHandler(response.config.url,response.status);
    });
  };
  $scope.$watch('query.filter', function (newValue, oldValue) {
		if(newValue == '') {
			$scope.userList = $scope.duplicateUserList;
		}
		if(newValue){
			$scope.items = $filter('filter')($scope.duplicateUserList, newValue);
			$scope.userList = $scope.items;
		}
  });
  $scope.viewUser = function(usersId) {
	  localStorage.setItem('userGuid', usersId);
	  $state.go("viewuser.userbasicinformation");
	  $scope.addTab('View User','viewuser.userbasicinformation');
  }
  $scope.editComment = function (event, dessert) {
    event.stopPropagation(); // in case autoselect is enabled
    
    var editDialog = {
      modelValue: dessert.comment,
      placeholder: 'Add a comment',
      save: function (input) {
        if(input.$modelValue === 'Donald Trump') {
          input.$invalid = true;
          return $q.reject();
        }
        if(input.$modelValue === 'Bernie Sanders') {
          return dessert.comment = 'FEEL THE BERN!'
        }
        dessert.comment = input.$modelValue;
      },
      targetEvent: event,
      title: 'Add a comment',
      validators: {
        'md-maxlength': 30
      }
    };
    
    var promise;
    
    if($scope.options.largeEditDialog) {
      promise = $mdEditDialog.large(editDialog);
    } else {
      promise = $mdEditDialog.small(editDialog);
    }
    
    promise.then(function (ctrl) {
      var input = ctrl.getInput();
      
      input.$viewChangeListeners.push(function () {
        input.$setValidity('test', input.$modelValue !== 'test');
      });
    });
  };
  
  $scope.toggleLimitOptions = function () {
    $scope.limitOptions = $scope.limitOptions ? undefined : [10, 25, 50, 100];
  };
  
  $scope.getTypes = function () {
    return ['Candy', 'Ice cream', 'Other', 'Pastry'];
  };
  $scope.logItem = function (userList) {
    void 0;
  };
  
  $scope.logOrder = function (order) {
    void 0;
  };
  
  $scope.logPagination = function (page, limit) {
    void 0;
    void 0;
  }

	
  $scope.loadData();
};