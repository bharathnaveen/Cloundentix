/*
 * Cloudentix Gulp Build and Release Engineering Core File v0.1
 * http://cloudentix.com/
 *
 * Copyright 2017, Sennovate Inc (www.sennovate.com)
 * 
 * Released under the MIT license
 * https://opensource.org/licenses/MIT
 *
 * Authors : Bharath Kumar Mohan and Shaji Kalidasan
 * Last Updated On : 2017-09-23
 *
 */
 
const buildVersionNumber = 'v1.0.1';

const gulp = require('gulp');
const clean = require('gulp-clean');
const concat = require('gulp-concat');
const uglify = require('gulp-uglify');
const imagemin = require('gulp-imagemin');
const war = require('gulp-war');
const zip = require('gulp-zip');
const hashsum = require("gulp-hashsum");
const md5 = require("gulp-md5");
const sourcemaps = require('gulp-sourcemaps');

const obfuscatedWarFileName = 'cloudentix-obfuscated.war';

const cloudentix = {
        app: '',
		temp: 'temp',
        dist: 'dist',
		obfuscated: 'obfuscated'
};

const mainJs = {
    js : [cloudentix.app + 'app/cloudentix.core.js', cloudentix.app + 'app/cloudentix.ui.js', cloudentix.app + 'app/routeConfig.js', cloudentix.app + 'app/cdt.config.js', cloudentix.app + 'app/cloudentix.config.js']
};

const coreAssets = {
	images : [cloudentix.app + 'assets/images/*'],
	fonts : [cloudentix.app + 'assets/fonts/*'],
	lib : [cloudentix.app + 'assets/lib/*'],
	css : [cloudentix.app + 'assets/css/*']	
};

const adminAssets = {
	images : [cloudentix.app + 'admin/assets/images/*'],
	fonts : [cloudentix.app + 'admin/assets/fonts/*'],
	lib : [cloudentix.app + 'admin/assets/lib/*'],
	css : [cloudentix.app + 'admin/assets/css/*'],
	cssFonts : [cloudentix.app + 'admin/assets/css/fonts/*']	
};

const managerAssets = {
	images : [cloudentix.app + 'manager/assets/images/*'],
	fonts : [cloudentix.app + 'manager/assets/fonts/*'],
	lib : [cloudentix.app + 'manager/assets/lib/*'],
	css : [cloudentix.app + 'manager/assets/css/*']	
};

const userAssets = {
	images : [cloudentix.app + 'users/assets/images/*'],
	fonts : [cloudentix.app + 'users/assets/fonts/*'],
	lib : [cloudentix.app + 'users/assets/lib/*'],
	css : [cloudentix.app + 'users/assets/css/*']		
};

const mainHtml = {
	html : [cloudentix.app + '*.html']
};

const adminHtml = {
        adminhtml : [cloudentix.app + 'admin/*.html'],
        dashboard : [cloudentix.app + 'admin/dashboard/*.html'],
        attestation : [cloudentix.app + 'admin/attestation/*.html'],
        attestationself : [cloudentix.app + 'admin/attestation/sub-selfattestation/*.html'],
        attestationpending : [cloudentix.app + 'admin/attestation/sub-pendingattestation/*.html'],
        attestationhistory : [cloudentix.app + 'admin/attestation/sub-historyattestation/*.html'],
        rolemanager: [cloudentix.app + 'admin/attestation/roleManager/*.html'],
        // rejectedroles: [cloudentix.app + 'admin/attestation/roleManager/*.html'],
        job : [cloudentix.app + 'admin/job/*.html'],
        manageSystem : [cloudentix.app + 'admin/manageSystem/*.html'],
		manageSystemUserProvision : [cloudentix.app + 'admin/manageSystem/User_Provision/*.html'],
        myCloudentix : [cloudentix.app + 'admin/myCloudentix/*.html'],
        myCloudentixsub : [cloudentix.app + 'admin/myCloudentix/sub-myCloudentix/*.html'],
        reports : [cloudentix.app + 'admin/reports/*.html'],
        resouceConfigure : [cloudentix.app + 'admin/resouceConfigure/*.html'],
        resources : [cloudentix.app + 'admin/resources/*.html'],
        resourcesadd : [cloudentix.app + 'admin/resources/addResource/*.html'],
        resourcesAD : [cloudentix.app + 'admin/resources/addResource/activedirectoryResource/*.html'],
        resourcesMssql : [cloudentix.app + 'admin/resources/addResource/mssql/*.html'],
        resourcesMySql : [cloudentix.app + 'admin/resources/addResource/mysql/*.html'],
        resources365 : [cloudentix.app + 'admin/resources/addResource/office365Resource/*.html'],
        resourcesOracle : [cloudentix.app + 'admin/resources/addResource/oracle/*.html'],
        resourcesview : [cloudentix.app + 'admin/resources/viewResource/*.html'],
        resourcesviewPrepopulate : [cloudentix.app + 'admin/resources/viewResource/prepopulate/*.html'],
        role : [cloudentix.app + 'admin/role/*.html'],
        rolesub : [cloudentix.app + 'admin/role/sub-role/*.html'],
        users : [cloudentix.app + 'admin/users/*.html'],
        support: [cloudentix.app + 'admin/support/*.html'],
        ticketstatus: [cloudentix.app + 'admin/support/cloudentix-admin-ticketstatus.html'],
        addataextractiontool: [cloudentix.app + 'admin/securityGovernor/dataMaintenance/ADDataExtractionTool/cloudentix-admin-sg-dm-addataextractiontool.html'],
        sgdashboard: [cloudentix.app + 'admin/securityGovernor/dataMaintenance/dashboard/cloudentix-admin-sg-dm-dashboard.html'],
        duplicateEmployeeId: [cloudentix.app + 'admin/securityGovernor/report/accountReport/acc-duplicateEmployeeId/cloudentix-admin-sg-acc-duplicateemployeeid.html'],
        duplicatemailPopup: [cloudentix.app + 'admin/securityGovernor/report/accountReport/acc-duplicateEmployeeId/cloudentix-duplicateemail-modal-popup.html'],
        expiration: [cloudentix.app + 'admin/securityGovernor/report/accountReport/acc-expiration/cloudentix-admin-sg-acc-expiration.html'],
        expirationmailPopup: [cloudentix.app + 'admin/securityGovernor/report/accountReport/acc-expiration/cloudentix-expirationemail-modal-popup.html'],
        expirationReport: [cloudentix.app + 'admin/securityGovernor/report/accountReport/acc-expirationReport/cloudentix-admin-sg-acc-expirationreport.html'],
        expirationReportPopup: [cloudentix.app + 'admin/securityGovernor/report/accountReport/acc-expirationReport/cloudentix-admin-sg-acc-expiration-modalPopup.html'],
        expirationReportMailPopup: [cloudentix.app + 'admin/securityGovernor/report/accountReport/acc-expirationReport/cloudentix-expriationreportemail-modal-popup.html'],
        mapping: [cloudentix.app + 'admin/securityGovernor/report/accountReport/acc-mapping/cloudentix-admin-sg-acc-mapping.html'],
        mappingSearch: [cloudentix.app + 'admin/securityGovernor/report/accountReport/acc-mapping/cdt-admin-sg-acc-mappingsearch.html'],
        mappingMailPopup: [cloudentix.app + 'admin/securityGovernor/report/accountReport/acc-mapping/cloudentix-mappingemail-modal-popup.html'],
        mappingsub1: [cloudentix.app + 'admin/securityGovernor/report/accountReport/acc-mapping/cdt-admin-sg-acc-mappingsub1.html'],
        mappingsub2: [cloudentix.app + 'admin/securityGovernor/report/accountReport/acc-mapping/cdt-admin-sg-acc-mappingsub2.html'],
        mappingsub3: [cloudentix.app + 'admin/securityGovernor/report/accountReport/acc-mapping/cdt-admin-sg-acc-mappingsub3.html'],
        mappingsub4: [cloudentix.app + 'admin/securityGovernor/report/accountReport/acc-mapping/cdt-admin-sg-acc-mappingsub4.html'],
        mappingsub5: [cloudentix.app + 'admin/securityGovernor/report/accountReport/acc-mapping/cdt-admin-sg-acc-mappingsub5.html'],
        mappingsub6: [cloudentix.app + 'admin/securityGovernor/report/accountReport/acc-mapping/cdt-admin-sg-acc-mappingsub6.html'],
        mappingsub7: [cloudentix.app + 'admin/securityGovernor/report/accountReport/acc-mapping/cdt-admin-sg-acc-mappingsub7.html'],
        mappingsub8: [cloudentix.app + 'admin/securityGovernor/report/accountReport/acc-mapping/cdt-admin-sg-acc-mappingsub8.html'],
        mappingsub9: [cloudentix.app + 'admin/securityGovernor/report/accountReport/acc-mapping/cdt-admin-sg-acc-mappingsub9.html'],
        multipleEmployeeIds: [cloudentix.app + 'admin/securityGovernor/report/accountReport/acc-multipleEmployeeIds/cloudentix-admin-sg-acc-multipleemployeeids.html'],
        multipleMailPopup: [cloudentix.app + 'admin/securityGovernor/report/accountReport/acc-multipleEmployeeIds/cloudentix-multipleemail-modal-popup.html'],
        passwordNotification: [cloudentix.app + 'admin/securityGovernor/report/accountReport/acc-passwordNotification/cloudentix-admin-sg-acc-passwordnotification.html'],
        passwordNotificationPopup: [cloudentix.app + 'admin/securityGovernor/report/accountReport/acc-passwordNotification/cloudentix-admin-passwordNotification-popup.html'],
        passwordNotificationMailPopup: [cloudentix.app + 'admin/securityGovernor/report/accountReport/acc-passwordNotification/cloudentix-passwordemail-modal-popup.html'],
        attestationreview: [cloudentix.app + 'admin/securityGovernor/report/AttestationReview/cloudentix-admin-sg-attestationreview.html'],
        attestationmailPopup: [cloudentix.app + 'admin/securityGovernor/report/AttestationReview/cloudentix-attestationemail-modal-popup.html'],
        sgschedule: [cloudentix.app + 'admin/securityGovernor/report/AttestationReview/cloudentix-admin-sg-schedule.html'],
        DAactive: [cloudentix.app + 'admin/securityGovernor/report/domainAdminReport/DAActive/cloudentix-admin-sg-DAactive.html'],
        DAactiveMailPopup: [cloudentix.app + 'admin/securityGovernor/report/domainAdminReport/DAActive/cloudentix-activeemail-modal-popup.html'],
        DAInactive: [cloudentix.app + 'admin/securityGovernor/report/domainAdminReport/DAInactive/cloudentix-admin-sg-DAInactive.html'],
        DAInactiveMailPopup: [cloudentix.app + 'admin/securityGovernor/report/domainAdminReport/DAInactive/cloudentix-inactiveemail-modal-popup.html'],
        ADGroupForJob: [cloudentix.app + 'admin/securityGovernor/report/roleMining/ADGroupForJob/cloudentix-admin-sg-ad-job.html'],
        ADGroupForJobMailPopup: [cloudentix.app + 'admin/securityGovernor/report/roleMining/ADGroupForJob/cloudentix-ademail-modal-popup.html'],
        BUStaffForJob: [cloudentix.app + 'admin/securityGovernor/report/roleMining/BUStaffForJob/cloudentix-admin-sg-bu-job.html'],
        BUStaffForJobMailPopup: [cloudentix.app + 'admin/securityGovernor/report/roleMining/BUStaffForJob/cloudentix-buemail-modal-popup.html'],
        CVueGroupForJob: [cloudentix.app + 'admin/securityGovernor/report/roleMining/CVueGroupForJob/cloudentix-admin-sg-cv-job.html'],
        CVueGroupForJobMailPopup: [cloudentix.app + 'admin/securityGovernor/report/roleMining/CVueGroupForJob/cloudentix-cvueemail-modal-popup.html'],
        jobtitlead: [cloudentix.app + 'admin/securityGovernor/report/roleMining/JobTitleForADGroup/cloudentix-admin-sg-jobtitlead.html'],
        jobtitlesadtafflist: [cloudentix.app + 'admin/securityGovernor/report/roleMining/JobTitleForADGroup/cloudentix-admin-sg-jobtitleadstafflist.html'],
        jobtitleadMailPopup: [cloudentix.app + 'admin/securityGovernor/report/roleMining/JobTitleForADGroup/cloudentix-jobademail-modal-popup.html'],
        jobtitlecvue: [cloudentix.app + 'admin/securityGovernor/report/roleMining/JobTitleForCVueGroup/cloudentix-admin-sg-jobtitlecvue.html'],
        jobtitlecvuestafflist: [cloudentix.app + 'admin/securityGovernor/report/roleMining/JobTitleForCVueGroup/cloudentix-admin-sg-jobtitlecvuestafflist.html'],
        jobtitlecvueMailPopup: [cloudentix.app + 'admin/securityGovernor/report/roleMining/JobTitleForCVueGroup/cloudentix-jobcvueemail-modal-popup.html']
};

const managerHtml = {	
		managerhtml : [cloudentix.app + 'manager/*.html'],
        dashboard : [cloudentix.app + 'manager/dashboard/*.html'],
        attestation : [cloudentix.app + 'manager/attestation/*.html'],
        attestationself : [cloudentix.app + 'manager/attestation/sub-selfattestation/*.html'],
        attestationpending : [cloudentix.app + 'manager/attestation/sub-pendingattestation/*.html'],
        attestationhistory : [cloudentix.app + 'manager/attestation/sub-historyattestation/*.html'],
		myCloudentix : [cloudentix.app + 'manager/myCloudentix/*.html'],
        myCloudentixsub : [cloudentix.app + 'manager/myCloudentix/sub-myCloudentix/*.html'],
		users : [cloudentix.app + 'manager/users/*.html'],
		support: [cloudentix.app + 'manager/support/*.html']
};

const userHtml = {	
		userhtml : [cloudentix.app + 'users/*.html'],
        dashboard : [cloudentix.app + 'users/dashboard/*.html'],
		myCloudentix : [cloudentix.app + 'users/myCloudentix/*.html'],
        myCloudentixsub : [cloudentix.app + 'users/myCloudentix/sub-myCloudentix/*.html'],
		users : [cloudentix.app + 'users/users/*.html'],
		support: [cloudentix.app + 'users/support/*.html']
};

//Clean the directory before creating a new build
gulp.task('clean', () => {    
   console.log("Cleaning " + cloudentix.temp); 
   gulp.src(cloudentix.temp + '/', {read: false})
      .pipe(clean()); 
	  
   console.log("Cleaning " + cloudentix.dist); 
   gulp.src(cloudentix.dist + '/', {read: false})
      .pipe(clean());
});

//Copy main Js
gulp.task('copy.main.js',function(){
	
    //Copy main Js
	console.log("Copying main Js : Js files");
	gulp.src(mainJs.js)
    .pipe(gulp.dest(cloudentix.temp + '/app/'));
	
});

   
//Copy core assets
gulp.task('copy.core.assets',function(){
	
    //Copy library files
	console.log("Copying core assets : library files");
	gulp.src(coreAssets.lib)
    .pipe(gulp.dest(cloudentix.temp + '/assets/lib/'));
	
    //Copy font files
	console.log("Copying core assets : fonts");
	gulp.src(coreAssets.fonts)
    .pipe(gulp.dest(cloudentix.temp + '/assets/fonts/'));
	
    //Copy css files
	console.log("Copying core assets : css files");
	gulp.src(coreAssets.css)
    .pipe(gulp.dest(cloudentix.temp + '/assets/css/'));
	
    //Copy image files
	console.log("Copying core assets : images");
	gulp.src(coreAssets.images)
	.pipe(imagemin({
		progressive: true,
		}))
    .pipe(gulp.dest(cloudentix.temp + '/assets/images/'));
	
});   

//Copy admin assets
gulp.task('copy.admin.assets',function(){
	
	//Copy library files
	console.log("Copying admin assets : library files");
	gulp.src(adminAssets.lib)
    .pipe(gulp.dest(cloudentix.temp + '/admin/assets/lib/'));
	
    //Copy font files
	console.log("Copying admin assets : fonts");
	gulp.src(adminAssets.fonts)
    .pipe(gulp.dest(cloudentix.temp + '/admin/assets/fonts/'));
	
    //Copy css files
	console.log("Copying admin assets : css files");
	gulp.src(adminAssets.css)
    .pipe(gulp.dest(cloudentix.temp + '/admin/assets/css/'));
	
	//Copy css font files
	console.log("Copying admin assets : css font files");
	gulp.src(adminAssets.cssFonts)
    .pipe(gulp.dest(cloudentix.temp + '/admin/assets/css/fonts/'));
	
	//Copy image files
	console.log("Copying admin assets : images");
	gulp.src(adminAssets.images)
	.pipe(imagemin({
		progressive: true,
		}))
    .pipe(gulp.dest(cloudentix.temp + '/admin/assets/images/'));

});

//Copy manager assets
gulp.task('copy.manager.assets',function(){
	
    //Copy library files
	console.log("Copying manager assets : library files");
	gulp.src(managerAssets.lib)
    .pipe(gulp.dest(cloudentix.temp + '/manager/assets/lib/'));
	
    //Copy font files
	console.log("Copying manager assets : fonts");
	gulp.src(managerAssets.fonts)
    .pipe(gulp.dest(cloudentix.temp + '/manager/assets/fonts/'));
	
    //Copy css files
	console.log("Copying manager assets : css files");
	gulp.src(managerAssets.css)
    .pipe(gulp.dest(cloudentix.temp + '/manager/assets/css/'));
	
    //Copy image files
	console.log("Copying manager assets : images");
	gulp.src(managerAssets.images)
	.pipe(imagemin({
		progressive: true,
		}))
    .pipe(gulp.dest(cloudentix.temp + '/manager/assets/images/'));

});   

//Copy user assets
gulp.task('copy.user.assets',function(){
	
    //Copy library files
	console.log("Copying user assets : library files");
	gulp.src(userAssets.lib)
    .pipe(gulp.dest(cloudentix.temp + '/users/assets/lib/'));
	
    //Copy font files
	console.log("Copying user assets : fonts");
	gulp.src(userAssets.fonts)
    .pipe(gulp.dest(cloudentix.temp + '/users/assets/fonts/'));
	
    //Copy css files
	console.log("Copying user assets : css files");
	gulp.src(userAssets.css)
    .pipe(gulp.dest(cloudentix.temp + '/users/assets/css/'));
	
    //Copy image files
	console.log("Copying user assets : images");
	gulp.src(userAssets.images)
	.pipe(imagemin({
		progressive: true,
		}))
    .pipe(gulp.dest(cloudentix.temp + '/users/assets/images/'));

});   

//Copy main html files
gulp.task('copy.main.html', function(){
	console.log("Copying main html files");
	gulp.src(mainHtml.html)
    .pipe(gulp.dest(cloudentix.temp + '/'))
});

//Copy admin html files
gulp.task('copy.admin.html', function(){
	console.log("Copying admin html files");
	gulp.src(adminHtml.adminhtml)
    .pipe(gulp.dest(cloudentix.temp + '/admin/'));
	
	gulp.src(adminHtml.dashboard)
    .pipe(gulp.dest(cloudentix.temp + '/admin/dashboard/'));
	
	gulp.src(adminHtml.attestation)
    .pipe(gulp.dest(cloudentix.temp + '/admin/attestation/'));
	
	gulp.src(adminHtml.attestationself)
    .pipe(gulp.dest(cloudentix.temp + '/admin/attestation/sub-selfattestation/'));
	
	gulp.src(adminHtml.attestationpending)
    .pipe(gulp.dest(cloudentix.temp + '/admin/attestation/sub-pendingattestation/'));
	
	gulp.src(adminHtml.attestationhistory)
    .pipe(gulp.dest(cloudentix.temp + '/admin/attestation/sub-historyattestation/'));

    gulp.src(adminHtml.rolemanager)
    .pipe(gulp.dest(cloudentix.temp + '/admin/attestation/roleManager/'));

    // gulp.src(adminHtml.rejectedroles)
    // .pipe(gulp.dest(cloudentix.temp + '/admin/attestation/roleManager/'));
	
	gulp.src(adminHtml.job)
    .pipe(gulp.dest(cloudentix.temp + '/admin/job/'));
	
	gulp.src(adminHtml.manageSystem)
    .pipe(gulp.dest(cloudentix.temp + '/admin/manageSystem/'));
	
	gulp.src(adminHtml.manageSystemUserProvision)
    .pipe(gulp.dest(cloudentix.temp + '/admin/manageSystem/User_Provision/'));
	
	gulp.src(adminHtml.myCloudentix)
    .pipe(gulp.dest(cloudentix.temp + '/admin/myCloudentix/'));
	
	gulp.src(adminHtml.myCloudentixsub)
    .pipe(gulp.dest(cloudentix.temp + '/admin/myCloudentix/sub-myCloudentix/'));
		
	gulp.src(adminHtml.reports)
    .pipe(gulp.dest(cloudentix.temp + '/admin/reports/'));
	
	gulp.src(adminHtml.resouceConfigure)
    .pipe(gulp.dest(cloudentix.temp + '/admin/resouceConfigure/'));
	
	gulp.src(adminHtml.resources)
    .pipe(gulp.dest(cloudentix.temp + '/admin/resources/'));
	
	gulp.src(adminHtml.resourcesadd)
    .pipe(gulp.dest(cloudentix.temp + '/admin/resources/addResource/'));
	
	gulp.src(adminHtml.resourcesAD)
    .pipe(gulp.dest(cloudentix.temp + '/admin/resources/addResource/activedirectoryResource/'));
	
	gulp.src(adminHtml.resourcesMssql)
    .pipe(gulp.dest(cloudentix.temp + '/admin/resources/addResource/mssql/'));
	
	gulp.src(adminHtml.resourcesMySql)
    .pipe(gulp.dest(cloudentix.temp + '/admin/resources/addResource/mysql/'));
	
	gulp.src(adminHtml.resources365)
    .pipe(gulp.dest(cloudentix.temp + '/admin/resources/addResource/office365Resource/'));
	
	gulp.src(adminHtml.resourcesOracle)
    .pipe(gulp.dest(cloudentix.temp + '/admin/resources/addResource/oracle/'));
	
	gulp.src(adminHtml.resourcesview)
    .pipe(gulp.dest(cloudentix.temp + '/admin/resources/viewResource/'));
	
	gulp.src(adminHtml.resourcesviewPrepopulate)
    .pipe(gulp.dest(cloudentix.temp + '/admin/resources/viewResource/prepopulate/'));
	
	gulp.src(adminHtml.role)
    .pipe(gulp.dest(cloudentix.temp + '/admin/role/'));
	
	gulp.src(adminHtml.rolesub)
    .pipe(gulp.dest(cloudentix.temp + '/admin/role/sub-role/'));
	
	gulp.src(adminHtml.users)
    .pipe(gulp.dest(cloudentix.temp + '/admin/users/'));
	
	gulp.src(adminHtml.support)
    .pipe(gulp.dest(cloudentix.temp + '/admin/support/'));

    gulp.src(adminHtml.ticketstatus)
    .pipe(gulp.dest(cloudentix.temp + '/admin/support/'));

    gulp.src(adminHtml.addataextractiontool)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/dataMaintenance/ADDataExtractionTool/'));

    gulp.src(adminHtml.sgdashboard)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/dataMaintenance/dashboard/'));

    gulp.src(adminHtml.duplicateEmployeeId)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/accountReport/acc-duplicateEmployeeId/'));
    
    gulp.src(adminHtml.duplicatemailPopup)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/accountReport/acc-duplicateEmployeeId/'));
    
    gulp.src(adminHtml.expiration)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/accountReport/acc-expiration/'));

    gulp.src(adminHtml.expirationmailPopup)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/accountReport/acc-expiration/'));
    
    gulp.src(adminHtml.expirationReport)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/accountReport/acc-expirationReport/'));

    gulp.src(adminHtml.expirationReportPopup)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/accountReport/acc-expirationReport/'));
    
    gulp.src(adminHtml.expirationReportMailPopup)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/accountReport/acc-expirationReport/'));
    
    gulp.src(adminHtml.mapping)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/accountReport/acc-mapping/'));

    gulp.src(adminHtml.mappingSearch)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/accountReport/acc-mapping/'));

    gulp.src(adminHtml.mappingMailPopup)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/accountReport/acc-mapping/'));
    
    gulp.src(adminHtml.mappingsub1)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/accountReport/acc-mapping/'));

    gulp.src(adminHtml.mappingsub2)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/accountReport/acc-mapping/'));

    gulp.src(adminHtml.mappingsub3)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/accountReport/acc-mapping/'));

    gulp.src(adminHtml.mappingsub4)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/accountReport/acc-mapping/'));

    gulp.src(adminHtml.mappingsub5)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/accountReport/acc-mapping/'));

    gulp.src(adminHtml.mappingsub6)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/accountReport/acc-mapping/'));

    gulp.src(adminHtml.mappingsub7)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/accountReport/acc-mapping/'));

    gulp.src(adminHtml.mappingsub8)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/accountReport/acc-mapping/'));

    gulp.src(adminHtml.mappingsub9)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/accountReport/acc-mapping/'));

    gulp.src(adminHtml.multipleEmployeeIds)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/accountReport/acc-multipleEmployeeIds/'));

    gulp.src(adminHtml.multipleMailPopup)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/accountReport/acc-multipleEmployeeIds/'));

    gulp.src(adminHtml.passwordNotification)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/accountReport/acc-passwordNotification/'));

    gulp.src(adminHtml.passwordNotificationPopup)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/accountReport/acc-passwordNotification/'));

    gulp.src(adminHtml.passwordNotificationMailPopup)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/accountReport/acc-passwordNotification/'));
    
    gulp.src(adminHtml.attestationreview)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/AttestationReview/'));

    gulp.src(adminHtml.attestationmailPopup)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/AttestationReview/'));

    gulp.src(adminHtml.sgschedule)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/AttestationReview/'));

    gulp.src(adminHtml.DAactive)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/domainAdminReport/DAActive/'));

    gulp.src(adminHtml.DAactiveMailPopup)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/domainAdminReport/DAActive/'));

    gulp.src(adminHtml.DAInactive)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/domainAdminReport/DAInactive/'));

    gulp.src(adminHtml.DAInactiveMailPopup)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/domainAdminReport/DAInactive/'));
    
    gulp.src(adminHtml.ADGroupForJob)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/roleMining/ADGroupForJob/'));

    gulp.src(adminHtml.ADGroupForJobMailPopup)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/roleMining/ADGroupForJob/'));
    
    gulp.src(adminHtml.BUStaffForJob)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/roleMining/BUStaffForJob/'));

    gulp.src(adminHtml.BUStaffForJobMailPopup)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/roleMining/BUStaffForJob/'));
    
    gulp.src(adminHtml.CVueGroupForJob)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/roleMining/CVueGroupForJob/'));

    gulp.src(adminHtml.CVueGroupForJobMailPopup)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/roleMining/CVueGroupForJob/'));
    
    gulp.src(adminHtml.jobtitlead)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/roleMining/JobTitleForADGroup/'));

    gulp.src(adminHtml.jobtitleadMailPopup)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/roleMining/JobTitleForADGroup/'));
    
    gulp.src(adminHtml.jobtitlesadtafflist)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/roleMining/JobTitleForADGroup/'));

    gulp.src(adminHtml.jobtitlecvue)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/roleMining/JobTitleForCVueGroup/'));

    gulp.src(adminHtml.jobtitlecvueMailPopup)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/roleMining/JobTitleForCVueGroup/'));
    
    gulp.src(adminHtml.jobtitlecvuestafflist)
    .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/roleMining/JobTitleForCVueGroup/'));
});

//Copy manager html files
gulp.task('copy.manager.html', function(){
	console.log("Copying manager html files");
	gulp.src(managerHtml.managerhtml)
    .pipe(gulp.dest(cloudentix.temp + '/manager/'));
	
	gulp.src(managerHtml.dashboard)
    .pipe(gulp.dest(cloudentix.temp + '/manager/dashboard/'));
	
	gulp.src(managerHtml.attestation)
    .pipe(gulp.dest(cloudentix.temp + '/manager/attestation/'));
	
	gulp.src(managerHtml.attestationself)
    .pipe(gulp.dest(cloudentix.temp + '/manager/attestation/sub-selfattestation/'));
	
	gulp.src(managerHtml.attestationpending)
    .pipe(gulp.dest(cloudentix.temp + '/manager/attestation/sub-pendingattestation/'));
	
	gulp.src(managerHtml.attestationhistory)
    .pipe(gulp.dest(cloudentix.temp + '/manager/attestation/sub-historyattestation/'));
	
	gulp.src(managerHtml.myCloudentix)
    .pipe(gulp.dest(cloudentix.temp + '/manager/myCloudentix/'));
	
	gulp.src(managerHtml.myCloudentixsub)
    .pipe(gulp.dest(cloudentix.temp + '/manager/myCloudentix/sub-myCloudentix/'));
	
	gulp.src(managerHtml.users)
    .pipe(gulp.dest(cloudentix.temp + '/manager/users/'));
	
	gulp.src(managerHtml.support)
    .pipe(gulp.dest(cloudentix.temp + '/manager/support/'));

});

//Copy user html files
gulp.task('copy.user.html', function(){
	console.log("Copying user html files");
	gulp.src(userHtml.userhtml)
    .pipe(gulp.dest(cloudentix.temp + '/users/'));
	
	gulp.src(userHtml.dashboard)
    .pipe(gulp.dest(cloudentix.temp + '/users/dashboard/'));
	
	gulp.src(userHtml.myCloudentix)
    .pipe(gulp.dest(cloudentix.temp + '/users/myCloudentix/'));
	
	gulp.src(userHtml.myCloudentixsub)
    .pipe(gulp.dest(cloudentix.temp + '/users/myCloudentix/sub-myCloudentix/'));    
	
	gulp.src(userHtml.users)
    .pipe(gulp.dest(cloudentix.temp + '/users/users/'));
	
	gulp.src(userHtml.support)
    .pipe(gulp.dest(cloudentix.temp + '/users/support/'));

});

// Role : Admin (Module : Attestation)
gulp.task('admin.attestation', () => {
	console.log("Concatenating admin attestation controllers");
    return gulp
        .src([
            cloudentix.app + 'admin/attestation/cloudentix.admin.attestation.attestationHistory.controller.js',
            cloudentix.app + 'admin/attestation/cloudentix.admin.attestation.attestationPendingWithMe.controller.js',
            cloudentix.app + 'admin/attestation/cloudentix.admin.attestation.controller.js',
            cloudentix.app + 'admin/attestation/cloudentix.admin.attestation.listOfAttestationPending.controller.js',
            cloudentix.app + 'admin/attestation/cloudentix-admin-sg-rolemanagerController.js'

        ])
        .pipe(sourcemaps.init())
        .pipe(concat('admin.attestation.controllers.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/admin/attestation'));
});

//Role : Admin (Module : Dashboard)
gulp.task('admin.dashboard', () => {
	console.log("Concatenating admin dashboard controllers");
    return gulp
        .src([
            cloudentix.app + 'admin/dashboard/cloudentix.admin.dashboard.controller-bleberry.js',
            cloudentix.app + 'admin/dashboard/cloudentix.admin.dashboard.controller.js'
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('admin.dashboard.controllers.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/admin/dashboard'));
});

//Role : Admin (Module : Job)
gulp.task('admin.job', () => {
	console.log("Concatenating admin job controllers");
    return gulp
        .src([
            cloudentix.app + 'admin/job/cloudentix.admin.job.controller.js',
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('admin.job.controllers.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/admin/job'));
});

//Role : Admin (Module : My Cloudentix)
gulp.task('admin.myCloudentix', () => {
	console.log("Concatenating admin my cloudentix controllers");
    return gulp
        .src([
            cloudentix.app + 'admin/myCloudentix/cloudentix.admin.myCloudentix.accessRequestsPendingApproval.controller.js',
            cloudentix.app + 'admin/myCloudentix/cloudentix.admin.myCloudentix.controller.js',
            cloudentix.app + 'admin/myCloudentix/cloudentix.admin.attestation.controller.js',
            cloudentix.app + 'admin/myCloudentix/cloudentix.admin.myCloudentix.listOfAccessRequests.controller.js'
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('admin.myCloudentix.controllers.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/admin/myCloudentix'));
});

//Role : Admin (Module : Reports)
gulp.task('admin.reports', () => {
	console.log("Concatenating admin reports controllers");
    return gulp
        .src([
            cloudentix.app + 'admin/reports/cloudentix.admin.reports.accessPolicyViolationReports.controller.js',
            cloudentix.app + 'admin/reports/cloudentix.admin.reports.controller.js',
            cloudentix.app + 'admin/reports/cloudentix.admin.reports.userCloudentixReports.controller.js',
            cloudentix.app + 'admin/reports/cloudentix.admin.reports.userTargetReports.controller.js'
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('admin.reports.controllers.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/admin/reports'));
});

//Role : Admin (Module : Role)
gulp.task('admin.role', () => {
	console.log("Concatenating admin role controllers");
    return gulp
        .src([
            cloudentix.app + 'admin/role/cloudentix.admin.role.accessPolicy.controller.js',
            cloudentix.app + 'admin/role/cloudentix.admin.role.approvalPolicy.controller.js',
            cloudentix.app + 'admin/role/cloudentix.admin.role.controller.js',
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('admin.role.controllers.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/admin/role'));
});

//Role : Admin (Module : Users)
gulp.task('admin.users', () => {
	console.log("Concatenating admin users controllers");
    return gulp
        .src([
            cloudentix.app + 'admin/users/cloudentix-admin-selectedResource.js',
            cloudentix.app + 'admin/users/cloudentix-admin-userResource.js',
            cloudentix.app + 'admin/users/cloudentix-admin-userRole.js',
            cloudentix.app + 'admin/users/cloudentix.admin.userInformation.js',
            cloudentix.app + 'admin/users/cloudentix.admin.users.controller.js'
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('admin.users.controllers.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/admin/users'));
});

//Role : Admin (Module : Manage System)
gulp.task('admin.manageSystem', () => {
	console.log("Concatenating admin manage system controllers");
    return gulp
        .src([
            cloudentix.app + 'admin/manageSystem/cloudentix.admin.manageSystem.controller.js',
            cloudentix.app + 'admin/manageSystem/cloudentix.admin.manageSystem.setFrequency.controller.js',
            cloudentix.app + 'admin/manageSystem/User_Provision/cloudentix-admin-userNotProvision.js',
            cloudentix.app + 'admin/manageSystem/User_Provision/cloudentix-admin-userProvision.js'
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('admin.manageSystem.controllers.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/admin/manageSystem'));
});

//Role : Admin (Module : Resources)
gulp.task('admin.resources', () => {
	console.log("Concatenating admin gulp controllers");
    return gulp
        .src([
            cloudentix.app + 'admin/resources/viewResource/cloudentix.admin.viewResourcesNew.controller.js',
            cloudentix.app + 'admin/resources/viewResource/prepopulate/cloudentix.admin.viewResourcesPrepopulate.js',
            cloudentix.app + 'admin/resources/cloudentix.admin.listResources.controller.js'
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('admin.resources.controllers.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/admin/resources'));
});

//Support : Admin (Module : Support)
gulp.task('admin.support', () => {
	console.log("Concatenating admin gulp controllers");
    return gulp
        .src([
            cloudentix.app + 'admin/support/cloudentix.admin.support.controller.js',
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('admin.support.controllers.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/admin/support'));
});

// Security Governor : Admin (Module : ADDataExtractionTool)
gulp.task('admin.addataextractiontool', () => {
    console.log("Concatenating admin addataextractiontool");
    return gulp
        .src([
            cloudentix.app + 'admin/securityGovernor/dataMaintenance/ADDataExtractionTool/cloudentix-admin-sg-dm-addataextractiontoolController.js'
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('admin.sg.addataextractiontool.controller.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/dataMaintenance/ADDataExtractionTool'))
});

// Security Governor : Admin (Module : dashboard)
gulp.task('admin.sgdashboard', () => {
    console.log("Concatenating admin dashboard ");
    return gulp
        .src([
            cloudentix.app + 'admin/securityGovernor/dataMaintenance/dashboard/cloudentix-admin-sg-dm-dashboardController.js'
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('admin.sg.dashboard.controller.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/dataMaintenance/dashboard'))
});

// Security Governor : Admin (Module : acc-duplicateEmployeeId)
gulp.task('admin.acc-duplicateEmployeeId', () => {
    console.log("Concatenating admin duplicateEmployeeId ");
    return gulp
        .src([
            cloudentix.app + 'admin/securityGovernor/report/accountReport/acc-duplicateEmployeeId/cloudentix-admin-sg-acc-duplicateemployeeidController.js'
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('admin.sg.acc-duplicateEmployeeId.controller.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/accountReport/acc-duplicateEmployeeId'))
});

// Security Governor : Admin (Module : acc-expiration)
gulp.task('admin.acc-expiration', () => {
    console.log("Concatenating admin acc-expiration ");
    return gulp
        .src([
            cloudentix.app + 'admin/securityGovernor/report/accountReport/acc-expiration/cloudentix-admin-sg-acc-expirationController.js'
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('admin.sg.acc-expiration.controller.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/accountReport/acc-expiration'))
});

// Security Governor : Admin (Module : acc-expirationReport)
gulp.task('admin.acc-expirationReport', () => {
    console.log("Concatenating admin acc-expirationReport ");
    return gulp
        .src([
            cloudentix.app + 'admin/securityGovernor/report/accountReport/acc-expirationReport/cloudentix-admin-sg-acc-expirationreportController.js'
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('admin.sg.acc-expirationReport.controller.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/accountReport/acc-expirationReport'))
});

// Security Governor : Admin (Module : acc-mapping)
gulp.task('admin.acc-sgmapping', () => {
    console.log("Concatenating admin acc-sgmapping ");
    return gulp
        .src([
            cloudentix.app + 'admin/securityGovernor/report/accountReport/acc-mapping/cloudentix-admin-sg-acc-mappingController.js'
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('admin.sg.acc-mapping.controller.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/accountReport/acc-mapping'))
});

// Security Governor : Admin (Module : acc-multipleEmployeeIds)
gulp.task('admin.acc-multipleEmployeeIds', () => {
    console.log("Concatenating admin acc-multipleEmployeeIds ");
    return gulp
        .src([
            cloudentix.app + 'admin/securityGovernor/report/accountReport/acc-multipleEmployeeIds/cloudentix-admin-sg-acc-multipleemployeeidsController.js'
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('admin.sg.acc-multipleEmployeeIds.controller.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/accountReport/acc-multipleEmployeeIds'))
});

// Security Governor : Admin (Module : acc-passwordNotification)
gulp.task('admin.acc-passwordNotification', () => {
    console.log("Concatenating admin acc-passwordNotification ");
    return gulp
        .src([
            cloudentix.app + 'admin/securityGovernor/report/accountReport/acc-passwordNotification/cloudentix-admin-sg-acc-passwordnotificationController.js'
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('admin.sg.acc-passwordNotification.controller.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/accountReport/acc-passwordNotification'))
});

// Security Governor : Admin (Module : AttestationReview)
gulp.task('admin.AttestationReview', () => {
    console.log("Concatenating admin AttestationReview ");
    return gulp
        .src([
            cloudentix.app + 'admin/securityGovernor/report/AttestationReview/cloudentix-admin-sg-attestationreviewController.js'
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('admin.sg.AttestationReview.controller.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/AttestationReview'))
});

// Security Governor : Admin (Module : DAActive)
gulp.task('admin.DAactive', () => {
    console.log("Concatenating admin DAactive ");
    return gulp
        .src([
            cloudentix.app + 'admin/securityGovernor/report/domainAdminReport/DAActive/cloudentix-admin-sg-DAactiveController.js'
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('admin.sg.DAActive.controller.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/domainAdminReport/DAActive'))
});

// Security Governor : Admin (Module : DAInctive)
gulp.task('admin.DAInactive', () => {
    console.log("Concatenating admin DAInactive ");
    return gulp
        .src([
            cloudentix.app + 'admin/securityGovernor/report/domainAdminReport/DAInactive/cloudentix-admin-sg-DAInactiveController.js'
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('admin.sg.DAInactive.controller.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/domainAdminReport/DAInactive'))
});

// Security Governor : Admin (Module : ADGroupForJob)
gulp.task('admin.ad-job', () => {
    console.log("Concatenating admin ad-job ");
    return gulp
        .src([
            cloudentix.app + 'admin/securityGovernor/report/roleMining/ADGroupForJob/cloudentix-admin-sg-ad-jobController.js'
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('admin.sg.ad-job.controller.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/roleMining/ADGroupForJob'))
});

// Security Governor : Admin (Module : BUStaffForJob)
gulp.task('admin.bu-job', () => {
    console.log("Concatenating admin bu-job ");
    return gulp
        .src([
            cloudentix.app + 'admin/securityGovernor/report/roleMining/BUStaffForJob/cloudentix-admin-sg-bu-jobController.js'
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('admin.sg.bu-job.controller.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/roleMining/BUStaffForJob'))
});

// Security Governor : Admin (Module : CVueGroupForJob)
gulp.task('admin.cv-job', () => {
    console.log("Concatenating admin cv-job ");
    return gulp
        .src([
            cloudentix.app + 'admin/securityGovernor/report/roleMining/CVueGroupForJob/cloudentix-admin-sg-cv-jobController.js'
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('admin.sg.cv-job.controller.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/roleMining/CVueGroupForJob'))
});

// Security Governor : Admin (Module : JobTitleForADGroup)
gulp.task('admin.jobtitlead', () => {
    console.log("Concatenating admin jobtitlead ");
    return gulp
        .src([
            cloudentix.app + 'admin/securityGovernor/report/roleMining/JobTitleForADGroup/cloudentix-admin-sg-jobtitleadController.js'
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('admin.sg.jobtitlead.controller.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/roleMining/JobTitleForADGroup'))
});

// Security Governor : Admin (Module : JobTitleForCVueGroup)
gulp.task('admin.jobtitlecvue', () => {
    console.log("Concatenating admin jobtitlecvue ");
    return gulp
        .src([
            cloudentix.app + 'admin/securityGovernor/report/roleMining/JobTitleForCVueGroup/cloudentix-admin-sg-jobtitlecvueController.js'
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('admin.sg.jobtitlecvue.controller.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/report/roleMining/JobTitleForCVueGroup'))
});

// Security Governor : Admin (Module : Role Manager)
// gulp.task('admin.rolemanager', () => {
//     console.log("Concatenating admin gulp controllers");
//     return gulp
//         .src([
//             cloudentix.app + 'admin/securityGovernor/roleManager/cloudentix-admin-sg-rolemanagerController.js'
//         ])
//         .pipe(sourcemaps.init())
//         .pipe(concat('admin.sg.rolemanager.controller.js'))
//         .pipe(uglify())
//         .pipe(sourcemaps.write('./'))
//         .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/roleManager'))
// });

gulp.task('admin.sgdataservice', () => {
    console.log("Concatenating admin SG data service");
    return gulp
        .src([
             cloudentix.app + 'admin/securityGovernor/service/sg-dataService.js'
        ])
        // .pipe(sourcemaps.init())
        // .pipe(concat('admin.sgdataservice.js'))
        // .pipe(uglify())
        // .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/service'))
})

gulp.task('admin.sgtoastmessageservice', () => {
    console.log("Concatenating admin SG toast service");
    return gulp
        .src([
             cloudentix.app + 'admin/securityGovernor/service/sg-toastMessageService.js'
        ])
        // .pipe(sourcemaps.init())
        // .pipe(concat('admin.sgtoastmessageservice.js'))
        // .pipe(uglify())
        // .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/service'))
})

gulp.task('admin.validationDirectives', () => {
    console.log("Concatenating admin SG toast service");
    return gulp
        .src([
             cloudentix.app + 'admin/securityGovernor/service/validationDirectives.js'
        ])
        // .pipe(sourcemaps.init())
        // .pipe(concat('admin.validationDirectives.js'))
        // .pipe(uglify())
        // .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/admin/securityGovernor/service'))
})

//Role : Admin (Task : Routing)
gulp.task('admin.route', () => {
	console.log("Concatenating admin route files");
    return gulp 
        .src([
            cloudentix.app + 'admin/assets/js/cloudentix.admin.addADroute.js',
            cloudentix.app + 'admin/assets/js/cloudentix.admin.addMsSqlroute.js',
            cloudentix.app + 'admin/assets/js/cloudentix.admin.addMySqlroute.js',
            cloudentix.app + 'admin/assets/js/cloudentix.admin.addOffice365route.js',
            cloudentix.app + 'admin/assets/js/cloudentix.admin.addOracleroute.js',
            cloudentix.app + 'admin/assets/js/cloudentix.admin.attestroute.js',
            cloudentix.app + 'admin/assets/js/cloudentix.admin.edituserroute.js',
            cloudentix.app + 'admin/assets/js/cloudentix.admin.main.controller.js',
            cloudentix.app + 'admin/assets/js/cloudentix.admin.mainrescPage.js',
            cloudentix.app + 'admin/assets/js/cloudentix.admin.manageroute.js',
            cloudentix.app + 'admin/assets/js/cloudentix.admin.mycloudentixroute.js',
            cloudentix.app + 'admin/assets/js/cloudentix.admin.roleroute.js',
            cloudentix.app + 'admin/assets/js/cloudentix.admin.userroute.js',
            cloudentix.app + 'admin/assets/js/cloudentix.admin.viewResourceRouteNew.js',
            cloudentix.app + 'admin/assets/js/cloudentix.admin.viewuserroute.js'
        ])
        .pipe(concat('admin.route.js'))
        .pipe(gulp.dest(cloudentix.temp + '/admin/assets/js'));
}); 

//Role : Manager (Module : Attestation)
gulp.task('manager.attestation', () => {
	console.log("Concatenating manager attestation controllers");
    return gulp
        .src([
            cloudentix.app + 'manager/attestation/cloudentix.manager.attestation.attestationHistory.controller.js',
            cloudentix.app + 'manager/attestation/cloudentix.manager.attestation.attestationPendingWithMe.controller.js',
            cloudentix.app + 'manager/attestation/cloudentix.manager.attestation.controller.js',
            cloudentix.app + 'manager/attestation/cloudentix.manager.attestation.listOfAttestationPending.controller.js'
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('manager.attestation.controllers.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/manager/attestation'));
});

//Role : Manager (Module : Dashboard)
gulp.task('manager.dashboard', () => {
	console.log("Concatenating manager dashboard controllers");
    return gulp
        .src([
            cloudentix.app + 'manager/dashboard/cloudentix.manager.dashboard.controller.js',
            cloudentix.app + 'manager/dashboard/cloudentix.manager.dashboard.controller1.js',
            cloudentix.app + 'manager/dashboard/cloudentix.manager.reports.accessPolicyViolationReports.controller.js'
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('manager.dashboard.controllers.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/manager/dashboard'));
});

//Role : Manager (Module : My Cloudentix)
gulp.task('manager.myCloudentix', () => {
	console.log("Concatenating manager my cloudentix controllers");
    return gulp
        .src([
            cloudentix.app + 'manager/myCloudentix/cloudentix.manager.myCloudentix.accessRequestsPendingApproval.controller.js',
            cloudentix.app + 'manager/myCloudentix/cloudentix.manager.myCloudentix.controller.js',
            cloudentix.app + 'manager/myCloudentix/cloudentix.manager.myCloudentix.listOfAccessRequests.controller.js'
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('manager.myCloudentix.controllers.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/manager/myCloudentix'));
});

//Role : Manager (Module : Users)
gulp.task('manager.users', () => {
	console.log("Concatenating manager users controllers");
    return gulp
        .src([
            cloudentix.app + 'manager/users/cloudentix-manager-selectedResource.js',
            cloudentix.app + 'manager/users/cloudentix-manager-userResource.js',
            cloudentix.app + 'manager/users/cloudentix-manager-userRole.js',
            cloudentix.app + 'manager/users/cloudentix.manager.userInformation.js',
            cloudentix.app + 'manager/users/cloudentix.manager.users.controller.js'
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('manager.users.controllers.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/manager/users'));
});

//Role : Manager (Task : Routing)
gulp.task('manager.route', () => {
	console.log("Concatenating manager route files");
    return gulp 
        .src([
            cloudentix.app + 'manager/assets/js/cloudentix.manager.viewuserroute.js',
            cloudentix.app + 'manager/assets/js/cloudentix.manager.attestroute.js',
            cloudentix.app + 'manager/assets/js/cloudentix.manager.main.controller.js',
            cloudentix.app + 'manager/assets/js/cloudentix.manager.mycloudentixroute.js'
        ])
        .pipe(concat('manager.route.js'))
        .pipe(gulp.dest(cloudentix.temp + '/manager/assets/js'));
}); 

//Role : User (Module : Dashboard)
gulp.task('user.dashboard', () => {
	console.log("Concatenating user dashboard controllers");
    return gulp
        .src([
            cloudentix.app + 'users/dashboard/cloudentix.user.dashboard.controller.js',
            cloudentix.app + 'users/dashboard/cloudentix.user.dashboard.controller1.js',
            cloudentix.app + 'users/dashboard/cloudentix.user.reports.accessPolicyViolationReports.controller.js'
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('user.dashboard.controllers.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/users/dashboard'));
});

//Role : User (Module : My Cloudentix)
gulp.task('user.myCloudentix', () => {
	console.log("Concatenating user my cloudentix controllers");
    return gulp
        .src([
            cloudentix.app + 'users/myCloudentix/cloudentix.user.myCloudentix.accessRequestsPendingApproval.controller.js',
            cloudentix.app + 'users/myCloudentix/cloudentix.user.myCloudentix.controller.js',
            cloudentix.app + 'users/myCloudentix/cloudentix.user.myCloudentix.listOfAccessRequests.controller.js'
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('user.myCloudentix.controllers.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/users/myCloudentix'));
});

//Role : User (Module : Users)
gulp.task('user.users', () => {
	console.log("Concatenating user module users controllers");
    return gulp
        .src([
            cloudentix.app + 'users/users/cloudentix-user-selectedResource.js',
            cloudentix.app + 'users/users/cloudentix-user-userResource.js',
            cloudentix.app + 'users/users/cloudentix-user-userRole.js',
            cloudentix.app + 'users/users/cloudentix.user.userInformation.js',
            cloudentix.app + 'users/users/cloudentix.user.users.controller.js'
        ])
        .pipe(sourcemaps.init())
        .pipe(concat('user.users.controllers.js'))
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(cloudentix.temp + '/users/users'));
});

//Role : User (Task : Routing)
gulp.task('user.route', () => {
	console.log("Concatenating user route files");
    return gulp 
        .src([
            cloudentix.app + 'users/assets/js/cloudentix.user.main.controller.js',
            cloudentix.app + 'users/assets/js/cloudentix.user.mycloudentixroute.js'
        ])
        .pipe(concat('user.route.js'))
        .pipe(gulp.dest(cloudentix.temp + '/users/assets/js'));
}); 

//Creating Web Archive (WAR) file
gulp.task('war', function () {
    gulp.src(cloudentix.temp + '/**')
        .pipe(war({
            welcome: 'index.html',
            displayName: 'Cloudentix Production WAR',
            version: buildVersionNumber
        }))
        .pipe(zip(obfuscatedWarFileName))
        .pipe(gulp.dest(cloudentix.dist + '/' + cloudentix.obfuscated));       
});

//Calculate MD5 Checksum
gulp.task('md5', function () {
    gulp.src([cloudentix.dist + '/' + cloudentix.obfuscated +  '/' + obfuscatedWarFileName]).
    pipe(hashsum({dest: cloudentix.dist + '/' + cloudentix.obfuscated, hash: "md5"}));	
});

gulp.task('default', ['clean', 'copy.main.js', 'copy.core.assets', 'copy.admin.assets', 'copy.manager.assets', 'copy.user.assets', 'copy.main.html', 'copy.admin.html','copy.manager.html', 'copy.user.html', 'admin.attestation', 'admin.dashboard', 'admin.job', 'admin.myCloudentix', 'admin.reports', 'admin.role', 'admin.users', 'admin.manageSystem', 'admin.resources', 'admin.support', 'admin.addataextractiontool', 'admin.sgdashboard', 'admin.acc-duplicateEmployeeId', 'admin.acc-expiration', 'admin.acc-expirationReport', 'admin.acc-sgmapping', 'admin.acc-multipleEmployeeIds', 'admin.acc-passwordNotification', 'admin.AttestationReview', 'admin.DAactive', 'admin.DAInactive', 'admin.ad-job', 'admin.bu-job', 'admin.cv-job', 'admin.jobtitlead', 'admin.jobtitlecvue', 'admin.sgdataservice', 'admin.sgtoastmessageservice', 'admin.validationDirectives', 'admin.route', 'manager.attestation', 'manager.dashboard', 'manager.myCloudentix', 'manager.users', 'manager.route', 'user.dashboard', 'user.myCloudentix', 'user.users', 'user.route']);


//'admin.addataextractiontool', 'admin.sgdashboard' , 'admin.acc-duplicateEmployeeId' , 'admin.acc-expiration' , 'admin.acc-expirationReport' , 'admin.acc-mapping' , 'admin.acc-multipleEmployeeIds' , 'admin.acc-passwordNotification' , 'admin.AttestationReview' , 'admin.DAactive' , 'admin.DAInactive' , 'admin.ad-job' , 'admin.bu-job' , 'admin.cv-job' , 'admin.jobtitlead' , 'admin.jobtitlecvue' , 'admin.rolemanager'
//'admin.rolemanager',