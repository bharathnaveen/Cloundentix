angular
    .module('cloudentixApp')
    .controller('jobController',jobCtrl)
    .controller('jobHistoryController',jobHistoryCtrl)
    .controller('schedularController', schedularController)
    .service('selectedJob',function(){
        this.jobSelect = function(array){
        this.jobName = array;
        }
        this.getJobSelect = function(){
        return this.jobName;
        }
    })
    jobCtrl.$inject = ['$scope', '$log', '$location', '$window', '$http', '$mdMedia', '$mdDialog','$rootScope', '$timeout', '$filter', '$state', 'selectedJob', 'SessionService'];
    jobHistoryCtrl.$inject = ['$scope', '$log', '$location', '$window', '$http', '$mdMedia', '$mdDialog','$rootScope', '$timeout', 'selectedJob', 'SessionService'];
    schedularController.$inject = ['$timeout', '$q', '$http', '$scope', '$mdDialog', '$mdToast', '$rootScope', 'job', 'SessionService'];
    
    function jobCtrl($scope, $log, $location, $window, $http, $mdMedia, $mdDialog,$rootScope, $timeout, $filter, $state, selectedJob, SessionService){
    //$scope.name = "RAM";
    var baseUrl = sessionStorage.getItem("WS_BASE_URL");
         var checkResourceURL = baseUrl + '/resources?check=true';
			var config = {
				url: checkResourceURL,
				method: "GET",
				headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
				}
			}
			$http(config)
			.success(function(response) {
                /*  check two resources (trusted and untrusted)available in if not it is navigated to add resource */
                  if(response.type === 'success'){
				if (response.data.login[0].trusted == 'N' || response.data.login[0].untrusted == 'N') {
                    if (response.data.login[0].trusted == 'N' && response.data.login[0].untrusted == 'N') {
                        $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure trusted and untrusted resources");
                    } else {
                        if (response.data.login[0].trusted == 'N') {
                            $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure the trusted resource");
                        } else if (response.data.login[0].untrusted === 'N') {
                            $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure an untrusted resource");
                        }
                    }
                }
                /* if two resources (trusted and untrusted) is configured then proceeds*/
                else if(response.data.login[0].trusted == 'Y' && response.data.login[0].untrusted == 'Y') {
     $scope.selectedUserRow = null;
     $rootScope.loaderCurrentStatus = 'true';
  $scope.selected = [];
  $scope.limitOptions = [10, 25, 50, 100];
  $scope.options = {
    rowSelection: true,
    multiSelect: false,
    autoSelect: true,
    decapitate: false,
    largeEditDialog: true,
    boundaryLinks: true,
    limitSelect: true,
    pageSelect: true
  };
  $scope.query = {
    order: 'name',
    limit: 10,
    page: 1,
	filter: ''
  };
    $rootScope.schedularListFunction = function(){ 
  var jobListURL = baseUrl + "/schedule";
   //$scope.dublicatejobList =[];
   $rootScope.startEnabled = true;
   var jobConfig = {
          url: jobListURL,
          method: "GET",
          dataType: 'json',
          async: false,
          headers: {
             "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
          }
        }
  $http(jobConfig)
      .then(function success(response) {
      $rootScope.loaderCurrentStatus = 'false';
      $scope.jobList =[];
      //console.log(response.data.records)
      
      angular.forEach(response.data.records, function(value, key) {
      if(value["schday"] != undefined){
             $scope.jobList.push({"schname":value["schname"],"schflag":value["schflag"],"schid":value["schid"],"schrscid":value["schrscid"],"schtype":value["schtype"],"schprotype":value["schprotype"],"schprotypeid":value["schprotypeid"],"schday":value["schday"],"schhour":value["schhour"],"schmin":value["schmin"],"schdetails":value["schdetails"]});
             }
             });
             
             //alert(response.data.records[0].schday)
             $rootScope.timezone = response.data.records[0].timezone;
              $scope.duplicatejobList = angular.copy($scope.jobList);
            // console.log( $scope.jobList)
      },function error(response) {
      $rootScope.loaderCurrentStatus = 'false';
    $scope.errorHandler(response.config.url,response.status);
            // It will work when the server returns the status "500 - Internal server" or 400 series errors
      }); 
      
      }
       
    $scope.logItem = function (jobList) {
    //console.log(jobList.schname,'was selected');
    $scope.arrayJob = [];
    $scope.arrayJob.push(jobList);
    
    selectedJob.jobSelect($scope.arrayJob);
    
  };

 
   $rootScope.schedularListFunction();
   
   $scope.history = function($event,jobList){
            if(jobList.schdetails == ''){
            void 0;
            }
            else{
            void 0;
            //$state.go("jobView");
			//$scope.addTab('Job View','jobView');
            }
   }
    /* it trigger seach field data for filtering list user*/
                    $scope.$watch('query.filter', function (newValue, oldValue) {
                    if(newValue) {
                            $scope.items = $filter('filter')($scope.duplicatejobList, newValue);
                            $scope.jobList = $scope.items;
                        }
                        else if(newValue == '') {
                           if($scope.duplicatejobList != undefined) {
                                $scope.jobList = $scope.duplicatejobList;
                           }
                        }

                    });
  
  $scope.stopConfigure = function($event,jobList){
  $rootScope.loaderCurrentStatus = 'true';
   var jobStopURL = baseUrl + "/schedule";
    var jobschduleid = jobList.schprotypeid;
         var jobrscid = jobList.schrscid;
   var reportConfig = {
          method: "DELETE",
          url: jobStopURL,
          dataType: 'json',
          async: false,
          headers: {
             "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
              "cdt-rscid":jobrscid,
              "cdt-schid":jobschduleid,
          }
        }
  $http(reportConfig)
      .then(function success(response) {
      $rootScope.loaderCurrentStatus = 'false';
      if(response.data.type == "success"){
			$scope.toastMessage('toast-success',response.data.message);
			}if(response.type == "error"){
			$scope.toastMessage('toast-error',response.data.message);
			}if(response.type == "warning"){
			$scope.toastMessage('toast-warn',response.data.message);
			}
             $rootScope.schedularListFunction();
             $rootScope.getHistory();
      },function error(response) {
      $rootScope.loaderCurrentStatus = 'false';
 $scope.errorHandler(response.config.url,response.status);
            // It will work when the server returns the status "500 - Internal server" or 400 series errors
      }); 
   }

  $scope.configure = function($event,jobs) {	

$mdDialog.show({
        controller: schedularController,
        controllerAs: 'scheduleCtrl',
        templateUrl: 'job/jobConfigure.html',
        parent: angular.element(document.body),
        targetEvent: $event,
        clickOutsideToClose:false,
         locals : {
                job:jobs
                },
      })
		}
    
    }
    }else {
    $rootScope.loaderCurrentStatus = 'false';
 $scope.errorHandler(response.message,response.status);
 
    }
    });
    
}

    function jobHistoryCtrl($scope, $log, $location, $window, $http, $mdMedia, $mdDialog,$rootScope, $timeout,selectedJob, SessionService){
             $scope.historyselected=[];
             if(selectedJob.getJobSelect() == undefined) {
                $location.url('/job');
                return 0;
            }
             $scope.jobname = selectedJob.jobName[0].schname;
             $scope.jobid = selectedJob.jobName[0].schprotypeid;
              $scope.limitOptions = [3, 5, 10];
              $scope.selected = [];
			  $scope.options = {
                rowSelection: true,
                multiSelect: false,
                autoSelect: true,
                decapitate: false,
                largeEditDialog: true,
                boundaryLinks: true,
                limitSelect: true,
                pageSelect: true
              };
              $scope.query = {
                order: 'name',
                limit: 3,
                page: 1,
                filter: ''
              };
			  $scope.selected1 = [];
			  $scope.limitOptions1 = [3, 5, 10];
              $scope.options1 = {
                rowSelection: true,
                multiSelect: false,
                autoSelect: true,
                decapitate: false,
                largeEditDialog: true,
                boundaryLinks: true,
                limitSelect: true,
                pageSelect: true
              };
              $scope.query1 = {
                order: 'name',
                limit: 3,
                page: 1,
                filter: ''
              };
              $scope.manualshow = false;
               /* For Manual Reconciliation*/ 
$scope.manualCall = function(){
void 0
        var loginId = localStorage.getItem("userid");
       $rootScope.loaderCurrentStatus = 'true';
       $scope.provision = [];
       $scope.notprovision = [];  
       $scope.colsnotprovisioned = [];
       $scope.colsprovisioned = [];
        if(selectedJob.jobName[0].schprotypeid === '1'){
             var resourceReconURL = baseUrl + '/recon/childparentrecon';
             var resourceid = selectedJob.jobName[0].schrscid;
        } else if(selectedJob.jobName[0].schprotypeid === '2'){
             var resourceReconURL = baseUrl + '/recon/lookuprecon';
            var resourceid = selectedJob.jobName[0].schrscid;
        }
        else{
         var resourceReconURL = baseUrl + '/autoprov';
         
         var resourceid = '';
        }
       void 0
        var username = 'cloudentix';
        var password = 'p@ssw0rd';
		var config = {
			url: resourceReconURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                "cdt-rscid": resourceid,
                "cdt-loginguid": loginId
			}
		}
		$http(config).then(function success(response) {  
           
           // $scope.ResourceReconciled = response.message;
            //$scope.reconresponseType = response.type;
             $scope.manualshow = true;
              $rootScope.loaderCurrentStatus = 'false';
            if(selectedJob.jobName[0].schprotypeid === '3'){
            $scope.provision = response.data.records[0].autoprovision[0].provisioned;
            $scope.notprovision = response.data.records[0].autoprovision[0].notprovisioned;
            $scope.provisioncount = response.data.records[0].autoprovision[0].provisionedcount;
            $scope.notprovisioncount = response.data.records[0].autoprovision[0].notprovisionedcount;
           
             $scope.provisionValue = 'User Provisioned ' +response.data.records[0].autoprovision[0].provisionedcount;
       
       $scope.notprovisionValue = 'User Not Provisioned '+ response.data.records[0].autoprovision[0].notprovisionedcount;
        if($scope.notprovision != '') {
                    $scope.colsnotprovisioned = Object.keys($scope.notprovision[0]);
                }
                if($scope.provision != '') {
                    $scope.colsprovisioned = Object.keys($scope.provision[0]);
                }
            //$scope.colsnotprovisioned = Object.keys($scope.notprovision[0]);
            //$scope.colsprovisioned = Object.keys($scope.provision[0]);
            }
            //console.log(response)
            if(response.data.type == "success"){
			$scope.toastMessage('toast-success',response.data.message);
			}if(response.type == "error"){
			$scope.toastMessage('toast-error',response.data.message);
			}if(response.type == "warning"){
			$scope.toastMessage('toast-warn',response.data.message);
			}
            
		},function error(response){
            $rootScope.loaderCurrentStatus = 'false';
 $scope.errorHandler(response.config.url,response.status);
        })
}
$scope.notprovisionFunction = function(){
    $scope.notprovisiondisplay = !$scope.notprovisiondisplay;
}
$scope.provisionFunction = function(){
$scope.provisiondisplay = !$scope.provisiondisplay;
}
/*Manual Reconciliation End*/  
         $rootScope.getHistory = function(){
              $rootScope.loaderCurrentStatus = 'true';
              $scope.jobUpdateList =[];
            $scope.getSelectedJob = selectedJob.getJobSelect();
            
               void 0
            var jobListURL = baseUrl + "/schedule";
           $scope.jobHistoryList =[];
           var jobConfig = {
                  url: jobListURL,
                  method: "GET",
                  dataType: 'json',
                  async: false,
                  headers: {
                     "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                  }
                }
          $http(jobConfig)
              .then(function success(response) {
             
              $rootScope.loaderCurrentStatus = 'false';
              //console.log(response.data.type)
               if(response.data.type == 'success') {
               //console.log(response.data.records[0].columnname)
               $scope.historyHeaders = [];
                    angular.forEach(response.data.records, function(value, key) {
                     var tabletitles = response.data.records[0].tabletitle[0];
                     $rootScope.timezone = response.data.records[0].timezone;
                     void 0;
                      $scope.historyHeaders.push({"schedule_details":tabletitles.sch_detail,"schedule_enddate":tabletitles.sch_end_date,"schedule_errorDetails":tabletitles.sch_error_detail,"schedule_result":tabletitles.sch_result,"schedule_startdate":tabletitles.sch_start_date});
                        if($scope.getSelectedJob[0].schname === value["schname"]){
                        
                      
                            void 0;
           $scope.jobUpdateList.push({"schname":value["schname"],"schflag":value["schflag"],"schid":value["schid"],"schrscid":value["schrscid"],"schtype":value["schtype"],"schprotype":value["schprotype"],"schprotypeid":value["schprotypeid"],"schday":value["schday"],"schhour":value["schhour"],"schmin":value["schmin"],"schdetails":value["schdetails"]});
                        
                       
                    if(value["schdetails"] != ''){
                            $scope.show = true;
                           $scope.jobHistoryList = value["schdetails"];
                           $scope.cols = Object.keys($scope.jobHistoryList[0]);
                          
                           
                          }
                             else{
                                 $scope.show = false;    
                             }
                        }
                   
                    
                    });
                     //console.log($scope.historyHeaders)
                    selectedJob.jobSelect($scope.jobUpdateList);
                    void 0;
                    $scope.getSelectedJob = selectedJob.getJobSelect();
            }
              },function error(response) {
                    // It will work when the server returns the status "500 - Internal server" or 400 series errors
                    $rootScope.loaderCurrentStatus = 'false';
 $scope.errorHandler(response.config.url,response.status);
              }); 
           }   
     $rootScope.getHistory();
    }
    
    function schedularController($timeout, $q, $http, $scope, $mdDialog, $mdToast, $rootScope, job, SessionService) {
          var self = this;
        self.cancel = function($event) {
          $mdDialog.cancel();
        } 
        $scope.timezone = $rootScope.timezone;
        $scope.isEnabled = false;
        $scope.jobValue = [];
        $scope.jobValue = job;
        void 0;
        void 0
    $scope.commonList =[];
    $scope.commonList.push({"key":"1","value":"Daily"},{"key":"2","value":"Weekly"});
    $scope.days =[];
    $scope.days.push({"key":"Mon","value":"Monday"},{"key":"Tue","value":"Tuesday"},{"key":"Wed","value":"Wednesday"},{"key":"Thu","value":"Thursday"},{"key":"Fri","value":"Friday"},{"key":"Sat","value":"Saturday"},{"key":"Sun","value":"Sunday"});
    
     $scope.scheduleHour = ['0','1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23'];
	  $scope.scheduleMinute = ['0','1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59'];
      
      
 $scope.changeList = function(scheduleSelected){
 //console.log(scheduleSelected.value)
   if($scope.scheduleSelected.value == 'Daily'){
           // console.log("fsf")
        $scope.isEnabled = true;
        }
        else{
        $scope.isEnabled = false;
        }
       
        
        } 
        
    $scope.changeDay = function(dayList1){
 //console.log($scope.dayList.value)
        if(dayList1){
           // console.log(dayList1);
            $scope.isEnabled = true;
            }
            else{
            void 0;
            $scope.isEnabled = false;
            }
        }
        
         var guid = localStorage.getItem("userid");
         var jobschduleid = job.schid;
         var jobrscid = job.schrscid;
         //var schdularType = job.schtype;
         var schedularprototype = job.schprotypeid;
         
        //console.log(guid + " " + " " + jobschduleid + " " + jobrscid + " " + schedularprototype)
  
        self.finish = function($event) {
             //console.log("Type:"+ $scope.scheduleSelected.value + "Day" +$scope.dayList.value+ "hour:" + $scope.scheduleHourSelect + "min" + $scope.scheduleMinuteSelect);
             
             var schedularValue = $scope.scheduleHourSelect + ":" + $scope.scheduleMinuteSelect;
             var jobConfigureURL = baseUrl + "/schedule";
             if($scope.scheduleSelected.value == 'Daily'){
                    var selectedDay = "";
                    var schdularType = '1';
             }else{
              var selectedDay = $scope.dayList.value;
              var schdularType = '2';
             }
             $scope.isLoading = true;
             var jobConfigurationPost = {
              url: jobConfigureURL,
              method: "POST",
              dataType: 'json',
              async: false,
              headers: {
                 "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                 "cdt-rscid":jobrscid,
                 "cdt-schtype":schdularType,
                 "cdt-schid":jobschduleid,
                 "cdt-guid":guid,
                 "cdt-schday":selectedDay,
                 "cdt-schvalue":schedularValue,
                 "cdt-schprotype":schedularprototype
                    }
            }
            $http(jobConfigurationPost)
                .then(function success(response) {
            //$mdDialog.cancel();
            //console.log(response.data.message)
            //console.log(response.message)
            $scope.isLoading = false;
                        var icon;
        if(response.data.type == 'success'){
            icon = 'done';
        }  else if(response.data.type == 'error'){
            icon = 'error_outline';
        } else if(response.data.type == 'warn'){
            icon = 'warning';
        } else{
            icon = 'info_outline';
        }
                $mdDialog.hide();
                 $mdToast.show({
            template : '<md-toast class="md-toast toast-'+response.data.type+'"><div class="md-toast-content"><i class="material-icons">'+icon+'</i>&nbsp;&nbsp; '+ response.data.message + '!</div></md-toast>',
             hideDelay: 3000,
             position: 'top right'
            });
            
      $rootScope.schedularListFunction();
      $rootScope.getHistory();
                    
              },function error(response) {
                    $scope.error = response.data.message;
                    $rootScope.loaderCurrentStatus = 'false';
 $scope.errorHandler(response.config.url,response.status);
                        //console.log($scope.error)
                   // It will work when the server returns the status "500 - Internal server" or 400 series errors
              }); 
         
       
        }
        
    }