


angular.module('cloudentixApp')
      .value('clientId', 'true')
	  .controller('approvalpolicy', approvalpolicy)
	  .controller('DialogCtrlapprovalLevels', DialogCtrlapprovalLevels)
	  approvalpolicy.$inject = ['$rootScope', '$scope', '$http', '$log' , '$mdDialog', '$rootScope', '$mdMedia', 'clientId', 'SessionService'];
	  DialogCtrlapprovalLevels.$inject = ['$timeout', '$q', '$http', '$scope', '$mdDialog', '$mdToast','$rootScope','theScope', 'SessionService'];
	  
      function approvalpolicy($rootScope, $scope, $http, $log , $mdDialog, $rootScope, $mdMedia, clientId, SessionService) {
	 var baseUrl = sessionStorage.getItem("WS_BASE_URL");
	var checkResourceURL = baseUrl + '/resources?check=true';
			var config = {
				//url:"dashboard/data.json",
				url:checkResourceURL,
				method: "GET",
				headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
				}
			}
			   
			$http(config)
			.success(function(response) {
             if(response.type === 'success'){
				if (response.data.login[0].trusted == 'N' || response.data.login[0].untrusted == 'N') {
                    if (response.data.login[0].trusted == 'N' && response.data.login[0].untrusted == 'N') {
                       $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure trusted and untrusted resources");
                    } else {
                        if (response.data.login[0].trusted == 'N') {
                            $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure the trusted resource");
                        } else if (response.data.login[0].untrusted === 'N') {
                            $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure an untrusted resource");
                        }
                    }
                }
                else if(response.data.login[0].trusted == 'Y' && response.data.login[0].untrusted == 'Y') {
	$rootScope.loaderCurrentStatus = 'true';
var roleid = localStorage.getItem("roleId");
var resourceid = localStorage.getItem("RescID");
var checkapprovalpolicy = localStorage.getItem("approvalpolicy");
  $scope.clientId = clientId;
  //console.log(checkapprovalpolicy);
  
 // $scope.message = 'Without Approval';
 // $scope.appType = 'false';

$scope.withapprovalmessage = "No approval levels available";
 $scope.onChange = function(cbState) {
  if(cbState){
  $scope.checkpolicy = false;
  $scope.responsemessage = "";
  $scope.appType = 'true';
  $scope.message = 'With Approval'
  }else{
  
  $scope.appType = 'false';
  $scope.message = 'Without Approval'
  if($scope.checkpolicy = true){
 $scope.enablecontent = 'Are you sure want to change without approval policy ';
			$scope.status = '  ';
			$scope.customFullscreen = $mdMedia('xs') || $mdMedia('sm');
			var confirm = $mdDialog.confirm()
			.title('Without approval policy')
			.textContent($scope.enablecontent)
			.ariaLabel('Confirm')
			.cancel('No')
			.ok('Yes');

			$mdDialog.show(confirm).then(function() {
  var withoutApprovalURL = baseUrl + '/approvalpolicy';
		var config = {
			url: withoutApprovalURL,
			method: "POST",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
				"cdt-rscid":resourceid,
				"cdt-roleid":roleid,
				"cdt-value":'{"records": []}'
			}
		}
		$http(config)
		.success(function(response){ 
			//console.log(response.message)
			$rootScope.listApproval(); 
		})
		.error(function(data) {
					
				});
			}, function() {
				$scope.appType = 'true';
				$scope.selectapprovaltype = true;
			});
  }
 
  }
  	//$scope.message = cbState;
  };
  
  $scope.saveApprovalPolicy = function(){
  if($scope.appType == 'true'){
  void 0;
  }
  else{
  
   
  //console.log("without approval")
  }
  }
$scope.selected = [];
$scope.selectedrsc = [];
$scope.userSelected = [];
  $scope.limitOptions = [10, 25, 50, 100];
  $scope.selectedrowelement = null;
  $scope.options = {
    rowSelection: false,
    multiSelect: false,
    autoSelect: false,
    decapitate: false,
    largeEditDialog: true,
    boundaryLinks: true,
    limitSelect: true,
    pageSelect: true
  };
  $scope.newField = {};
	
          $scope.editing = false;
		  $scope.checkapprovaltype =" ";
		  $scope.checkapprovaluser ="";
      /* This function is used to edit the table row in approval policy*/
	  $scope.editAppKey = function(field,index) {
		$scope.clientId = false;
		void 0;
		void 0;
		 $scope.selectedrowelement = ($scope.selectedrowelement == index) ? null : index;
		$scope.disabled = true
        $scope.editing = $scope.attributesList.indexOf(field);
        $scope.newField = angular.copy(field);
		$scope.checkstring = field.approvaltype.split("-");
			$scope.checkapprovaltype = $scope.checkstring[0].trim();
			$scope.checkapprovaluser = field.guid;
    }
    $scope.saveField = function(approvalid,approvalorder,approvaltype,guid) {
	void 0;
	$scope.clientId = true;       
	   if ($scope.editing !== false) {
            $scope.attributesList[$scope.editing] = $scope.newField;
            $scope.editing = false;
        } 
		 var userid = localStorage.getItem("userid");
		var updateURL = baseUrl + '/approvalpolicy';
		var config = {
			url: updateURL,
			method: "PUT",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
				"cdt-rscid":resourceid,
				"cdt-roleid":roleid,
				"cdt-appflag":'E',
				"cdt-appid":approvalid,
				"cdt-apptype":approvaltype,
				"cdt-apporder":approvalorder,
				"cdt-appvalue":guid,
                "cdt-loginguid" : userid,
			}
		}
		$http(config)
		.then(function success(response){ 
			//console.log(response.message)
			if(response.data.type == "success"){
			$scope.toastMessage('toast-success',response.data.message);
			}if(response.data.type == "error"){
			$scope.toastMessage('toast-error',response.data.message);
			}if(response.data.type == "warning"){
			$scope.toastMessage('toast-warn',response.data.message);
			}
			$rootScope.listApproval();
			
		},function error(response){
         $rootScope.loaderCurrentStatus = 'false';
 $scope.errorHandler(response.config.url,response.status);
        });
 //  console.log($scope.save1);		
    };
 
    $scope.cancel = function(index) {
	$scope.clientId = true;
        if ($scope.editing !== false) {
            $scope.attributesList[$scope.editing] = $scope.newField;
            $scope.editing = false;
        }       
    };
  $scope.query = {
    order: 'name',
    limit: 10,
    page: 1
  };
	 var baseUrl = sessionStorage.getItem("WS_BASE_URL");
	 var roleid = localStorage.getItem("roleId");
var resourceid = localStorage.getItem("RescID");
		$rootScope.listApproval = function(){
		var requestAccessURL = baseUrl + '/approvalpolicy';
		var config = {
			url: requestAccessURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
				"cdt-rscid":resourceid,
				"cdt-roleid":roleid,
			}
		}
		   
		$http(config)
		.then(function success(response){
			$rootScope.loaderCurrentStatus = 'false';
			$scope.checkpolicy = false;
		if(response.data.records.length == '0'){
		
		$scope.selectapprovaltype = false;
		$scope.responsemessage = response.data.message;
		$scope.appType = 'false';
		$scope.message = 'Without Approval'
		//$scope.onChange(false);
		$scope.attributesList = [];
		}			/*if(response.type == "success"){
			$scope.toastMessage('toast-success',response.message);
			}if(response.type == "error"){
			$scope.toastMessage('toast-error',response.message);
			}if(response.type == "warning"){
			$scope.toastMessage('toast-warn',response.message);
			}*/
			else{
			$scope.appType = 'true';
				$scope.checkpolicy = false;
			$scope.responsemessage = "";
			$scope.message = 'With Approval'
			$scope.attributesList = [];
			$scope.checkapprovaltypestr = [];
			  //alert(response.records[0].listAccessRequest[0].rolename)
			angular.forEach(response.data.records, function(value, key) {
				$scope.attributesList.push({"approvalorder" : value["approvalorder"],"approvaltype" : value["approvaltype"],"approvalid" : value["approvalid"],"guid" : value["id"]});
				
			});
			
			$scope.selectapprovaltype = true;
			$scope.onChange(true);
			}
		
		},function error(response){
         $rootScope.loaderCurrentStatus = 'false';
        $scope.errorHandler(response.config.url,response.status);
        });
		$scope.checkpolicy = true;
		}
		$rootScope.listApproval(); 
		/*$scope.addRow = function (index) {
      $scope.attributesList.push();
  };*/
  $scope.a = true;
  $scope.isDisabled = false;
  $scope.temarray = [];
  

  $scope.removeRow = function (index,approvalid,approvalorder,approvaltype,guid) {
  $scope.enablecontent = 'Are you sure want to delete this approval policy ';
			$scope.status = '  ';
			$scope.customFullscreen = $mdMedia('xs') || $mdMedia('sm');
			var confirm = $mdDialog.confirm()
			.title('Delete approval policy')
			.textContent($scope.enablecontent)
			.ariaLabel('Confirm')
			.cancel('No')
			.ok('Yes');

			$mdDialog.show(confirm).then(function() {
			 var deleteURL = baseUrl + '/approvalpolicy';
		var config = {
			url: deleteURL,
			method: "PUT",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
				"cdt-rscid":resourceid,
				"cdt-roleid":roleid,
				"cdt-appflag":'D',
				"cdt-appid":approvalid,
				"cdt-apptype":approvaltype,
				"cdt-apporder":approvalorder,
				"cdt-appvalue":guid,
			}
		}
		   
		$http(config)
		.then(function success(response){ 
		//console.log(response.message);
			if(response.data.type == "success"){
			$scope.toastMessage('toast-success',response.data.message);
			}if(response.data.type == "error"){
			$scope.toastMessage('toast-error',response.data.message);
			}if(response.data.type == "warning"){
			$scope.toastMessage('toast-warn',response.data.message);
			}
		$rootScope.listApproval();
		},function(response) {
				 $rootScope.loaderCurrentStatus = 'false';
                $scope.errorHandler(response.config.url,response.status);	
				});
			}, function() {
			});
     // $scope.attributesList.splice(index, 1);
	  	
  };
		var approvaltypeURL = baseUrl + '/list/approvaltype';
		var config = {
			url: approvaltypeURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
			}
		}
		   
		$http(config)
		.then(function success(response){ 		
			$scope.approvaltypeList = [];
			//console.log(response.records[0].dropdownlist[0].key)
			  //alert(response.records[0].listAccessRequest[0].rolename)
			angular.forEach(response.data.records[0].dropdownlist, function(value, key) {
				$scope.approvaltypeList.push({"key" : value["key"],"value" : value["value"]});
			});
			
		},function error(response){
         $rootScope.loaderCurrentStatus = 'false';
 $scope.errorHandler(response.config.url,response.status);
        });
		
		$scope.selecttype = function(index) {
   $scope.selectedrowelement = ($scope.selectedrowelement == index) ? null : index;
  }
  
  
		$scope.logItem = function (attributesList) {
    //console.log(attributesList.approvalorder, 'was selected');
	$scope.dval = attributesList.approvaltype;
  };
  
  $scope.logOrder = function (order) {
    //console.log('order: ', order);
  };
  
  $scope.logPagination = function (page, limit) {
    void 0;
    void 0;
  }

  
  var listusersURL = baseUrl + '/users';
   var userid = localStorage.getItem("userid");
		var config = {
			url:listusersURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                 "cdt-loginguid": userid
			}
		}
		   
		$http(config)
		.then(function success(response){ 
		
			//$scope.desserts = response.data;
		
			$scope.userList = [];
			  
			angular.forEach(response.data.records[0].listusers, function(value, key) {
				$scope.userList.push({"guid" : value["guid"],"userName" : value["username"],"ntwuserid" : value["ntwuserid"],"emailid" : value["emailid"],"employeeId" : value["employeeid"],"managerName" : value["managername"],"statusFlag" : value["statusflag"]});
			});
		},function error(response){
         $rootScope.loaderCurrentStatus = 'false';
 $scope.errorHandler(response.config.url,response.status);
        });
		
		$scope.call = function(id,value){
	
	void 0;
	}
	$scope.users = function(value){
	
	//console.log(value);
	}
	
	
	
  $scope.show = function($event) {			
$mdDialog.show({
		locals: {
                    theScope: $scope.attributesList,
                },
        controller: DialogCtrlapprovalLevels,
       controllerAs: 'approvalpolicyctrl',
        templateUrl: 'role/sub-role/addApprovalpolicy.html',
        parent: angular.element(document.body),
        targetEvent: $event,
		//controller: mdDialogCtrl,
        clickOutsideToClose:false,
		
      })
	  //console.log($scope.attributesList);
		}
				}
                }else {
    $rootScope.loaderCurrentStatus = 'false';
 $scope.errorHandler(response.message,response.status);
 
    }
			});

}
function DialogCtrlapprovalLevels($timeout, $q, $http, $scope, $mdDialog, $mdToast,$rootScope,theScope, SessionService){	
	  //$scope.selected1 = [];
	var self = this;
		var userid = localStorage.getItem("userid");
	 var baseUrl = sessionStorage.getItem("WS_BASE_URL");
	 var roleid = localStorage.getItem("roleId");
var resourceid = localStorage.getItem("RescID");
	self.cancel = function($event) {
      $mdDialog.cancel();
	  //$scope.toastMessage('toast-success','fsfs');
    }
	//console.log(theScope);
	//alert(theScope.length);
	$scope.approvalLevels= [];
	//$scope.approvalLevels= theScope.approvaltype;
	
	var requestAccessURL = baseUrl + '/approvalpolicy';
		var config = {
			url: requestAccessURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
				"cdt-rscid":resourceid,
				"cdt-roleid":roleid,
			}
		}
		   
		$http(config)
		.then(function success(response){ 
			$scope.modalattributesList = [];
			
			
			  //alert(response.records[0].listAccessRequest[0].rolename)
			angular.forEach(response.data.records, function(value, key) {
			
			if(value["approvaltype"] == "User's Manager"){
			var approvaltype = value["approvaltype"];
			}
			else{
			var aptype = value["approvaltype"].split("-");
			var approvaltype = aptype[0].trim();
			var checkapprovaluser = value["id"];
			}
            
				$scope.approvalLevels.push({"approvalorder" : value["approvalorder"],"approvaltype" : approvaltype,"approvalid" : value["approvalid"],"selecteduser":checkapprovaluser});
			
			});

		},function error(response){
         $rootScope.loaderCurrentStatus = 'false';
 $scope.errorHandler(response.config.url,response.status);
        });
		
	$scope.selectedtype = [];

self.saveapproval = function(data){
	var userguid;
	$scope.addvalue = {"records": []};
	var approvertype=0, approvaruser=0;
	 for(var i=0;i<data.length;i++){
		//console.log(data[i].approvalModel.key);
		
		if(data[i].approvalModel.key == '1'){
		void 0;
			approvertype++;
			if(approvertype == 2){
			$scope.error = 'true';
			$scope.errormessage = "Please select different approver";
			}
			else{
			void 0;
			$scope.errormessage ='';
			$scope.error = 'false';
			userguid = '';
			}
		}
		else {
		approvaruser++;
		if(approvaruser == 2){
			if(data[0].usermodal.guid == data[1].usermodal.guid){
			$scope.error = 'true';
			userguid = '';
			$scope.errormessage = "Please select different User";
			} 
			else{
			$scope.errormessage ='';
			userguid =  data[i].usermodal.guid;
			$scope.error = 'false';
			}
		}else{
			$scope.errormessage ='';
			$scope.error = 'false';
			userguid =  data[i].usermodal.guid;
		}
		}
		
		
		$scope.addvalue.records.push({"apptype":data[i].approvalModel.key,"appvalue":userguid,"apporder":i+1})
		//console.log(data[i].usermodal.guid);
	  }
	  if($scope.error == 'false'){
	  var finalvalue = JSON.stringify($scope.addvalue);
	//console.log(finalvalue)
	//console.log(finalvalue);
	  $scope.isLoading = true;
	  var addapprovaltypeURL = baseUrl + '/approvalpolicy';
		var config = {
			url: addapprovaltypeURL,
			method: "POST",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
				"cdt-rscid":resourceid,
				"cdt-roleid":roleid,
				"cdt-value":finalvalue,
                "cdt-loginguid" : userid,
			}
		}
		   
		$http(config)
		.then(function success(response){ 
$scope.isLoading = false;		
				var icon;
			if(response.data.type == 'success'){
				icon = 'done';
			}  else if(response.data.type == 'error'){
				icon = 'error_outline';
			} else if(response.data.type == 'warn'){
				icon = 'warning';
			} else{
				icon = 'info_outline';
			}
			//$mdDialog.hide();
			 $mdToast.show({
        template : '<md-toast class="md-toast toast-'+response.data.type+'"><div class="md-toast-content"><i class="material-icons">'+icon+'</i>&nbsp;&nbsp; '+ response.data.message + '!</div></md-toast>',
         hideDelay: 3000,
         position: 'top right'
		});
		$mdDialog.hide();
		$rootScope.listApproval();
		},function error(response){
         $rootScope.loaderCurrentStatus = 'false';
 $scope.errorHandler(response.config.url,response.status);
        });
	  
	}
	
	}
	

	$scope.addApproval1 = function(){
   $scope.approvalLevels.push({});
   //console.log($scope.approvalLevels.length)
  }
   $scope.removeApproval = function (index) {
      $scope.approvalLevels.splice(index, 1);
  };
	
	
	//$scope.resource_id = rscid;
	//var selected = [];
	//$scope.load = function(){
  	var approvaltypeURL = baseUrl + '/list/approvaltype';
		var config = {
			url: approvaltypeURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
			}
		}
		   
		$http(config)
		.success(function(response){ 		
			$scope.approvaltypeList = [];
			//console.log(response.records[0].dropdownlist[0].key)
			  //alert(response.records[0].listAccessRequest[0].rolename)
			angular.forEach(response.records[0].dropdownlist, function(value, key) {
				$scope.approvaltypeList.push({"key" : value["key"],"value" : value["value"]});
			});
		});

	var listusersURL = baseUrl + '/users';
     var userid = localStorage.getItem("userid");
		var config = {
			url:listusersURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                 "cdt-loginguid": userid
			}
		}
		   
		$http(config)
		.then(function success(response){ 
			$scope.userList = [];
			angular.forEach(response.data.records[0].listusers, function(value, key) {
				$scope.userList.push({"guid" : value["guid"],"userName" : value["username"],"ntwuserid" : value["ntwuserid"],"emailid" : value["emailid"],"employeeId" : value["employeeid"],"managerName" : value["managername"],"statusFlag" : value["statusflag"]});
			});
			$scope.setApproval();
		},function error(response){
         $rootScope.loaderCurrentStatus = 'false';
 $scope.errorHandler(response.config.url,response.status);
        });
	$scope.setApproval = function() {
		$timeout(function() {
		}, 3000);
	}
}