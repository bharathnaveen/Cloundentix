
	

angular.module('cloudentixApp')	
	.value('clientId', 'true')
	.controller('accpolicy', accpolicy)
	.controller('addaccesspolicyController', addaccesspolicyController)
	accpolicy.$inject = ['$rootScope', '$scope', '$q', '$timeout', '$log' , '$mdMedia', '$mdDialog', '$http', '$rootScope', 'clientId', '$filter', 'SessionService'];
    addaccesspolicyController.$inject = ['$timeout', '$q', '$http', '$scope', '$mdDialog', '$rootScope', '$mdToast', 'SessionService'];

    function accpolicy($rootScope, $scope, $q, $timeout, $log , $mdMedia, $mdDialog, $http, $rootScope, clientId, $filter, SessionService) {
	var baseUrl = sessionStorage.getItem("WS_BASE_URL");
	var checkResourceURL = baseUrl + '/resources?check=true';
			var config = {
				//url:"dashboard/data.json",
				url:checkResourceURL,
				method: "GET",
				headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
				}
			}
			   
			$http(config)
			.success(function(response) {
             if(response.type === 'success'){
				if (response.data.login[0].trusted == 'N' || response.data.login[0].untrusted == 'N') {
                    if (response.data.login[0].trusted == 'N' && response.data.login[0].untrusted == 'N') {
                       $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure trusted and untrusted resources");
                    } else {
                        if (response.data.login[0].trusted == 'N') {
                            $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure the trusted resource");
                        } else if (response.data.login[0].untrusted === 'N') {
                            $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure an untrusted resource");
                        }
                    }
                }
                else if(response.data.login[0].trusted == 'Y' && response.data.login[0].untrusted == 'Y') {
	
	 $rootScope.loaderCurrentStatus = 'true';
var rolename = localStorage.getItem("roleValue");
var roleid = localStorage.getItem("roleId");
var resourceid = localStorage.getItem("RescID");
$scope.rolename = rolename;
$scope.clientId = clientId;
    $scope.promise = $timeout(function () {
      $rootScope.accesspolicyList();
    }, 100);
  $scope.limitOptions = [10, 25, 50, 100];
  $scope.roletext = [];
  $scope.options = {
    rowSelection: false,
    multiSelect: false,
    autoSelect: true,
    decapitate: false,
    largeEditDialog: true,
    boundaryLinks: true,
    limitSelect: true,
    pageSelect: true
  };
  
  $scope.query = {
    order: 'name',
    limit: 10,
    page: 1,
	filter: ''
  };
 $scope.newField = {};
          $scope.editing = false;
		  $scope.i = 1;
      $scope.editAppKey = function(field,checkdropdown,tvalue,i) {
	    void 0
	  if(checkdropdown == 'N'){
	  //console.log($scope.accesspolicylist.accpol_value)
	 $scope.roletext[i] = tvalue;
	 }
	 $scope.clientId = false;
        $scope.editing = $scope.accesspolicylist.indexOf(field);
        $scope.newField = angular.copy(field);
    }
    $scope.save1 = [];
   
   $scope.saveField = function(attribute,operator,value,conditionid,txtval,checkdropdown,index) {
		 $rootScope.loaderCurrentStatus = 'true';
	 $scope.clientId = true;
	 if(checkdropdown == 'N'){
	 $scope.passvalue = $scope.roletext[index];
	 }
	 else {
	 	 $scope.passvalue = value;
	 }
	void 0;
        if ($scope.editing !== false) {
            $scope.accesspolicylist[$scope.editing] = $scope.newField;
            //$scope.editing = false;
        } 
        var userid = localStorage.getItem("userid");
		var updateURL = baseUrl + '/accesspolicy';
      var config = {
			url: updateURL,
			method: "PUT",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
				"cdt-rscid":resourceid,
				"cdt-roleid":roleid,
				"cdt-attribute":attribute,
				"cdt-operator":operator,
				"cdt-value":$scope.passvalue,
				"cdt-acpcondid":conditionid,
                "cdt-loginguid" : userid,
			}
		}
		   
		$http(config)
		.then(function success(response){
 $rootScope.loaderCurrentStatus = 'false';
$scope.editing = false; 
		if(response.data.type == "success"){
            
            
			$scope.toastMessage('toast-success',response.data.message);
			}if(response.data.type == "error"){
			$scope.toastMessage('toast-error',response.data.message);
            
			}if(response.data.type == "warning"){
			$scope.toastMessage('toast-warn',response.data.message);
			}
		//console.log(response.message);
		 $rootScope.accesspolicyList();
		},function error(response){
         $rootScope.loaderCurrentStatus = 'false';
         $rootScope.accesspolicyList();
 $scope.errorHandler(response.config.url,response.status);
        });
   //console.log($scope.save1);		
    };
  $scope.removeRow = function (index,conditionid) {
  
  $scope.enablecontent = 'Are you sure want to delete this rule ';
			$scope.status = '  ';
			$scope.customFullscreen = $mdMedia('xs') || $mdMedia('sm');
			var confirm = $mdDialog.confirm()
			.title('Delete Rule')
			.textContent($scope.enablecontent)
			.ariaLabel('Confirm')
			.cancel('No')
			.ok('Yes');

			$mdDialog.show(confirm).then(function() {
			 var updateURL = baseUrl + '/accesspolicy';
      var config = {
			url: updateURL,
			method: "DELETE",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
				"cdt-rscid":resourceid,
				"cdt-roleid":roleid,
				"cdt-acpcondid":conditionid,
			}
		}
		   
		$http(config)
		.then(function success(response){ 
		//console.log(response.message);
			if(response.data.type == "success"){
			$scope.toastMessage('toast-success',response.data.message);
			}if(response.data.type == "error"){
			$scope.toastMessage('toast-error',response.data.message);
			}if(response.data.type == "warning"){
			$scope.toastMessage('toast-warn',response.data.message);
			}
		$rootScope.accesspolicyList();
		},function error(response) {
				 $rootScope.loaderCurrentStatus = 'false';
 $scope.errorHandler(response.config.url,response.status);	
				});
			}, function() {
			});
      //$scope.accesspolicylist.splice(index, 1);

		
		}
		
		
    $scope.cancel = function(index) {
$scope.clientId = true;
		if ($scope.editing !== false) {
		
            //$scope.accesspolicylist[$scope.editing] = $scope.newField;
            $scope.editing = false;
           
        }  
 $rootScope.accesspolicyList();        
    };
$scope.requestAccess = function($event,$scope) {	

$mdDialog.show({
        controller: addaccesspolicyController,
       controllerAs: 'accesspolicyctrl',
        templateUrl: 'role/sub-role/addAccesspolicy.html',
        parent: angular.element(document.body),
        targetEvent: $event,
		//controller: mdDialogCtrl,
        clickOutsideToClose:false
      })
	  //$rootScope.accesspolicyList();
		}
$scope.ap = 'false';
$rootScope.accesspolicyList = function (){
		var listaccesspolicyURL = baseUrl + '/accesspolicy';
		var config = {
			url: listaccesspolicyURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
				"cdt-rscid":resourceid,
				"cdt-roleid":roleid,
			}
		}
		   
		$http(config)
		.then(function success(response){ 
			$scope.userResponse = response.data.type;
			$scope.accesspolicylist = [];
			$scope.duplicateAccesspolicylist = [];
			$rootScope.loaderCurrentStatus = 'false';
			if(response.data.type == 'success') {
				angular.forEach(response.data.records, function(value, key) {
					$scope.accesspolicylist.push({"accpol_attribute" : value["accpol_attributevalue"],"accpol_operator" : value["accpol_operator"],"accpol_value" : value["accpol_value"],"accpol_condid" : value["accpol_condid"]});
				
				});
			 $scope.duplicateAccesspolicylist = angular.copy($scope.accesspolicylist);
			}
			else{
				$scope.userErrorMessage = response.data.message;
			}
			},function error(response){
             $rootScope.loaderCurrentStatus = 'false';
 $scope.errorHandler(response.config.url,response.status);
            });
		}
		
		$scope.$watch('query.filter', function (newValue, oldValue) {
			if(newValue == '') {
				$scope.accesspolicylist = $scope.duplicateAccesspolicylist;
			}
			if(newValue){
				$scope.items = $filter('filter')($scope.duplicateAccesspolicylist, newValue);
				$scope.accesspolicylist = $scope.items;
			}
		});
		$scope.accpolAttributeList = [];
	$scope.accpoldropdownlist = [];
	$scope.accesspolicyfull = [];
	var requestURL = baseUrl + '/accesspolicy/acpdropdown';
      var config = {
			url: requestURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
			}
		}
		   
		$http(config)
		.then(function success(response){ 
		
		//console.log(response.records);
			  //alert(response.records[0].listAccessRequest[0].rolename)
			angular.forEach(response.data.records, function(value, key) {
			$scope.accesspolicyfull = response.data.records;
			$scope.accpolAttributeList.push({"key" : value["key"],"value" : value["value"],"dropdown":value["dropdown"]});
				
		});
				},function error(response){
                 $rootScope.loaderCurrentStatus = 'false';
 $scope.errorHandler(response.config.url,response.status);
                });
		$scope.changedropdownList = function(value){
		
		
		//alert(value.dropdown);
        $scope.disabled = false;
			for(var i=0;i<$scope.accesspolicyfull.length;i++){
			if(value.dropdown == 'Y'){
            $scope.disabled = true;
			if(value.key == $scope.accesspolicyfull[i].key ){
			$scope.accpoldropdownlist = $scope.accesspolicyfull[i].dropdownlist;
			//console.log($scope.accpoldropdownlist)
			}
		}
		else{
		//console.log("No");
		}
		}
		
		
		}
				}
                }else {
    $rootScope.loaderCurrentStatus = 'false';
 $scope.errorHandler(response.message,response.status);
 
    }
			});
}
function addaccesspolicyController ($timeout, $q, $http, $scope, $mdDialog, $rootScope, $mdToast, SessionService){	
	
var roleid = localStorage.getItem("roleId");
var resourceid = localStorage.getItem("RescID");
var baseUrl = sessionStorage.getItem("WS_BASE_URL");

//console.log(roleList);
	//$scope.resource_id = rscid;
	
  //$scope.selected = [];
var self = this;
		
	self.cancel = function($event) {
      $mdDialog.cancel();
	  //$scope.toastMessage('toast-success','fsfs');
    }
    
	$scope.accAttributeList = [];
	$scope.dropdownlist = [];
	$scope.accesspolicydp = [];
	var requestURL = baseUrl + '/accesspolicy/acpdropdown';
      var config = {
			url: requestURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
			}
		}
		   
		$http(config)
		.then(function success(response){ 
		
		//console.log(response.records);
			  //alert(response.records[0].listAccessRequest[0].rolename)
			angular.forEach(response.data.records, function(value, key) {
			$scope.accesspolicydp = response.data.records;
			$scope.accAttributeList.push({"key" : value["key"],"value" : value["value"],"dropdown":value["dropdown"]});
				
		});
				},function error(){
                 $rootScope.loaderCurrentStatus = 'false';
                $scope.errorHandler(response.config.url,response.status);
                });
		
		$scope.changeList = function(value){
		//alert();
		$scope.requestaccess.$setUntouched();
   $scope.requestaccess.$setPristine(true);
		if(value.dropdown == 'Y'){
			for(var i=0;i<$scope.accesspolicydp.length;i++){
			if(value.key == $scope.accesspolicydp[i].key){
			
			$scope.dropdownlist = $scope.accesspolicydp[i].dropdownlist;
			//console.log($scope.dropdownlist)
			}
		}
		}
		
		else{
		void 0;
		}
		}
	self.finish = function($event) {
	if($scope.selected.dropdown == 'Y'){
	$scope.finalvalue = $scope.roleValue.key;
	}else{
	$scope.finalvalue = $scope.roletext;
	}
	void 0
	//console.log($scope.resource_id);
	//console.log($scope.role.lookupkey);
    var userid = localStorage.getItem("userid");
	var createruleURL = baseUrl + '/accesspolicy';
      var config = {
			url: createruleURL,
			method: "POST",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
				"cdt-rscid":resourceid,
				"cdt-roleid":roleid,
				"cdt-attribute":$scope.selected.key,
				"cdt-operator":$scope.symbol,
				"cdt-value":$scope.finalvalue,
                "cdt-loginguid" : userid,
			}
		}
		   
		$http(config)
		.then(function success(response){ 
		var icon;
	if(response.data.type == 'success'){
		icon = 'done';
	}  else if(response.data.type == 'error'){
		icon = 'error_outline';
	} else if(response.data.type == 'warn'){
		icon = 'warning';
	} else{
		icon = 'info_outline';
	}
			$mdDialog.hide();
			 $mdToast.show({
        template : '<md-toast class="md-toast toast-'+response.data.type+'"><div class="md-toast-content"><i class="material-icons">'+icon+'</i>&nbsp;&nbsp; '+ response.data.message + '!</div></md-toast>',
         hideDelay: 3000,
         position: 'top right'
		});
			//alert(response.message)
			 //$scope.toastMessage('toast-success',response.message);
			$rootScope.accesspolicyList();	
			});
	   
    };
	
}
