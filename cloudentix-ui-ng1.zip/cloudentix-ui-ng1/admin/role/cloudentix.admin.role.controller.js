angular.module('cloudentixApp')
    .controller('listroles', listroles);
listroles.$inject = ['$rootScope', '$scope', '$log', '$location', '$window', '$timeout', '$http', '$q', '$filter', '$state', 'SessionService'];

function listroles($rootScope, $scope, $log, $location, $window, $timeout, $http, $q, $filter, $state, SessionService) {
    var baseUrl = sessionStorage.getItem("WS_BASE_URL");
    var checkResourceURL = baseUrl + '/resources?check=true';
    var config = {
        //url:"dashboard/data.json",
        url: checkResourceURL,
        method: "GET",
        headers: {
            "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
        }
    }

    $http(config)
        .success(function (response) {
            if (response.type == 'success') {
                if (response.data.login[0].trusted == 'N' || response.data.login[0].untrusted == 'N') {
                    if (response.data.login[0].trusted == 'N' && response.data.login[0].untrusted == 'N') {
                        $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure trusted and untrusted resources");
                    } else {
                        if (response.data.login[0].trusted == 'N') {
                            $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure the trusted resource");
                        } else if (response.data.login[0].untrusted === 'N') {
                            $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure an untrusted resource");
                        }
                    }
                }
                else if (response.data.login[0].trusted == 'Y' && response.data.login[0].untrusted == 'Y') {
                    $scope.total;
                    $rootScope.loaderCurrentStatus = 'true';

                    var listresourcesURL = baseUrl + '/listresources';
                    var config = {
                        url: listresourcesURL,
                        method: "GET",
                        headers: {
                            "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                        }
                    }

                    $http(config)
                        .then(function success(response) {
                            $scope.userResponse = response.data.type;
                            $rootScope.loaderCurrentStatus = 'false';
                            $scope.resourceList = [];
                            if (response.data.type == "success") {
                                angular.forEach(response.data.records[0].rscdetails, function (value, key) {
                                    $scope.resourceList.push({ "rescId": value["rescid"], "rescName": value["rescname"], "tarflag": value["tarflag"] });
                                });
                            } else {
                                $scope.userErrorMessage = response.data.message;
                            }

                        }, function error(response) {
                            $rootScope.loaderCurrentStatus = 'false';
                            $scope.errorHandler(response.config.url, response.status);
                        });

                    // Data Table

                    $scope.selected = [];
                    $scope.limitOptions = [10, 25, 50, 100];

                    $scope.options = {
                        rowSelection: true,
                        multiSelect: false,
                        autoSelect: true,
                        decapitate: false,
                        largeEditDialog: true,
                        boundaryLinks: true,
                        limitSelect: true,
                        pageSelect: true
                    };

                    $scope.query = {
                        order: 'name',
                        limit: 10,
                        page: 1,
                        filter: ''
                    };

                    $scope.getroles = function (rscid, rsctype, rescname, startrecord, endrecord) {
                        //Resource ID 
                        void 0
                        if (startrecord) {
                            sessionStorage.setItem("RescID", rscid);
                            localStorage.setItem("RescID", rscid);
                            localStorage.setItem("RescType", rsctype);
                            localStorage.setItem("RescName", rescname);
                        }
                        // var a = "Resource " + $scope.itemSelected.rescName +" selected"
                        //console.log(a);
                        // $scope.toastMessage('toast-info',a);
                        var listrolesURL = baseUrl + '/list/getroles';
                        if (startrecord) {
                            var params = {
                                start: startrecord,
                                size: endrecord,
                            }
                        } else {
                            var params = {
                                start: 1,
                                size: 10,
                            }
                        }
                        var config = {
                            url: listrolesURL,
                            method: "GET",
                            params: params,
                            headers: {
                                "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                                "cdt-rscid": rscid,
                            }
                        }

                        $http(config)
                            .then(function success(response) {
                                console.log(response, 'Role Res');
                                if (response.data.type == 'success') {
                                    $scope.roleList = [];
                                    $scope.duplicateroleList = [];
                                    angular.forEach(response.data.records[0].dropdownlist, function (value, key) {
                                        $scope.roleList.push({ "key": value["key"], "value": value["value"], "approvalpolicy": value["approvalpolicy"], "accesspolicy": value["accesspolicy"] });
                                    });
                                    $scope.duplicateroleList = angular.copy($scope.roleList);
                                    //$scope.itemSelected = {"resource_name" :$scope.values['0'].resource_name}
                                } else {
                                    $scope.toastMessage('toast-error', response.data.message);
                                }
                            }, function error(response) {
                                $rootScope.loaderCurrentStatus = 'false';
                                $scope.errorHandler(response.config.url, response.status);
                            });
                    }

                    $scope.onPaginate = function () {
                        var rscid = localStorage.getItem("RescID");
                        var rsctype = localStorage.getItem("RescType");
                        var rescname = localStorage.getItem("RescName");
                        var startrecord = ($scope.query.page * $scope.query.limit) - $scope.query.limit + 1;
                        var endrecord = $scope.query.page * $scope.query.limit;
                        $scope.getroles(rscid, rsctype, rescname, startrecord, endrecord);
                    }

                    $scope.$watch('query.filter', function (newValue, oldValue) {
                        if (newValue == '') {
                            $scope.roleList = $scope.duplicateroleList;
                        }
                        if (newValue) {
                            $scope.items = $filter('filter')($scope.duplicateroleList, newValue);
                            $scope.roleList = $scope.items;
                        }
                    });

                    $scope.toggleLimitOptions = function () {
                        $scope.limitOptions = $scope.limitOptions ? undefined : [10, 25, 50, 100];
                    };

                    $scope.getTypes = function () {
                        return ['Candy', 'Ice cream', 'Other', 'Pastry'];
                    };

                    $scope.loadStuff = function () {
                        $scope.promise = $timeout(function () {
                            $scope.getroles($scope.itemSelected.rescId);
                        }, 1000);
                    }
                    $scope.checkpolicy = function (resourcetype, Y) {

                        $scope.promise1 = $timeout(function () {
                            //$scope.getroles($scope.itemSelected.rescId);
                        }, 1000);
                        void 0;
                        localStorage.setItem("roleValue", Y.value);
                        localStorage.setItem("roleId", Y.key);
                        localStorage.setItem("approvalpolicy", Y.approvalpolicy);
                        if (resourcetype == 'Y') {
                            $state.go("roleView.approvalpolicy");
                            $scope.addTab('Role View', 'roleView.approvalpolicy');
                            //alert('hi')	
                        } else {
                            $state.go("roleView.accesspolicy");
                            $scope.addTab('Role View', 'roleView.accesspolicy');
                            //alert('hifff');	
                        }
                        //alert('hifdsfsdf')
                    }
                    $scope.logItem = function (roleList) {
                        void 0;
                        sessionStorage.setItem("roleValue", roleList.value);
                        sessionStorage.setItem("roleId", roleList.key);
                        sessionStorage.setItem("approvalpolicy", roleList.approvalpolicy);
                        localStorage.setItem("roleValue", roleList.value);
                        localStorage.setItem("roleId", roleList.key);
                        localStorage.setItem("approvalpolicy", roleList.approvalpolicy);
                    };

                    $scope.logOrder = function (order) {
                        void 0;
                    };

                    $scope.logPagination = function (page, limit) {
                        void 0;
                        void 0;
                    }

                    var deferred = $q.defer();
                    $scope.promise = deferred.promise;
                    // ...
                    deferred.resolve();
                }
            } else {
                $rootScope.loaderCurrentStatus = 'false';
                $scope.errorHandler(response.message, response.status);

            }
        });

}