angular.module('cloudentixApp')
.controller('usernotProvision', usernotProvision)
usernotProvision.$inject = ['$rootScope', '$scope', '$http', 'storeNotprovision'];
function usernotProvision($rootScope, $scope, $http, storeNotprovision) {
		'use strict';
		$scope.selected = [];
		$scope.limitOptions = [10, 25, 50, 100];
		$scope.options = {
			rowSelection: false,
			multiSelect: false,
			autoSelect: true,
			decapitate: false,
			largeEditDialog: true,
			boundaryLinks: true,
			limitSelect: true,
			pageSelect: true
		};
		$scope.query = {
			order: 'name',
			limit: 10,
			page: 1
		};
		$scope.toggleLimitOptions = function () {
		$scope.limitOptions = $scope.limitOptions ? undefined : [10, 25, 50, 100];
	};
	$scope.getTypes = function () {
		return ['Candy', 'Ice cream', 'Other', 'Pastry'];
	};
	$scope.logItem = function (item) {
		console.log(item.name, 'was selected');
	};
	$scope.logOrder = function (order) {
		console.log('order: ', order);
	};
	  
	$scope.logPagination = function (page, limit) {
		console.log('page: ', page);
		console.log('limit: ', limit);
	}	
	$scope.userNotProvisionlist = storeNotprovision.putnotProvision();
	if($scope.userNotProvisionlist == '') {
		$scope.userNotProvisionlist = undefined;
	}
}