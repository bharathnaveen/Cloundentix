angular
    .module('cloudentixApp')
	.controller('managesetfrequency', setfrequency)
	.service('storeNotprovision', function() {
		this.getnotProvision = function(notuser, user) {
			this.getuser = user;
			this.getnotuser = notuser;
		}
		this.putnotProvision = function() {
			return this.getnotuser;
		}
		this.putProvision = function() {
			return this.getuser;
		}
	})
	.filter( 'monthfilter', function() {
        return function( input ) {
            if (input == "1") {
                return input= input + ' Month';
            } else {
                return input= input + ' Months';
            }
        };
    })
    setfrequency.$inject = ['$scope', '$rootScope', '$http',  '$mdDialog', '$mdMedia', '$mdToast', 'storeNotprovision', 'SessionService'];
    function setfrequency($scope, $rootScope, $http,  $mdDialog, $mdMedia, $mdToast, storeNotprovision, SessionService) {
        var baseUrl = sessionStorage.getItem("WS_BASE_URL");
        var checkResourceURL = baseUrl + '/resources?check=true';
		var config = {
			url: checkResourceURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
			}
		}
		$http(config).success(function(response) {
               if(response.type === 'success'){
			if (response.data.login[0].trusted == 'N' || response.data.login[0].untrusted == 'N') {
                if (response.data.login[0].trusted == 'N' && response.data.login[0].untrusted == 'N') {
                       $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure trusted and untrusted resources");
                } else {
                    if (response.data.login[0].trusted == 'N') {
                        $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure the trusted resource");
                    } else if (response.data.login[0].untrusted === 'N') {
                        $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure an untrusted resource");
                    }
                }
            }
            else if(response.data.login[0].trusted == 'Y' && response.data.login[0].untrusted == 'Y') {
                $rootScope.loaderCurrentStatus = 'true';
                $scope.setrequency = ['1','2','3','4','5','6','7','8','9','10','11','12'];
                $scope.sethour = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23];
                $scope.setminute = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59];
                var setFrequencyURL = baseUrl + '/frequency';
                var userid = localStorage.getItem("userid");
                $scope.setFrequency = function() {
                    var config = {
                        url: setFrequencyURL,
                        method: "POST",
                        headers: {
                            "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                            //"cdt-hours": $scope.getHour,
                            //"cdt-minutes": $scope.getMinute,
                            "cdt-month": $scope.getfrequency,
                            "cdt-loginguid" : userid,
                        }
                    }
                    $http(config).success(function(response) {
                        if(response.type == "success") {
                           $scope.toastMessage('toast-success',response.message);
                        }
                        if(response.type == "error") {
                           $scope.toastMessage('toast-error',response.message);
                        }
                        if(response.type == "warning") {
                           $scope.toastMessage('toast-warn',response.message);
                        }
                    })
                    .error(function(data) {
                    });
                }
                $scope.getselectedFrequency = function() {
                    var getFrequencyURL = baseUrl + '/frequency';
                    var config = {
						url: getFrequencyURL,
						method: "GET",
						headers: {
							"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
						}
					}
					$http(config).success(function(response) {
						 $rootScope.loaderCurrentStatus = 'false';
						if(response.type == "success"){
							$scope.getHour = response.data.hour;
							$scope.getMinute = response.data.minute;
							$scope.getfrequency = response.data.months;
						}
					})
					.error(function(data) {
                    });
                }
                $scope.runReconciliation = function() {
                    var resourceReconciled;
                    $rootScope.loaderCurrentStatus = 'true';
                    var listResourceURL = baseUrl + '/resources/list';
                    var config = {
                        url: listResourceURL,
                        method: "GET",
                        headers: {
                                "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                        }
                    }
                    $http(config).success(function(response) {
                        if(response.type == 'success') {
                            resourceReconciled = response.records[0].rscdetails.length + ' Resources Reconciled';
                        }
                    })
                    var autoprovisioningURL = baseUrl + '/autoprov';
                    var userid = localStorage.getItem("userid");
                    var config = {
						url: autoprovisioningURL,
						method: "GET",
						headers: {
							"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                            "cdt-loginguid" : userid,
						}
					}
					$http(config).success(function(response) {
						$rootScope.loaderCurrentStatus = 'false';
						if(response.type == "success") {
							$scope.notuserProvisionedData = [];
							angular.forEach(response.records[0].autoprovision[0].notprovisioned, function(value, key) {
								$scope.notuserProvisionedData.push({"Guid" : value["guid"],"Username" : value["username"],"resourcename" : value["resourcename"],"status" : value["status"]});
							});
							$scope.userProvisionedData = [];
							angular.forEach(response.records[0].autoprovision[0].provisioned, function(value, key) {
								$scope.userProvisionedData.push({"Guid" : value["guid"],"Username" : value["username"],"resourcename" : value["resourcename"],"status" : value["status"]});
							});
							void 0;
							storeNotprovision.getnotProvision($scope.notuserProvisionedData, $scope.userProvisionedData);
							$scope.toastMessage('toast-success',response.message);
							$scope.ResourceReconciled = resourceReconciled;
							$scope.userprovisioned = 'User Provisioned ' + response.records[0].autoprovision[0].provisionedcount;
							$scope.notuserprovisioned = 'User Not Provisioned ' + response.records[0].autoprovision[0].notprovisionedcount;
						}
						if(response.type == "error") {
						   $scope.toastMessage('toast-error', response.message);
						}
						if(response.type == "warning") {
						   $scope.toastMessage('toast-warn', response.message);
						} 
					})
					.error(function(data) {
                    $rootScope.loaderCurrentStatus = 'false';
                    $scope.errorHandler(response.config.url,response.status);
					});
                }
                $scope.getselectedFrequency();
			}
            }else {
    $rootScope.loaderCurrentStatus = 'false';
 $scope.errorHandler(response.message,response.status);
 
    }
		});
    };