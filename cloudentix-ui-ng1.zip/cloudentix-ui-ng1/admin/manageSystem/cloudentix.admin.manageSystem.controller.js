angular
    .module('cloudentixApp')
    .controller('manageSystemUserAttributes', manageSystemUserAttributes)
    .controller('addUserAttributeCtrl', addUserAttributeCtrl)
    .controller('editUserAttributeCtrl', editUserAttributeCtrl)
    manageSystemUserAttributes.$inject = ['$rootScope', '$mdEditDialog', '$q', '$scope','$timeout', '$http',  '$mdDialog', '$mdMedia', '$mdToast', '$filter', 'SessionService'];
    addUserAttributeCtrl.$inject = ['$http', '$mdDialog', '$rootScope', '$scope', '$controller', '$mdToast', '$window', 'SessionService'];
    editUserAttributeCtrl.$inject = ['$http', '$mdDialog', '$rootScope', '$scope', '$controller', 'attributeID', '$mdToast', 'SessionService'];
    function manageSystemUserAttributes($rootScope, $mdEditDialog, $q, $scope, $timeout, $http,  $mdDialog, $mdMedia, $mdToast, $filter, SessionService) {
        'use strict';
        var baseUrl = sessionStorage.getItem("WS_BASE_URL");
        $rootScope.loaderCurrentStatus = 'true';
        $scope.selected = [];
        $scope.limitOptions = [10, 25, 50, 100];
        $scope.options = {
            rowSelection: false,
            multiSelect: false,
            autoSelect: true,
            decapitate: false,
            largeEditDialog: true,
            boundaryLinks: true,
            limitSelect: true,
            pageSelect: true
        };
        $scope.query = {
            order: 'name',
            limit: 10,
            page: 1,
            filter: ''
        };
        $rootScope.loadUserAttribute = function () {
            var userAttributeURL = baseUrl + '/userattributes';
            var config = {
                url: userAttributeURL,
                method: "GET",
                headers: {
                    "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                }
            }
            $http(config).then(function success(response) { 
                $scope.managesystemResponse = response.data.type;
                $rootScope.loaderCurrentStatus = 'false';
                if(response.data.type == "success") {
                    $rootScope.attributesList = response.data.records[0].listattributes;
                    $scope.duplicateAttributeList = angular.copy($scope.attributesList);
                } else {
                    $scope.managesystemErrorMessage = response.data.message;
                }	
            },function error(response){
                $rootScope.loaderCurrentStatus = 'false';
                $scope.errorHandler(response.config.url,response.status);
            });
        };
        $scope.$watch('query.filter', function (newValue, oldValue) {
            if(newValue == '') {
                $rootScope.attributesList = $scope.duplicateAttributeList;
            }
            if(newValue){
                $scope.items = $filter('filter')($scope.duplicateAttributeList, newValue);
                $rootScope.attributesList = $scope.items;
            }
        });
        
        $rootScope.loadUserAttribute();
        $scope.addUserAttribute = function() {
            $mdDialog.show({
                controller: addUserAttributeCtrl,
                templateUrl: 'manageSystem/cloudentix-admin-userattribute.html',
                parent: angular.element(document.body),
                clickOutsideToClose:false
            })
        }

        $scope.editUserAttribute = function(id) {
            $scope.getuserattr = id;
            $mdDialog.show({
                locals: {
                    attributeID: $scope.getuserattr
                },  
                controller: editUserAttributeCtrl,
                templateUrl: 'manageSystem/cloudentix-admin-editUserattribute.html',
                parent: angular.element(document.body),
                clickOutsideToClose:false
            })
        }
        $scope.deleteUserAttribute = function(attrid, attrname) {
			$scope.attestcontent = 'Would you like to delete the attribute name ' + attrname;
			var confirm = $mdDialog.confirm()
			.title('User Attribute')
			.textContent($scope.attestcontent)
			.ariaLabel('Confirm')
			.ok('Yes')
			.cancel('No');
			$mdDialog.show(confirm).then(function() {
				$rootScope.loaderCurrentStatus = 'true';
                    var userid = localStorage.getItem("userid");
				var deleteUserAttributeURL = baseUrl + '/userattributes';
				var config = {
					url: deleteUserAttributeURL,
					method: "DELETE",
					headers: {
						"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
						"cdt-userattrid": attrid,
                         //"cdt-loginguid": userid,
					}
				}
				$http(config).then(function success(response) {
                    if(response.data.type == "success") {
                        $rootScope.loadUserAttribute();
                        $scope.toastMessage('toast-success',response.data.message);
                    } else if(response.data.type == "error") {
                        $scope.toastMessage('toast-error',response.data.message);
                    } else if(response.data.type == "warning") {
                        $scope.toastMessage('toast-warn',response.data.message);
                    } else {
                        $scope.toastMessage('toast-error',response.data.message);
                    }
				},function error(response) {
                    $rootScope.loaderCurrentStatus = 'false';
                    $scope.errorHandler(response.config.url,response.status);
				});
			}, function() {
			});
        }
    };
    function addUserAttributeCtrl($http, $mdDialog, $rootScope, $scope, $controller, $mdToast, $window, SessionService) {
        var baseUrl = sessionStorage.getItem("WS_BASE_URL");
        $scope.editoption = true;
        $scope.displayoption = true;
        $scope.mappingoption = true;
        $scope.uniqueoption = true;
        $scope.addAttributeClose = function() {
            $mdDialog.hide();
        };
        $scope.cancelAddAttribute = function() {
           $mdDialog.cancel();
        };
        $scope.submitAddAttribute = function(isValid) {
            var userid = localStorage.getItem("userid");
            var addDisplayName =  $scope.attributeName;
			var addDescription =  $scope.description.replace(/[\r\n]/g, ' ');
            var addEditoption =  $scope.editoption == true && 'Y' || 'N';
            var addDisplayoption =  $scope.displayoption == true && 'Y' || 'N';
            var addMappingoption =  $scope.mappingoption == true && 'Y' || 'N';
            var addUniqueoption = $scope.uniqueoption == true && 'Y' || 'N';
            if (isValid) {
                $rootScope.loaderCurrentStatus = 'true';
                var addUserAttributeURL = baseUrl + '/userattributes'; 
                var config = {
                    url: addUserAttributeURL,
                    method: "POST",
                    headers: {
                        "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                        "cdt-displayname": addDisplayName,
                        "cdt-description": addDescription,
                        "cdt-editflag": addEditoption,
                        "cdt-displayflag": addDisplayoption,
                        "cdt-uniqueflag": addUniqueoption,
                        "cdt-mappingflag": addMappingoption,
                        "cdt-loginguid": userid,
                    }
                }
                $http(config).then(function success(response) {
                    $rootScope.loaderCurrentStatus = 'false';
                    var icon;
                    if(response.data.type == 'success') {
                        $rootScope.loadUserAttribute();
                        icon = 'done';
                        $mdDialog.hide();
                    } else if(response.data.type == 'error') {
                        icon = 'error_outline';
                    } else if(response.data.type == 'warn') {
                        icon = 'warning';
                    } else {
                        icon = 'info_outline';
                    }
                    $mdToast.show({
                        template : '<md-toast class="md-toast toast-'+response.data.type+'"><div class="md-toast-content"><i class="material-icons">'+icon+'</i>&nbsp;&nbsp; '+ response.data.message + '!</div></md-toast>',
                        hideDelay: 3000,
                        position: 'top right'
                    });
                },function error(response) {
                    $rootScope.loaderCurrentStatus = 'false';
                    $scope.errorHandler(response.config.url,response.status);
				});	
            }
        }
    }
    function editUserAttributeCtrl($http, $mdDialog, $rootScope, $scope, $controller, attributeID, $mdToast, SessionService) {
        var baseUrl = sessionStorage.getItem("WS_BASE_URL");
        var editUserAttributeURL = baseUrl + '/userattributes?format=json&attrid='
        var config = {
            url: editUserAttributeURL + attributeID,
            method: "GET",
            headers: {
                "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
            }
        }
        $http(config).success(function(response) {
            $scope.editAttributeName =  response.records[0].listattributes[0]["displayname"];
            $scope.editDescription = response.records[0].listattributes[0]["description"]
            $scope.editEditoption =  response.records[0].listattributes[0]["editflag"] == "Y" && true || false;
            $scope.editDisplayoption =  response.records[0].listattributes[0]["displayflag"] == "Y" && true || false;
            $scope.editMappingoption =  response.records[0].listattributes[0]["mappingflag"] == "Y" && true || false;
            $scope.editUniqueoption = response.records[0].listattributes[0]["uniqueflag"] == "Y" && true || false;
        })
        .error(function(data) {
            $rootScope.loaderCurrentStatus = 'false';
            $scope.errorHandler(response.config.url,response.status);              
        });	
        $scope.editAttributeClose = function() {
            $mdDialog.hide();
        };
        $scope.cancelEditAttribute = function() {
            $mdDialog.cancel();
        };
        $scope.submiteditAttribute = function(isValid) {
            if (isValid) {
                $rootScope.loaderCurrentStatus = 'true';
                updateAttributeName =  $scope.editAttributeName;
                updateDescription = $scope.editDescription.replace(/[\r\n]/g, ' ');
                updateEditoption =  $scope.editEditoption == true && 'Y' || 'N';
                updateDisplayoption =  $scope.editDisplayoption == true && 'Y' || 'N';
                updateMappingoption =  $scope.editMappingoption == true && 'Y' || 'N';
                updateUniqueoption = $scope.editUniqueoption == true && 'Y' || 'N';
                var updateUserAttributeURL = baseUrl + '/userattributes';
                var userid = localStorage.getItem("userid");
                var config = {
                    url: updateUserAttributeURL,
                    method: "PUT",
                    headers: {
                        "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                        "cdt-userattrid" : attributeID,
                        "cdt-displayname": updateAttributeName,
                        "cdt-description": updateDescription,
                        "cdt-editflag": updateEditoption,
                        "cdt-displayflag": updateDisplayoption,
                        "cdt-uniqueflag": updateUniqueoption,
                        "cdt-mappingflag": updateMappingoption,
                        "cdt-loginguid" : userid,
                    }
                }
                $http(config).success(function(response) {
                    var icon;
                    $rootScope.loaderCurrentStatus = 'false';
                    if(response.type == 'success') {
                        icon = 'done';
                        $rootScope.loadUserAttribute();
                        $mdDialog.hide();
                    } else if(response.type == 'error') {
                        icon = 'error_outline';
                    } else if(response.type == 'warn') {
                        icon = 'warning';
                    } else{
                        icon = 'info_outline';
                    }
                    $mdToast.show({
                        template : '<md-toast class="md-toast toast-'+response.type+'"><div class="md-toast-content"><i class="material-icons">'+icon+'</i>&nbsp;&nbsp; '+ response.message + '!</div></md-toast>',
                        hideDelay: 3000,
                        position: 'top right'
                    });
                })
                .error(function(data) {
                    $rootScope.loaderCurrentStatus = 'false';
                    $scope.errorHandler(response.config.url,response.status);
                });	
            }
        }
    }