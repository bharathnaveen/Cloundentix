
// angular.module('cloudentixApp')
//   .controller('SGDashboardController', SGDashboardController);

// SGDashboardController.$inject = ['$scope', '$rootScope', 'SGdataService'];

// function SGDashboardController($scope, $rootScope, SGdataService) {

  
//   $scope.selected = [];
//   $scope.limitOptions = [10, 25, 50, 100];

//   $scope.options = {
//     rowSelection: false,
//     multiSelect: false,
//     autoSelect: true,
//     decapitate: false,
//     largeEditDialog: true,
//     boundaryLinks: true,
//     limitSelect: true,
//     pageSelect: true
// };

//   $scope.query = {
//     order: 'name',
//     limit: 10,
//     page: 1
//   };

  
//   $scope.getData = function (startrecord, endrecord) {
//     console.log('Sg inner dashboard');
//     var url = '/dashboard';
//     if (startrecord) {
//       var params = {
//         start: startrecord,
//         end: endrecord
//       }
//     } else {
//       var params = {
//         start: 1,
//         end: 10
//       }
//     }
//     $rootScope.loaderCurrentStatus = 'true';
//     SGdataService.getData(url, params).then(successHandler, errorHandler);

//     function successHandler(response) {
//       $scope.sgdashboard = response.record;
      
//     //   $scope.sgdashboard = [
//     //     {
//     //     datasource: "ACTIVEDIRECTORY" + index,
//     //     frequency: "Weekly"  + index,
//     //     lastuploadeddate:"2014-06-10"  + index,
//     //     lastuploadedqm:"Q2"  + index,
//     //     nextuploadeddate:"2014-06-17" + index,
//     //     nextuploadedqm:"Q2xvxxv" + index
//     //   },
//     //   {
//     //     datasource: "ACTIVEDIRECTORY" + index,
//     //     frequency: "Weekly" + index,
//     //     lastuploadeddate:"2014-06-10" + index,
//     //     lastuploadedqm:"Q2" + index,
//     //     nextuploadeddate:"2014-06-17" + index,
//     //     nextuploadedqm:"Q2hghfg" + index
//     //   },
//     //   {
//     //     datasource: "ACTIVEDIRECTORY" + index,
//     //     frequency: "Weekly" + index,
//     //     lastuploadeddate:"2014-06-10" + index,
//     //     lastuploadedqm:"Q2",
//     //     nextuploadeddate:"2014-06-17" + index,
//     //     nextuploadedqm:"Q2ggg" + index
//     //   },
//     //   {
//     //     datasource: "ACTIVEDIRECTORY" + index,
//     //     frequency: "Weekly" + index,
//     //     lastuploadeddate:"2014-06-10" + index,
//     //     lastuploadedqm:"Q2" + index,
//     //     nextuploadeddate:"2014-06-17" + index,
//     //     nextuploadedqm:"Q2lll" + index
//     //   },
//     //   {
//     //     datasource: "ACTIVEDIRECTORY" + index,
//     //     frequency: "Weekly" + index,
//     //     lastuploadeddate:"2014-06-10" + index,
//     //     lastuploadedqm:"Q2" + index,
//     //     nextuploadeddate:"2014-06-17" + index,
//     //     nextuploadedqm:"Q2gfdghh" + index
//     //   },
//     //   {
//     //     datasource: "ACTIVEDIRECTORY" + index,
//     //     frequency: "Weekly" + index,
//     //     lastuploadeddate:"2014-06-10" + index,
//     //     lastuploadedqm:"Q2" + index,
//     //     nextuploadeddate:"2014-06-17" + index,
//     //     nextuploadedqm:"Q2gfdghh" + index
//     //   },
//     //   {
//     //     datasource: "ACTIVEDIRECTORY" + index,
//     //     frequency: "Weekly" + index,
//     //     lastuploadeddate:"2014-06-10" + index,
//     //     lastuploadedqm:"Q2" + index,
//     //     nextuploadeddate:"2014-06-17" + index,
//     //     nextuploadedqm:"Q2gfdghh" + index
//     //   },
//     //   {
//     //     datasource: "ACTIVEDIRECTORY" + index,
//     //     frequency: "Weekly" + index,
//     //     lastuploadeddate:"2014-06-10" + index,
//     //     lastuploadedqm:"Q2" + index,
//     //     nextuploadeddate:"2014-06-17" + index,
//     //     nextuploadedqm:"Q2gfdghh" + index
//     //   },
//     //   {
//     //     datasource: "ACTIVEDIRECTORY" + index,
//     //     frequency: "Weekly" + index,
//     //     lastuploadeddate:"2014-06-10" + index,
//     //     lastuploadedqm:"Q2" + index,
//     //     nextuploadeddate:"2014-06-17" + index,
//     //     nextuploadedqm:"Q2gfdghh" + index
//     //   },
//     //   {
//     //     datasource: "ACTIVEDIRECTORY" + index,
//     //     frequency: "Weekly" + index,
//     //     lastuploadeddate:"2014-06-10" + index,
//     //     lastuploadedqm:"Q2" + index,
//     //     nextuploadeddate:"2014-06-17" + index,
//     //     nextuploadedqm:"Q2gfdghh" + index
//     //   },
//     //   {
//     //     datasource: "ACTIVEDIRECTORY" + index,
//     //     frequency: "Weekly" + index,
//     //     lastuploadeddate:"2014-06-10" + index,
//     //     lastuploadedqm:"Q2" + index,
//     //     nextuploadeddate:"2014-06-17" + index,
//     //     nextuploadedqm:"Q2gfdghh" + index
//     //   },
//     //   {
//     //     datasource: "ACTIVEDIRECTORY" + index,
//     //     frequency: "Weekly" + index,
//     //     lastuploadeddate:"2014-06-10" + index,
//     //     lastuploadedqm:"Q2" + index,
//     //     nextuploadeddate:"2014-06-17" + index,
//     //     nextuploadedqm:"Q2gfdghh" + index
//     //   },
//     //   {
//     //     datasource: "ACTIVEDIRECTORY" + index,
//     //     frequency: "Weekly" + index,
//     //     lastuploadeddate:"2014-06-10" + index,
//     //     lastuploadedqm:"Q2" + index,
//     //     nextuploadeddate:"2014-06-17" + index,
//     //     nextuploadedqm:"Q2gfdghh" + index
//     //   }
//     // ]
//     //   //console.log($scope.sgdashboard);
//     //   for(var i=0; i<$scope.sgdashboard.length; i++){
//     //     var index = i + 1;
//     //     //console.log(index);
//     //   }
//       $rootScope.loaderCurrentStatus = 'false';
//     }
//   }

//   $scope.onPaginate = function () {
//     var startrecord = ($scope.query.page * $scope.query.limit) - $scope.query.limit + 1;
//     var endrecord = $scope.query.page * $scope.query.limit;
//     $scope.getData(startrecord, endrecord);
//   }

//   $scope.toggleLimitOptions = function () {
//     $scope.limitOptions = $scope.limitOptions ? undefined : [10, 25, 50, 100];
//   };

//   $scope.logItem = function (item) {
//     console.log(item.name, 'was selected');
//   };

//   $scope.logOrder = function (order) {
//     console.log('order: ', order);
//   };

//   $scope.logPagination = function (page, limit) {
//     console.log('page: ', page);
//     console.log('limit: ', limit);
//   }

//   function errorHandler(e) {
//     console.log(e.toString());
//   }
//   $scope.getData();
// }



//   // const baseUrl = sessionStorage.getItem('WS_BASE_URL');
//   // /* base Url for list resource */
//   // const checkResourceURL = `${baseUrl}/resources?check=true`;
//   // const config = {
//   //   url: checkResourceURL,
//   //   method: 'GET',
//   //   headers: {
//   //     Authorization: `Basic ${btoa(`${SessionService.defaultusername}:${SessionService.defaultpassword}`)}`,
//   //   },
//   // };
//   // $http(config)
//   //   .success((response) => {
//   //     /*  check two resources (trusted and untrusted)available in if not it is navigated to add resource */
//   //     if (response.type == 'success') {
//   //       if (response.data.login[0].trusted == 'N' || response.data.login[0].untrusted == 'N') {
//   //         if (response.data.login[0].trusted == 'N' && response.data.login[0].untrusted == 'N') {
//   //           $scope.resouceconfigureMessage('Cloudentix requires atleast one trusted and untrusted resource.Please configure trusted and untrusted resources');
//   //         } else if (response.data.login[0].trusted == 'N') {
//   //           $scope.resouceconfigureMessage('Cloudentix requires atleast one trusted and untrusted resource.Please configure the trusted resource');
//   //         } else if (response.data.login[0].untrusted === 'N') {
//   //           $scope.resouceconfigureMessage('Cloudentix requires atleast one trusted and untrusted resource.Please configure an untrusted resource');
//   //         }
//   //       }
//   //       /* if two resources (trusted and untrusted) is configured then proceeds */
//   //       else if (response.data.login[0].trusted == 'Y' && response.data.login[0].untrusted == 'Y') {
//   //         /* it clear service data */
//   //         keepInputfields.storedata = {};
//   //         let convertUserguid;
//   //         keepInputfields.storeTrusteddata = {};
//   //         keepInputfields.storerolesdata.listroles = [];
//   //         $scope.selected = [];
//   //         $scope.limitOptions = [10, 25, 50, 100];
//   //         $scope.options = {
//   //           rowSelection: false,
//   //           multiSelect: false,
//   //           autoSelect: true,
//   //           decapitate: false,
//   //           largeEditDialog: true,
//   //           boundaryLinks: true,
//   //           limitSelect: true,
//   //           pageSelect: true,
//   //         };
//   //         $scope.query = {
//   //           order: 'name',
//   //           limit: 10,
//   //           page: 1,
//   //           filter: '',
//   //         };
//   //         $scope.loadData = function () {
//   //           $rootScope.loaderCurrentStatus = 'true';
//   //           const listUser = `${baseUrl}/users`;
//   //           const userid = localStorage.getItem('userid');
//   //           $scope.adminid = userid;
//   //           const usertype = localStorage.getItem('usertype');
//   //           const config = {
//   //             url: listUser,
//   //             method: 'GET',
//   //             headers: {
//   //               Authorization: `Basic ${btoa(`${SessionService.defaultusername}:${SessionService.defaultpassword}`)}`,
//   //               'cdt-loginguid': userid,
//   //             },
//   //           };
//   //           $http(config)
//   //             .then((response) => {
//   //               $rootScope.loaderCurrentStatus = 'false';
//   //               $scope.userResponse = response.data.type;
//   //               if (response.data.type == 'success') {
//   //                 $scope.userList = [];
//   //                 $scope.duplicateUserList = [];
//   //                 angular.forEach(response.data.records[0].listusers, (value, key) => {
//   //                   $scope.userList.push({
//   //                     guid: value.guid, userName: value.username, ntwuserid: value.ntwuserid, emailid: value.emailid, employeeId: value.employeeid, managerName: value.managername, statusFlag: value.statusflag,
//   //                   });
//   //                 });
//   //                 $scope.duplicateUserList = angular.copy($scope.userList);
//   //               } else if (response.data.type == 'error') {
//   //                 $scope.toastMessage('toast-error', response.data.message);
//   //               } else if (response.data.type == 'warning') {
//   //                 $scope.toastMessage('toast-warn', response.data.message);
//   //               } else {
//   //                 $scope.toastMessage('toast-error', response.data.message);
//   //               }
//   //             }, (response) => {
//   //               $rootScope.loaderCurrentStatus = 'false';
//   //               $scope.errorHandler(response.config.url, response.status);
//   //             });
//   //         };
//   //         /* it trigger seach field data for filtering list user */
//   //         $scope.$watch('query.filter', (newValue, oldValue) => {
//   //           if (newValue == '') {
//   //             $scope.userList = $scope.duplicateUserList;
//   //           }
//   //           if (newValue) {
//   //             $scope.items = $filter('filter')($scope.duplicateUserList, newValue);
//   //             $scope.userList = $scope.items;
//   //           }
//   //         });

//   //         $scope.toggleLimitOptions = function () {
//   //           $scope.limitOptions = $scope.limitOptions ? undefined : [10, 25, 50, 100];
//   //         };
//   //         $scope.logItem = function (userList) {
//   //           void 0;
//   //         };
//   //         $scope.logOrder = function (order) {
//   //           void 0;
//   //         };
//   //         $scope.logPagination = function (page, limit) {
//   //           void 0;
//   //           void 0;
//   //         };
//   //         $scope.loadData();
//   //       }
//   //     } else {
//   //       $rootScope.loaderCurrentStatus = 'false';
//   //       $scope.errorHandler(response.message, response.status);
//   //     }
//   //   });
