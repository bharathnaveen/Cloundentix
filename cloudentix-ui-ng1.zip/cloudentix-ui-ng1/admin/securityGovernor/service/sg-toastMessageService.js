angular
    .module('cloudentixApp')
    .service('SGtoastService', SGtoastService)

SGtoastService.$inject = ['$mdToast'];

/**
*  service for handling toaster messages. 
* @memberof module:cloudentixApp
* @requires $mdToast
* @ngInject
*/

function SGtoastService($mdToast) {

    /**
    * To display toast message using '$mdToast' component
    * @param type
    * @param msg
    */
    this.toastmessage = function (type, msg) {
        var icon;
        if (type == 'success') {
            icon = 'done';
        } else if (type == 'error') {
            icon = 'error_outline';
        } else if (type == 'warning') {
            icon = 'warning';
        } else {
            icon = 'info';
        }
        $mdToast.show({
            template: '<md-toast class="md-toast ' + type + '"><div class="md-toast-content"><i class="material-icons">' + icon + '</i>&nbsp;&nbsp;' + msg + '</div></md-toast>',
            hideDelay: 3000,
            position: 'top right'
        });
    }
}

