angular.module('cloudentixApp')
// .directive('emailValidation', function(){
//     console.log('hi directive');
//     return{
//         restrict: ' ',
//         require: 'ngModel',
//         link: function(scope, element, attribute, ngModel){
//             var emailValidation = attribute.emailValidation.split(',');
//             // console.log(emailValidation, 'email msg');
//             // console.log('hi directive one');
//             ngModel.$parsers.unshift(function (value){
//             console.log(value);
//             });
//         }
//     };
// } );

.directive('emailValidation', function() {
    console.log('hi directive');
    return {
      require: 'ngModel',
      controller: SGAccExpirationController,
      link: function(scope, elem, attr, ngModel) {
        var emailValidation = attr.emailValidation.split(',');
        ngModel.$parsers.unshift(function(value) {
          // console.log(value);
        var replaceSpace = value.replace(/[\s]/g, '');
        // console.log(replaceSpace, 'this is space removed text');
          var arr = replaceSpace.split(',');
          console.log(arr, 'this is array of input'); 
          var i;
          var re = new RegExp(/^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/);
          for(i=0; i<=arr.length; i++){
            if(!arr[i]){
              return;
              // arr[i]++; 
            }
             if(arr[i].match(re)){
              console.log("Valid");
              //  return true
              //  arr[i]++; 
             }
             else {
              console.log("Invalid");
              //  return false
             }
          }
        });
      }
    };
  });
 // console.log(finalArr[i], 'all valid email ids');
            // var final = arr[i].match(/^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/); 
          // console.log(arr, 'this is comma split text text');  
 // console.log(replaceSpace, 'this is space removed text');
   //   var replaceSpace = value.replace(/^\s+|\s+$/gm,'');
        //   var replaceSpace = value.trim();