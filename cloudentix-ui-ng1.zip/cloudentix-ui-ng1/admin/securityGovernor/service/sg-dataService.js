angular
    .module('cloudentixApp')
    .service('SGdataService', SGdataService)

SGdataService.$inject = ['$http', '$q', 'SessionService', 'SGURL'];

/**
*  service for handling http calls.
* @memberof module:cloudentixApp
* @requires $http
* @requires $q
* @requires SessionService
* @requires SGURL
* @ngInject
*/

function SGdataService($http, $q, SessionService, SGURL) {

    /**
    * Getting Data Values in GET API
    * @param url
    * @param headerObj
    * @param params
    */
    this.getData = function (url, headerObj, params) {

        var deferred = $q.defer()
        var headers = {};
        headers["Authorization"] = "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword);
        headers = Object.assign(headers, headerObj);
        options = {
            method: 'GET',
            cache: false,
            url: SGURL + url,
            params: params,
            headers: headers
        };

        function handleSuccess(data, status, headers, config) {
            deferred.resolve(data, status, headers, config);
        }

        function handleError(data, status, headers, config) {
            deferred.reject(data, status, headers, config);
        }
        $http(options).success(handleSuccess).error(handleError);
        return deferred.promise;
    }
    /**
    * Posting Data Values in POST API
    * @param url
    * @param headerObj
    * @param params
    */
    this.saveData = function (url, headerObj, params) {

        var deferred = $q.defer()
        var headers = {};
        headers["Authorization"] = "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword);
        headers = Object.assign(headers, headerObj);
        options = {
            method: 'POST',
            cache: false,
            url: SGURL + url,
            params: params,
            headers: headers
        };

        function handleSuccess(data, status, headers, config) {
            deferred.resolve(data, status, headers, config);
        }

        function handleError(data, status, headers, config) {
            deferred.reject(data, status, headers, config);
        }
        $http(options).success(handleSuccess).error(handleError);
        return deferred.promise;
    }
    /**
    * Posting Mail Data Values in POST API
    * @param url
    * @param data
    */
    this.saveMailData = function (url, data) {
        var deferred = $q.defer(),
            options = {
                method: 'POST',
                cache: false,
                url: SGURL + url,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Authorization': 'Basic ' + btoa(SessionService.defaultusername + ':' + SessionService.defaultpassword)
                },
                transformRequest: function (obj) {
                    var str = [];
                    for (var p in obj)
                        str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
                    return str.join("&");
                },
                data: {
                    'mail': data
                },
            };

        function handleSuccess(data, status, headers, config) {
            deferred.resolve(data, status, headers, config);
        }

        function handleError(data, status, headers, config) {
            deferred.reject(data, status, headers, config);
        }
        $http(options).success(handleSuccess).error(handleError);
        return deferred.promise;
    }

    /**
    * Posting Mail Data Values in POST API
    * @param url
    * @param data
    */
    this.saveSchedular = function (url, data) {
        var deferred = $q.defer(),
            options = {
                method: 'POST',
                cache: false,
                url: SGURL + url,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Authorization': 'Basic ' + btoa(SessionService.defaultusername + ':' + SessionService.defaultpassword)
                },
                transformRequest: function (obj) {
                    var str = [];
                    for (var p in obj)
                        str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
                    return str.join("&");
                },
                data: {
                    'json_data': data
                },
            };

        function handleSuccess(data, status, headers, config) {
            deferred.resolve(data, status, headers, config);
        }

        function handleError(data, status, headers, config) {
            deferred.reject(data, status, headers, config);
        }
        $http(options).success(handleSuccess).error(handleError);
        return deferred.promise;
    }

    /**
    * Posting Mail Data Values in POST API
    * @param url
    * @param data
    */
    this.saveUpdateColumn = function (url, params, data) {
        var deferred = $q.defer(),
            options = {
                method: 'POST',
                cache: false,
                url: SGURL + url,
                params: params,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Authorization': 'Basic ' + btoa(SessionService.defaultusername + ':' + SessionService.defaultpassword),
                    'username': sessionStorage.getItem('cdt-uname')
                },
                transformRequest: function (obj) {
                    var str = [];
                    for (var p in obj)
                        str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
                    return str.join("&");
                },
                data: {
                    'colnames': data
                },
            };

        function handleSuccess(data, status, headers, config) {
            deferred.resolve(data, status, headers, config);
        }

        function handleError(data, status, headers, config) {
            deferred.reject(data, status, headers, config);
        }
        $http(options).success(handleSuccess).error(handleError);
        return deferred.promise;
    }

}