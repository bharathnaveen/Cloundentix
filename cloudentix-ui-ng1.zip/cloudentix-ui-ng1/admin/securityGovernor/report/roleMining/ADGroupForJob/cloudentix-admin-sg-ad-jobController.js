angular.module('cloudentixApp')
    .controller('ADGroupController', ADGroupController);

ADGroupController.$inject = ['$scope', '$rootScope', '$window', '$mdDialog', 'SGtoastService', 'SGdataService'];

function ADGroupController($scope, $rootScope, $window, $mdDialog, SGtoastService, SGdataService) {


    $scope.query = {
        order: 'adgroups',
    };
//     $('#name').change(function(){
//      $('select.whatever').val('').selectmenu('refresh');
// });
// document.getElementById("name").innerHTML.change(function(){
//     document.getElementsByTagName("select").value("").selectmenu("refresh");
// });
// document.getElementById("adjob").options.length = 0;
// document.getElementById("name").innerHTML = multiselect('clearSelection');

// elements = document.getElementsByTagName("md-select")
// for(var i=0; i < elements.length ; i++){
// elements[i].selectedIndex= 0;
// }

// var option1Options = ["option1 - 1", "option1 - 2", "option1 - 3"];
// var option2Options = [["option2 - 1-1","option2 - 1-2","option2 - 1-3"],
//                ["option2 - 2-1","option2 - 2-2","option2 - 2-3"],
//                ["option2 - 3-1","option2 - 3-2","option2 - 3-3"]];
// function myCtrl($scope){

    $scope.businessUnit;
    $scope.jobTitle = [];
    $scope.getChange = function(){
        console.log('hiii log');
        var key = $scope.sgBusinessUnit.indexOf($scope.businessUnit);
        var myNewOptions = $scope.jobTitle[key];
        $scope.jobTitle = myNewOptions;
    };
// }


    $scope.getBusinessUnit = function () {
        var businessUnitURL = '/bussinessunit';
        $rootScope.loaderCurrentStatus = 'true';
        SGdataService.getData(businessUnitURL).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgBusinessUnit = response.record;
            $rootScope.loaderCurrentStatus = 'false';
        }
    }

    $scope.getJobTitle = function (bu) {
        var jobtitleURL = '/adgroupjobtitle';
        $rootScope.loaderCurrentStatus = 'true';
        var headerObj = {
            bu: bu
        }
        SGdataService.saveData(jobtitleURL, headerObj).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgJobTilte = response.record;
            $rootScope.loaderCurrentStatus = 'false';
        }
    }

    $scope.getADGroupList = function (bu, jobtitle) {
        var adgrouplistURL = '/adgroupsforjobtitlerecords';
        $rootScope.loaderCurrentStatus = 'true';
        $rootScope.bu = bu;
        $rootScope.jobtitle = jobtitle;
        var headerObj = {
            bu: bu,
            jobtitle: jobtitle,
            username: sessionStorage.getItem('cdt-uname')
        }
        var params = {
            format: 'html'
        }
        SGdataService.saveData(adgrouplistURL, headerObj, params).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgADGroup = response.records[0];
            $scope.getPDF();
            $rootScope.loaderCurrentStatus = 'false';
        }
    }

    $scope.getMailDetails = function (username, mailCC, mailBCC, subject, message) {
        var mailTo = document.getElementById("To").value.split(/[ ,]+/);
        var mailCC = document.getElementById("CC").value.split(/[ ,]+/);
        var mailBCC = document.getElementById("BCC").value.split(/[ ,]+/);
        var mailURL = '/adgroupsforjobtitlerecords';
        var mailJSON = {
            mail_to: mailTo,
            mail_cc: mailCC,
            mail_bcc: mailBCC,
            subject: subject,
            message: message
        }
        var headerObj = {
            bu: $rootScope.bu,
            jobtitle: $rootScope.jobtitle,
            username: sessionStorage.getItem('cdt-uname'),
            mail: JSON.stringify(mailJSON)
        }
        var params = {
            start: 1,
            end: 10,
            format: 'mail'
        }
        $rootScope.loaderCurrentStatus = 'true';
        SGdataService.saveData(mailURL, headerObj, params).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgMailData = response;
            $rootScope.loaderCurrentStatus = 'false';
            SGtoastService.toastmessage('toast-info', response.message);
            if (response.message == "Mail Sent Successfully") {
                $state.go('securityGovernor.adgroupjob');
            }
        }
    }

    $scope.getPDF = function () {
        var getPDFURL = '/adgroupsforjobtitlerecords';
        $rootScope.loaderCurrentStatus = 'true';
        var headerObj = {
            bu: $rootScope.bu,
            jobtitle: $rootScope.jobtitle,
            username: sessionStorage.getItem('cdt-uname')
        }
        var params = {
            start: 1,
            end: 10,
            format: 'pdf'
        }

        SGdataService.saveData(getPDFURL, headerObj, params).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgPDF = response;
            // var pathname = new URL($scope.sgPDF.url).pathname;
            // var path = pathname.substr(1, 100);
            // var fileName = path;
            // var a = document.createElement("a");
            // document.body.appendChild(a);
            // var file = new Blob([$scope.sgPDF.url], { type: 'application/pdf' });
            // var fileURL = $window.URL.createObjectURL(file);
            // a.href = fileURL;
            // a.download = fileName;
            // a.click();
            $rootScope.loaderCurrentStatus = 'false';
        }
    }

    $scope.getPrint = function () {
        var getPrintURL = '/adgroupsforjobtitlerecords';
        $rootScope.loaderCurrentStatus = 'true';
        var headerObj = {
            bu: $rootScope.bu,
            jobtitle: $rootScope.jobtitle,
            username: sessionStorage.getItem('cdt-uname')
        }
        var params = {
            start: 1,
            end: 10,
            format: 'pdf'
        }

        SGdataService.saveData(getPrintURL, headerObj, params).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgPrint = response;
            var parent = $window.open('', '_blank');
            $window.open($scope.sgPrint.url, '_blank');
            parent.close();
            $rootScope.loaderCurrentStatus = 'false';
        }
    }

    $scope.status = '  ';
    $scope.customFullscreen = false;
    $scope.subject = "AD Groups for Job Title";
    $scope.username = sessionStorage.getItem('cdt-uname');
    $scope.message = "Please find the attached Security Governor Report 'AD Groups for Job Title'.";


    $scope.showAdvanced = function (ev) {
        $mdDialog.show({
            controller: ADGroupController,
            templateUrl: '../admin/securityGovernor/report/roleMining/ADGroupForJob/cloudentix-ademail-modal-popup.html',
            parent: angular.element(document.body),
            targetEvent: ev,
            clickOutsideToClose: true,
            fullscreen: $scope.customFullscreen // Only for -xs, -sm breakpoints.
        })
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
    };

    function errorHandler(e) {
        console.log(e.toString());
    }
    $scope.getBusinessUnit();
}