angular.module('cloudentixApp')
    .controller('JobTitleADGroupController', JobTitleADGroupController);

JobTitleADGroupController.$inject = ['$scope', '$filter', '$rootScope', '$window', '$mdDialog', 'SGtoastService', 'SGdataService'];

function JobTitleADGroupController($scope, $filter, $rootScope, $window, $mdDialog, SGtoastService, SGdataService) {

    $scope.selected = [];
    $scope.limitOptions = [10, 25, 50, 100];

    $scope.options = {
        rowSelection: false,
        multiSelect: false,
        autoSelect: true,
        decapitate: false,
        largeEditDialog: true,
        boundaryLinks: true,
        limitSelect: true,
        pageSelect: true
    };

    $scope.query = {
        order: 'jobtitle',
        limit: 10,
        page: 1
    };
    $scope.subject = "Job Titles for AD Group";
    $scope.username = sessionStorage.getItem('cdt-uname');
    $scope.message = "Please find the attached Security Governor Report 'Job Titles for AD Group'.";



    $scope.getGroupData = function () {
        var databaseURL = '/jobtitleforadgroups';
        $rootScope.loaderCurrentStatus = 'true';
        SGdataService.getData(databaseURL).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgGroups = response.record;
            $rootScope.loaderCurrentStatus = 'false';
        }
    }

    $scope.getJobTitleADGroup = function (groups, startrecord, endrecord) {
        var jobtitleadgroupURL = '/jobtitleforadgroupsrecord';
        $rootScope.loaderCurrentStatus = 'true';
        $rootScope.groups = groups;
        var headerObj = {
            groups: groups,
            username: sessionStorage.getItem('cdt-uname')
        }
        if (startrecord) {
            var params = {
                start: startrecord,
                end: endrecord,
                format: 'html'
            }
        } else {
            var params = {
                start: 1,
                end: 10,
                format: 'html'
            }
        }
        SGdataService.saveData(jobtitleadgroupURL, headerObj, params).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgJobTilteADGroup = response;
            $scope.getPDF();
            $rootScope.loaderCurrentStatus = 'false';
        }
    }

    $scope.getMailDetails = function (username, mailCC, mailBCC, subject, message) {
        var mailTo = document.getElementById("To").value.split(/[ ,]+/);
        var mailCC = document.getElementById("CC").value.split(/[ ,]+/);
        var mailBCC = document.getElementById("BCC").value.split(/[ ,]+/);
        var mailURL = '/jobtitleforadgroupsrecord';
        var mailJSON = {
            mail_to: mailTo,
            mail_cc: mailCC,
            mail_bcc: mailBCC,
            subject: subject,
            message: message
        }
        var headerObj = {
            groups: $rootScope.groups,
            username: sessionStorage.getItem('cdt-uname'),
            mail: JSON.stringify(mailJSON)
        }
        var params = {
            start: 1,
            end: 10,
            format: 'mail'
        }
        $rootScope.loaderCurrentStatus = 'true';
        SGdataService.saveData(mailURL, headerObj, params).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgMailData = response;
            $rootScope.loaderCurrentStatus = 'false';
            SGtoastService.toastmessage('toast-info', response.message);
            if (response.message == "Mail Sent Successfully") {
                $state.go('securityGovernor.jobtitlead');
            }
        }
    }

    $scope.getPDF = function () {
        var getPDFURL = '/jobtitleforadgroupsrecord';
        $rootScope.loaderCurrentStatus = 'true';
        var headerObj = {
            groups: $rootScope.groups,
            username: sessionStorage.getItem('cdt-uname')
        }
        var params = {
            start: 1,
            end: 10,
            format: 'pdf'
        }

        SGdataService.saveData(getPDFURL, headerObj, params).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgPDF = response;
            // var pathname = new URL($scope.sgPDF.url).pathname;
            // var path = pathname.substr(1, 100);
            // var fileName = path;
            // var a = document.createElement("a");
            // document.body.appendChild(a);
            // var file = new Blob([$scope.sgPDF.url], { type: 'application/pdf' });
            // var fileURL = $window.URL.createObjectURL(file);
            // a.href = fileURL;
            // a.download = fileName;
            // a.click();
            $rootScope.loaderCurrentStatus = 'false';
        }
    }


    $scope.getPrint = function () {
        var getPrintURL = '/jobtitleforadgroupsrecord';
        $rootScope.loaderCurrentStatus = 'true';
        var headerObj = {
            groups: $rootScope.groups,
            username: sessionStorage.getItem('cdt-uname')
        }
        var params = {
            start: 1,
            end: 10,
            format: 'pdf'
        }

        SGdataService.saveData(getPrintURL, headerObj, params).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgPrint = response;
            var parent = $window.open('', '_blank');
            $window.open($scope.sgPrint.url, '_blank');
            parent.close();
            $rootScope.loaderCurrentStatus = 'false';
        }
    }

    $scope.status = '  ';
    $scope.customFullscreen = false;

    $scope.showAdvanced = function (ev) {
        $mdDialog.show({
            controller: JobTitleADGroupController,
            templateUrl: '../admin/securityGovernor/report/roleMining/JobTitleForADGroup/cloudentix-jobademail-modal-popup.html',
            parent: angular.element(document.body),
            targetEvent: ev,
            clickOutsideToClose: true,
            fullscreen: $scope.customFullscreen // Only for -xs, -sm breakpoints.
        })
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
    };


    $scope.onPaginate = function () {
        var startrecord = ($scope.query.page * $scope.query.limit) - $scope.query.limit + 1;
        var endrecord = $scope.query.page * $scope.query.limit;
        $scope.getJobTitleADGroup($scope.groups, startrecord, endrecord);
    }

    $scope.toggleLimitOptions = function () {
        $scope.limitOptions = $scope.limitOptions ? undefined : [10, 25, 50, 100];
    };

    $scope.logItem = function (item) {
        console.log(item.name, 'was selected');
    };

    $scope.logOrder = function (order) {
        console.log('order: ', order);
    };

    $scope.logPagination = function (page, limit) {
        console.log('page: ', page);
        console.log('limit: ', limit);
    }

    function errorHandler(e) {
        console.log(e.toString());
    }
    $scope.getGroupData();
}