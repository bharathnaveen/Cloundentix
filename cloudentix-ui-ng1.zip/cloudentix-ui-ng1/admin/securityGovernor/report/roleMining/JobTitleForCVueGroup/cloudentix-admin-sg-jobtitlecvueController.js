angular.module('cloudentixApp')
    .controller('JobTitleCVueGroupController', JobTitleCVueGroupController);

JobTitleCVueGroupController.$inject = ['$scope', '$filter', '$rootScope', '$window', '$mdDialog', 'SGtoastService', 'SGdataService', '$stateParams'];

function JobTitleCVueGroupController($scope, $filter, $rootScope, $window, $mdDialog, SGtoastService, SGdataService, $stateParams) {
     /**
     * @memberof module:cloudentixApp
     
     * CRUD application is performed and also displays the data
     * @requires $scope
     * @requires $filter
     * @requires $rootScope
     * @requires $window
     * @requires $mdDialog
     * @requires SGdataService
     * @requires $stateParams
     * @ngInject
     */
    $scope.selected = [];
    $scope.limitOptions = [10, 25, 50, 100];
    // Options to use pagination
    $scope.options = {
        rowSelection: false,
        multiSelect: false,
        autoSelect: true,
        decapitate: false,
        largeEditDialog: true,
        boundaryLinks: true,
        limitSelect: true,
        pageSelect: true
    };
    // Pagination query values
    $scope.query = {
        order: 'jobtitle',
        limit: 10,
        page: 1
    };

    $scope.database;
    $scope.cvueGroup = [];
    $scope.getChange = function(){
        console.log('hiii log');
        var key = $scope.sgDatabase.indexOf($scope.database);
        var myNewOptions = $scope.cvueGroup[key];
        $scope.cvueGroup = myNewOptions;
    };

    $scope.subject = "Job Titles for a CVue Group";
    $scope.username = sessionStorage.getItem('cdt-uname');
    $scope.message = "Please find the attached Security Governor Report 'Job Titles for a CVue Group'.";

    // Getting all values for database using GET API
    $scope.getDatabaseData = function () {
        var databaseURL = '/dblist';
        $rootScope.loaderCurrentStatus = 'true';
        SGdataService.getData(databaseURL).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgDatabase = response;
            $rootScope.loaderCurrentStatus = 'false';
        }
    }
    /**
    * Getting all values for CVUE Group using POST API by passing parameter
    * @param db
    */
    $scope.getCvueGroup = function (db) {
        var cvueGroupURL = '/jobtitleforacvuegroup';
        $rootScope.loaderCurrentStatus = 'true';
        var headerObj = {
            db: db
        }
        SGdataService.saveData(cvueGroupURL, headerObj).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgcvueGroup = response.record;
            $rootScope.loaderCurrentStatus = 'false';
        }
    }
    /**
    * Getting all values for Job Title for CVUE Group using POST API by passing parameter
    * @param db
    * @param jobtitle
    * @param startrecord
    * @param endrecord
    */
    $scope.getJobTitleCvueGroupList = function (db, jobtitle, startrecord, endrecord) {
        var jobtitlecvuegrouplistURL = '/jobtitleforacvuegroupreport';
        $rootScope.loaderCurrentStatus = 'true';
        $rootScope.db = db;
        $rootScope.jobtitle = jobtitle;
        var headerObj = {
            db: db,
            jobtitle: jobtitle,
            username: sessionStorage.getItem('cdt-uname')
        }
        if (startrecord) {
            var params = {
                start: startrecord,
                end: endrecord,
                format: 'html'
            }
        } else {
            var params = {
                start: 1,
                end: 10,
                format: 'html'
            }
        }
        SGdataService.saveData(jobtitlecvuegrouplistURL, headerObj, params).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgJobTitleCvueGroup = response;
            $scope.getPDF();
            $rootScope.loaderCurrentStatus = 'false';
        }
    }
    /**
    * Posting mail data for Job Title for CVUE Group using POST API by passing parameter
    * @param username
    * @param mailCC
    * @param mailBCC
    * @param subject
    * @param message
    */
    $scope.getMailDetails = function (username, mailCC, mailBCC, subject, message) {
        var mailTo = document.getElementById("To").value.split(/[ ,]+/);
        var mailCC = document.getElementById("CC").value.split(/[ ,]+/);
        var mailBCC = document.getElementById("BCC").value.split(/[ ,]+/);
        var mailURL = '/jobtitleforacvuegroupreport';
        var mailJSON = {
            mail_to: mailTo,
            mail_cc: mailCC,
            mail_bcc: mailBCC,
            subject: subject,
            message: message
        }
        var headerObj = {
            db: $rootScope.db,
            jobtitle: $rootScope.jobtitle,
            username: sessionStorage.getItem('cdt-uname'),
            mail: JSON.stringify(mailJSON)
        }
        var params = {
            start: 1,
            end: 10,
            format: 'mail'
        }
        $rootScope.loaderCurrentStatus = 'true';
        SGdataService.saveData(mailURL, headerObj, params).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgMailData = response;
            $rootScope.loaderCurrentStatus = 'false';
            SGtoastService.toastmessage('toast-info', response.message);
            if (response.message == "Mail Sent Successfully") {
                $state.go('securityGovernor.jobtitlecvue');
            }
        }
    }
    // Getting PDF URL using POST API  
    $scope.getPDF = function () {
        var getPDFURL = '/jobtitleforacvuegroupreport';
        $rootScope.loaderCurrentStatus = 'true';
        var headerObj = {
            db: $rootScope.db,
            jobtitle: $rootScope.jobtitle,
            username: sessionStorage.getItem('cdt-uname')
        }
        var params = {
            start: 1,
            end: 10,
            format: 'pdf'
        }

        SGdataService.saveData(getPDFURL, headerObj, params).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgPDF = response;
            // var pathname = new URL($scope.sgPDF.url).pathname;
            // var path = pathname.substr(1, 100);
            // var fileName = path;
            // var a = document.createElement("a");
            // document.body.appendChild(a);
            // var file = new Blob([$scope.sgPDF.url], { type: 'application/pdf' });
            // var fileURL = $window.URL.createObjectURL(file);
            // a.href = fileURL;
            // a.download = fileName;
            // a.click();
            $rootScope.loaderCurrentStatus = 'false';
        }
    }
    // Getting PRINT URL using POST API 
    $scope.getPrint = function () {
        var getPrintURL = '/jobtitleforacvuegroupreport';
        $rootScope.loaderCurrentStatus = 'true';
        var headerObj = {
            db: $rootScope.db,
            jobtitle: $rootScope.jobtitle,
            username: sessionStorage.getItem('cdt-uname')
        }
        var params = {
            start: 1,
            end: 10,
            format: 'pdf'
        }

        SGdataService.saveData(getPrintURL, headerObj, params).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgPrint = response;
            var parent = $window.open('', '_blank');
            $window.open($scope.sgPrint.url, '_blank');
            parent.close();
            $rootScope.loaderCurrentStatus = 'false';
        }
    }
    // Getting Job Title CVUE Group for Staffs Values using POST API 
    $scope.getJobTitleCvueGroupStaffList = function () {
        var cvueStaffURL = '/jtcvuegrpstaffs';
        $rootScope.loaderCurrentStatus = 'true';

        var headerObj = {
            db: $stateParams.db,
            jobtitle: $stateParams.job,
            staffname: $stateParams.staffid
        }

        SGdataService.saveData(cvueStaffURL, headerObj).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgJobTitleCvueGroupStaffList = response.record;
            $rootScope.loaderCurrentStatus = 'false';
        }
    }
    $scope.getJobTitleCvueGroupStaffList();

    $scope.status = '  ';
    $scope.customFullscreen = false;
    // Modal Popup for mail data
    $scope.showAdvanced = function (ev) {
        $mdDialog.show({
            controller: JobTitleCVueGroupController,
            templateUrl: '../admin/securityGovernor/report/roleMining/JobTitleForCVueGroup/cloudentix-jobcvueemail-modal-popup.html',
            parent: angular.element(document.body),
            targetEvent: ev,
            clickOutsideToClose: true,
            fullscreen: $scope.customFullscreen // Only for -xs, -sm breakpoints.
        })
    };
    // Cancel method for mail popup
    $scope.cancel = function () {
        $mdDialog.cancel();
    };
    // Getting values by pagination
    $scope.onPaginate = function () {
        var startrecord = ($scope.query.page * $scope.query.limit) - $scope.query.limit + 1;
        var endrecord = $scope.query.page * $scope.query.limit;
        $scope.getJobTitleCvueGroupList($scope.database, $scope.cvueGroup, startrecord, endrecord);
    }
    // Pagination toggle Limit
    $scope.toggleLimitOptions = function () {
        $scope.limitOptions = $scope.limitOptions ? undefined : [10, 25, 50, 100];
    };
    // Pagination Log Item
    $scope.logItem = function (item) {
        console.log(item.name, 'was selected');
    };
    // Pagination Log Order
    $scope.logOrder = function (order) {
        console.log('order: ', order);
    };
    // Log method for Pagination
    $scope.logPagination = function (page, limit) {
        console.log('page: ', page);
        console.log('limit: ', limit);
    }
    // Error handler method
    function errorHandler(e) {
        console.log(e.toString());
    }
    $scope.getDatabaseData();
}