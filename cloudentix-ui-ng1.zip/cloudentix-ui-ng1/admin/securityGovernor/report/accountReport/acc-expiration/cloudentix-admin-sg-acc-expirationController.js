angular.module('cloudentixApp')
  .controller('SGAccExpirationController', SGAccExpirationController);

SGAccExpirationController.$inject = ['$scope', '$rootScope', '$window', '$mdDialog','SGtoastService', 'SGdataService'];

function SGAccExpirationController($scope, $rootScope, $window, $mdDialog, SGtoastService, SGdataService) {

  $scope.selected = [];
  $scope.limitOptions = [10, 25, 50, 100];

  $scope.options = {
    rowSelection: false,
    multiSelect: false,
    autoSelect: true,
    decapitate: false,
    largeEditDialog: true,
    boundaryLinks: true,
    limitSelect: true,
    pageSelect: true
  };

  $scope.query = {
    order: 'name',
    limit: 10,
    page: 1
  };
  $scope.subject = "Accounts - Expiration";
  $scope.username = sessionStorage.getItem('cdt-uname');
  $scope.message = "Please find the attached Security Governor Report 'Accounts - Expiration'";
  
  
  $scope.getMailDetails = function (username, mailCC, mailBCC, subject, message) {
      var mailTo = document.getElementById("To").value.split(/[ ,]+/);
      var mailCC = document.getElementById("CC").value.split(/[ ,]+/);
      var mailBCC = document.getElementById("BCC").value.split(/[ ,]+/);

      var mailURL = '/reportaccountsexpiration';
      var mailJSON = {
        mail_to: mailTo,
        mail_cc: mailCC,
        mail_bcc: mailBCC,
        subject: subject,
        message: message
      }
      var headerObj = {
        username: sessionStorage.getItem('cdt-uname'),
        mail: JSON.stringify(mailJSON)
      }
      var params = {
        start: 1,
        end: 10,
        format: 'mail'
      }
      $rootScope.loaderCurrentStatus = 'true';
      SGdataService.getData(mailURL, headerObj, params).then(successHandler, errorHandler);

      function successHandler(response) {
        $scope.sgMailData = response;
        $rootScope.loaderCurrentStatus = 'false';
        SGtoastService.toastmessage('toast-info', response.message);
            if (response.message == "Mail Sent Successfully") {
                $state.go('securityGovernor.acc-expiration');
            }
      }
  }


  $scope.getPDF = function () {
    var getPDFURL = '/reportaccountsexpiration';
    $rootScope.loaderCurrentStatus = 'true';
    var headerObj = {
      username: sessionStorage.getItem('cdt-uname')
    }
    var params = {
      start: 1,
      end: 10,
      format: 'pdf'
    }

    SGdataService.getData(getPDFURL, headerObj, params).then(successHandler, errorHandler);

    function successHandler(response) {
      $scope.sgPDF = response;
      // var pathname = new URL($scope.sgPDF.url).pathname;
      // var path = pathname.substr(1, 100);
      // var fileName = path;
      // var a = document.createElement("a");
      // document.body.appendChild(a);
      // var file = new Blob([$scope.sgPDF.url], { type: 'application/pdf' });
      // var fileURL = $window.URL.createObjectURL(file);
      // a.href = fileURL;
      // a.download = fileName;
      // a.click();
      $rootScope.loaderCurrentStatus = 'false';
    }
  }

  $scope.getPrint = function () {
    var getPrintURL = '/reportaccountsexpiration';
    $rootScope.loaderCurrentStatus = 'true';
    var headerObj = {
      username: sessionStorage.getItem('cdt-uname')
    }
    var params = {
      start: 1,
      end: 10,
      format: 'pdf'
    }

    SGdataService.getData(getPrintURL, headerObj, params).then(successHandler, errorHandler);

    function successHandler(response) {
      $scope.sgPrint = response;
      var parent = $window.open('', '_blank');
      $window.open($scope.sgPrint.url, '_blank');
      parent.close();
      $rootScope.loaderCurrentStatus = 'false';
    }
  }

  $scope.getData = function (startrecord, endrecord) {
    var url = '/reportaccountsexpiration';
    $rootScope.loaderCurrentStatus = 'true';

    var headerObj = {
      username: sessionStorage.getItem('cdt-uname')
    }

    if (startrecord) {
      var params = {
        start: startrecord,
        end: endrecord,
        format: 'html'
      }
    } else {
      var params = {
        start: 1,
        end: 10,
        format: 'html'
      }
    }

    SGdataService.getData(url, headerObj, params).then(successHandler, errorHandler);

    function successHandler(response) {
      $scope.sgaccexpiration = response;
      $scope.getPDF();
      $rootScope.loaderCurrentStatus = 'false';
    }
  }

  $scope.status = '  ';
  $scope.customFullscreen = false;

  $scope.showAdvanced = function (ev) {
    $mdDialog.show({
      controller: SGAccExpirationController,
      templateUrl: '../admin/securityGovernor/report/accountReport/acc-expiration/cloudentix-expirationemail-modal-popup.html',
      parent: angular.element(document.body),
      targetEvent: ev,
      clickOutsideToClose: true,
      fullscreen: $scope.customFullscreen // Only for -xs, -sm breakpoints.
    })
  };

  $scope.cancel = function () {
    $mdDialog.cancel();
  };

  $scope.onPaginate = function () {
    var startrecord = ($scope.query.page * $scope.query.limit) - $scope.query.limit + 1;
    var endrecord = $scope.query.page * $scope.query.limit;
    $scope.getData(startrecord, endrecord);
  }

  $scope.toggleLimitOptions = function () {
    $scope.limitOptions = $scope.limitOptions ? undefined : [10, 25, 50, 100];
  };

  $scope.logItem = function (item) {
    console.log(item.name, 'was selected');
  };

  $scope.logOrder = function (order) {
    console.log('order: ', order);
  };

  $scope.logPagination = function (page, limit) {
    console.log('page: ', page);
    console.log('limit: ', limit);
  }
  function errorHandler(e) {
    console.log(e.toString());
  }
  $scope.getData();
}
