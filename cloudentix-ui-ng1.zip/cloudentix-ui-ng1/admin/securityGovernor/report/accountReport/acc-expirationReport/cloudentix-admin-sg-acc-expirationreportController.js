angular.module('cloudentixApp')
    .controller('sgaccExpRptDateController', sgaccExpRptDateController);

sgaccExpRptDateController.$inject = ['$scope', '$rootScope', '$window', '$mdDialog', 'SGtoastService', 'SGdataService', 'SessionService'];

function sgaccExpRptDateController($scope, $rootScope, $window, $mdDialog, SGtoastService, SGdataService, SessionService) {
    var header = document.getElementById("myDIV");
    var btns = header.getElementsByClassName("accExp-rep-button-left");
    for (var i = 0; i < btns.length; i++) {
        btns[i].addEventListener("click", function () {
            var current = document.getElementsByClassName("active_btn");
            current[0].className = current[0].className.replace(" active_btn", "");
            this.className += " active_btn";
        });
    }

    $scope.query = {
        order: 'name'
    };

    $rootScope.dateItems = [];
    $rootScope.managerItems = [];
    $scope.getAccountExpireationDate = function () {
        var url = '/accountexpirationdate';
        $rootScope.loaderCurrentStatus = 'true';
        var headerObj = {
            username: sessionStorage.getItem('cdt-uname')
        }
        var params = {
            format: 'html'
        }
        SGdataService.getData(url, headerObj, params).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgaccexpirationdate = response;
            angular.forEach($scope.sgaccexpirationdate.records, function (date) {
                $rootScope.dateItems = date.accountexpirations;
            });
            $scope.getDatePDF();
            $rootScope.loaderCurrentStatus = 'false';
            console.log('date', $scope.sgaccexpirationdate);
        }
    }

    $scope.showConfirmForDate = function (ev) {
        // Appending dialog to document.body to cover sidenav in docs app
        var confirm = $mdDialog.confirm()
            .title('Expire User')
            .textContent('Do you want to send the mail from Cloudentix?')
            .ariaLabel('Lucky day')
            .targetEvent(ev)
            .ok('OK')
            .cancel('Cancel');

        $mdDialog.show(confirm).then(function () {
            var expDateMailUrl = '/accexpdatemail'
            $rootScope.loaderCurrentStatus = 'true';
            if ($rootScope.checkboxObjForDate) {
                console.log('single Object');
                var checkJsonRecordDate = {
                    array: $rootScope.checkboxObjForDate
                }
                console.log('checkJsonRecordDate', checkJsonRecordDate);
                var json = JSON.stringify(checkJsonRecordDate, function (key, value) {
                    if (key === "$$hashKey") {
                        return undefined;
                    }
                    return value;
                });
                $rootScope.checkboxObjForDate = [];
                console.log('json date', json);
            }
            if ($rootScope.checkboxAllForDate) {
                console.log('all Object');
                var allJsonRecordDate = {
                    array: $rootScope.checkboxAllForDate
                }
                var json = JSON.stringify(allJsonRecordDate, function (key, value) {
                    if (key === "$$hashKey") {
                        return undefined;
                    }
                    return value;
                });
                $rootScope.checkboxAllForDate = [];
            }
            SGdataService.saveMailData(expDateMailUrl, json).then(successHandler, errorHandler);
            function successHandler(response) {
                $scope.sgDataMailData = response;
                $rootScope.loaderCurrentStatus = 'false';
                SGtoastService.toastmessage('toast-info', response.message);
                if (response.message == "Mail Sent Successfully") {
                    $state.go('securityGovernor.acc-expirationreport');
                }
                location.reload(true);
            }
            $scope.status = '';
        }, function () {
            $scope.status = '';
        });

    };

    $rootScope.arrayDate = [];
    $scope.checkboxObjForDate = function (one) {
        var idx =  $rootScope.arrayDate.indexOf(one);
        console.log('id', idx);
        if (idx > -1) {
            $rootScope.arrayDate.splice(idx, 1);
            $rootScope.checkboxObjForDate = $rootScope.arrayDate;
            console.log('if array',  $rootScope.checkboxObjForDate);
        }
        else {
            $rootScope.arrayDate.unshift(one);
            $rootScope.checkboxObjForDate = $rootScope.arrayDate;
            console.log('else array', $rootScope.checkboxObjForDate);
        }
        
    }

    // $scope.checkboxObjForDate = function (one) {
    //     console.log('full obj', one);
    //     // var checkBox = document.getElementById("dateoneObj");
    //     // if (checkBox.checked == true) {
    //     $rootScope.checkboxObjForDate.unshift(one);
    //     console.log('obj array', $rootScope.checkboxObjForDate);
    //     //  }
    // }

    $scope.allcheckForDate = function (all) {
        $rootScope.checkboxAllForDate = [];
        var checkBox = document.getElementById("dateall");
        if (checkBox.checked == true) {
            angular.forEach(all, function (value) {
                angular.forEach(value.accountexpirations, function (date) {
                    $rootScope.checkboxAllForDate.push(date);
                });
            });
        }
    }

    $scope.getDatePDF = function () {
        var getDatePDFURL = '/accountexpirationdate';
        $rootScope.loaderCurrentStatus = 'true';
        var headerObj = {
            username: sessionStorage.getItem('cdt-uname')
        }
        var params = {
            format: 'pdf'
        }
        SGdataService.getData(getDatePDFURL, headerObj, params).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgDatePDF = response;
            // var pathname = new URL($scope.sgDatePDF.url).pathname;
            // var path = pathname.substr(1, 100);
            // var fileName = path;
            // var a = document.createElement("a");
            // document.body.appendChild(a);
            // var file = new Blob([$scope.sgDatePDF.url], { type: 'application/pdf' });
            // var fileURL = $window.URL.createObjectURL(file);
            // a.href = fileURL;
            // a.download = fileName;
            // a.click();
            $rootScope.loaderCurrentStatus = 'false';
        }
    }

    $scope.getDatePrint = function () {
        var getDatePrintURL = '/accountexpirationdate';
        $rootScope.loaderCurrentStatus = 'true';
        var headerObj = {
            username: sessionStorage.getItem('cdt-uname')
        }
        var params = {
            start: 1,
            end: 10,
            format: 'pdf'
        }

        SGdataService.getData(getDatePrintURL, headerObj, params).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgDatePrint = response;
            var parent = $window.open('', '_blank');
            $window.open($scope.sgDatePrint.url, '_blank');
            parent.close();
            $rootScope.loaderCurrentStatus = 'false';
        }
    }

    $scope.getAccountExpireationManager = function () {
        var url = '/accountexpirationmanager';
        $rootScope.loaderCurrentStatus = 'true';
        var headerObj = {
            username: sessionStorage.getItem('cdt-uname')
        }
        var params = {
            format: 'html'
        }
        SGdataService.getData(url, headerObj, params).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgaccexpirationmanager = response;
            angular.forEach($scope.sgaccexpirationmanager.records, function (mngr) {
                $rootScope.managerItems = mngr.accountexpiremanager;
            });
            $scope.getManagerPDF();
            $rootScope.loaderCurrentStatus = 'false';
            console.log($scope.sgaccexpirationmanager, 'manager');
        }
    }

    $scope.showConfirmForManager = function (ev) {
        // Appending dialog to document.body to cover sidenav in docs app
        var confirm = $mdDialog.confirm()
            .title('Expire User')
            .textContent('Do you want to send the mail from Cloudentix?')
            .ariaLabel('Lucky day')
            .targetEvent(ev)
            .ok('OK')
            .cancel('Cancel');

        $mdDialog.show(confirm).then(function () {
            var expManagermailURL = '/accexpmanmail';
            $rootScope.loaderCurrentStatus = 'true';
            if ($rootScope.checkboxObjForManager) {
                var checkJsonRecordManager = {
                    array: $rootScope.checkboxObjForManager
                }
                var json = JSON.stringify(checkJsonRecordManager, function (key, value) {
                    if (key === "$$hashKey") {
                        return undefined;
                    }
                    return value;
                });
                $rootScope.checkboxObjForManager = [];
            }
            if ($rootScope.checkboxAllForManager) {
                var allJsonRecordManager = {
                    array: $rootScope.checkboxAllForManager
                }
                var json = JSON.stringify(allJsonRecordManager, function (key, value) {
                    if (key === "$$hashKey") {
                        return undefined;
                    }
                    return value;
                });
                $rootScope.checkboxAllForManager = [];
                // console.log('manager', json);
                // console.log('$rootScope.checkboxAllForManager', $rootScope.checkboxAllForManager);
                // console.log('sgaccexpirationmanager.records', $scope.sgaccexpirationmanager);
            }
            SGdataService.saveMailData(expManagermailURL, json).then(successHandler, errorHandler);
            function successHandler(response) {
                $scope.sgManagerMailData = response;
                $rootScope.loaderCurrentStatus = 'false';
                SGtoastService.toastmessage('toast-info', response.message);
                if (response.message == "Mail Sent Successfully") {
                    $state.go('securityGovernor.acc-expirationreport');
                }
                location.reload(true);
            }
            $scope.status = '';
        }, function () {
            $scope.status = '';
        });
    };
    $rootScope.arrayManager = [];
    $scope.checkboxObjForManager = function (mngrObj) {
        var idx =  $rootScope.arrayManager.indexOf(mngrObj);
        console.log('id', idx);
        if(idx > -1){
            $rootScope.arrayManager.splice(idx, 1);
            $rootScope.checkboxObjForManager = $rootScope.arrayManager;
            console.log('if array',  $rootScope.checkboxObjForManager);
        }
        else{
            $rootScope.arrayManager.unshift(mngrObj);
            $rootScope.checkboxObjForManager = $rootScope.arrayManager;
            console.log('else array', $rootScope.checkboxObjForManager);
        }
    }

    $scope.allcheckForManager = function (all) {
        $rootScope.checkboxAllForManager = [];
        var checkBox = document.getElementById("managerall");
        if (checkBox.checked == true) {
            angular.forEach(all, function (value) {
                angular.forEach(value.accountexpiremanager, function (manager) {
                    $rootScope.checkboxAllForManager.push(manager);
                });
            });
        }
    }
    $scope.getManagerPDF = function () {
        var getManagerPDFURL = '/accountexpirationmanager';
        $rootScope.loaderCurrentStatus = 'true';
        var headerObj = {
            username: sessionStorage.getItem('cdt-uname')
        }
        var params = {
            format: 'pdf'
        }
        SGdataService.getData(getManagerPDFURL, headerObj, params).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgManagerPDF = response;
            // var pathname = new URL($scope.sgManagerPDF.url).pathname;
            // var path = pathname.substr(1, 100);
            // var fileName = path;
            // var a = document.createElement("a");
            // document.body.appendChild(a);
            // var file = new Blob([$scope.sgManagerPDF.url], { type: 'application/pdf' });
            // var fileURL = $window.URL.createObjectURL(file);
            // a.href = fileURL;
            // a.download = fileName;
            // a.click();
            $rootScope.loaderCurrentStatus = 'false';
        }
    }

    $scope.getManagerPrint = function () {
        var getManagerPrintURL = '/accountexpirationmanager';
        $rootScope.loaderCurrentStatus = 'true';
        var headerObj = {
            username: sessionStorage.getItem('cdt-uname')
        }
        var params = {
            start: 1,
            end: 10,
            format: 'pdf'
        }

        SGdataService.getData(getManagerPrintURL, headerObj, params).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgManagerPrint = response;
            var parent = $window.open('', '_blank');
            $window.open($scope.sgManagerPrint.url, '_blank');
            parent.close();
            $rootScope.loaderCurrentStatus = 'false';
        }
    }

    $scope.subject = "Account Expiration Report";
    $scope.username = sessionStorage.getItem('cdt-uname');
    $scope.message = "Please find the attached Security Governor Report 'Account Expiration Report'.";


    $scope.getAccountSetup = function () {
        var accsetupURL = "/accountsetup";
        $rootScope.loaderCurrentStatus = 'true';

        SGdataService.getData(accsetupURL).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgaccsetup = response.record[0];
            console.log($scope.sgaccsetup, 'acc setup');
            $rootScope.loaderCurrentStatus = 'false';
        }
    }
    $scope.getAccountSetup();

    $scope.addAccountSetup = function (service, consolidate) {
        var addaccoutsetupURL = "/accexpsetup";
        $rootScope.loaderCurrentStatus = 'true';

        var headerObj = {
            srvcmailid: service,
            conmailid: consolidate
        }

        SGdataService.saveData(addaccoutsetupURL, headerObj).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgaccsetupdata = response;
            $rootScope.loaderCurrentStatus = 'false';
        }
    }

    $scope.status = '';
    $scope.customFullscreen = false;

    $scope.showAdvanced = function (ev) {
        $mdDialog.show({
            controller: sgaccExpRptDateController,
            templateUrl: '../admin/securityGovernor/report/accountReport/acc-expirationReport/cloudentix-admin-sg-acc-expiration-modalPopup.html',
            parent: angular.element(document.body),
            targetEvent: ev,
            clickOutsideToClose: true,
            fullscreen: $scope.customFullscreen // Only for -xs, -sm breakpoints.
        })
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
    };

    function errorHandler(e) {
        console.log(e.toString());
    }

    $scope.getAccountExpireationDate();
    $scope.getAccountExpireationManager();
}

