angular.module('cloudentixApp')
    .controller('SGAttestationController', SGAttestationController);
// .controller('mailPopupCtrl', mailPopupCtrl);

SGAttestationController.$inject = ['$scope', '$filter', '$rootScope', '$window', '$mdDialog', '$state', 'SGtoastService', 'SGdataService'];


function SGAttestationController($scope, $filter, $rootScope, $window, $mdDialog, $state, SGtoastService, SGdataService) {


    $scope.selected = [];
    $scope.limitOptions = [10, 25, 50, 100];

    $scope.options = {
        rowSelection: false,
        multiSelect: false,
        autoSelect: true,
        decapitate: false,
        largeEditDialog: true,
        boundaryLinks: true,
        limitSelect: true,
        pageSelect: true
    };

    $scope.query = {
        order: 'name',
        limit: 10,
        page: 1
    };

    $scope.manager;
    $scope.jobRole = [];
    $scope.changeDatabase = function(){
        console.log('hiii log');
        var key = $scope.sgManager.indexOf($scope.manager);
        var myNewOptions = $scope.jobRole[key];
        $scope.jobRole = myNewOptions;
    };

    $scope.jobRole;
    $scope.staffname = [];
    $scope.changeBusinessUnit = function(){
        var key1 = $scope.sgJobRole.indexOf($scope.jobRole);
        var myNewOptions = $scope.staffname[key1];
        $scope.staffname = myNewOptions;
    };

    $scope.manager;
    $scope.staffname = [];
    $scope.changeJobTitle = function(){
        var key = $scope.sgManager.indexOf($scope.manager);
        var myNewOptions = $scope.staffname[key];
        $scope.staffname = myNewOptions;
    };

    $scope.subject = "Campus Vue Ground-Attestation Reviews";
    $scope.username = sessionStorage.getItem('cdt-uname');
    $scope.message = "Please find the attached Security Governor Report 'Campus Vue Ground-Attestation Reviews'.";

    $scope.getManagerData = function () {
        var managerURL = '/manager';
        $rootScope.loaderCurrentStatus = 'true';
        SGdataService.getData(managerURL).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgManager = response.record;
            // console.log($scope.sgManager, 'Length<<<>>>')
            $rootScope.loaderCurrentStatus = 'false';
        }
    }

    $rootScope.checkedToggleArray = [];

    $scope.toggle = function (item, list) {

        var idx = list.indexOf(item);
        if (idx > -1) {
            list.splice(idx, 1);
            $rootScope.checkedToggleArray = list.map(function (obj) {
                return obj.email;
            });
        }
        else {
            list.push(item);
            $rootScope.checkedToggleArray = list.map(function (obj) {
                return obj.email;
            });
        }
        console.log($rootScope.checkedToggleArray, 'toggle Array')
    };

    $scope.exists = function (item, list) {
        return list.indexOf(item) > -1;
    };

    $scope.isIndeterminate = function () {
        return ($scope.selected.length !== 0 &&
            $scope.selected.length !== $scope.sgManager.length);

    };

    $scope.isChecked = function () {
        // console.log($scope.sgManager, 'checked return item');
        return $scope.selected.length === $scope.sgManager.length;
    };

    $scope.toggleAll = function () {
        if ($scope.selected.length === $scope.sgManager.length) {
            $scope.selected = [];
            // console.log(, "all object");
        } else if ($scope.selected.length === 0 || $scope.selected.length > 0) {
            $scope.selected = $scope.sgManager.slice(0);
        }
    };
    $scope.allObjectManager = function (all) {
        var checkBox = document.getElementById("allCheckedManager");
        if (checkBox.checked == false) {
            $rootScope.checkedToggleArray = all.map(function (obj) {
                return obj.email;
            });
            console.log($rootScope.checkedToggleArray, 'all object');
        }
    }

    // $scope.startDate = $scope.start_date;
    $scope.endDate = $scope.end_date;
    $scope.reccuranceDate = $scope.date;
    $scope.start_date = new Date();
    $scope.endDate = new Date();
    $scope.reccuranceDate = new Date();

    $scope.minDate = new Date(
        $scope.start_date.getFullYear(),
        $scope.start_date.getMonth(),
        $scope.start_date.getDate()
    );
    $scope.minDate = new Date(
        $scope.endDate.getFullYear(),
        $scope.endDate.getMonth(),
        $scope.endDate.getDate()
    );
    $scope.minDate = new Date(
        $scope.reccuranceDate.getFullYear(),
        $scope.reccuranceDate.getMonth(),
        $scope.reccuranceDate.getDate()
    );
    // startDate = "";
    // endDate = "";
    // reccuranceDate = "";
    $scope.frequency = "once";
    $scope.now = "true";
    $scope.date_active = "false";

    $scope.getScheduler = function (schedulename, cc, frequency, now, date, time, monthdate, monthindex, startdate, enddate, dateValue) {
        $rootScope.loaderCurrentStatus = 'true';
        var attestationSchedulerURL = '/schedular';
        var endDateFormat = $filter("date")(enddate, 'yyyy-MM-dd');
        var dateFormat = $filter("date")(date, 'yyyy-MM-dd');
        if (startdate) {
            var startDateFormat = $filter("date")(startdate, 'yyyy-MM-dd');
        } else {
            var startDateFormat = "false";
        }
        if (monthindex) {
            var monthindexValue = monthindex;
        } else {
            var monthindexValue = "false";
        }
        if (cc == true) {
            var ccValue = sessionStorage.getItem('cdt-uname');
        } else {
            var ccValue = "";
        }
        if (now == "true") {
            var nowValue = "true";
        } else {
            var nowValue = "false";
        }
        if (enddate) {
            var endDateValue = endDateFormat;
        } else {
            var endDateValue = "false";
        }
        if(schedulename){
            var scduleName = schedulename;
        }else{
            scduleName = "";
        }
        // if (dateValue == "false") {
        //     var endDateValue = "false";
        // } else {
        //     var endDateValue = endDateFormat;
        // }
        if (date) {
            var selectedDate = dateFormat;
        } else {
            var selectedDate = "false";
        }
        if (monthdate) {
            var monthdateValue = monthdate;
        } else {
            var monthdateValue = "false"
        }
        if (time) {
            var timeValue = time;
        } else {
            var timeValue = "false";
        }
        var schedularDetails = [{
            manager: $rootScope.checkedToggleArray,
            schedulename: scduleName,
            cc: ccValue,
            reccurance: [{
                frequency: frequency,
                now: nowValue,
                date: selectedDate,
                time: timeValue,
                monthdate: monthdateValue,
                monthindex: monthindexValue
            }],
            time_period: [{
                start_date: startDateFormat,
                end_date: endDateValue
            }]
        }]
        var data = {
            schedular: schedularDetails
        }
        var json = JSON.stringify(data, function (key, value) {
            if (key === "$$hashKey") {
                return undefined;
            }
            return value;
        });

        SGdataService.saveSchedular(attestationSchedulerURL, json).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgSchedular = response;
            $rootScope.loaderCurrentStatus = 'false';
            SGtoastService.toastmessage('toast-info', response.message);
            if (response.message == "Schedular started successfully") {
                $state.go('securityGovernor.attestationReview');
            }
        }
    }

    $scope.getJobRole = function (manager) {
        var jobroleURL = '/attestationreviewjobrole';
        var headerObj = {
            managername: manager
        }
        $rootScope.loaderCurrentStatus = 'true';
        SGdataService.saveData(jobroleURL, headerObj).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgJobRole = response.record;
            $rootScope.loaderCurrentStatus = 'false';
        }
    }

    $scope.getStaffName = function (manager, jobrole) {
        var staffnameURL = '/attestationreviewstaffname';
        var headerObj = {
            managername: manager,
            jobtitle: jobrole
        }
        $rootScope.loaderCurrentStatus = 'true';
        SGdataService.saveData(staffnameURL, headerObj).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgStaffName = response.record;
            $rootScope.loaderCurrentStatus = 'false';
        }
    }

    $scope.getMailDetails = function (username, mailCC, mailBCC, subject, message) {
        var mailTo = document.getElementById("To").value.split(/[ ,]+/);
        var mailCC = document.getElementById("CC").value.split(/[ ,]+/);
        var mailBCC = document.getElementById("BCC").value.split(/[ ,]+/);
        var mailURL = '/attestationreviewcvuegroup';
        var mailJSON = {
            mail_to: mailTo,
            mail_cc: mailCC,
            mail_bcc: mailBCC,
            subject: subject,
            message: message
        }
        var headerObj = {
            managername: $rootScope.manager,
            jobtitle: $rootScope.jobtitle,
            staffname: $rootScope.staffname,
            username: sessionStorage.getItem('cdt-uname'),
            mail: JSON.stringify(mailJSON)
        }
        var params = {
            start: 1,
            end: 10,
            format: 'mail'
        }
        $rootScope.loaderCurrentStatus = 'true';
        SGdataService.saveData(mailURL, headerObj, params).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgMailData = response;
            $rootScope.loaderCurrentStatus = 'false';
            SGtoastService.toastmessage('toast-info', response.message);
            if (response.message == "Mail Sent Successfully") {
                $state.go('securityGovernor.attestationReview');
            }
        }
    }

    $scope.getPDF = function () {
        var getPDFURL = '/attestationreviewcvuegroup';
        $rootScope.loaderCurrentStatus = 'true';
        var headerObj = {
            managername: $rootScope.manager,
            jobtitle: $rootScope.jobtitle,
            staffname: $rootScope.staffname,
            username: sessionStorage.getItem('cdt-uname')
        }
        var params = {
            start: 1,
            end: 10,
            format: 'pdf'
        }

        SGdataService.saveData(getPDFURL, headerObj, params).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgPDF = response;
            // var pathname = new URL($scope.sgPDF.url).pathname;
            // var path = pathname.substr(1, 100);
            // var fileName = path;
            // var a = document.createElement("a");
            // document.body.appendChild(a);
            // var file = new Blob([$scope.sgPDF.url], { type: 'application/pdf' });
            // var fileURL = $window.URL.createObjectURL(file);
            // a.href = fileURL;
            // a.download = fileName;
            // a.click();
            $rootScope.loaderCurrentStatus = 'false';
        }
    }

    $scope.getPrint = function () {
        var getPrintURL = '/attestationreviewcvuegroup';
        $rootScope.loaderCurrentStatus = 'true';
        var headerObj = {
            managername: $rootScope.manager,
            jobtitle: $rootScope.jobtitle,
            staffname: $rootScope.staffname,
            username: sessionStorage.getItem('cdt-uname')
        }
        var params = {
            start: 1,
            end: 10,
            format: 'pdf'
        }

        SGdataService.saveData(getPrintURL, headerObj, params).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgPrint = response;
            var parent = $window.open('', '_blank');
            $window.open($scope.sgPrint.url, '_blank');
            parent.close();
            $rootScope.loaderCurrentStatus = 'false';
        }
    }

    $scope.getCvueGroupAttestationList = function (manager, jobrole, staffname, startrecord, endrecord) {
        var cvuegroupattestationlistURL = '/attestationreviewcvuegroup';
        $rootScope.manager = manager;
        $rootScope.jobtitle = jobrole;
        $rootScope.staffname = staffname;
        var headerObj = {
            managername: manager,
            jobtitle: jobrole,
            staffname: staffname,
            username: sessionStorage.getItem('cdt-uname')
        }
        if (startrecord) {
            var params = {
                start: startrecord,
                end: endrecord,
                format: 'html'
            }
        } else {
            var params = {
                start: 1,
                end: 10,
                format: 'html'
            }
        }
        $rootScope.loaderCurrentStatus = 'true';
        SGdataService.saveData(cvuegroupattestationlistURL, headerObj, params).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgCvueGroupAttestation = response;
            $scope.getPDF();
            $rootScope.loaderCurrentStatus = 'false';
        }
    }

    $scope.onPaginate = function () {
        var startrecord = ($scope.query.page * $scope.query.limit) - $scope.query.limit + 1;
        var endrecord = $scope.query.page * $scope.query.limit;
        $scope.getCvueGroupAttestationList($scope.manager, $scope.jobRole, $scope.staffname, startrecord, endrecord);
    }

    $scope.status = '  ';
    $scope.customFullscreen = false;

    $scope.showAdvanced = function (ev) {
        $mdDialog.show({
            controller: SGAttestationController,
            templateUrl: '../admin/securityGovernor/report/AttestationReview/cloudentix-attestationemail-modal-popup.html',
            parent: angular.element(document.body),
            targetEvent: ev,
            clickOutsideToClose: true,
            fullscreen: $scope.customFullscreen // Only for -xs, -sm breakpoints.
        })
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
    };

    $scope.toggleLimitOptions = function () {
        $scope.limitOptions = $scope.limitOptions ? undefined : [10, 25, 50, 100];
    };

    $scope.logItem = function (item) {
        console.log(item.name, 'was selected');
    };

    $scope.logOrder = function (order) {
        console.log('order: ', order);
    };

    $scope.logPagination = function (page, limit) {
        console.log('page: ', page);
        console.log('limit: ', limit);
    }

    function errorHandler(e) {
        console.log(e.toString());
    }
    $scope.getManagerData();
}


