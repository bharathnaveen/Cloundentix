angular
    .module('cloudentixApp')
    .controller('viewRescPrepopulateController', viewRescprepopulateCtrl)
    .controller('prepopulateEditController', prepopulateEditController)
    viewRescprepopulateCtrl.$inject = ['$scope', '$mdDialog', '$mdMedia', '$timeout', '$http', '$rootScope', '$filter', 'SessionService'];
    prepopulateEditController.$inject = ['$timeout', '$q', '$http', '$scope', '$mdDialog', '$mdToast', '$rootScope', 'prepopulate', 'SessionService'];
    
    var baseUrl = sessionStorage.getItem("WS_BASE_URL");
function viewRescprepopulateCtrl($scope, $mdDialog, $mdMedia, $timeout, $http, $rootScope, $filter, SessionService) { 
    $rootScope.loaderCurrentStatus = 'true';
    $scope.selected = [];
    $scope.limitOptions = [10, 25, 50, 100];
    $scope.options = {
        rowSelection: true,
    multiSelect: false,
    autoSelect: true,
    decapitate: false,
    largeEditDialog: true,
    boundaryLinks: true,
    limitSelect: true,
    pageSelect: true
  };
  $scope.query = {
    order: 'name',
    limit: 10,
    page: 1,
	filter: ''
  };
  this.openMenu = function($mdOpenMenu, ev) {
      originatorEv = ev;
      $mdOpenMenu(ev);
    };
  $rootScope.prepopulateListFunction = function () {
      var prepopulateListURL = baseUrl + '/prepopulate/columnslist';
      var resourceDetails = JSON.parse(localStorage.getItem("ResourceDetails"));
		var config = {
			url: prepopulateListURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                "cdt-rscid": resourceDetails.resourceid,
			}
		}
		$http(config).success(function(response) {
            $scope.resourceResponse = response.type;   
            $rootScope.loaderCurrentStatus = 'false';
			$scope.prepopulateList = [];
			$scope.prepopulateDuplicateList = [];
            if(response.type == 'success') {
			angular.forEach(response.records, function(value, key) {
				$scope.prepopulateList.push({"editable" : value["editable"],"trgtcolumnname" : value["trgtcolumnname"],"prepopval" : value["prepopval"]});
           }); 
            $scope.prepopulateDuplicateList = angular.copy($scope.prepopulateList); 
            }
			else{
				$scope.resourceErrorMessage = response.message;
			}
		})
       };
       
       /* it trigger seach field data for filtering list user*/
                    $scope.$watch('query.filter', function (newValue, oldValue) {
                        if(newValue == '') {
                            $scope.prepopulateList = $scope.prepopulateDuplicateList;
                        }
                        if(newValue) {
                            $scope.items = $filter('filter')($scope.prepopulateDuplicateList, newValue);
                            $scope.prepopulateList = $scope.items;
                        }
                    });
  $scope.logPagination = function (page, limit) {
    void 0;
    void 0;
  }
  
    $rootScope.prepopulateListFunction();
    
   
    $scope.remove = function($event,selectedprepopulate){
      
		 $scope.prepopulateRemoveContent = 'Are you sure want to remove this prepopulate?';
			$scope.status = '  ';
			$scope.customFullscreen = $mdMedia('xs') || $mdMedia('sm');
			var confirm = $mdDialog.confirm()
			.title('Prepopulate Remove')
			.textContent($scope.prepopulateRemoveContent)
			.ariaLabel('Confirm')
			.cancel('No')
			.ok('Yes');

			$mdDialog.show(confirm).then(function() {
                            var prepopulateListURL = baseUrl + '/prepopulate';
                  var resourceDetails = JSON.parse(localStorage.getItem("ResourceDetails"));
                 var guid = localStorage.getItem("userid");
                    var config = {
                        url: prepopulateListURL,
                        method: "DELETE",
                        headers: {
                            "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                            "cdt-rscid": resourceDetails.resourceid,
                            "cdt-trgcolumnname":selectedprepopulate.trgtcolumnname,
                            "cdt-loginguid":guid,
                        }
                    }
                    $http(config).then(function success(response) {
                        //$scope.resourceResponse = response.data.type;   
                        $rootScope.loaderCurrentStatus = 'false';
                        $scope.prepopulateList = [];
                        if(response.data.type == "success"){
                        $scope.toastMessage('toast-success',response.data.message);
                        }if(response.type == "error"){
                        $scope.toastMessage('toast-error',response.data.message);
                        }if(response.type == "warning"){
                        $scope.toastMessage('toast-warn',response.data.message);
                        }
                        $rootScope.prepopulateListFunction();
                        },function error(response) {
                        // It will work when the server returns the status "500 - Internal server" or 400 series errors
                  });
            }, function() {
				
			});
    }
    
    $scope.edit = function($event,prepop){
   $mdDialog.show({
        controller: prepopulateEditController,
        controllerAs: 'editPrepopulateCtrl',
        templateUrl: 'resources/viewResource/prepopulate/cloudentix-admin-viewResourceEditPrepopulate.html',
        parent: angular.element(document.body),
        targetEvent: $event,
        clickOutsideToClose:false,
         locals : {
                prepopulate:prepop
                },
      })
    }
}
    
	function prepopulateEditController($timeout, $q, $http, $scope, $mdDialog, $mdToast, $rootScope, prepopulate, SessionService) {

    $scope.columnname = prepopulate.trgtcolumnname;
    var self = this;
     self.cancel = function($event) {
          $mdDialog.cancel();
        } 
        var a = prepopulate.prepopval;
        $scope.prepopulateSelected = [];
        if(a == ''){
        void 0
        $scope.prepopulateSelected[0] = 'directmapping';
        $scope.prepopulateSelected[1] = 'user attribute';
        $scope.prepopulateSelected[2] = 'First Name';
        
        }else{
        $scope.prepopulateSelected = a.split(/[()]+/);
       
        void 0;
        }
        $scope.prepopulateMapTypeList = [];
        
        
        
				$scope.prepopulateMapTypeList.push({"key" : "1","value":"concat","name":"Concatenation"},{"key" : "2","value":"substring","name":"Sub String"},{"key" : "3","value":"directmapping","name":"Direct Mapping"});
                 //console.log($scope.prepopulateMapTypeList[2].value);
         /*console.log($scope.prepopulateSelected[0]);
         console.log($scope.prepopulateSelected[1]);
         console.log($scope.prepopulateSelected[2]);*/
         $scope.substringValue ={
            value: 0
         };
        
         
         if($scope.prepopulateSelected[1] === 'string'){
                $scope.stringValue = $scope.prepopulateSelected[2];
         } 
         if($scope.prepopulateSelected[0] === 'concat'){
          if($scope.prepopulateSelected[1] !== 'resource'){
            $scope.concatPrepopulateSelectedTemp = $scope.prepopulateSelected[3].split(',');
            
            $scope.concatPrepopulateSelected = $scope.concatPrepopulateSelectedTemp[1];
            void 0
            $scope.concatPrepopulateAttributeSelected = $scope.prepopulateSelected[4];
            $scope.concatPrepopulateAttributeOptionSelected = $scope.prepopulateSelected[5];
            if($scope.concatPrepopulateSelected === 'string'){
                $scope.stringConcatValue = $scope.prepopulateSelected[4];
         }
         
          }else{
        $scope.concatPrepopulateSelectedTemp = $scope.prepopulateSelected[4].split(',');
        
        $scope.concatPrepopulateSelected = $scope.concatPrepopulateSelectedTemp[1];
        $scope.concatPrepopulateAttributeSelected = $scope.prepopulateSelected[5];
        $scope.concatPrepopulateAttributeOptionSelected = $scope.prepopulateSelected[6];
        if($scope.concatPrepopulateSelected === 'string'){
                $scope.stringConcatValue = $scope.prepopulateSelected[5];
         }
         }
         }
         
         
        //console.log($scope.concatPrepopulateSelected)
         if($scope.prepopulateSelected[0] === 'substring'){
         if($scope.prepopulateSelected[1] === 'resource'){
         
                $scope.e = $scope.prepopulateSelected[4].split(',');
                //console.log()
                var a =  parseInt($scope.e[1]);
                $scope.substringValue = {
                value : a
                };
                }else{
                $scope.e = $scope.prepopulateSelected[3].split(',');
                //console.log()
                var a =  parseInt($scope.e[1]);
                $scope.substringValue = {
                value : a
                };
                }
         }
        var prepopulateTypeListURL = baseUrl + '/prepopulate/dropdownlist';
      //var resourceDetails = JSON.parse(sessionStorage.getItem("ResourceDetails"));
    // var guid = sessionStorage.getItem("userid");
		var config = {
			url: prepopulateTypeListURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
			}
		}
		$http(config).success(function(response) {
        $scope.prepopulateTypeList = [];
        if(response.type == 'success'){
        angular.forEach(response.records[0].dropdownlist, function(value, key) {
				$scope.prepopulateTypeList.push({"key" : value["key"],"value":value["value"]});
           }); 
        }
        
        })
        
   
    $scope.changeList = function(selected){
		void 0
		 
            $scope.isShow = false;
            if(selected.key === 'resource'){
                var prepopulateKey = selected.key;
                
            }
            else if(selected.key === 'user attribute'){
            var prepopulateKey = selected.key;
            $scope.isShow = false;
            }
           if((selected.key === 'resource' ) || (selected.key === 'user attribute')){
               var prepopulateresourceListURL = baseUrl + '/prepopulate/dropdownfvalue';
              var resourceDetails = JSON.parse(localStorage.getItem("ResourceDetails"));
                var config = {
                    url: prepopulateresourceListURL,
                    method: "GET",
                    headers: {
                        "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                        "cdt-prepoptype": prepopulateKey,	
                        "cdt-rscid":resourceDetails.resourceid
                    }
                }
                $http(config).success(function(response) {
                $scope.prepopulateResourceList = [];
                 $scope.trustedResource = '';
                $scope.prepopulateUserAttributeList = [];
                if(response.type == 'success'){
                    if(selected.key === 'user attribute'){
                     angular.forEach(response.records[0].listattributes, function(value, key) {
                            $scope.prepopulateUserAttributeList.push({"key" : value["displayname"]});
                       }); 
                    }
                    else if(selected.key === 'resource'){
                    angular.forEach(response.records[0].dropdownlist, function(value, key) {
                            $scope.prepopulateResourceList.push({"key" : value["key"],"value":value["value"]});
                       }); 
                    }
                    }
                    if(response.type == 'error'){
                        $scope.trustedResource  =  response.message;
                    }
                })
            
            }
    $scope.editPrepopulate.$setUntouched();
   $scope.editPrepopulate.$setPristine(true);
        }
        $scope.changeResource = function(rscSelected,rscKey){
        $scope.isShow = true;
        $scope.prepopulateResourceValueList = [];
        $scope.rscSelectedValue = '';
        //$scope.$setPristine(true);
         var prepopulateTypeListURL = baseUrl + '/prepopulate/dropdownsvalue';
      var resourceDetails = JSON.parse(localStorage.getItem("ResourceDetails"));
		var config = {
			url: prepopulateTypeListURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                "cdt-rscid":resourceDetails.resourceid,
                "cdt-prepopval":rscSelected.key,
                "cdt-prepoptype":rscKey
			}
		}
		$http(config).success(function(response) {
        
        if(response.type == 'success'){
        angular.forEach(response.records, function(value, key) {
				$scope.prepopulateResourceValueList.push({"key" : value["trgtcolumnname"]});
           }); 
        }
        
        })
        }
        
        /*
         * For Concat in prepopulate
         */
            
    $scope.changeListConcat = function(selected){
            $scope.isShowConcat = false;
            if(selected.key === 'resource'){
                var prepopulateKey = selected.key;
                
            }
            else if(selected.key === 'user attribute'){
            var prepopulateKey = selected.key;
            $scope.isShowConcat = false;
            }
           if((selected.key === 'resource' ) || (selected.key === 'user attribute')){
               var prepopulateresourceListURL = baseUrl + '/prepopulate/dropdownfvalue';
              var resourceDetails = JSON.parse(localStorage.getItem("ResourceDetails"));
                var config = {
                    url: prepopulateresourceListURL,
                    method: "GET",
                    headers: {
                        "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                        "cdt-prepoptype": prepopulateKey,	
                        "cdt-rscid":resourceDetails.resourceid
                    }
                }
                $http(config).success(function(response) {
                $scope.prepopulateResourceListConcat = [];
                $scope.prepopulateUserAttributeListConcat = [];
                if(response.type == 'success'){
                    if(selected.key === 'user attribute'){
                     angular.forEach(response.records[0].listattributes, function(value, key) {
                            $scope.prepopulateUserAttributeListConcat.push({"key" : value["displayname"]});
                       }); 
                    }
                    else if(selected.key === 'resource'){
                    angular.forEach(response.records[0].dropdownlist, function(value, key) {
                            $scope.prepopulateResourceListConcat.push({"key" : value["key"],"value":value["value"]});
                       }); 
                    }
                    }
                })
            
            }
    
        }
        $scope.changeResourceConcat = function(rscSelected,rscKey){
        $scope.isShowConcat = true;
        $scope.concatrscSelectedValue = '';
        
         var prepopulateTypeListURL = baseUrl + '/prepopulate/dropdownsvalue';
      var resourceDetails = JSON.parse(localStorage.getItem("ResourceDetails"));
		var config = {
			url: prepopulateTypeListURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                "cdt-rscid":resourceDetails.resourceid,
                "cdt-prepopval":rscSelected.key,
                "cdt-prepoptype":rscKey
			}
		}
		$http(config).success(function(response) {
        $scope.prepopulateResourceValueListConcat = [];
        if(response.type == 'success'){
        angular.forEach(response.records, function(value, key) {
				$scope.prepopulateResourceValueListConcat.push({"key" : value["trgtcolumnname"]});
           }); 
        }
        
        })
        }
        
         
         self.updatePrepopulate = function(valid){
            
            if(valid){
            
                var prepopulateUpdateURL = baseUrl + '/prepopulate';
                var resourceDetails = JSON.parse(localStorage.getItem("ResourceDetails"));
                var guid = localStorage.getItem("userid");
            $rootScope.loaderCurrentStatus = 'true';
            if(($scope.selectedMapType.value == 'directmapping') || ($scope.selectedMapType.value == 'substring')){
                    if($scope.selectedMapType.value == 'substring'){
                          var substringValue = $scope.substringValue.value;
                    }else{
                        var substringValue = '';
                    }
                    if($scope.selected.key === 'resource'){
                        var prepopulate_column_name = $scope.rscSelectedValue.key;
                        var prepopulate_value = $scope.rscSelected.value;
                    }
                    else if($scope.selected.key === 'user attribute'){
                        var prepopulate_column_name = '';
                          var prepopulate_value = $scope.userAtttibuteSelected.key;
                    }
                    else if($scope.selected.key === 'string'){
                        var prepopulate_column_name = '';
                          var prepopulate_value = $scope.stringValue;
                    }
                    var finalval = '{"records":[{"methodid":"'+$scope.selectedMapType.value+'","prepopvalue":[{"prepoptype":"'+$scope.selected.key+'","valuea":"'+prepopulate_value+'","valueb":"'+prepopulate_column_name+'","valuec":"'+substringValue+'"}]}]}'
            }else{
                    if($scope.selected.key === 'resource'){
                        var prepopulate_column_name = $scope.rscSelectedValue.key;
                        var prepopulate_value = $scope.rscSelected.value;
                    }
                    else if($scope.selected.key === 'user attribute'){
                        var prepopulate_column_name = '';
                          var prepopulate_value = $scope.userAtttibuteSelected.key;
                    }
                    else if($scope.selected.key === 'string'){
                        var prepopulate_column_name = '';
                          var prepopulate_value = $scope.stringValue;
                    }
                    /* 2nd level*/
                    if($scope.concatselected.key === 'resource'){
                        var prepopulateConcat_column_name = $scope.concatrscSelectedValue.key;
                        var prepopulateConcat_value = $scope.concatrscSelected.value;
                    }
                    else if($scope.concatselected.key === 'user attribute'){
                        var prepopulateConcat_column_name = '';
                          var prepopulateConcat_value = $scope.concatuserAtttibuteSelected.key;
                    }
                    else if($scope.concatselected.key === 'string'){
                        var prepopulateConcat_column_name = '';
                          var prepopulateConcat_value = $scope.stringConcatValue;
                    }
                    var substringValue = '';
                var finalval = '{"records":[{"methodid":"'+$scope.selectedMapType.value+'","prepopvalue":[{"prepoptype":"'+$scope.selected.key+'","valuea":"'+prepopulate_value+'","valueb":"'+prepopulate_column_name+'","valuec":"'+substringValue+'"},{"prepoptype":"'+$scope.concatselected.key+'","valuea":"'+prepopulateConcat_value+'","valueb":"'+prepopulateConcat_column_name+'","valuec":"'+substringValue+'"}]}]}'
            }
            
            
            void 0
		var config = {
			url: prepopulateUpdateURL,
			method: "PUT",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                "cdt-rscid": resourceDetails.resourceid,
                //"cdt-prepoptype": $scope.selected.key,
                "cdt-trgcolumnname": prepopulate.trgtcolumnname,
                //"cdt-prepopval": prepopulate_value,
                //"cdt-prepopcolumnname": prepopulate_column_name,
                "cdt-prepopinput":finalval,
                "cdt-loginguid": guid

			}
		}
		$http(config).then(function success(response) {
        $scope.prepopulateResourceValueList = [];
        $rootScope.loaderCurrentStatus = 'false';
        var icon;
        if(response.data.type == 'success'){
            icon = 'done';
        }  else if(response.data.type == 'error'){
            icon = 'error_outline';
        } else if(response.data.type == 'warn'){
            icon = 'warning';
        } else{
            icon = 'info_outline';
        }
                $mdDialog.hide();
                 $mdToast.show({
            template : '<md-toast class="md-toast toast-'+response.data.type+'"><div class="md-toast-content"><i class="material-icons">'+icon+'</i>&nbsp;&nbsp; '+ response.data.message + '!</div></md-toast>',
             hideDelay: 3000,
             position: 'top right'
            });
             $rootScope.prepopulateListFunction();
        },function error(response) {
            // It will work when the server returns the status "500 - Internal server" or 400 series errors
            }); 
         }
         }
		 
		   
    }

    