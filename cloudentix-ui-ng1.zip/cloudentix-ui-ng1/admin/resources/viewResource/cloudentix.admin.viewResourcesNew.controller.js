angular
    .module('cloudentixApp')
    .controller('viewRescRolesController', viewRescRolesCtrl)
    .controller('viewRescLookupController', listrescLookupCtrl)
    .controller('viewRescUsersController', viewRescUsersCtrl)
    .controller('viewRescSetupController', viewRescSetupCtrl)
    .controller('resourceReconciliation', viewResourceReconciliation)
    var baseUrl = sessionStorage.getItem("WS_BASE_URL");
    var username = 'cloudentix';
    var password = 'p@ssw0rd';
    viewRescRolesCtrl.$inject = ['$scope', '$mdDialog', '$mdMedia', '$timeout', '$http', '$rootScope', '$filter', 'SessionService'];  
    listrescLookupCtrl.$inject = ['$scope', '$mdDialog', '$mdMedia', '$timeout', '$http', '$rootScope', 'SessionService'];
    viewRescUsersCtrl.$inject = ['$scope', '$mdDialog', '$mdMedia', '$timeout', '$http', '$rootScope', '$filter', 'SessionService'];
    viewRescSetupCtrl.$inject = ['$scope', '$mdDialog', '$mdMedia', '$timeout', '$http', '$rootScope', 'SessionService'];
    viewResourceReconciliation.$inject = ['$scope', '$http', '$rootScope', 'SessionService'];
function viewRescRolesCtrl($scope, $mdDialog, $mdMedia, $timeout, $http, $rootScope, $filter, SessionService) { 
$scope.editMode = false; 
    $rootScope.loaderCurrentStatus = 'true';
    $scope.selected = [];
    $scope.limitOptions = [10, 25, 50, 100];
    $scope.options = {
        rowSelection: true,
        multiSelect: false,
        autoSelect: true,
        decapitate: false,
        largeEditDialog: true,
        boundaryLinks: true,
        limitSelect: true,
        pageSelect: true
  };
  $scope.query = {
    order: 'name',
    limit: 10,
    page: 1,
	filter: ''
  };
  
  $scope.loadData = function () {
      var listRolesURL = baseUrl + '/list/getroles';
      var resourceDetails = JSON.parse(localStorage.getItem("ResourceDetails"));
		var config = {
			url: listRolesURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                "cdt-rscid": resourceDetails.resourceid,
			}
		}
		$http(config).success(function(response) {
            $scope.resourceResponse = response.type;   
            $rootScope.loaderCurrentStatus = 'false';
			$scope.rolesList = [];
             $scope.duplicateRoleList = [];
            if(response.type == 'success') {
			angular.forEach(response.records[0].dropdownlist, function(value, key) {
				$scope.rolesList.push({"roleid" : value["key"],"rolename" : value["value"]});
           });
        $scope.duplicateRoleList = angular.copy($scope.rolesList);           
            }
			else{
				$scope.resourceErrorMessage = response.message;
			}
		})
       };
       /* it trigger seach field data for filtering list user*/
                    $scope.$watch('query.filter', function (newValue, oldValue) {
                        if(newValue == '') {
                            $scope.rolesList = $scope.duplicateRoleList;
                        }
                        if(newValue) {
                            $scope.items = $filter('filter')($scope.duplicateRoleList, newValue);
                            $scope.rolesList = $scope.items;
                        }
                    });
                    
  $scope.logPagination = function (page, limit) {
    void 0;
    void 0;
  }
  
    $scope.loadData();
}
    
    /* List Users controller */
    
function viewRescUsersCtrl($scope, $mdDialog, $mdMedia, $timeout, $http, $rootScope, $filter, SessionService) { 
 $scope.editMode = false; 
    $rootScope.loaderCurrentStatus = 'true';
    $scope.selected = [];
    $scope.limitOptions = [10, 25, 50, 100];
    $scope.options = {
        rowSelection: true,
        multiSelect: false,
        autoSelect: true,
        decapitate: false,
        largeEditDialog: true,
        boundaryLinks: true,
        limitSelect: true,
        pageSelect: true
  };
  $scope.query = {
    order: 'name',
    limit: 10,
    page: 1,
	filter: ''
  };
  
  $scope.loadData = function () {
      var listUsersURL = baseUrl + '/resources/users';
      var resourceDetails = JSON.parse(localStorage.getItem("ResourceDetails"));
		var config = {
			url: listUsersURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                "cdt-rscid": resourceDetails.resourceid,
			}
		}
		$http(config).success(function(response) {
        //alert();
        
            $scope.resourceResponse = response.type;   
            $rootScope.loaderCurrentStatus = 'false';
			$scope.usersList = [];
			$scope.usersDuplicateList = [];
            $scope.tableHeaderList = [];
            $scope.tableDataList = [];
            var replace, replaceData;
            if(response.type == 'success') {
                 $scope.responseempty = false;
                var result = JSON.parse(response.records[0].columnvalue);
                $scope.usersList = result.values;
                $scope.cols = Object.keys($scope.usersList[0]);
                angular.forEach($scope.cols, function(value, key) {              
                    replace = value.replace(/ /g, "_");
                    $scope.tableHeaderList.push({"title": value, "order": replace});
                });
                angular.forEach($scope.usersList, function(value, keys) {
                    $scope.tableDataList.push({});
                    angular.forEach(value, function(value, key) {
                        replaceData = key.replace(/ /g, "_");
                        $scope.tableDataList[keys][replaceData] = value;
                    });
                });                    
                $scope.usersDuplicateList = angular.copy($scope.tableDataList); 
                
            }
			else{
            $scope.responseempty = true;
            if(!response.type){
            $scope.resourceErrorMessage = 'Users not available please check resource configuration';
            }
            else{
				$scope.resourceErrorMessage = response.message;
                }
			}
		})
       };
        /* it trigger seach field data for filtering list user*/
                    $scope.$watch('query.filter', function (newValue, oldValue) {
                        if(newValue == '') {
                            $scope.tableDataList = $scope.usersDuplicateList;
                        }
                        if(newValue) {
                            $scope.items = $filter('filter')($scope.usersDuplicateList, newValue);
                            $scope.tableDataList = $scope.items;
                        }
                    });
  $scope.logPagination = function (page, limit) {
    void 0;
    void 0;
  }
  
    $scope.loadData();
}
/* Lookup controller */

function listrescLookupCtrl($scope, $mdDialog, $mdMedia, $timeout, $http, $rootScope, SessionService) { 
 $scope.editMode = false; 
    $rootScope.loaderCurrentStatus = 'true';
    $scope.selected = [];
    $scope.limitOptions = [10, 25, 50, 100];
    $scope.options = {
        rowSelection: true,
        multiSelect: false,
        autoSelect: true,
        decapitate: false,
        largeEditDialog: true,
        boundaryLinks: true,
        limitSelect: true,
        pageSelect: true
  };
  $scope.query = {
    order: 'name',
    limit: 10,
    page: 1,
	filter: ''
  };
  
  $scope.loadData = function () {
        $scope.isShow = true;
        var listUsersURL = baseUrl + '/resources/lookuptable';
        var resourceDetails = JSON.parse(localStorage.getItem("ResourceDetails"));
		var config = {
			url: listUsersURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                "cdt-rscid": resourceDetails.resourceid,
			}
		}
		$http(config).success(function(response) {
            $scope.resourceResponse = response.type;   
            $rootScope.loaderCurrentStatus = 'false';
			$scope.lookupList = [];
            if(response.type == 'success') {
                   //$scope.lookupList = response.records[0].lookupdetails;
                   //$scope.cols1 = Object.keys($scope.lookupList[0]);
            angular.forEach(response.records[0].lookupdetails, function(value, key) {                
				$scope.lookupList.push({"colname" : value["colname"],"lookupid" : value["lookupid"],"lookupkeycol" : value["lookupkeycol"],"lookupname" : value["lookupname"],"lookuptblname" : value["lookuptblname"],"lookupvalcol" : value["lookupvalcol"]});
            }); 
            }
			else{
				$scope.resourceErrorMessage = response.message;
			}
		})
       };
  $scope.logPagination = function (page, limit) {
    void 0;
    void 0;
  }
  
    $scope.loadData();
    
    
    $scope.lookupView = function($event,lookupid){
        //$rootScope.loaderCurrentStatus = 'true';
        var lookupViewURL = baseUrl + '/resources/lookupdata';
        var resourceDetails = JSON.parse(localStorage.getItem("ResourceDetails"));
		var config = {
			url: lookupViewURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                "cdt-lookupid": lookupid,
			}
		}
		$http(config).success(function(response) {
            $scope.isShow = false;
            $scope.resourceResponse = response.type;   
            $rootScope.loaderCurrentStatus = 'false';
			$scope.lookupviewList = [];
            if(response.type == 'success') {
                   $scope.lookupListView = response.records[0].dropdownlist;
                   $scope.lookupcols = Object.keys($scope.lookupListView[0]);
           
            }
			else{
				$scope.resourceErrorMessage = response.message;
			}
		})
    }
    
    $scope.back = function(){
    $scope.isShow = true;
    }
}


function viewRescSetupCtrl($scope, $mdDialog, $mdMedia, $timeout, $http, $rootScope, SessionService){
 $rootScope.loaderCurrentStatus = 'true';
 $scope.updatePasswordError = '';
 $scope.editMode = false; //updatePasswordError = '';
 $scope.selected = [];
    $scope.limitOptions = [10, 25, 50, 100];
    $scope.options = {
        rowSelection: true,
        multiSelect: false,
        autoSelect: true,
        decapitate: false,
        largeEditDialog: true,
        boundaryLinks: true,
        limitSelect: true,
        pageSelect: true
  };
  $scope.query = {
    order: 'name',
    limit: 10,
    page: 1,
	filter: ''
  };
var setupURL = baseUrl + '/resources/details';
        var resourceDetails = JSON.parse(localStorage.getItem("ResourceDetails"));
		var config = {
			url: setupURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                "cdt-rscid": resourceDetails.resourceid,
			}
		}
		$http(config).success(function(response) {
            $scope.isShow = false;
            $scope.resourceResponse = response.type;   
            
			$scope.setupResource = [];
			$scope.setupTables = [];
            if(response.type == 'success') {
				$scope.singlerole = response.records[0].issinglerole;
                $scope.dbtype = resourceDetails.resourcetype;
				$scope.isTrusted =resourceDetails.trustedtype;
			//	console.log('log'+$scope.isTrusted);
			if($scope.isTrusted == 'Y')
				$scope.lablecontent="User Attributes";
			else
				$scope.lablecontent="Reconciliation Rule";
                  $rootScope.loaderCurrentStatus = 'false';
                  $scope.setupMap = response.records[0].mappingvalues;
                  $scope.setupMapcols = Object.keys($scope.setupMap[0]);
                  
                  //$scope.setupResource = response.records[0].rscdetails;
                  $scope.setupTables = response.records[0].trgtresctbldetails[0];
                  angular.forEach(response.records[0].rscdetails, function(value, key) {                
				$scope.setupResource.push({"label" : value["label"],"type" : value["type"],"value" : value["value"]});
            }); 
                  //$scope.resourceType = $scope.setupResource[0].dbypeid;
                  //console.log($scope.resourceType)
                  //$scope.setupResourcecols = Object.keys($scope.setupResource[0]);
               void 0
                void 0
               // console.log($scope.setupMapcols)
            }
			else{
				//$scope.resourceErrorMessage = response.message;
			}
		})
        
        $scope.editAppKey = function(){
            $scope.updatePasswordError = '';
            $scope.passwordEdit = '';
			$scope.editMode = true;
        }
        $scope.saveField = function(password){
        //console.log(password);
        if((password == null) || (password == '')){
            $scope.updatePasswordError = 'Password field is required'
        }
        else{
        void 0;
        var resourceDetails = JSON.parse(localStorage.getItem("ResourceDetails"));
           var rescid = resourceDetails.resourceid;
           var updatePasswordURL = baseUrl + '/resources';
           var updatePasswordvalue = password;
           var userid = localStorage.getItem("userid");
         
           var config = {
			url: updatePasswordURL,
			method: "PUT",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                "cdt-rscid":rescid,
                "cdt-pwd":updatePasswordvalue,
                "cdt-loginguid" : userid,
			}
		}
		$http(config).then(function success(response) {
			
        
             if(response.data.type == "success"){ 
			 $timeout(function() {
    $scope.editMode = false;
    }, 1000);
				 
                $scope.toastMessage('toast-success',response.data.message);
                $scope.updatePasswordError = '';
                
            }
            else{
            $scope.updatePasswordError = response.data.message;
            }
           },function error(response){
           
           });
        }
        }
//console.log("setup")
}
function viewResourceReconciliation($scope, $http, $rootScope, SessionService) {
 $scope.editMode = false; 
    var resourceDetails = JSON.parse(localStorage.getItem("ResourceDetails"));
    var loginId = localStorage.getItem("userid");
    $scope.resourceRecon = function() {
        $rootScope.loaderCurrentStatus = 'true';
        var resourceReconURL = baseUrl + '/recon/childparentrecon';
		var config = {
			url: resourceReconURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                "cdt-rscid": resourceDetails.resourceid,
                "cdt-loginguid": loginId
			}
		}
		$http(config).success(function(response) {  
            $rootScope.loaderCurrentStatus = 'false';
            $scope.ResourceReconciled = response.message;
            $scope.reconresponseType = response.type;
		})
    }
    $scope.resourcelookupRecon = function() {
        $rootScope.loaderCurrentStatus = 'true';
        var resourceReconURL = baseUrl + '/recon/lookuprecon';
		var config = {
			url: resourceReconURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                "cdt-rscid": resourceDetails.resourceid,
                "cdt-loginguid": loginId
			}
		}
		$http(config).success(function(response) {  
            $rootScope.loaderCurrentStatus = 'false';
            $scope.ResourcelookupReconciled = response.message;
            $scope.lookresponseType = response.type;
		})
    }
    
}
		
	

    