angular
    .module('cloudentixApp')
    .controller('listrescController', listrescCtrl)
   
    var baseUrl = sessionStorage.getItem("WS_BASE_URL");
    var username = sessionStorage.getItem("");
    var password = sessionStorage.getItem("");
    listrescCtrl.$inject = ['$mdEditDialog', '$scope', '$mdDialog', '$mdMedia', '$timeout', '$http', '$rootScope', '$filter', '$state', 'SessionService'];
	function listrescCtrl($mdEditDialog, $scope, $mdDialog, $mdMedia, $timeout, $http, $rootScope, $filter, $state, SessionService) { 
   $rootScope.loaderCurrentStatus = 'true';
         $scope.selected = [];
   $scope.limitOptions = [10, 25, 50, 100];
  $scope.options = {
    rowSelection: true,
    multiSelect: false,
    autoSelect: true,
    decapitate: false,
    largeEditDialog: true,
    boundaryLinks: true,
    limitSelect: true,
    pageSelect: true
  };
  $scope.query = {
    order: 'name',
    limit: 10,
    page: 1,
	filter: ''
  };
  
  $scope.loadData = function () {
      var listResourceURL = baseUrl + '/resources/list';
		var config = {
			url: listResourceURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
			}
		}
		$http(config).then(function success(response) {
            $scope.resourceResponse = response.data.type;   
            $rootScope.loaderCurrentStatus = 'false';
			$scope.resourceList = [];
            if(response.data.type == 'success') {
			angular.forEach(response.data.records[0].rscdetails, function(value, key) {
				$scope.resourceList.push({"resourcename" : value["rescname"],"resourcetype" : value["dbypeid"],"trustedtype" : value["tarflag"],"resourcehostname" : value["taraddress"],"resourceid" : value["rescid"],"resourceusers" : value["noofuser"],"resourceroles" : value["noofrole"]});
      
           }); 
                
                $scope.duplicateResourceList = angular.copy($scope.resourceList);
            }
			else{
				$scope.resourceErrorMessage = response.data.message;
			}
		},function error(response){
         $rootScope.loaderCurrentStatus = 'false';
        void 0;
        $scope.errorHandler(response.config.url,response.status);
        })
       
       };
       /* it trigger seach field data for filtering list user*/
                    $scope.$watch('query.filter', function (newValue, oldValue) {
                        if(newValue == '') {
                            $scope.resourceList = $scope.duplicateResourceList;
                        }
                        if(newValue) {
                            $scope.items = $filter('filter')($scope.duplicateResourceList, newValue);
                            $scope.resourceList = $scope.items;
                        }
                    });
    this.openMenu = function($mdOpenMenu, ev) {
      originatorEv = ev;
      $mdOpenMenu(ev);
    };
    $scope.viewRsc = function($event,r){
    void 0;
    localStorage.setItem("ResourceDetails",JSON.stringify(r));
    $state.go('viewResource');
    $scope.addTab('View Resource','viewResource')
    }
 $scope.logItem = function (resourceList) {
 //localStorage.setItem("ResourceDetails",JSON.stringify(resourceList));
 //console.log(resourceList)
 }
    $scope.remove = function($event,resource) {
    $scope.disablecontent = 'Do you want to delete the resource';
			$scope.status = '  ';
			$scope.customFullscreen = $mdMedia('xs') || $mdMedia('sm');
			var confirm = $mdDialog.confirm()
			.title('Delete')
			.textContent($scope.disablecontent)
			.ariaLabel('Confirm')
			.ok('Yes')
			.cancel('No');
      
    var deleteResourceURL = baseUrl + '/resources';

   //var rescid = sessionStorage.getItem("resourceid");
   //alert(rescid);
   $mdDialog.show(confirm).then(function() {
                 $rootScope.loaderCurrentStatus = 'true'; 
    var config = {
			url: deleteResourceURL,
			method: "DELETE",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                "cdt-rscid":resource.resourceid,
			}
		}
        $http(config).success(function(response) { 
        if(response.type == "success"){
           $rootScope.loaderCurrentStatus = 'false';
		$scope.toastMessage('toast-success',response.message);
        //void 0;
        //alert("load data");
		$scope.loadData();
       }
        
        if(response.type == "error"){
			$scope.toastMessage('toast-error',response.message);
			 $scope.loadData();
            }
           
        });
    });
    }
 
    //Get guid
    var usertype = localStorage.getItem("usertype");   
    if(usertype == 'Admin'){
        var username = localStorage.getItem("username");
        //alert("username..."+username);
        //alert("usertype..."+usertype);
        var getGuidURL = baseUrl + '/guid';
		var config = {
			url: getGuidURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                "cdt-uname":username,
			}
		}
		$http(config).success(function(response) {
            //console.log("response..",response);
            var guiduserid=response.data.login[0]["guid"];
           //alert("Guid..."+guiduserid);
            sessionStorage.setItem("userid", guiduserid);
            localStorage.setItem("userid", guiduserid);
           //console.log(sessionStorage.getItem("userid"));
        });
    }
  $scope.loadStuff = function () {
    $scope.promise = $timeout(function () {
      $scope.loadData();
    }, 1000);
  }
  
  $scope.logPagination = function (page, limit) {
    void 0;
    void 0;
  }
  
  $scope.loadData();
      } ;
    
	
		
	

    