angular
    .module('cloudentixApp')
	.controller('ADaddresourcemainctrl', adMain)
    .controller('ADaddresourcefirstsetupCtrl', adFirstSetup)
	.controller('ADaddresourcesetupCtrl', adSetup)
	.controller('ADuserattrmappingcontroller', adReconAttributeRole)
	.service('keepVal', function(){
		this.adStore = function(x){
		  this.storeAD = x;
		}
		this.adGetVal = function(){
		  return this.storeAD;
		}
	})
	.service('keepValsetup', function(){
		this.setupStore = function(x){
		  this.storesetup = x;
		}
		this.setupGetVal = function(){
		  return this.storesetup;
		}
	})
	.factory('selectTabService', function(){
		var tabActive = '0';
		return {  
			tabActive: function() { return tabActive; },
			setTabActive: function(x) { tabActive = x; }
		};
		})
	.run(['$rootScope', '$state', '$stateParams',
        function($rootScope, $state, $stateParams) {
            $rootScope.$state = $state;
            $rootScope.$stateParams = $stateParams;
        }
    ])
	.config(
        ['$stateProvider', '$urlRouterProvider',
            function($stateProvider, $urlRouterProvider) {
                $urlRouterProvider
                $stateProvider
                .state('ADaddresources.adaddrsc', {
                    url: '/ADaddresource',
					templateUrl: 'resources/addResource/activedirectoryResource/cloudentix-admin-resources-addResource-AD-setup-inital.html',                
				})
				.state('ADaddresources.Details', {
					url: '/adDetails',
					templateUrl: 'resources/addResource/activedirectoryResource/cloudentix-admin-resources-addResource-AD-setup.html'
				})
				.state('ADaddresources.ADreconattributerule', {
					url: '/ADreconattributerule',
					templateUrl: 'resources/addResource/activedirectoryResource/cloudentix-admin-resources-addResource-AD-reconattributerule.html'
				})
            }
        ]
	);
	adMain.$inject = ['$scope', '$log', '$state', '$rootScope', '$location', 'keepVal', 'keepValsetup', 'SessionService'];
	adFirstSetup.$inject = ['$http', '$scope', '$rootScope', '$log', '$state', '$location', 'keepVal', 'SessionService'];
	adSetup.$inject = ['$http', '$scope', '$rootScope', '$log', '$state', '$location', 'keepValsetup', 'keepVal', 'SessionService'];
	adReconAttributeRole.$inject = ['$http', '$scope', '$log', '$rootScope', '$state', 'keepRecon', 'keepValsetup', 'keepVal', '$mdDialog', '$location', 'SessionService'];
	var  Resourcetabs;
	function adMain($scope, $log, $state, $rootScope, $location, keepVal, keepValsetup, SessionService) {
		keepVal.storeAD = undefined;
		keepValsetup.storesetup = undefined;
		Resourcetabs = [
			{ title: 'Setup', tabLink: "ADaddresources.adaddrsc", tabSerial : "1"},
			{ title: 'Resource Details', tabLink: "ADaddresources.Details", tabSerial : "2"}
			/*{ title: 'Reconciliation Rule', tabLink: "ADaddresources.ADreconattributerule", tabSerial : "2"}*/     
		],
		selected = null,
		previous = null;
		$rootScope.Resourcetabs = Resourcetabs;
		$scope.selectedIndex = 0;
		$rootScope.loadWidth = 33;
		$scope.selectTabService = 0;
		$scope.$watch('selectedIndex', function(current, old){
			previous = selected;
			selected = Resourcetabs[current];
		});
		$scope.wizardActive = function(activePath){
			var activePath = activePath.replace('#','')
			activePath = activePath.replace('.','/');
			locationPath = $location.path();
			locationPath = locationPath.replace('/','');
			if(activePath === locationPath){
				return 'wizard-active';
			} 
			else {
				return '';
			}  
		}
	}
	function  adFirstSetup($http, $scope, $rootScope, $log, $state, $location, keepVal, SessionService) {
		var tabLength = $rootScope.Resourcetabs.length;
		var checkResourceURL = baseUrl + '/resources?check=true';
		var config = {
			url: checkResourceURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
			}
		}
		$http(config)
		.then(function success(response) {
			$rootScope.loaderCurrentStatus = 'false';
			if(response.data.type == 'success'){
				if (response.data.data.login[0].trusted == 'N') {
					$scope.TrustedAvailable = true;
					if(tabLength == 2)
						$rootScope.loadWidth = 50;
				} else if (response.data.data.login[0].trusted == 'Y') {
					$scope.TrustedAvailable = false;
					if(tabLength == 2) {
						$rootScope.Resourcetabs.push({ title: 'Reconciliation Rule', tabLink: "ADaddresources.ADreconattributerule",  tabSerial : "3"});
					}	
				}
			}
			else if(response.data.type == 'error'){
				$scope.toastMessage('toast-error',response.data.message);
			}
			else if(response.data.type == 'warning'){
				$scope.toastMessage('toast-warn',response.data.message);
			}
			
		},function error(response){
			// It will work when the server returns the status "500 - Internal server" or 400 series errors
			$rootScope.loaderCurrentStatus = 'false';
			$scope.errorHandler(response.config.url,response.status);
		});
		$scope.form = {};
		var adVal = keepVal.adGetVal();
		if(adVal != undefined) {
			if(tabLength === 3)
				$rootScope.loadWidth = 33;
			$scope.form.resourceName = adVal.resourceName;
			$scope.form.radiobuttonmodel = adVal.radiobuttonmodel;
		}
		$scope.selectTabService = 0;
		$scope.next = function(Resourcetabs){ 
			keepVal.adStore($scope.form);
			var resourcename = $scope.form.resourceName;           
			var istrusted = $scope.form.radiobuttonmodel;
			var addResourceuntrustedsecstepURL = baseUrl + '/addrscAD/chkrscname';   
			var config = 
			{
				url: addResourceuntrustedsecstepURL,
				method: "GET",
				headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
					"cdt-rescname":resourcename,
					"cdt-istrusted": istrusted,
						}
			}
			$http(config)
				.then(function success(response) {
			if(response.data.type == "success")
			{
				var cTab = $scope.selectedIndex + 1;
				if((cTab == '1') && (istrusted == 'N')){
				$rootScope.loadWidth = 66;
				} 
				if((cTab == '1') && (istrusted == 'Y')){
					 $rootScope.loadWidth = 100;
				} 
				tabLength = Resourcetabs.length;
				
				if(istrusted == 'N'){	
					if(tabLength == '2')
					Resourcetabs.push({ title: 'Reconciliation Rule', tabLink: "ADaddresources.ADreconattributerule",  tabSerial : "3"});
					} else {
					var tabIndex = Resourcetabs.findIndex(ResourcetabsArray => ResourcetabsArray.tabSerial == '3' );
					if(tabLength == '3')
					Resourcetabs.splice(tabIndex, 1);
					}
					$scope.selectedIndex = Math.min($scope.selectedIndex + 1, 5);
					var nextTab = $scope.selectedIndex;	
					var gotoUrl =  $rootScope.Resourcetabs[nextTab].tabLink;
				$state.go(gotoUrl);	
			}
			else if(response.data.type == "error")
			{
				$scope.toastMessage('toast-error',response.data.message);
				$state.go('ADaddresources.adaddrsc');
			}	
			else if(response.data.type == "warning"){
				$scope.toastMessage('toast-warn',response.data.message);
				$state.go('ADaddresources.adaddrsc');
				}
			},function error(response){
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				$rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);
				});  
		}
	}
		     
   function  adSetup($http, $scope, $rootScope, $log, $state, $location, keepValsetup,keepVal, SessionService){
        $scope.form = {};
        $scope.selectTabService = 1;
        var adVal = keepValsetup.setupGetVal();
        var adFirstVal = keepVal.adGetVal();
        if(adFirstVal == undefined) {
            $location.url('/ADaddresources/ADaddresource');
        } else {
            var resourcename = adFirstVal.resourceName;
            var istrustedval = adFirstVal.radiobuttonmodel;
            $scope.form.istrust = adFirstVal.radiobuttonmodel;
        }
        if(adVal != undefined){
			if(Resourcetabs.length == 3)
				$rootScope.loadWidth = 66;
            $scope.form.hostName = adVal.hostName;
            $scope.form.userName = adVal.userName;
            $scope.form.password = adVal.password;
            $scope.form.Port = adVal.Port;
            $scope.form.databaseName = adVal.databaseName;
        }
	/*This method load when it's trusted
	*/
		$scope.addrescsetupsubmit = function(Resourcetabs)
	    { 
			$rootScope.loaderCurrentStatus = 'true';
			var hostname = $scope.form.hostName;
			var username = $scope.form.userName;
			var password = $scope.form.password;
			var port = $scope.form.Port;
			var databasename = $scope.form.databaseName;     
			var addResourcetrustFinalURL = baseUrl + '/addrscAD/final';
			var config = {
				url: addResourcetrustFinalURL,
				method: "POST",
				headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
					"cdt-id":'4',
					"cdt-rescname":resourcename,
					"cdt-host":hostname,
					"cdt-username":username,
					"cdt-pwd":password, 
					"cdt-port":port,
					"cdt-istrusted": istrustedval,
					"cdt-dns": databasename,
						}
			}
			$http(config)
				.then(function success(response) {
					 $rootScope.loaderCurrentStatus = 'false';
		   if(response.data.type == "success"){
				$scope.toastMessage('toast-success',response.data.message);
				$state.go('resources');
				$scope.addTab('Resources','resources');
			}
			else if(response.data.type == "error"){
				$scope.toastMessage('toast-error',response.data.message);
				}
			else if(response.data.type == "warning"){
				$scope.toastMessage('toast-warn',response.data.message);
				}
			},function error(response) {
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);

		  });     
		};
       
	  /*This method loads when it's un trusted
	  */
		$scope.next = function(Resourcetabs) 
		{		
		$rootScope.loaderCurrentStatus = 'true';
		keepValsetup.setupStore($scope.form);
		var hostname = $scope.form.hostName;
		var username = $scope.form.userName;
		var password = $scope.form.password;
		var port = $scope.form.Port;
		var databasename = $scope.form.databaseName;     
		
		var addResourceuntrustedsecstepURL = baseUrl + '/addrscAD/chkrscdetails';
		var config = {  
				url: addResourceuntrustedsecstepURL,
				method: "GET",
				headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
					"cdt-host":hostname,
					"cdt-username":username,
					"cdt-pwd":password, 
					"cdt-port":port,
					"cdt-dns": databasename,
						}
			}
			$http(config)
				.then(function success(response) {
					$rootScope.loaderCurrentStatus = 'false';
				if(response.data.type == "success"){
					var cTab = $scope.selectedIndex + 1;
					if((cTab == '2') && (istrustedval == 'N')){
						$state.go("ADaddresources. ADreconattributerule");
						$rootScope.loadWidth = 100;
					} 
					var tabLength = Resourcetabs.length;
					$scope.selectedIndex = Math.min($scope.selectedIndex + 2, 5) ;

					var nextTab = $scope.selectedIndex;	
					var gotoUrl =  $rootScope.Resourcetabs[nextTab].tabLink;
					if($location.path() == '/ADaddresources/ adDetails'){
						$rootScope.loadWidth = 100;
						$state.go("ADaddresources.ADreconattributerule");
					}else{
						$state.go(gotoUrl);	
					}
			}
			else if(response.data.type == "error"){
				$scope.toastMessage('toast-error',response.data.message);
				$state.go('ADaddresources.Details');
			}	
			else if(response.data.type == "warning"){
				$scope.toastMessage('toast-warn',response.data.message);
				$state.go('ADaddresources.Details');
				}	
			},function error(response) {
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				$rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);

			});
		};
		$scope.previous = function(Resourcetabs) {
			$scope.selectedIndex = Math.max($scope.selectedIndex - 2, 0);
			var prevTab = $scope.selectedIndex;
			var gotoUrl = $rootScope.Resourcetabs[prevTab].tabLink;
			var tabLength = Resourcetabs.length;
			var cTab = $scope.selectedIndex + 1;
			if((cTab == '1') && (tabLength == '3')){
				 $rootScope.loadWidth = 33;
			} else {
				$rootScope.loadWidth = 50;
			}
			$state.go(gotoUrl);
		};  	
	}
	function  adReconAttributeRole($http, $scope, $log, $rootScope, $state, keepRecon, keepValsetup, keepVal, $mdDialog, $location, SessionService) {	 
		$rootScope.userattributetitle = false;
		$rootScope.loadWidth = 100;
		$rootScope.count=0;
		$scope.form={};
		$rootScope.listAttributes = [];
		$rootScope.finalMappingColumn = {"records": []};
		$scope.selectTabService = 2;
		var adVal = keepValsetup.setupGetVal();
		var adFirstVal = keepVal.adGetVal();
		if(adFirstVal == undefined) {
			$location.url('/ADaddresources/ADaddresource');
		} else {
			var resourcename = adFirstVal.resourceName;
			var istrustedval = adFirstVal.radiobuttonmodel;
		}
		var hostname = adVal.hostName;
		var username = adVal.userName;
		var password = adVal.password;
		var port = adVal.Port;
		var databasename = adVal.databaseName;
		$rootScope.count=0;
		  //add button
		$scope.userattributesvalues={"records": []};
		$scope.userattributeaddbutton=function($event,$scope){
		$mdDialog.show({
		   controller: addADReconController,
			controllerAs: 'adreconrulectrl',
			templateUrl: 'resources/addResource/activedirectoryResource/cloudentix-admin-resources-addResource-AD-reconRule.html',
			parent: angular.element(document.body),
			targetEvent: $event,
			clickOutsideToClose:false
		  })
		}
		//delete button
		$scope.Deleterecon=function(index){
			$rootScope.count--;			
			$rootScope.listAttributes.splice(index, 1);
			$rootScope.finalMappingColumn.records.splice(index, 1);
			if($rootScope.listAttributes.length === 0) {
				$rootScope.userattributetitle = false;
			}
		}	
		$scope.previous = function(Resourcetabs) {
		  $scope.selectedIndex = Math.max($scope.selectedIndex + 1, 0);
		  var prevTab = $scope.selectedIndex;
		  var gotoUrl = $rootScope.Resourcetabs[prevTab].tabLink;
		  $state.go(gotoUrl);
		  $rootScope.loadWidth = 50;

		}; 
		$scope.ADresourcesubmit = function() {
			$rootScope.loaderCurrentStatus = 'true';
			var addResourceFinalURL = baseUrl + '/addrscAD/final';
			$scope.finalAttribute = {'records':[]};
			angular.forEach($rootScope.finalMappingColumn.records, function(value, key) {
				var array = [];
				var array1 = [];
				if(value["userAttrId"]== '1'){
							$scope.userAttrId = value["userAttrId"];
							array.push(value["concat1"]+','+value["concat2"]);						
						}
						//SubString User Attribute Mapping
						else if(value["userAttrId"]== '2'){
							$scope.userAttrId = value["userAttrId"];
							array.push(value["substringMapping"]+','+value["substring"]);						
						}
						//DirectMapping User Attribute Mapping
						else if(value["userAttrId"]== '3'){
							$scope.userAttrId = value["userAttrId"];
							array.push(value["directmapping"]);
						}
						//Target Attribute Mapping
						//Concat Target Attribute Mapping
						if(value["targetCol"]== '1'){
							$scope.targetuserAttrId = value["targetCol"];
							array1.push(value["targetConcat1"]+','+value["targetConcat2"]);					
						}
						//SubString Target Attribute Mapping
						else if(value["targetCol"]== '2'){
							$scope.targetuserAttrId = value["targetCol"];
							array1.push(value["targetsubstringMapping"]+','+value["targetSubstring"]);						
						}
						//DirectMapping Target Attribute Mapping
						else if(value["targetCol"]== '3'){
							$scope.targetuserAttrId = value["targetCol"];
							array1.push(value["targetdirectMapping"]);
						}
						//array1.push(value["targetCol"]);
						$scope.finalAttribute.records.push({"cloudusrattr":[{"methodid": $scope.userAttrId,"col": array}], "trgtusrattr":[{"methodid":$scope.targetuserAttrId,"col": array1}]});
				   
			   // array.push(value["userAttrId"]);
				//array1.push(value["targetCol"]);
				//$scope.finalAttribute.records.push({"cloudusrattr":[{"methodid": '3',"col": array}], "trgtusrattr":[{"methodid":"3","col": array1}]});
			});
			var data = angular.toJson($scope.finalAttribute);
			//console.log(angular.toJson($scope.finalAttribute));
			// console.log(resourcename +" "+istrustedval+" "+hostname+" "+username+" "+password+" "+port+" "+databasename)
			var config = {
				url : addResourceFinalURL,
				method :"POST",
				headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
					"cdt-id": '4',
					"cdt-rescname": resourcename,
					"cdt-host": hostname,
					"cdt-username": username,
					"cdt-pwd": password, 
					"cdt-port": port,
					"cdt-istrusted": istrustedval,
					"cdt-dns": databasename,
					"cdt-reconattribute": data,
					"cdt-singlerole": 'N'
				}
			}				
			$http(config)
				.then(function success(response) {
					$rootScope.loaderCurrentStatus = 'false';
				if(response.data.type == "success"){
					$scope.toastMessage('toast-success',response.data.message);
					$state.go('resources');
					$scope.addTab('Resources','resources');
					}
			
				else if(response.data.type == "error"){
					$rootScope.loaderCurrentStatus = 'false';
					$scope.toastMessage('toast-error',response.data.message);
					}
				
				else if(response.data.type == "warning"){
					$rootScope.loaderCurrentStatus = 'false';
					$scope.toastMessage('toast-warn',response.data.message);
					}
			},function error(response) {
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);
			});		 
		};	 
	}
	function addADReconController($http, $scope, $rootScope, $state,$mdDialog,keepUDM,keepRecon, SessionService){
		$scope.form={};
		var length=$rootScope.listAttributes.length;
		var tableval=keepUDM.primaryTableGetVal();
		var self = this;
		$scope.userattributesvalue = {"records": []};
		$scope.reconruleSelected = '';					
		var addResourceUserMappingMethodURL = baseUrl + '/method';
		var config = {
			url: addResourceUserMappingMethodURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
			}
		}
		$http(config)
			.then(function success(response) {
			$rootScope.loaderCurrentStatus = 'false';
			$scope.userResponse = response.data.type;   	
			$scope.addMappinguserattributes = [];     
			if (response.data.type == "success") {			
				for(var i=0;i<response.data.records[0].dropdownlist.length;i++)
				{
					$scope.addMappinguserattributes.push({"id":response.data.records[0].dropdownlist[i].key,"value":response.data.records[0].dropdownlist[i].value});
					if(response.data.records[0].dropdownlist[i].key=="3"){
						$scope.reconruleSelected=response.data.records[0].dropdownlist[i].value;
					}	
				}
				}
				else {
						$scope.managesystemErrorMessage = response.message;
					}
			},function error(response) {
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);

		  });	
			var addResourceUserAttributesMappingURL = baseUrl + '/userattributes';
			var config = {
				url: addResourceUserAttributesMappingURL,
				method: "GET",
				headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
				}
			}
			$http(config)
				.then(function success(response) {        
				$scope.resourceuserattributes = [];               
					for(var i=0;i<response.data.records[0].listattributes.length;i++)
					{
						$scope.resourceuserattributes.push({"id":response.data.records[0].listattributes[i].colname,"value":response.data.records[0].listattributes[i].displayname});
					}
			},function error(response) {
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);

		  });
			var AdlistColumns = baseUrl + '/addrscAD/gettargetcol';
			var config = {
			url: AdlistColumns,
			method: "GET",
			headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
				}
			}
			$http(config)
				.then(function success(response) {
				$scope.targetcolumns=[];
				angular.forEach(response.data.records[0].targetcolumns, function(value,key) {
					$scope.targetcolumns.push(value); 
				});
			},function error(response) {
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				$scope.errorHandler(response.config.url,response.status);
		  });
		self.cancel = function($event) {
		  $mdDialog.cancel();
		}
		self.finish = function($event) {
			$rootScope.listAttributes.push({});
			if($scope.userattributesvalue.records[0].userAttrId=='1'){
				var userConcat="concat("+$scope.userattributesvalue.records[0].concat1+","+$scope.userattributesvalue.records[0].concat2+")";
				$scope.attrId=$scope.userattributesvalue.records[0].userAttrId;
				$scope.userAttrConcat=userConcat;
				//console.log($scope.userattributesvalue.records[0].concat1);
				$rootScope.listAttributes[length].userattribute = userConcat;
			}
			else if($scope.userattributesvalue.records[0].userAttrId=='2'){
				var userSubstring="substring("+$scope.userattributesvalue.records[0].substringMapping+","+$scope.userattributesvalue.records[0].substring+")";
				//console.log(userSubstring);
				$rootScope.listAttributes[length].userattribute = userSubstring;
			}
			else if($scope.userattributesvalue.records[0].userAttrId=='3'){
				var userDirectMapping="directmapping("+$scope.userattributesvalue.records[0].directmapping+")";
				//console.log(userDirectMapping);
				$rootScope.listAttributes[length].userattribute = userDirectMapping;
			}
			if($scope.userattributesvalue.records[0].targetCol=='1'){
				var targetConcat="concat("+$scope.userattributesvalue.records[0].targetConcat1+","+$scope.userattributesvalue.records[0].targetConcat2+")";
				//console.log(targetConcat);
				$rootScope.listAttributes[length].targetattribute = targetConcat;
			}
			else if($scope.userattributesvalue.records[0].targetCol=='2'){
				var targetSubstringMapping="substring("+$scope.userattributesvalue.records[0].targetsubstringMapping+","+$scope.userattributesvalue.records[0].targetSubstring+")";
				//console.log(targetSubstringMapping);
				$rootScope.listAttributes[length].targetattribute = targetSubstringMapping;
			}
			else if($scope.userattributesvalue.records[0].targetCol=='3'){
				var targetAttrDirectMapping="directmapping("+$scope.userattributesvalue.records[0].targetdirectMapping+")";
				//console.log(targetAttrDirectMapping);
				$rootScope.listAttributes[length].targetattribute = targetAttrDirectMapping;
			}
			$rootScope.finalMappingColumn.records.push($scope.userattributesvalue.records[0]);
			//console.log($rootScope.finalMappingColumn);	
			$mdDialog.hide();
			var arr=[];
			angular.forEach($rootScope.listAttributes, function(value, key) {
			arr.concat([arr.push(value.userattribute + ' '+value.targetattribute)]);
			});
			//console.log(arr);
			var uniqOb = {};
			for (var i in arr)
				uniqOb[arr[i]] = "";
			if (arr.length == Object.keys(uniqOb).length){
			}
			else{
			$rootScope.listAttributes.splice(-1, 1);
			$rootScope.finalMappingColumn.records.splice(-1, 1);
			  $mdDialog.show(
				$mdDialog.alert()
				.clickOutsideToClose(false)
				.title('Recon Rule')
				.textContent('Selected Recon Rule already exists. Please select a different User Attributes Mapped Column and Target Attributes Mapped Column')
				.ok('ok')
			);
			}
			$rootScope.userattributetitle = true;
			$rootScope.count++;
		};

	}
angular
	.module('cloudentixApp')
	.controller('MsSqladdrescourcemainctrl',mssqladdRscMainCtrl)
	.controller('MsSqladdresourcemysqlsetupCtrl',mssqlsetup)
	.controller('MsSqluserdatamappingcontroller',mssqluserdatamapping)
	.controller('MsSqlchildtabledatamappingcontroller',mssqlchilddatamapping)
	.controller('MsSqluserattrmappingcontroller',mssqlUserattrmapping)
	.controller('MsSqltrusteduserattrmappingcontroller',mssqlTrustedUserAttrMapping)
	.controller('MsSqllookupTabledataMappingController',mssqlLookupTableDataMapping)

	.config(
		['$stateProvider', '$urlRouterProvider',
			function($stateProvider,$urlRouterProvider){
				$urlRouterProvider
				$stateProvider
					.state('MsSqladdresources.mssqladdrsc', {
						url:'/mssqladdrsc',
						templateUrl: 'resources/addResource/mssql/cloudentix-admin-resources-addResource-mssql-setup.html',
					})
					.state('MsSqladdresources.userdatamapping', {
						url: '/mssqluserdatamapping',
						templateUrl: 'resources/addResource/mssql/cloudentix-admin-resources-addResource-mssql-userdatamapping.html',
					})
					.state('MsSqladdresources.childtabledatamapping', {
						url: '/mssqlchildtabledatamapping',
						templateUrl: 'resources/addResource/mssql/cloudentix-admin-resources-addResource-mssql-childtabledatamapping.html',
					})
					//mssql-trusted  
					.state('MsSqladdresources.userattributesmapping', {
						url: '/mssqluserattributesmapping',
						templateUrl: 'resources/addResource/mssql/cloudentix-admin-resources-addResource-mssql-trusteduserattributesmapping.html',
					}) 
            
					//mssql-untrusted-reconattributerule
					.state('MsSqladdresources.recon', {
						url: '/mssqlrecon',
						templateUrl: 'resources/addResource/mssql/cloudentix-admin-resources-addResource-mssql-userattributesmapping.html',
					})
					.state('MsSqladdresources.lookuptabledatamapping', {
						url: '/mssqllookuptabledatamapping',
						templateUrl: 'resources/addResource/mssql/cloudentix-admin-resources-addResource-mssql-lookuptabledatamapping.html',
					});
			}
		]
	)
	.service('keepValue', function(){
		this.mysqlStore = function(x, y){
			this.storemysql = x;
			this.storetablemysql = y;
		}
		this.mysqlGetVal = function(){
			return this.storemysql;
		}
		this.tableGetVal = function(){
			return this.storetablemysql;
		}
	  })
	.service('keepUDM', function(){
		this.udmStore = function(x,y){
			this.storeUDM = x;
			this.storeprimarytablemysql = y;
	  }
	  this.UDMGetVal = function(){
			return this.storeUDM;
	  }
	  this.primaryTableGetVal = function(){
			return this.storeprimarytablemysql;
	  }
	})
	.service('keepCDM', function(){
		this.cdmStore = function(x){
			this.storeCDM = x;
		}
		this.CDMGetVal = function(){
			return this.storeCDM;
		}
	})
	.service('keepRecon', function(){
		this.reconStore = function(x){
			this.storeRecon = x;
		}
		this.reconAttrStore = function(x){
			this.storeAttributeRecon = x;
		}
		this.reconGetVal = function(){
			return this.storeRecon;
		}
		this.reconGetAttr = function(){
			return this.storeAttributeRecon;
		}
	})
	.service('keepTUAM', function(){
		this.tuamStore = function(x){
			this.storeTUAM = x;
		}
		this.tuamGetVal = function(){
			return this.storeTUAM;
		}
	})
	  .factory('selectTabService', function(){
		var tabActive = '0';
		return {  
		tabActive: function() { return tabActive; },
		setTabActive: function(x) { tabActive = x; }
			};
		})
	.run(['$rootScope', '$state', '$stateParams',
        function($rootScope, $state, $stateParams) {
            $rootScope.$state = $state;
            $rootScope.$stateParams = $stateParams;
			}
		])
		mssqladdRscMainCtrl.$inject = ['$scope', '$log', '$state', '$rootScope', '$location', 'keepValue', 'keepUDM', 'keepCDM', 'keepRecon', 'keepTUAM', 'SessionService'];
		mssqlsetup.$inject = ['$scope','$http','$rootScope', '$state','keepValue', 'SessionService'];
		mssqluserdatamapping.$inject = ['$http', '$scope', '$rootScope', '$state','keepUDM', 'keepValue', '$timeout', '$location', 'SessionService'];
		mssqlchilddatamapping.$inject = ['$http','$scope','$state','$rootScope', 'keepValue','keepCDM','keepUDM', '$timeout', '$location', 'SessionService'];
		mssqlUserattrmapping.$inject = ['$http', '$scope', '$rootScope', '$state','keepUDM','keepRecon', '$mdDialog', 'keepValue', '$location', 'SessionService'];
		mssqlTrustedUserAttrMapping.$inject = ['$http', '$scope', '$rootScope', '$state', 'keepUDM','keepValue','keepTUAM', '$location', 'SessionService'];
		mssqlLookupTableDataMapping.$inject = ['$http','$scope','$rootScope','$state', 'keepValue', 'keepUDM', 'keepCDM', 'keepRecon','keepTUAM', '$mdDialog', '$location', 'SessionService'];
	function mssqladdRscMainCtrl ($scope, $log, $state, $rootScope, $location, keepValue, keepUDM, keepCDM, keepRecon, keepTUAM, SessionService) {
		keepValue.storemysql = undefined;
		keepUDM.storeUDM = undefined;
		keepCDM.storeCDM = undefined;
		keepRecon.storeRecon = undefined;
		keepTUAM.storeTUAM = undefined;
		// keepDM.storeDM = undefined;
		$scope.selectTabService = 0;
		var Resourcetabs = [
			{ title: 'Setup', tabLink: "MsSqladdresources.mssqladdrsc", tabSerial : "1"},
			{ title: 'User Data Mapping', tabLink: "MsSqladdresources.userdatamapping", tabSerial : "2"},
			{ title: 'Role Data Mapping', tabLink: "MsSqladdresources.childtabledatamapping", tabSerial : "3"},          
			{ title: 'User Attributes Mapping', tabLink: "MsSqladdresources.userattributesmapping", tabSerial : "4"},
			{ title: 'Reference Data Mapping', tabLink: "MsSqladdresources.lookuptabledatamapping", tabSerial : "5"}
		],
        selected = null,
        previous = null;
		$rootScope.Resourcetabs = Resourcetabs;
		$scope.selectedIndex = 0;
		$rootScope.loadWidth = 20;
		$scope.$watch('selectedIndex', function(current, old){
			//console.log( $scope.selectedIndex);
			previous = selected;
			selected = Resourcetabs[current];
		});
	
	$scope.wizardActive = function(activePath){
        var activePath = activePath.replace('#','')
		activePath = activePath.replace('.','/');
		locationPath = $location.path();
		   locationPath = locationPath.replace('/','');
			if(activePath === locationPath){
			   return 'wizard-active';
			}else{
			   return '';
			}
        }
    
	}
  
  	function mssqlsetup($scope,$http,$rootScope, $state,keepValue, SessionService){
        var checkResourceURL = baseUrl + '/resources?check=true';
		var config = {
			url: checkResourceURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
			}
		}
       	$http(config)
		.then(function success(response) {
			$rootScope.loaderCurrentStatus = 'false';
			if(response.data.type == 'success'){
				if (response.data.data.login[0].trusted == 'N') {
					$scope.TrustedAvailable = true;
				} else if (response.data.data.login[0].trusted == 'Y') {
					$scope.TrustedAvailable = false;
					$rootScope.Resourcetabs[3].title = "Reconciliation Rule"
					$rootScope.Resourcetabs[3].tabLink = "MsSqladdresources.recon"	
				}
			}
			else if(response.data.type == 'error'){
				$scope.toastMessage('toast-error',response.data.message);
			}
			else if(response.data.type == 'warning'){
				$scope.toastMessage('toast-warn',response.data.message);
			}
			
		},function error(response){
			// It will work when the server returns the status "500 - Internal server" or 400 series errors
			$rootScope.loaderCurrentStatus = 'false';
			$scope.errorHandler(response.config.url,response.status);
		});
		$scope.form={};
		var mssqlval=keepValue.mysqlGetVal();
        $scope.selectTabService = 0;
		if(mssqlval != undefined)
		{
			$scope.form.resourceName = mssqlval.resourceName;
			$scope.form.hostName = mssqlval.hostName;
			$scope.form.userName = mssqlval.userName;
			$scope.form.password = mssqlval.password;
			$scope.form.Port = mssqlval.Port;
			$scope.form.databaseName = mssqlval.databaseName;
			$scope.form.radiobuttonmodel = mssqlval.radiobuttonmodel;
		}
		$scope.next = function(Resourcetabs){
            $rootScope.loaderCurrentStatus = 'true';
			var resourcename = $scope.form.resourceName;
			var hostname = $scope.form.hostName;
			var username = $scope.form.userName;
			var password = $scope.form.password;
			var port = $scope.form.Port;
			var databasename = $scope.form.databaseName;     
			var radiobuttonmodel = $scope.form.radiobuttonmodel;
			
			var addResourceSetupURL = baseUrl + '/addmssql/gettargettables';
			var config = {
			url: addResourceSetupURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                "cdt-rescname":resourcename,
                "cdt-host":hostname,
                "cdt-port":port,
                "cdt-username":username,
                "cdt-pwd":password,
                "cdt-db":databasename, 
                "cdt-istrusted":radiobuttonmodel
				}
			}
		$http(config)
			.then(function success(response) {
            $rootScope.loaderCurrentStatus = 'false';
			if(response.data.type=="success"){
				$scope.resourcetargettables = [];     
                angular.forEach(response.data.records[0].targettables, function(key,value) {
                $scope.resourcetargettables.push(response.data.records[0].targettables[value]);
                }); 
				if(radiobuttonmodel === 'N'){
					var temp;
					temp = Resourcetabs[3].title;
					Resourcetabs[3].title = "Reconciliation Rule"
					Resourcetabs[3].tabLink = "MsSqladdresources.recon"
				} else {
					var temp;
					temp = Resourcetabs[3].title;
					Resourcetabs[3].title = "User Attributes Mapping"
					Resourcetabs[3].tabLink = "MsSqladdresources.userattributesmapping"
				}
				keepValue.mysqlStore($scope.form, $scope.resourcetargettables);
				$scope.selectedIndex = Math.min($scope.selectedIndex + 1, 5) ;
				//selectTabService.setTabActive($scope.selectedIndex);
				var nextTab = $scope.selectedIndex;	
				var gotoUrl =  $rootScope.Resourcetabs[nextTab].tabLink;
				$state.go(gotoUrl);
				$rootScope.loadWidth = 40;
			}
			else if(response.data.type == "error"){
			$scope.toastMessage('toast-error',response.data.message);
			$state.go('MsSqladdresources.mssqladdrsc');
            }
            else if(response.data.type == "warning"){
			$scope.toastMessage('toast-warn',response.data.message);
			$state.go('MsSqladdresources.mssqladdrsc');
            }
		},function error(response){
			// It will work when the server returns the status "500 - Internal server" or 400 series errors
			$rootScope.loaderCurrentStatus = 'false';
			$scope.errorHandler(response.config.url,response.status);
		});
		}
	}
	function mssqluserdatamapping($http, $scope, $rootScope, $state,keepUDM, keepValue, $timeout, $location, SessionService){
		$scope.form = {};
		$scope.userdatamappingform = {};
        var mssqlVal = keepValue.mysqlGetVal();
        if(mssqlVal == undefined) {
            $location.url('/MsSqladdresources/mssqladdrsc');
			return;
        }
		var udmVal = keepUDM.UDMGetVal();
		$scope.istrustedvalfinal = mssqlVal.radiobuttonmodel;
		var tableval=keepValue.tableGetVal();
		$scope.selectTabService = 1;
		var countservice = 0;
		$scope.usertable= angular.copy(tableval);
		$scope.getlistofcolumns=function(tableform){
            $rootScope.loaderCurrentStatus = 'true';
			$scope.form.singleSelectusertablekey = '';
			$scope.form.singleSelectpasswordcolumn = '';
			$scope.form.singleSelectstatuscol = '';
			$scope.form.enableValue = '';
			$scope.form.disableValue = '';
			tableform.$setUntouched();
            tableform.$setPristine(true);
			var addResourceUserDataMappingURL = baseUrl + '/addmssql/gettargetcolumns';
			var resourcetablename = $scope.form.usertablenamemodel;
			var hostname = mssqlVal.hostName;
			var username = mssqlVal.userName;
			var password = mssqlVal.password;
			var port = mssqlVal.Port;
			var databasename = mssqlVal.databaseName;
			var istrustedval = mssqlVal.radiobuttonmodel;
			
			var config = {
				url : addResourceUserDataMappingURL,
				method : "GET",
				headers : {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
					"cdt-host":hostname,
					"cdt-port":port,
					"cdt-username":username,
					"cdt-pwd":password,
					"cdt-db":databasename, 
					"cdt-istrusted":istrustedval,
					"cdt-tablename":resourcetablename,
				}
			}
			$http(config)
				.then(function success(response) {
                $rootScope.loaderCurrentStatus = 'false';
				$scope.resourcetargetcolumns = [];
				angular.forEach(response.data.records[0].targetcolumns,function(key,value){
					$scope.resourcetargetcolumns.push(response.data.records[0].targetcolumns[value]);
				})
				$scope.usertablekey= angular.copy($scope.resourcetargetcolumns);
				var passwordnone=["None"];
				var passwordcolumn1= angular.copy($scope.resourcetargetcolumns);
				$scope.passwordcolumn=passwordnone.concat(passwordcolumn1);
				if(istrustedval == "Y")
				{
					$scope.statuscolumn= angular.copy($scope.resourcetargetcolumns);
				}
				else{
					var statusone=["None"];
					var statuscolumn1= angular.copy($scope.resourcetargetcolumns);
					$scope.statuscolumn= statusone.concat(statuscolumn1);
				}
				$scope.userrolecolumn= angular.copy($scope.resourcetargetcolumns);
				if(udmVal != undefined && countservice === 0){
					$scope.form.singleSelectusertablekey = udmVal.singleSelectusertablekey;
					$scope.form.singleSelectpasswordcolumn = udmVal.singleSelectpasswordcolumn;
					$scope.form.singleRoleMapping = udmVal.singleRoleMapping;
					$scope.form.singleSelectstatuscol = udmVal.singleSelectstatuscol;
					$scope.form.enableValue = udmVal.enableValue;
					$scope.form.disableValue = udmVal.disableValue;
					$timeout(function () {
						$scope.form.singleSelectedRole = udmVal.singleSelectedRole;
					}, 1000);	
				}
				countservice = countservice + 1;
			},function error(response){
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				$rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);
		});
		}
		$scope.resetStatusValue = function(selectedStatus) {
            if(selectedStatus == 'None') {
                $scope.form.enableValue = '';
                $scope.form.disableValue  = '';
            }
        }
		if(udmVal != undefined){
		$rootScope.loaderCurrentStatus = 'true';	
		$scope.form.usertablenamemodel = udmVal.usertablenamemodel;
		$timeout(function () {
				$scope.getlistofcolumns($scope.userdatamappingform.loginForm);
            }, 1000);
        //$scope.form.singleSelectusertablekey = udmVal.singleSelectusertablekey;
        //$scope.form.singleSelectpasswordcolumn = udmVal.singleSelectpasswordcolumn;
		//$scope.form.singleRoleMapping = udmVal.singleRoleMapping;
		//$scope.form.singleSelectedRole = udmVal.singleSelectedRole;
        //$scope.form.singleSelectstatuscol = udmVal.singleSelectstatuscol;
        //$scope.form.enableValue = udmVal.enableValue;
        //$scope.form.disableValue = udmVal.disableValue;
		}
		$scope.next = function(Resourcetabs) {
			if($scope.form.singleSelectpasswordcolumn=="None") {
				$scope.form.singleSelectpasswordcolumn="";
			}
			if($scope.form.singleSelectstatuscol=="None") {
				$scope.form.singleSelectstatuscol="";
			}
			keepUDM.udmStore($scope.form , $scope.resourcetargetcolumns);
			$scope.selectedIndex = Math.min($scope.selectedIndex + 2, 5) ;
			var nextTab = $scope.selectedIndex;	
			var gotoUrl =  $rootScope.Resourcetabs[nextTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 60;
		};		
		$scope.previous = function(Resourcetabs) {
			$scope.selectedIndex = Math.max($scope.selectedIndex - 2, 0);
			var prevTab = $scope.selectedIndex;
			var gotoUrl = $rootScope.Resourcetabs[prevTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 20;
		};  	
	}
	function mssqlchilddatamapping($http,$scope,$state,$rootScope, keepValue,keepCDM,keepUDM, $timeout, $location, SessionService){
		$scope.form = {};
        var mssqlVal = keepValue.mysqlGetVal();
        if(mssqlVal == undefined) {
            $location.url('/MsSqladdresources/mssqladdrsc');
			return;
        }
		var udmVal = keepUDM.UDMGetVal();
		$scope.singlerolemapvalue = udmVal.singleRoleMapping;
		var cdmVal = keepCDM.CDMGetVal();
		var tableval=keepValue.tableGetVal();
        $scope.selectTabService = 2;
		$scope.userroletable= angular.copy(tableval);
		$scope.roletablevalue= angular.copy(tableval);
		if($scope.singlerolemapvalue == 'N')
		{
		$scope.getlistofcolumnsforuserrole=function(tableform, useridcol, roleidcol){
            $rootScope.loaderCurrentStatus = 'true';
			$scope.form.useridcolumnmodel = '';
			$scope.form.userroleidcolumnmodel = '';
			tableform.$setUntouched();
            tableform.$setPristine(true);
			var addResourceChildDataMappingURL = baseUrl + '/addmssql/gettargetcolumns';
			var userroletableid = $scope.form.userroletablemodel;
			var hostname = mssqlVal.hostName;
			var username = mssqlVal.userName;
			var password = mssqlVal.password;
			var port = mssqlVal.Port;
			var databasename = mssqlVal.databaseName;
			var istrustedval = mssqlVal.radiobuttonmodel;
			if(userroletableid != undefined){
				var config = {
					url : addResourceChildDataMappingURL,
					method : "GET",
					headers : {
						"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
						"cdt-host":hostname,
						"cdt-port":port,
						"cdt-username":username,
						"cdt-pwd":password,
						"cdt-db":databasename, 
						"cdt-istrusted":istrustedval,
						"cdt-tablename":userroletableid,
					}
				}
				$http(config)
					.then(function success(response) {
					$rootScope.loaderCurrentStatus = 'false';
					$scope.resourcetargetcolumnsuserroletable = [];
					angular.forEach(response.data.records[0].targetcolumns,function(key,value){
						$scope.resourcetargetcolumnsuserroletable.push(response.data.records[0].targetcolumns[value]);
					})
					$scope.useridcolumn= angular.copy($scope.resourcetargetcolumnsuserroletable);
					$scope.userroleidcolumn= angular.copy($scope.resourcetargetcolumnsuserroletable);
					if(useridcol != undefined && roleidcol != undefined) {
						$scope.form.useridcolumnmodel = cdmVal.useridcolumnmodel;
						$scope.form.userroleidcolumnmodel = cdmVal.userroleidcolumnmodel;
					}
				},function error(response){
					// It will work when the server returns the status "500 - Internal server" or 400 series errors
					$rootScope.loaderCurrentStatus = 'false';
					$scope.errorHandler(response.config.url,response.status);
				});
			}
		}		
		}
		$scope.getlistofcolumnsforroletable = function(tableform, roleidcol, rolenamecol){
            $rootScope.loaderCurrentStatus = 'true';
			$scope.form.roleidcolumnmodel = '';
			$scope.form.rolenamecolumnmodel = '';
			tableform.$setUntouched();
            tableform.$setPristine(true);
			var addResourceChildDataMappingURL = baseUrl + '/addmssql/gettargetcolumns';
			var userroletableid = $scope.form.roletablemodel;
			var hostname = mssqlVal.hostName;
			var username = mssqlVal.userName;
			var password = mssqlVal.password;
			var port = mssqlVal.Port;
			var databasename = mssqlVal.databaseName;
			var istrustedval = mssqlVal.radiobuttonmodel;
			var config = {
				url : addResourceChildDataMappingURL,
				method : "GET",
				headers : {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
					"cdt-host":hostname,
					"cdt-port":port,
					"cdt-username":username,
					"cdt-pwd":password,
					"cdt-db":databasename, 
					"cdt-istrusted":istrustedval,
					"cdt-tablename":userroletableid,
				}
			}
			$http(config)
				.then(function success(response) {
                $rootScope.loaderCurrentStatus = 'false';
				$scope.resourcetargetcolumnsroletable = [];
				angular.forEach(response.data.records[0].targetcolumns,function(key,value){
					$scope.resourcetargetcolumnsroletable.push(response.data.records[0].targetcolumns[value]);
				})
				$scope.roleidcolumn= angular.copy($scope.resourcetargetcolumnsroletable);
				$scope.rolenamecolumn= angular.copy($scope.resourcetargetcolumnsroletable);
				if(roleidcol != undefined && rolenamecol != undefined) {
					$scope.form.roleidcolumnmodel = cdmVal.roleidcolumnmodel;
					$scope.form.rolenamecolumnmodel = cdmVal.rolenamecolumnmodel;
				}
			},function error(response){
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				$rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);
			});
		}
		$scope.next = function(Resourcetabs) {
			keepCDM.cdmStore($scope.form);
			$scope.selectedIndex = Math.min($scope.selectedIndex + 3, 5) ;
			//selectTabService.setTabActive($scope.selectedIndex);
			var nextTab = $scope.selectedIndex;	
			var gotoUrl =  $rootScope.Resourcetabs[nextTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 80;
		};
		if(cdmVal != undefined){
			 $rootScope.loaderCurrentStatus = 'true';
			if($scope.singlerolemapvalue == 'N'){
			$scope.form.userroletablemodel = cdmVal.userroletablemodel;
			$timeout(function () {
					$scope.getlistofcolumnsforuserrole($scope.childdatamappingform.loginForm, cdmVal.useridcolumnmodel, cdmVal.userroleidcolumnmodel);
				}, 1000);
			}
			//this for role table
			$scope.form.roletablemodel = cdmVal.roletablemodel;
			$timeout(function () {
						$scope.getlistofcolumnsforroletable($scope.childdatamappingform.loginForm, cdmVal.roleidcolumnmodel, cdmVal.rolenamecolumnmodel);
					}, 1000);
			}
		
			$scope.previous = function(Resourcetabs){
				$scope.selectedIndex = Math.max($scope.selectedIndex - 0, 1);
				//selectTabService.setTabActive($scope.selectedIndex);
				var prevTab = $scope.selectedIndex;
				var gotoUrl = $rootScope.Resourcetabs[prevTab].tabLink;
				$state.go(gotoUrl);
				$rootScope.loadWidth = 40;
			}
	}
	
	function mssqlUserattrmapping($http, $scope, $rootScope, $state,keepUDM,keepRecon, $mdDialog, keepValue, $location, SessionService){
        var mssqlVal = keepValue.mysqlGetVal();
		$rootScope.userattributetitle = false;
        if(mssqlVal == undefined) {
            $location.url('/MsSqladdresources/mssqladdrsc');
			return;
        }
		var reconval = keepRecon.reconGetVal();
		var reconvalAttr = keepRecon.reconGetAttr();
		$rootScope.count=0;
		$scope.form={};
		$rootScope.listAttributes = [];
		$rootScope.finalMappingColumn = {"records": []};
		$scope.userattributeaddbutton=function($event,$scope){
		$mdDialog.show({
			controller: addmsSqlReconController,
			controllerAs: 'msSqlreconrulectrl',
			templateUrl: 'resources/addResource/mssql/cloudentix-admin-resources-addResource-mssql-addReconRule.html',
			parent: angular.element(document.body),
			targetEvent: $event,
			//controller: mdDialogCtrl,
			clickOutsideToClose:false
		})
		}
		 	 //delete button
		$scope.Deleterecon=function(index){
			$rootScope.count--;			
			$rootScope.listAttributes.splice(index, 1);
			$rootScope.finalMappingColumn.records.splice(index, 1);
            if($rootScope.listAttributes.length == 0) {
                $rootScope.userattributetitle = false;
            }
		}			
		if(reconval != undefined && reconvalAttr != undefined) {
			$rootScope.userattributetitle = true;
			$scope.trustusratt=reconval;
			var length=reconvalAttr.length;
			for(var i = 0; i < length; i++)
			{
				$scope.listAttributes.push({});
				$rootScope.count++;
			}
			for(var count = 0; count < length; count++)
			{					
				$scope.listAttributes[count].userattribute = reconvalAttr[count].userattribute;
				$scope.listAttributes[count].targetattribute = reconvalAttr[count].targetattribute;					
			}
			angular.forEach($scope.trustusratt, function(value, key) {
				$rootScope.finalMappingColumn.records.push(value);
			});			
		}	
		$scope.previous = function(Resourcetabs) {
			$scope.selectedIndex = Math.max($scope.selectedIndex - 1, 2);
			var prevTab = $scope.selectedIndex;
			var gotoUrl = $rootScope.Resourcetabs[prevTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 60;
		}; 		
		$scope.next = function(Resourcetabs){
			keepRecon.reconStore($rootScope.finalMappingColumn.records);
			keepRecon.reconAttrStore($rootScope.listAttributes);
			$scope.selectedIndex = Math.min($scope.selectedIndex + 4, 5) ;
			var nextTab = $scope.selectedIndex;	
			var gotoUrl =  $rootScope.Resourcetabs[nextTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 100;
		}	
	}
	
	function mssqlTrustedUserAttrMapping($http, $scope, $rootScope, $state, keepUDM,keepValue,keepTUAM, $location, SessionService){
		$scope.form={};
		var mssqlVal = keepValue.mysqlGetVal();
        if(mssqlVal == undefined) {
            $location.url('/MsSqladdresources/mssqladdrsc');
			return;
        }
		$scope.resourcename = mssqlVal.resourceName;
        $scope.selectTabService = 4;
		var trustusrattrmappval = keepTUAM.tuamGetVal();
		var tableval=keepUDM.primaryTableGetVal();
		$scope.targetcolumns= angular.copy(tableval);
        $rootScope.loaderCurrentStatus = 'true';
		var addResourceUserAttributesMappingURL = baseUrl + '/userattributes';
		var config = {
			url: addResourceUserAttributesMappingURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
            }
		}
		$scope.reconattribute = {"records": []}; 
		$http(config)
			.then(function success(response) {
			$rootScope.loaderCurrentStatus = 'false';
            for(var i=0;i<response.data.records[0].listattributes.length;i++)
			{
				$scope.reconattribute.records.push({"id":response.data.records[0].listattributes[i].userattid,"value":response.data.records[0].listattributes[i].displayname,"uniqueflag":response.data.records[0].listattributes[i].uniqueflag});
			}
		},function error(response){
			// It will work when the server returns the status "500 - Internal server" or 400 series errors
			$rootScope.loaderCurrentStatus = 'false';
			$scope.errorHandler(response.config.url,response.status);
		});
		$scope.previous = function(Resourcetabs) {
			$scope.selectedIndex = Math.max($scope.selectedIndex - 1, 2);
			var prevTab = $scope.selectedIndex;
			var gotoUrl = $rootScope.Resourcetabs[prevTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 60;

		}; 
		if(trustusrattrmappval != undefined) {
			$scope.trustusratt=trustusrattrmappval;
			angular.forEach($scope.trustusratt.records, function(value, key) {
				$scope.form[value["userAttrId"]] = value["targetCol"];
			});
			
		}
		
		$scope.next = function(Resourcetabs) {
			var userAttr = {"records": []};
			angular.forEach($scope.form, function(value, key) {
				if(value != "")
				{
					userAttr.records.push({"userAttrId": key, "targetCol": value});
				}
			});
			keepTUAM.tuamStore(userAttr);
			//console.log("trusted Attr Mapping"+angular.toJson($scope.reconattribute));
			$scope.selectedIndex = Math.min($scope.selectedIndex + 4, 5) ;
			//selectTabService.setTabActive($scope.selectedIndex);
			var nextTab = $scope.selectedIndex;	
			var gotoUrl =  $rootScope.Resourcetabs[nextTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 100;
		}
	}
	function mssqlLookupTableDataMapping($http,$scope,$rootScope,$state, keepValue, keepUDM, keepCDM, keepRecon,keepTUAM, $mdDialog, $location, SessionService){
		$scope.lookuptabletitle = false;
        var mssqlVal = keepValue.mysqlGetVal();
        if(mssqlVal == undefined) {
            $location.url('/MsSqladdresources/mssqladdrsc');
			return;
        }
		var tableval=keepUDM.primaryTableGetVal();
		$scope.targetlookupcolumns= angular.copy(tableval);
		var tableval=keepValue.tableGetVal();
		var udmVal = keepUDM.UDMGetVal();
		var cdmVal = keepCDM.CDMGetVal();
		
		$scope.selectTabService = 5;
		$scope.lookuptable= angular.copy(tableval);
		
		$scope.getlistoflookuptable=function(tableform,lookuptable, id){
            $rootScope.loaderCurrentStatus = 'true';
			$scope.lookupvalues.records[id].lookupkeycol = '';
			$scope.lookupvalues.records[id].lookupvalcol  = '';
			tableform.$setUntouched();
            tableform.$setPristine(true);
			var addResourceChildDataMappingURL = baseUrl + '/addmssql/gettargetcolumns';
			var userroletableid = lookuptable;
			var hostname = mssqlVal.hostName;
			var username = mssqlVal.userName;
			var password = mssqlVal.password;
			var port = mssqlVal.Port;
			var databasename = mssqlVal.databaseName;
			var istrustedval = mssqlVal.radiobuttonmodel;
			var config = {
				url : addResourceChildDataMappingURL,
				method : "GET",
				headers : {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
               
					"cdt-host":hostname,
					"cdt-port":port,
					"cdt-username":username,
					"cdt-pwd":password,
					"cdt-db":databasename, 
					"cdt-istrusted":istrustedval,
					"cdt-tablename":userroletableid,
				}
			}
			$http(config)
				.then(function success(response) {
                $rootScope.loaderCurrentStatus = 'false';
				$scope.resourcetargetcolumnsuserroletable = [];
				angular.forEach(response.data.records[0].targetcolumns,function(key,value){
					$scope.resourcetargetcolumnsuserroletable.push(response.data.records[0].targetcolumns[value]);
				})
				$scope.lookupvalues.records[id].getlooktable = angular.copy($scope.resourcetargetcolumnsuserroletable);
				$scope.lookupvalues.records[id].getlookkey  = angular.copy($scope.resourcetargetcolumnsuserroletable);
			},function error(response){
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				$rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);
			});
		}
		$scope.lookupvalues = {"records": []};
		var count = 0;
		$scope.AddLookup = function() {
			$scope.lookuptabletitle=true;
			$scope.lookupvalues.records.push({"id": count});
			count++;
		}
		$scope.CheckDuplicate = function(index) {
			var arr=[];
			angular.forEach($scope.lookupvalues.records, function(value, key) {
				arr.concat([arr.push(value.usrtblcol + ' '+value.lookuptbl)]);
			});
			// temporary object 
			var uniqOb = {};
			/* create object attribute with name=value in array, this will not keep dupes*/
			for (var i in arr)
				uniqOb[arr[i]] = "";
			// if object's attributes match array, then no dupes! 
			if (arr.length == Object.keys(uniqOb).length){
			}
			else{
				$scope.lookupvalues.records.splice(index, 1);
				$scope.lookupvalues.records.push({});
				  $mdDialog.show(
					$mdDialog.alert()
					.clickOutsideToClose(false)
					.title('Lookup')
					.textContent('Selected field already exists. Please select a different user attribute and lookup attribute')
					.ok('ok')
				);
			}		
		 };
		$scope.previous = function(Resourcetabs){
			$scope.selectedIndex = Math.max($scope.selectedIndex - 1, 3);
			//selectTabService.setTabActive($scope.selectedIndex);
			var prevTab = $scope.selectedIndex;
			var gotoUrl = $rootScope.Resourcetabs[prevTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 80;
		}
		$scope.DeleteLookup = function(index) {
			if($scope.lookupvalues.records.length == 1) {
				$scope.lookuptabletitle = false;
			}
			$scope.lookupvalues.records.splice(index, 1);
		}
		$scope.AddResourceFinal = function() {
            $rootScope.loaderCurrentStatus = 'true';
			var lookupvalues;
			if($scope.lookupvalues.records.length == 0) {
				lookupvalues = '{"records":[]}';
			} else {
				lookupvalues = {"records": []};
				angular.forEach($scope.lookupvalues.records,function(value, key){
					lookupvalues.records.push({"usrtblcol":value["usrtblcol"], "lookuptbl": value["lookuptbl"], "lookupkeycol": value["lookupkeycol"], "lookupvalcol": value["lookupvalcol"]});
				});
				lookupvalues =angular.toJson(lookupvalues);
			}
			var addResourceFinalURL = baseUrl + '/addmssql/final';
			var mssqlval=keepValue.mysqlGetVal();
			var resourcename = mssqlval.resourceName;
			var hostname = mssqlval.hostName;
			var username = mssqlval.userName;
			var password = mssqlval.password;
			var port = mssqlval.Port;
			var databasename = mssqlval.databaseName;
			var istrustedval = mssqlval.radiobuttonmodel;
			var resourcetablename = udmVal.usertablenamemodel;
			var usertableprimarykey = udmVal.singleSelectusertablekey;
			var passwordcolumn = udmVal.singleSelectpasswordcolumn;
			var singlerolemapping = udmVal.singleRoleMapping;
			var singleSelectedRole = udmVal.singleSelectedRole;
			var statuscolumn = udmVal.singleSelectstatuscol;
			var enableval = udmVal.enableValue;
			var disableval = udmVal.disableValue;
			var userroletable = cdmVal.userroletablemodel;
			var userid = cdmVal.useridcolumnmodel;
			var userroleid = cdmVal.userroleidcolumnmodel;
			var roletable = cdmVal.roletablemodel;
			var roleid = cdmVal.roleidcolumnmodel;
			var rolename = cdmVal.rolenamecolumnmodel;
			var finaluserattributesvalue = '';
			var finalreconattributesvalue = '';
			if(istrustedval === 'N'){
				var reconval = keepRecon.reconGetVal();
                finalreconattributesvalue = {'records':[]};
                angular.forEach(reconval, function(value, key) {
                    //console.log(value +"---"+ key);
                    var array = [];
                    var array1 = [];
					//User Attribute Mapping
					//Concat User Attribute Mapping
					if(value["userAttrId"]== '1'){
						$scope.userAttrId = value["userAttrId"];
						array.push(value["concat1"]+','+value["concat2"]);						
					}
					//SubString User Attribute Mapping
					else if(value["userAttrId"]== '2'){
						$scope.userAttrId = value["userAttrId"];
						array.push(value["substringMapping"]+','+value["substring"]);						
					}
					//DirectMapping User Attribute Mapping
					else if(value["userAttrId"]== '3'){
						$scope.userAttrId = value["userAttrId"];
						array.push(value["directmapping"]);
					}
					//Target Attribute Mapping
					//Concat Target Attribute Mapping
                    if(value["targetCol"]== '1'){
						$scope.targetuserAttrId = value["targetCol"];
						array1.push(value["targetConcat1"]+','+value["targetConcat2"]);					
					}
					//SubString Target Attribute Mapping
					else if(value["targetCol"]== '2'){
						$scope.targetuserAttrId = value["targetCol"];
						array1.push(value["targetsubstringMapping"]+','+value["targetSubstring"]);						
					}
					//DirectMapping Target Attribute Mapping
					else if(value["targetCol"]== '3'){
						$scope.targetuserAttrId = value["targetCol"];
						array1.push(value["targetdirectMapping"]);
					}
                    //array1.push(value["targetCol"]);
                    finalreconattributesvalue.records.push({"cloudusrattr":[{"methodid": $scope.userAttrId,"col": array}], "trgtusrattr":[{"methodid":$scope.targetuserAttrId,"col": array1}]});
                });
				finalreconattributesvalue = angular.toJson(finalreconattributesvalue);
				finaluserattributesvalue = '{"records":[]}';
			}
			else {
				var trustusrattrmappval = keepTUAM.tuamGetVal();
				finaluserattributesvalue = angular.toJson(trustusrattrmappval);
				finalreconattributesvalue = '{"records":[]}';
			}
			
			
			var config = {
				url: addResourceFinalURL,
				method: "POST",
				headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
					"cdt-id":'2',
					"cdt-rescname":resourcename,
					"cdt-host":hostname,
					"cdt-username":username,
					"cdt-pwd":password, 
					"cdt-port":port,
					"cdt-istrusted": istrustedval,
					"cdt-db": databasename,
					"cdt-usertbl": resourcetablename,
					"cdt-usertblprimary": usertableprimarykey,
					"cdt-pwdcol": passwordcolumn,
					"cdt-statuscol": statuscolumn,
					"cdt-enable": enableval,
					"cdt-disable": disableval,
					"cdt-userroletbl": userroletable,
					"cdt-userid": userid,
					"cdt-userroleid": userroleid,
					"cdt-roletbl": roletable,
					"cdt-roleid": roleid,
					"cdt-rolename": rolename,
					"cdt-reconattribute":finalreconattributesvalue,
					"cdt-userattribute":finaluserattributesvalue,
					"cdt-lookup":lookupvalues,
					"cdt-usrtblrolid":singleSelectedRole,
					"cdt-singlerole":singlerolemapping,
				}
			}
			$http(config)
				.then(function success(response) {
             $rootScope.loaderCurrentStatus = 'false';
				if(response.data.type == "success"){
					$scope.toastMessage('toast-success',response.data.message);
					$state.go('resources');
                    $scope.addTab('Resources','resources');
					keepValue.storemysql = undefined;
					keepUDM.storeUDM = undefined;
					keepCDM.storeCDM = undefined;
					keepRecon.storeRecon = undefined;
					keepTUAM.storeTUAM = undefined;
					//keepDM.storeDM = undefined;
				}
				else if(response.data.type == "error"){
					$rootScope.loaderCurrentStatus = 'false';
					$scope.toastMessage('toast-error',response.data.message);
					//$state.go('resources');
				}
			},function error(response){
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				$rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);
		});
		}
	}
    function addmsSqlReconController($http, $scope, $rootScope, $state,$mdDialog,keepUDM,keepRecon, SessionService){
		$scope.form={};
		var length=$rootScope.listAttributes.length;
		var tableval=keepUDM.primaryTableGetVal();
		var self = this;		
		$scope.userattributesvalue = {"records": []};	
		$scope.reconruleSelected='';
        $scope.selectTabService = 3;
		$scope.targetcolumns= angular.copy(tableval);
		//Get Method api
		var addResourceUserMappingMethodURL = baseUrl + '/method';
		var config = {
			url: addResourceUserMappingMethodURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
            }
		}
		$http(config)
			.then(function success(response) { 
		$scope.userResponse = response.data.type;   		
        $scope.addMappinguserattributes = [];     
		if (response.data.type == "success") {			
            for(var i=0;i<response.data.records[0].dropdownlist.length;i++)
            {
				$scope.addMappinguserattributes.push({"id":response.data.records[0].dropdownlist[i].key,"value":response.data.records[0].dropdownlist[i].value});
				if(response.data.records[0].dropdownlist[i].key=="3"){
					$scope.reconruleSelected=response.data.records[0].dropdownlist[i].value;
				}	
            }
			//console.log("addMappinguserattributes"+$scope.addMappinguserattributes);
			//console.log("addMappinguserattributes"+$scope.userResponse);
		}
		else {
            $scope.managesystemErrorMessage = response.data.message;
         }
		},function error(response){
			// It will work when the server returns the status "500 - Internal server" or 400 series errors
			$rootScope.loaderCurrentStatus = 'false';
			$scope.errorHandler(response.config.url,response.status);
		});
		//Get userattributes  api		
		var addResourceUserAttributesMappingURL = baseUrl + '/userattributes';
		var config = {
			url: addResourceUserAttributesMappingURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
            }
		}
		$http(config)
			.then(function success(response) {       
            $scope.resourceuserattributes = [];               
            for(var i=0;i<response.data.records[0].listattributes.length;i++)
            {
				$scope.resourceuserattributes.push({"id":response.data.records[0].listattributes[i].colname,"value":response.data.records[0].listattributes[i].displayname});
            }
				//console.log("resourceuserattributes"+$scope.resourceuserattributes);
		},function error(response){
			// It will work when the server returns the status "500 - Internal server" or 400 series errors
			$rootScope.loaderCurrentStatus = 'false';
			$scope.errorHandler(response.config.url,response.status);
		});
		$scope.userattributesvalues={"records": []};		
		self.cancel = function($event) {
		$mdDialog.cancel();
		};
		self.finish = function($event) {
			$rootScope.listAttributes.push({});
			$rootScope.userattributetitle = true;
			if($scope.userattributesvalue.records[0].userAttrId=='1'){
				var userConcat="concat("+$scope.userattributesvalue.records[0].concat1+","+$scope.userattributesvalue.records[0].concat2+")";
				$scope.attrId=$scope.userattributesvalue.records[0].userAttrId;
				$scope.userAttrConcat=userConcat;
				//console.log($scope.userattributesvalue.records[0].concat1);
				$rootScope.listAttributes[length].userattribute = userConcat;
			}
			else if($scope.userattributesvalue.records[0].userAttrId=='2'){
				var userSubstring="substring("+$scope.userattributesvalue.records[0].substringMapping+","+$scope.userattributesvalue.records[0].substring+")";
				//console.log(userSubstring);
				$rootScope.listAttributes[length].userattribute = userSubstring;
			}
			else if($scope.userattributesvalue.records[0].userAttrId=='3'){
				var userDirectMapping="directmapping("+$scope.userattributesvalue.records[0].directmapping+")";
				//console.log(userDirectMapping);
				$rootScope.listAttributes[length].userattribute = userDirectMapping;
			}
			if($scope.userattributesvalue.records[0].targetCol=='1'){
				var targetConcat="concat("+$scope.userattributesvalue.records[0].targetConcat1+","+$scope.userattributesvalue.records[0].targetConcat2+")";
				//console.log(targetConcat);
				$rootScope.listAttributes[length].targetattribute = targetConcat;
			}
			else if($scope.userattributesvalue.records[0].targetCol=='2'){
				var targetSubstringMapping="substring("+$scope.userattributesvalue.records[0].targetsubstringMapping+","+$scope.userattributesvalue.records[0].targetSubstring+")";
				//console.log(targetSubstringMapping);
				$rootScope.listAttributes[length].targetattribute = targetSubstringMapping;
			}
			else if($scope.userattributesvalue.records[0].targetCol=='3'){
				var targetAttrDirectMapping="directmapping("+$scope.userattributesvalue.records[0].targetdirectMapping+")";
				//console.log(targetAttrDirectMapping);
				$rootScope.listAttributes[length].targetattribute = targetAttrDirectMapping;
			}
			$rootScope.finalMappingColumn.records.push($scope.userattributesvalue.records[0]);
			//console.log($rootScope.finalMappingColumn);	
			$mdDialog.hide();
			var arr=[];
		  angular.forEach($rootScope.listAttributes, function(value, key) {
			arr.concat([arr.push(value.userattribute + ' '+value.targetattribute)]);
			});
			//console.log(arr);
			var uniqOb = {};
			for (var i in arr)
				uniqOb[arr[i]] = "";
			if (arr.length == Object.keys(uniqOb).length){
			 }
			  else{
				$rootScope.count--;
				$rootScope.listAttributes.splice(-1, 1);
				$rootScope.finalMappingColumn.records.splice(-1, 1);
				  $mdDialog.show(
					$mdDialog.alert()
					.clickOutsideToClose(false)
					.title('Recon Rule')
					.textContent('Selected Recon Rule already exists. Please select a different User Attributes Mapped Column and Target Attributes Mapped Column')
					.ok('ok')
				);
			  }
			$rootScope.count++;

		};
		
	}
	
angular
	.module('cloudentixApp')
	.controller('MySqladdrescourcemainctrl',mysqladdRscMainCtrl)
	.controller('MySqladdresourcemysqlsetupCtrl',mysqlSetup)
	.controller('MySqluserdatamappingcontroller',mysqlUserDataMapping)
	.controller('MySqlchildtabledatamappingcontroller',mysqlchilddatamapping)
	.controller('MySqluserattrmappingcontroller',mysqlUserattrmapping)
	.controller('MySqltrusteduserattrmappingcontroller',mysqlTrustedUserAttrMapping)
	.controller('MySqllookupTabledataMappingController',mysqlLookupTableDataMapping)
	
	.config(
		['$stateProvider', '$urlRouterProvider',
			function($stateProvider,$urlRouterProvider){
				$urlRouterProvider
				$stateProvider
					.state('MySqladdresources.mysqladdrsc', {
					url:'/sqladdrsc',
					onEnter: function() {
						void 0;
					},
					templateUrl: 'resources/addResource/mysql/cloudentix-admin-resources-addResource-mysql-setup.html',
					})
					
					.state('MySqladdresources.userdatamapping', {
					url: '/userdatamapping',
					onEnter: function() {
					void 0;
					},
					templateUrl: 'resources/addResource/mysql/cloudentix-admin-resources-addResource-mysql-userdatamapping.html',
					})
					
					.state('MySqladdresources.childtabledatamapping', {
					url: '/childtabledatamapping',
					onEnter: function() {
					void 0;
					},
					templateUrl: 'resources/addResource/mysql/cloudentix-admin-resources-addResource-mysql-childtabledatamapping.html',
					})
					
					//mysql-trusted  
					.state('MySqladdresources.userattributesmapping', {
					url: '/userattributesmapping',
					onEnter: function() {
					void 0;
					},
					templateUrl: 'resources/addResource/mysql/cloudentix-admin-resources-addResource-mysql-trusteduserattributesmapping.html',
					}) 
            
					//mysql-untrusted-reconattributerule
					.state('MySqladdresources.recon', {
					url: '/recon',
					onEnter: function() {
					void 0;
					},
					templateUrl: 'resources/addResource/mysql/cloudentix-admin-resources-addResource-mysql-userattributesmapping.html',
					})
					.state('MySqladdresources.lookuptabledatamapping', {
					url: '/lookuptabledatamapping',
					onEnter: function() {
					void 0;
					},
					templateUrl: 'resources/addResource/mysql/cloudentix-admin-resources-addResource-mysql-lookuptabledatamapping.html',
					});
				}
		
		])
	.service('keepValue', function(){
		this.mysqlStore = function(x, y){
			this.storemysql = x;
			this.storetablemysql = y;
		}
		this.mysqlGetVal = function(){
			return this.storemysql;
		}
		this.tableGetVal = function(){
			return this.storetablemysql;
		}
		  
	})
	.service('keepUDM', function(){
		this.udmStore = function(x,y){
			this.storeUDM = x;
			this.storeprimarytablemysql = y;
		}
		this.UDMGetVal = function(){
			return this.storeUDM;
		}
		this.primaryTableGetVal = function(){
			return this.storeprimarytablemysql;
		}
	})
	.service('keepCDM', function(){
		this.cdmStore = function(x){
			this.storeCDM = x;
		}
		this.CDMGetVal = function(){
			return this.storeCDM;
		}
	})
	.service('keepRecon', function(){
		this.reconStore = function(x){
			this.storeRecon = x;
		}
		this.reconAttrStore = function(x){
		  this.storeAttributeRecon = x;
		}
		this.reconGetVal = function(){
		  return this.storeRecon;
		}
		this.reconGetAttr = function(){
		  return this.storeAttributeRecon;
		}
	})
	.service('keepTUAM', function(){
		this.tuamStore = function(x){
			this.storeTUAM = x;
		}
	  this.tuamGetVal = function(){
			return this.storeTUAM;
	  }
	})
	.factory('selectTabService', function(){
		var tabActive = '0';
		return {  
			tabActive: function() { return tabActive; },
			setTabActive: function(x) { tabActive = x; }
		};
	})
	.run(['$rootScope', '$state', '$stateParams',
        function($rootScope, $state, $stateParams) {
            $rootScope.$state = $state;
            $rootScope.$stateParams = $stateParams;
			}
	])
	mysqladdRscMainCtrl.$inject = ['$scope', '$log', '$state', '$rootScope', '$location', 'keepValue', 'keepUDM', 'keepCDM', 'keepRecon', 'keepTUAM', 'SessionService'];
	mysqlSetup.$inject = ['$scope','$http','$rootScope', '$state','keepValue', 'SessionService'];
	mysqlUserDataMapping.$inject = ['$http', '$scope', '$rootScope', '$state','keepUDM', 'keepValue', '$timeout', '$location', 'SessionService'];
	mysqlchilddatamapping.$inject = ['$http','$scope','$state','$rootScope', 'keepValue','keepCDM', '$timeout', 'keepUDM', '$location', 'SessionService'];
	mysqlUserattrmapping.$inject = ['$http', '$scope', '$rootScope', '$state', '$mdDialog', 'keepUDM', 'keepRecon', 'keepValue', '$location', 'SessionService'];
	mysqlTrustedUserAttrMapping.$inject = ['$http', '$scope', '$rootScope', '$state', 'keepUDM','keepValue', 'keepTUAM', '$location', 'SessionService'];
	mysqlLookupTableDataMapping.$inject = ['$http','$scope','$rootScope','$state', 'keepValue', 'keepUDM', 'keepCDM', 'keepRecon', 'keepTUAM', '$mdDialog', '$location', 'SessionService'];
	function mysqladdRscMainCtrl ($scope, $log, $state, $rootScope, $location, keepValue, keepUDM, keepCDM, keepRecon, keepTUAM, SessionService) {
		keepValue.storemysql = undefined;
		keepUDM.storeUDM = undefined;
		keepCDM.storeCDM = undefined;
		keepRecon.storeRecon = undefined;
		keepTUAM.storeTUAM = undefined;
		// keepDM.storeDM = undefined;
		$scope.selectTabService = 0;
		var Resourcetabs = [
			{ title: 'Setup', tabLink: "MySqladdresources.mysqladdrsc", tabSerial : "1"},
			{ title: 'User Data Mapping', tabLink: "MySqladdresources.userdatamapping", tabSerial : "2"},
			{ title: 'Role Data Mapping', tabLink: "MySqladdresources.childtabledatamapping", tabSerial : "3"},          
			{ title: 'User Attributes Mapping', tabLink: "MySqladdresources.userattributesmapping", tabSerial : "4"},
			{ title: 'Reference Data Mapping', tabLink: "MySqladdresources.lookuptabledatamapping", tabSerial : "5"}
		],
		selected = null,
		previous = null;
		$rootScope.Resourcetabs = Resourcetabs;
		$scope.selectedIndex = 0;
		$rootScope.loadWidth = 20;
		$scope.$watch('selectedIndex', function(current, old){
			//console.log( $scope.selectedIndex);
			previous = selected;
			selected = Resourcetabs[current];
		});
		$scope.wizardActive = function(activePath){
		var activePath = activePath.replace('#','')
		activePath = activePath.replace('.','/');
		locationPath = $location.path();
		locationPath = locationPath.replace('/','');
			if(activePath === locationPath){
			   return 'wizard-active';
			}else{
			   return '';
			}
		}
	}
	function mysqlSetup($scope,$http,$rootScope, $state,keepValue, SessionService) {
        var checkResourceURL = baseUrl + '/resources?check=true';
		var config = {
			url: checkResourceURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
			}
		}
		$http(config)
		.then(function success(response) {
			$rootScope.loaderCurrentStatus = 'false';
			if(response.data.type == 'success'){
				if (response.data.data.login[0].trusted == 'N') {
					$scope.TrustedAvailable = true;
				} else if (response.data.data.login[0].trusted == 'Y') {
					$scope.TrustedAvailable = false;
					$rootScope.Resourcetabs[3].title = "Reconciliation Rule"
					$rootScope.Resourcetabs[3].tabLink = "MySqladdresources.recon"	
				}
			}
			else if(response.data.type == 'error'){
				$scope.toastMessage('toast-error',response.data.message);
			}
			else if(response.data.type == 'warning'){
				$scope.toastMessage('toast-warn',response.data.message);
			}
			
		},function error(response){
			// It will work when the server returns the status "500 - Internal server" or 400 series errors
			$rootScope.loaderCurrentStatus = 'false';
			$scope.errorHandler(response.config.url,response.status);
		});
		$scope.form={};
		var mysqlVal=keepValue.mysqlGetVal();
        $scope.selectTabService = 0;
		if(mysqlVal != undefined)
		{
			$scope.form.resourceName = mysqlVal.resourceName;
			$scope.form.hostName = mysqlVal.hostName;
			$scope.form.userName = mysqlVal.userName;
			$scope.form.password = mysqlVal.password;
			$scope.form.Port = mysqlVal.Port;
			$scope.form.databaseName = mysqlVal.databaseName;
			$scope.form.radiobuttonmodel = mysqlVal.radiobuttonmodel;
		}
		$scope.next = function(Resourcetabs){ 
		//console.log('i am in next firsr step');
			$rootScope.loaderCurrentStatus = 'true';
			var resourcename = $scope.form.resourceName;
			var hostname = $scope.form.hostName;
			var username = $scope.form.userName;
			var password = $scope.form.password;
			var port = $scope.form.Port;
			var databasename = $scope.form.databaseName;     
			var radiobuttonmodel = $scope.form.radiobuttonmodel;
			
			var addResourceSetupURL = baseUrl + '/addrsc/gettargettables';
			var config = {
			url: addResourceSetupURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                "cdt-rescname":resourcename,
                "cdt-host":hostname,
                "cdt-port":port,
                "cdt-username":username,
                "cdt-pwd":password,
                "cdt-db":databasename, 
                "cdt-istrusted":radiobuttonmodel

				}
			}
			$http(config)
				.then(function success(response) {
				$rootScope.loaderCurrentStatus = 'false';
				if(response.data.type == "success"){
					$scope.resourcetargettables = [];     
					angular.forEach(response.data.records[0].targettables, function(key,value) {
					$scope.resourcetargettables.push(response.data.records[0].targettables[value]);
					}); 
					if(radiobuttonmodel === 'N'){
						var temp;
						temp = Resourcetabs[3].title;
						Resourcetabs[3].title = "Reconciliation Rule"
						Resourcetabs[3].tabLink = "MySqladdresources.recon"
					} else {
						var temp;
						temp = Resourcetabs[3].title;
						Resourcetabs[3].title = "User Attributes Mapping"
						Resourcetabs[3].tabLink = "MySqladdresources.userattributesmapping"
					}
					 keepValue.mysqlStore($scope.form, $scope.resourcetargettables);
					 $scope.selectedIndex = Math.min($scope.selectedIndex + 1, 5) ;
					//selectTabService.setTabActive($scope.selectedIndex);
					var nextTab = $scope.selectedIndex;	
					var gotoUrl =  $rootScope.Resourcetabs[nextTab].tabLink;

					$state.go(gotoUrl);
					$rootScope.loadWidth = 40;
				}
				else if(response.data.type == "error"){
					$scope.toastMessage('toast-error',response.data.message);
					$state.go('MySqladdresources.mysqladdrsc');
				}
				else if(response.data.type == "warning"){
					$scope.toastMessage('toast-warn',response.data.message);
					$state.go('MySqladdresources.mysqladdrsc');
				}
			},function error(response){
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				$rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);
				}); 	
		}
	}
	function mysqlUserDataMapping($http, $scope, $rootScope, $state,keepUDM, keepValue, $timeout, $location, SessionService){
		$scope.form = {};
		$scope.userdatamappingform = {};
        var mysqlVal = keepValue.mysqlGetVal();
        if(mysqlVal == undefined) {
            $location.url('/MySqladdresources/sqladdrsc');
			return;
        }
		var udmVal = keepUDM.UDMGetVal();
		$scope.istrustedvalfinal = mysqlVal.radiobuttonmodel;
		var tableval=keepValue.tableGetVal();
        $scope.selectTabService = 1;
		var countservice = 0;
		$scope.usertable= angular.copy(tableval);
		$scope.getlistofcolumns = function(tableform) {
			$rootScope.loaderCurrentStatus = 'true';	
			$scope.form.singleSelectusertablekey = '';
			$scope.form.singleSelectpasswordcolumn = '';
			$scope.form.singleSelectstatuscol = '';
			$scope.form.enableValue = '';
			$scope.form.disableValue = '';
			tableform.$setUntouched();
            tableform.$setPristine(true);
			var addResourceUserDataMappingURL = baseUrl + '/addrsc/gettargetcolumns';
			var resourcetablename = $scope.form.usertablenamemodel;
			var hostname = mysqlVal.hostName;
			var username = mysqlVal.userName;
			var password = mysqlVal.password;
			var port = mysqlVal.Port;
			var databasename = mysqlVal.databaseName;
			var istrustedval = mysqlVal.radiobuttonmodel;
			var config = {
				url : addResourceUserDataMappingURL,
				method : "GET",
				headers : {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
					"cdt-host":hostname,
					"cdt-port":port,
					"cdt-username":username,
					"cdt-pwd":password,
					"cdt-db":databasename, 
					"cdt-istrusted":istrustedval,
					"cdt-tablename":resourcetablename
				}
			}
			$http(config)
				.then(function success(response) {
				$rootScope.loaderCurrentStatus = 'false';
				$scope.resourcetargetcolumns = [];
				angular.forEach(response.data.records[0].targetcolumns,function(key,value){
					$scope.resourcetargetcolumns.push(response.data.records[0].targetcolumns[value]);
				})
				$scope.usertablekey= angular.copy($scope.resourcetargetcolumns);
				var passwordnone=["None"];
				var passwordcolumn1= angular.copy($scope.resourcetargetcolumns);
				$scope.passwordcolumn=passwordnone.concat(passwordcolumn1);
				if(istrustedval == "Y") {
					$scope.statuscolumn= angular.copy($scope.resourcetargetcolumns);
				}
				else {
					var statusone=["None"];
					var statuscolumn1= angular.copy($scope.resourcetargetcolumns);
					$scope.statuscolumn= statusone.concat(statuscolumn1);
				}
				$scope.userrolecolumn= angular.copy($scope.resourcetargetcolumns);
				if(udmVal != undefined && countservice === 0) {
					$scope.form.singleRoleMapping = udmVal.singleRoleMapping;
					$scope.form.singleSelectusertablekey = udmVal.singleSelectusertablekey;
					$scope.form.singleSelectpasswordcolumn = udmVal.singleSelectpasswordcolumn;
					$scope.form.singleSelectstatuscol = udmVal.singleSelectstatuscol;
					$scope.form.enableValue = udmVal.enableValue;
					$scope.form.disableValue = udmVal.disableValue;
					$timeout(function () {
						$scope.form.singleSelectedRole = udmVal.singleSelectedRole;
					}, 1000);
				}
				countservice = countservice + 1;
			},function error(response){
					// It will work when the server returns the status "500 - Internal server" or 400 series errors
					$rootScope.loaderCurrentStatus = 'false';
					$scope.errorHandler(response.config.url,response.status);
				});  
		}
        $scope.resetStatusValue = function(selectedStatus) {
            if(selectedStatus == 'None') {
                $scope.form.enableValue = '';
                $scope.form.disableValue  = '';
            }
        }
		if(udmVal != undefined){
			$rootScope.loaderCurrentStatus = 'true';	
			$scope.form.usertablenamemodel = udmVal.usertablenamemodel;
			$timeout(function () {
				$scope.getlistofcolumns($scope.userdatamappingform.loginForm);
            }, 1000);
			//$scope.form.singleSelectusertablekey = udmVal.singleSelectusertablekey;
			//$scope.form.singleSelectpasswordcolumn = udmVal.singleSelectpasswordcolumn;
			//$scope.form.singleRoleMapping = udmVal.singleRoleMapping;
			//$scope.form.singleSelectedRole = udmVal.singleSelectedRole;
			//$scope.form.singleSelectstatuscol = udmVal.singleSelectstatuscol;
			//$scope.form.enableValue = udmVal.enableValue;
			//$scope.form.disableValue = udmVal.disableValue;
		}
		$scope.next = function(Resourcetabs) {
			if($scope.form.singleSelectpasswordcolumn=="None") {
				$scope.form.singleSelectpasswordcolumn="";
			}
			if($scope.form.singleSelectstatuscol=="None") {
				$scope.form.singleSelectstatuscol="";
			}
            keepUDM.udmStore($scope.form , $scope.resourcetargetcolumns);
			$scope.selectedIndex = Math.min($scope.selectedIndex + 2, 5) ;
		//	selectTabService.setTabActive($scope.selectedIndex);
			var nextTab = $scope.selectedIndex;	
			var gotoUrl =  $rootScope.Resourcetabs[nextTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 60;
		};		
		$scope.previous = function(Resourcetabs) {
			$scope.selectedIndex = Math.max($scope.selectedIndex - 2, 0);
			//selectTabService.setTabActive($scope.selectedIndex);
			var prevTab = $scope.selectedIndex;
			var gotoUrl = $rootScope.Resourcetabs[prevTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 20;
		};  	
	}
	function mysqlchilddatamapping($http,$scope,$state,$rootScope, keepValue,keepCDM, $timeout, keepUDM, $location, SessionService){
		$scope.form = {};
		$scope.childdatamappingform = {};
        var mysqlVal=keepValue.mysqlGetVal();
        if(mysqlVal == undefined) {
            $location.url('/MySqladdresources/sqladdrsc');
			return;
        }
		var udmVal = keepUDM.UDMGetVal();
		$scope.singlerolemapvalue = udmVal.singleRoleMapping;
		var cdmVal = keepCDM.CDMGetVal();
		var tableval=keepValue.tableGetVal();
        $scope.selectTabService = 2;
		$scope.userroletable= angular.copy(tableval);
		$scope.roletablevalue= angular.copy(tableval);
		if($scope.singlerolemapvalue == 'N')
		{
			$scope.getlistofcolumnsforuserrole=function(tableform, useridcol, roleidcol){
				$rootScope.loaderCurrentStatus = 'true';
				$scope.form.useridcolumnmodel = '';
				$scope.form.userroleidcolumnmodel = '';
				tableform.$setUntouched();
				tableform.$setPristine(true);
				var addResourceChildDataMappingURL = baseUrl + '/addrsc/gettargetcolumns';
				var userroletableid = $scope.form.userroletablemodel;
				var hostname = mysqlVal.hostName;
				var username = mysqlVal.userName;
				var password = mysqlVal.password;
				var port = mysqlVal.Port;
				var databasename = mysqlVal.databaseName;
				var istrustedval = mysqlVal.radiobuttonmodel;
				if(userroletableid != undefined){
					var config = {
						url : addResourceChildDataMappingURL,
						method : "GET",
						headers : {
							"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
							"cdt-host":hostname,
							"cdt-port":port,
							"cdt-username":username,
							"cdt-pwd":password,
							"cdt-db":databasename, 
							"cdt-istrusted":istrustedval,
							"cdt-tablename":userroletableid,
						}
					}
					$http(config)
						.then(function success(response) {
						$rootScope.loaderCurrentStatus = 'false';
						$scope.resourcetargetcolumnsuserroletable = [];
						angular.forEach(response.data.records[0].targetcolumns,function(key,value){
							$scope.resourcetargetcolumnsuserroletable.push(response.data.records[0].targetcolumns[value]);
						})
						$scope.useridcolumn= angular.copy($scope.resourcetargetcolumnsuserroletable);
						$scope.userroleidcolumn= angular.copy($scope.resourcetargetcolumnsuserroletable);
						if(useridcol != undefined && roleidcol != undefined) {
							$scope.form.useridcolumnmodel = cdmVal.useridcolumnmodel;
							$scope.form.userroleidcolumnmodel = cdmVal.userroleidcolumnmodel;
						}
					},function error(response){
						// It will work when the server returns the status "500 - Internal server" or 400 series errors
						$rootScope.loaderCurrentStatus = 'false';
						$scope.errorHandler(response.config.url,response.status);
					}); 
				}				
				}		
		}
		$scope.getlistofcolumnsforroletable = function(tableform, roleidcol, rolenamecol){
			$rootScope.loaderCurrentStatus = 'true';
			$scope.form.roleidcolumnmodel = '';
			$scope.form.rolenamecolumnmodel = '';
			tableform.$setUntouched();
            tableform.$setPristine(true);
			var addResourceChildDataMappingURL = baseUrl + '/addrsc/gettargetcolumns';
			var userroletableid = $scope.form.roletablemodel;
			var hostname = mysqlVal.hostName;
			var username = mysqlVal.userName;
			var password = mysqlVal.password;
			var port = mysqlVal.Port;
			var databasename = mysqlVal.databaseName;
			var istrustedval = mysqlVal.radiobuttonmodel;
			var config = {
				url : addResourceChildDataMappingURL,
				method : "GET",
				headers : {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
               
					"cdt-host":hostname,
					"cdt-port":port,
					"cdt-username":username,
					"cdt-pwd":password,
					"cdt-db":databasename, 
					"cdt-istrusted":istrustedval,
					"cdt-tablename":userroletableid,
				}
			}
			$http(config)
				.then(function success(response) {
				$rootScope.loaderCurrentStatus = 'false';
				$scope.resourcetargetcolumnsroletable = [];
				angular.forEach(response.data.records[0].targetcolumns,function(key,value){
					$scope.resourcetargetcolumnsroletable.push(response.data.records[0].targetcolumns[value]);
				})
				$scope.roleidcolumn= angular.copy($scope.resourcetargetcolumnsroletable);
				$scope.rolenamecolumn= angular.copy($scope.resourcetargetcolumnsroletable);
				if(roleidcol != undefined && rolenamecol != undefined) {
					$scope.form.roleidcolumnmodel = cdmVal.roleidcolumnmodel;
					$scope.form.rolenamecolumnmodel = cdmVal.rolenamecolumnmodel;
				}
			},function error(response){
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				$rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);
				});  
		}
		$scope.next = function(Resourcetabs) {
			keepCDM.cdmStore($scope.form);
			$scope.selectedIndex = Math.min($scope.selectedIndex + 3, 5) ;
			//selectTabService.setTabActive($scope.selectedIndex);
			var nextTab = $scope.selectedIndex;	
			var gotoUrl =  $rootScope.Resourcetabs[nextTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 80;
		};
		if(cdmVal != undefined){
			$rootScope.loaderCurrentStatus = 'true';	
			if($scope.singlerolemapvalue == 'N'){	
				$scope.form.userroletablemodel = cdmVal.userroletablemodel;
			$timeout(function () {
				$scope.getlistofcolumnsforuserrole($scope.childdatamappingform.loginForm, cdmVal.useridcolumnmodel, cdmVal.userroleidcolumnmodel);
            }, 1000);
			}
		//this for role table
			$scope.form.roletablemodel = cdmVal.roletablemodel;
			$timeout(function () {
					$scope.getlistofcolumnsforroletable($scope.childdatamappingform.loginForm, cdmVal.roleidcolumnmodel, cdmVal.rolenamecolumnmodel);
				}, 1000);
		}
		
		$scope.previous = function(Resourcetabs){
			$scope.selectedIndex = Math.max($scope.selectedIndex - 0, 1);
			//selectTabService.setTabActive($scope.selectedIndex);
			var prevTab = $scope.selectedIndex;
			var gotoUrl = $rootScope.Resourcetabs[prevTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 40;
		}
		
	}
	function mysqlUserattrmapping($http, $scope, $rootScope, $state, $mdDialog, keepUDM, keepRecon, keepValue, $location, SessionService) {
        var mysqlVal = keepValue.mysqlGetVal();
		$rootScope.userattributetitle = false;
        if(mysqlVal == undefined) {
            $location.url('/MySqladdresources/sqladdrsc');
			return;
        }
		var reconval = keepRecon.reconGetVal();
		var reconvalAttr = keepRecon.reconGetAttr();
		$rootScope.count=0;
		$scope.form={};
		$rootScope.listAttributes = [];
		$rootScope.finalMappingColumn = {"records": []};
		$scope.userattributeaddbutton=function($event,$scope){
		$mdDialog.show({
			controller: MysqladdReconController,
			controllerAs: 'reconrulectrl',
			templateUrl: 'resources/addResource/mysql/cloudentix-admin-resources-addResource-mysql-addReconRule.html',
			parent: angular.element(document.body),
			targetEvent: $event,
			//controller: mdDialogCtrl,
			clickOutsideToClose:false
		})
		}
		 	 //delete button
		$scope.Deleterecon=function(index){
			$rootScope.count--;					
			$rootScope.listAttributes.splice(index, 1);
			$rootScope.finalMappingColumn.records.splice(index, 1);
            if($rootScope.finalMappingColumn.records.length == 0) {
                $rootScope.userattributetitle = false;
            }
		}			
		if(reconval != undefined && reconvalAttr != undefined) {
			$rootScope.userattributetitle = true;
			//console.log(reconval);
			$scope.trustmap=reconval;
			var length=reconvalAttr.length;
			for(var i = 0; i < length; i++)
			{
				$scope.listAttributes.push({});
				$rootScope.count++;
			}
			for(var count = 0; count < length; count++)
			{					
				$scope.listAttributes[count].userattribute = reconvalAttr[count].userattribute;
				$scope.listAttributes[count].targetattribute = reconvalAttr[count].targetattribute;					
			}
			angular.forEach($scope.trustmap, function(value, key) {
				$rootScope.finalMappingColumn.records.push(value);
			});			
		}	
		$scope.previous = function(Resourcetabs) {
			$scope.selectedIndex = Math.max($scope.selectedIndex - 1, 2);
			var prevTab = $scope.selectedIndex;
			var gotoUrl = $rootScope.Resourcetabs[prevTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 60;
		}; 		
		$scope.next = function(Resourcetabs){
			keepRecon.reconStore($rootScope.finalMappingColumn.records);
			keepRecon.reconAttrStore($rootScope.listAttributes);
			$scope.selectedIndex = Math.min($scope.selectedIndex + 4, 5) ;
			var nextTab = $scope.selectedIndex;	
			var gotoUrl =  $rootScope.Resourcetabs[nextTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 100;
		}
		
	}
	
	function mysqlTrustedUserAttrMapping($http, $scope, $rootScope, $state, keepUDM,keepValue, keepTUAM, $location, SessionService){
		$scope.form={};
		var mysqlVal=keepValue.mysqlGetVal();
        if(mysqlVal == undefined) {
            $location.url('/MySqladdresources/sqladdrsc');
			return;
        }
		$scope.resourcename = mysqlVal.resourceName;
        $scope.selectTabService = 4;
		var trustusrattrmappval = keepTUAM.tuamGetVal();
		var tableval=keepUDM.primaryTableGetVal();
		$scope.targetcolumns= angular.copy(tableval);
		var addResourceUserAttributesMappingURL = baseUrl + '/userattributes';
		var config = {
			url: addResourceUserAttributesMappingURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
            }
		}
		$scope.reconattribute = {"records": []}; 
		$http(config)
			.then(function success(response) {     
            for(var i=0;i<response.data.records[0].listattributes.length;i++)
			{
				$scope.reconattribute.records.push({"id":response.data.records[0].listattributes[i].userattid,"value":response.data.records[0].listattributes[i].displayname,"uniqueflag":response.data.records[0].listattributes[i].uniqueflag});
				//console.log("id"+response.records[0].listattributes[i].userattid);
			}
			},function error(response){
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				$rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);
				});  
		$scope.previous = function(Resourcetabs) {
			$scope.selectedIndex = Math.max($scope.selectedIndex - 1, 2);
			//selectTabService.setTabActive($scope.selectedIndex);
			var prevTab = $scope.selectedIndex;
			var gotoUrl = $rootScope.Resourcetabs[prevTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 60;

		}; 
		if(trustusrattrmappval != undefined) {
			$scope.trustmap=trustusrattrmappval;
			angular.forEach($scope.trustmap.records, function(value, key) {
				$scope.form[value["userAttrId"]] = value["targetCol"];
			});
		}
		
		$scope.next = function(Resourcetabs) {
			var userAttr = {"records": []};
			angular.forEach($scope.form, function(value, key) {
				if(value != "")
				{
					userAttr.records.push({"userAttrId": key, "targetCol": value});
				}
			});
			keepTUAM.tuamStore(userAttr);
			void 0;
			$scope.selectedIndex = Math.min($scope.selectedIndex + 4, 5) ;
			//selectTabService.setTabActive($scope.selectedIndex);
			var nextTab = $scope.selectedIndex;	
			var gotoUrl =  $rootScope.Resourcetabs[nextTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 100;
		}
	}
	function mysqlLookupTableDataMapping($http,$scope,$rootScope,$state, keepValue, keepUDM, keepCDM, keepRecon, keepTUAM, $mdDialog, $location, SessionService){
		$scope.lookuptabletitle = false;
		$scope.lookuptabledata = {};
        var mysqlVal = keepValue.mysqlGetVal();
        if(mysqlVal == undefined) {
            $location.url('/MySqladdresources/sqladdrsc');
			return;
        }
		var tableval=keepUDM.primaryTableGetVal();
		$scope.targetlookupcolumns= angular.copy(tableval);
		var tableval=keepValue.tableGetVal();
		var udmVal = keepUDM.UDMGetVal();
		var cdmVal = keepCDM.CDMGetVal();
		$scope.selectTabService = 5;
		$scope.lookuptable= angular.copy(tableval);
		$scope.getlistoflookuptable=function(tableform,lookuptable, id){
			//$scope.form.useridcolumnmodel = '';
			//$scope.form.userroleidcolumnmodel = '';
			void 0;
			$rootScope.loaderCurrentStatus = 'true';
			$scope.lookupvalues.records[id].lookupkeycol = '';
			$scope.lookupvalues.records[id].lookupvalcol  = '';
			tableform.$setUntouched();
            tableform.$setPristine(true);
			var addResourceChildDataMappingURL = baseUrl + '/addrsc/gettargetcolumns';
			var userroletableid = lookuptable;
			var hostname = mysqlVal.hostName;
			var username = mysqlVal.userName;
			var password = mysqlVal.password;
			var port = mysqlVal.Port;
			var databasename = mysqlVal.databaseName;
			var istrustedval = mysqlVal.radiobuttonmodel;
			var config = {
				url : addResourceChildDataMappingURL,
				method : "GET",
				headers : {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
					"cdt-host":hostname,
					"cdt-port":port,
					"cdt-username":username,
					"cdt-pwd":password,
					"cdt-db":databasename, 
					"cdt-istrusted":istrustedval,
					"cdt-tablename":userroletableid,
				}
			}
			$http(config)
				.then(function success(response) {
					 $rootScope.loaderCurrentStatus = 'false';
				$scope.resourcetargetcolumnsuserroletable = [];
				angular.forEach(response.data.records[0].targetcolumns,function(key,value){
					$scope.resourcetargetcolumnsuserroletable.push(response.data.records[0].targetcolumns[value]);
				})
				$scope.lookupvalues.records[id].getlooktable = angular.copy($scope.resourcetargetcolumnsuserroletable);
				$scope.lookupvalues.records[id].getlookkey  = angular.copy($scope.resourcetargetcolumnsuserroletable);
			},function error(response){
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				$rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);
				});  
		}
		$scope.lookupvalues = {"records": []};
		var count = 0;
		$scope.AddLookup = function() {
			$scope.lookuptabletitle=true;
			$scope.lookupvalues.records.push({"id": count});
			count++;
			}
			$scope.CheckDuplicate = function(index) {
			var arr=[];
			angular.forEach($scope.lookupvalues.records, function(value, key) {
				arr.concat([arr.push(value.usrtblcol + ' '+value.lookuptbl)]);
			});
			// temporary object 
			var uniqOb = {};
			/* create object attribute with name=value in array, this will not keep dupes*/
			for (var i in arr)
				uniqOb[arr[i]] = "";
			// if object's attributes match array, then no dupes! 
			if (arr.length == Object.keys(uniqOb).length){
			}
			else{
				$scope.lookupvalues.records.splice(index, 1);
				$scope.lookupvalues.records.push({});
				  $mdDialog.show(
					$mdDialog.alert()
					.clickOutsideToClose(false)
					.title('Lookup')
					.textContent('Selected field already exists. Please select a different user attribute and lookup attribute')
					.ok('ok')
				);
			}		
		 };
		$scope.previous = function(Resourcetabs){
			$scope.selectedIndex = Math.max($scope.selectedIndex - 1, 3);
			//selectTabService.setTabActive($scope.selectedIndex);
			var prevTab = $scope.selectedIndex;
			var gotoUrl = $rootScope.Resourcetabs[prevTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 80;
		}
		$scope.DeleteLookup = function(index) {
			if($scope.lookupvalues.records.length == 1) {
				$scope.lookuptabletitle = false;
			}
			$scope.lookupvalues.records.splice(index, 1);
		}
		$scope.AddResourceFinal = function() {
            $rootScope.loaderCurrentStatus = 'true';
			var lookupvalues;
			if($scope.lookupvalues.records.length == 0) {
				lookupvalues = '{"records":[]}';
			} else {
				lookupvalues = {"records": []};
				angular.forEach($scope.lookupvalues.records,function(value, key){
					lookupvalues.records.push({"usrtblcol":value["usrtblcol"], "lookuptbl": value["lookuptbl"], "lookupkeycol": value["lookupkeycol"], "lookupvalcol": value["lookupvalcol"]});
				});
				lookupvalues =angular.toJson(lookupvalues);
			}
			var addResourceFinalURL = baseUrl + '/addrsc/final';
			var mysqlVal=keepValue.mysqlGetVal();
			var resourcename = mysqlVal.resourceName;
			var hostname = mysqlVal.hostName;
			var username = mysqlVal.userName;
			var password = mysqlVal.password;
			var port = mysqlVal.Port;
			var databasename = mysqlVal.databaseName;
			var istrustedval = mysqlVal.radiobuttonmodel;
			var resourcetablename = udmVal.usertablenamemodel;
			var usertableprimarykey = udmVal.singleSelectusertablekey;
			var passwordcolumn = udmVal.singleSelectpasswordcolumn;
			var singlerolemapping = udmVal.singleRoleMapping;
			var singleSelectedRole = udmVal.singleSelectedRole;
			var statuscolumn = udmVal.singleSelectstatuscol;
			var enableval = udmVal.enableValue;
			var disableval = udmVal.disableValue;
			var userroletable = cdmVal.userroletablemodel;
			var userid = cdmVal.useridcolumnmodel;
			var userroleid = cdmVal.userroleidcolumnmodel;
			var roletable = cdmVal.roletablemodel;
			var roleid = cdmVal.roleidcolumnmodel;
			var rolename = cdmVal.rolenamecolumnmodel;
			var finaluserattributesvalue = '';
			var finalreconattributesvalue = '';
			if(istrustedval === 'N'){
				var reconval = keepRecon.reconGetVal();
                finalreconattributesvalue = {'records':[]};
                angular.forEach(reconval, function(value, key) {
                    //console.log(value +"---"+ key);
                    var array = [];
                    var array1 = [];
					//User Attribute Mapping
					//Concat User Attribute Mapping
					if(value["userAttrId"]== '1'){
						$scope.userAttrId = value["userAttrId"];
						array.push(value["concat1"]+','+value["concat2"]);						
					}
					//SubString User Attribute Mapping
					else if(value["userAttrId"]== '2'){
						$scope.userAttrId = value["userAttrId"];
						array.push(value["substringMapping"]+','+value["substring"]);						
					}
					//DirectMapping User Attribute Mapping
					else if(value["userAttrId"]== '3'){
						$scope.userAttrId = value["userAttrId"];
						array.push(value["directmapping"]);
					}
					//Target Attribute Mapping
					//Concat Target Attribute Mapping
                    if(value["targetCol"]== '1'){
						$scope.targetuserAttrId = value["targetCol"];
						array1.push(value["targetConcat1"]+','+value["targetConcat2"]);					
					}
					//SubString Target Attribute Mapping
					else if(value["targetCol"]== '2'){
						$scope.targetuserAttrId = value["targetCol"];
						array1.push(value["targetsubstringMapping"]+','+value["targetSubstring"]);						
					}
					//DirectMapping Target Attribute Mapping
					else if(value["targetCol"]== '3'){
						$scope.targetuserAttrId = value["targetCol"];
						array1.push(value["targetdirectMapping"]);
					}
                    //array1.push(value["targetCol"]);
                    finalreconattributesvalue.records.push({"cloudusrattr":[{"methodid": $scope.userAttrId,"col": array}], "trgtusrattr":[{"methodid":$scope.targetuserAttrId,"col": array1}]});
                });
				finalreconattributesvalue = angular.toJson(finalreconattributesvalue);
				finaluserattributesvalue = '{"records":[]}';
			}
			else {
				var trustusrattrmappval = keepTUAM.tuamGetVal();
				finaluserattributesvalue = angular.toJson(trustusrattrmappval);
				finalreconattributesvalue = '{"records":[]}';
			}
			var config = {
				url: addResourceFinalURL,
				method: "POST",
				headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
					"cdt-id":'1',
					"cdt-rescname":resourcename,
					"cdt-host":hostname,
					"cdt-username":username,
					"cdt-pwd":password, 
					"cdt-port":port,
					"cdt-istrusted": istrustedval,
					"cdt-db": databasename,
					"cdt-usertbl": resourcetablename,
					"cdt-usertblprimary": usertableprimarykey,
					"cdt-pwdcol": passwordcolumn,
					"cdt-statuscol": statuscolumn,
					"cdt-enable": enableval,
					"cdt-disable": disableval,
					"cdt-userroletbl": userroletable,
					"cdt-userid": userid,
					"cdt-userroleid": userroleid,
					"cdt-roletbl": roletable,
					"cdt-roleid": roleid,
					"cdt-rolename": rolename,
					"cdt-reconattribute":finalreconattributesvalue,
					"cdt-userattribute":finaluserattributesvalue,
					"cdt-lookup":lookupvalues,
					"cdt-usrtblrolid":singleSelectedRole,
					"cdt-singlerole":singlerolemapping,
				}
			}
			$http(config)
				.then(function success(response) {
				$rootScope.loaderCurrentStatus = 'false';
				if(response.data.type == "success")
				{
					$scope.toastMessage('toast-success',response.data.message);
					$state.go('resources');
                    $scope.addTab('Resources','resources');
					keepValue.storemysql = undefined;
					keepUDM.storeUDM = undefined;
					keepCDM.storeCDM = undefined;
					keepRecon.storeRecon = undefined;
					keepTUAM.storeTUAM = undefined;
					//keepDM.storeDM = undefined;
				}
				if(response.data.type == "error"){
					$rootScope.loaderCurrentStatus = 'false';
					$scope.toastMessage('toast-error',response.data.message);
					//$state.go('resources');
				}
			},function error(response){
					// It will work when the server returns the status "500 - Internal server" or 400 series errors
					$rootScope.loaderCurrentStatus = 'false';
					$scope.errorHandler(response.config.url,response.status);
				});   
		}
	}
    //ReconController Popup
	function MysqladdReconController($http, $scope, $rootScope, $state,$mdDialog,keepUDM,keepRecon, SessionService){
		$scope.form={};
		var length=$rootScope.listAttributes.length;
		var tableval=keepUDM.primaryTableGetVal();
		var self = this;		
		$scope.userattributesvalue = {"records": []};	
		$scope.reconruleSelected='';
        $scope.selectTabService = 3;
		$scope.targetcolumns= angular.copy(tableval);
		//Get Method api
		var addResourceUserMappingMethodURL = baseUrl + '/method';
		var config = {
			url: addResourceUserMappingMethodURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
            }
		}
		$http(config)
			.then(function success(response) {
		$scope.userResponse = response.data.type;   		
        $scope.addMappinguserattributes = [];     
		if (response.data.type == "success") {			
            for(var i=0;i<response.data.records[0].dropdownlist.length;i++)
            {
				$scope.addMappinguserattributes.push({"id":response.data.records[0].dropdownlist[i].key,"value":response.data.records[0].dropdownlist[i].value});
				if(response.data.records[0].dropdownlist[i].key=="3"){
					$scope.reconruleSelected=response.data.records[0].dropdownlist[i].value;
				}	
            }
		}
		else {
            $scope.managesystemErrorMessage = response.data.message;
        }
		},function error(response){
			// It will work when the server returns the status "500 - Internal server" or 400 series errors
			$rootScope.loaderCurrentStatus = 'false';
			$scope.errorHandler(response.config.url,response.status);
				}); 
		//Get userattributes  api		
		var addResourceUserAttributesMappingURL = baseUrl + '/userattributes';
		var config = {
			url: addResourceUserAttributesMappingURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
            }
		}
		$http(config)
				.then(function success(response) {    
            $scope.resourceuserattributes = [];               
            for(var i=0;i<response.data.records[0].listattributes.length;i++)
            {
				$scope.resourceuserattributes.push({"id":response.data.records[0].listattributes[i].colname,"value":response.data.records[0].listattributes[i].displayname});
            }
		},function error(response){
			// It will work when the server returns the status "500 - Internal server" or 400 series errors
			$rootScope.loaderCurrentStatus = 'false';
			$scope.errorHandler(response.config.url,response.status);
				});  
		$scope.userattributesvalues={"records": []};		
		self.cancel = function($event) {
			$mdDialog.cancel();
		};
		self.finish = function($event) {
			$rootScope.listAttributes.push({});
			$rootScope.userattributetitle = true;
			if($scope.userattributesvalue.records[0].userAttrId=='1'){
				var userConcat="concat("+$scope.userattributesvalue.records[0].concat1+","+$scope.userattributesvalue.records[0].concat2+")";
				$scope.attrId=$scope.userattributesvalue.records[0].userAttrId;
				$scope.userAttrConcat=userConcat;
				//console.log($scope.userattributesvalue.records[0].concat1);
				$rootScope.listAttributes[length].userattribute = userConcat;
			}
			else if($scope.userattributesvalue.records[0].userAttrId=='2'){
				var userSubstring="substring("+$scope.userattributesvalue.records[0].substringMapping+","+$scope.userattributesvalue.records[0].substring+")";
				//console.log(userSubstring);
				$rootScope.listAttributes[length].userattribute = userSubstring;
			}
			else if($scope.userattributesvalue.records[0].userAttrId=='3'){
				var userDirectMapping="directmapping("+$scope.userattributesvalue.records[0].directmapping+")";
				//console.log(userDirectMapping);
				$rootScope.listAttributes[length].userattribute = userDirectMapping;
			}
			if($scope.userattributesvalue.records[0].targetCol=='1'){
				var targetConcat="concat("+$scope.userattributesvalue.records[0].targetConcat1+","+$scope.userattributesvalue.records[0].targetConcat2+")";
				//console.log(targetConcat);
				$rootScope.listAttributes[length].targetattribute = targetConcat;
			}
			else if($scope.userattributesvalue.records[0].targetCol=='2'){
				var targetSubstringMapping="substring("+$scope.userattributesvalue.records[0].targetsubstringMapping+","+$scope.userattributesvalue.records[0].targetSubstring+")";
				//console.log(targetSubstringMapping);
				$rootScope.listAttributes[length].targetattribute = targetSubstringMapping;
			}
			else if($scope.userattributesvalue.records[0].targetCol=='3'){
				var targetAttrDirectMapping="directmapping("+$scope.userattributesvalue.records[0].targetdirectMapping+")";
				//console.log(targetAttrDirectMapping);
				$rootScope.listAttributes[length].targetattribute = targetAttrDirectMapping;
			}
			$rootScope.finalMappingColumn.records.push($scope.userattributesvalue.records[0]);
			//console.log($rootScope.finalMappingColumn);	
			$mdDialog.hide();
				var arr=[];
			angular.forEach($rootScope.listAttributes, function(value, key) {
				arr.concat([arr.push(value.userattribute + ' '+value.targetattribute)]);
			});
			//console.log(arr);
			var uniqOb = {};
			for (var i in arr)
				uniqOb[arr[i]] = "";
			if (arr.length == Object.keys(uniqOb).length){
			 }
			  else{
					$rootScope.count--;	
					$rootScope.listAttributes.splice(-1, 1);
					$rootScope.finalMappingColumn.records.splice(-1, 1);
					$mdDialog.show(
						$mdDialog.alert()
						.clickOutsideToClose(false)
						.title('Recon Rule')
						.textContent('Selected Recon Rule already exists. Please select a different User Attributes Mapped Column and Target Attributes Mapped Column')
						.ok('ok')
				);
			  }
			$rootScope.count++;

		};
		
	}
	
angular
    .module('cloudentixApp')
	.controller('Office365addresourcemainctrl', Office365AddrescCtrl)
    .controller('Office365addresourcefirstsetupCtrl', Office365firstsetup)
	.controller('Office365addresourcesetupCtrl', office365setup)
	.controller('Office365userattrmappingCtrl', Office365reconattributeruleCtrl)
	.service('keepVal', function(){
		this.adStore = function(x){
			this.storeAD = x;
		}
		this.adGetVal = function(){
			return this.storeAD;
		}
	})
	.service('keepValsetup', function(){
		this.setupStore = function(x){
			this.storesetup = x;
		}
		this.setupGetVal = function(){
			return this.storesetup;
		}
	})
	.factory('selectTabService', function(){
		var tabActive = '0';
		return {  
			tabActive: function() { return tabActive; },
			setTabActive: function(x) { tabActive = x; }
		};
	})
	.run(['$rootScope', '$state', '$stateParams',
        function($rootScope, $state, $stateParams) {
            $rootScope.$state = $state;
            $rootScope.$stateParams = $stateParams;
        }
    ])
	.config(
        ['$stateProvider', '$urlRouterProvider',
            function($stateProvider, $urlRouterProvider) {
                $urlRouterProvider
                $stateProvider
                .state('Office365addresources.office365addrsc', {
                    url: '/Office365addresource',
                    templateUrl: 'resources/addResource/office365Resource/cloudentix-admin-resources-addResource-Office365-setup-inital.html',
                })
				.state('Office365addresources.Details', {
					url: '/Office365Details',
					templateUrl: 'resources/addResource/office365Resource/cloudentix-admin-resources-addResource-Office365-setup.html'
				})
				.state('Office365addresources.Office365reconattributerule', {
					url: '/Office365reconattributerule',
					templateUrl: 'resources/addResource/office365Resource/cloudentix-admin-resources-addResource-Office365-reconattributerule.html'
				})
            }
        ]
	);
	Office365AddrescCtrl.$inject = ['$scope', '$log', '$state', '$rootScope', '$location', 'keepVal', 'keepValsetup', 'SessionService'];
	Office365firstsetup.$inject = ['$http', '$scope', '$rootScope', '$log', '$state', '$location', 'keepVal', 'SessionService'];
	office365setup.$inject = ['$http', '$scope', '$rootScope', '$log', '$state', '$location', 'keepValsetup','keepVal', 'SessionService'];
	Office365reconattributeruleCtrl.$inject = ['$http', '$scope', '$log', '$rootScope', '$state', 'keepRecon','keepValsetup','keepVal','$mdDialog','$location', 'SessionService'];
	var  Resourcetabs;

	function Office365AddrescCtrl ($scope, $log, $state, $rootScope, $location, keepVal, keepValsetup, SessionService) {
		keepVal.storeAD = undefined;
		keepValsetup.storesetup = undefined;
		Resourcetabs = [
				  { title: 'Setup', tabLink: "Office365addresources.office365addrsc", tabSerial : "1"},
				  { title: 'Resource Details', tabLink: "Office365addresources.Details", tabSerial : "2"}
				/*{ title: 'Reconciliation Rule', tabLink: "Office365addresources.Office365reconattributerule", tabSerial : "2"}*/  
				],
		selected = null,
		previous = null;
		$rootScope.Resourcetabs = Resourcetabs;
		$scope.selectedIndex = 0;
		$rootScope.loadWidth = 33;
		$scope.selectTabService = 0;
		$scope.$watch('selectedIndex', function(current, old){
		previous = selected;
		selected = Resourcetabs[current];
		});
		$scope.wizardActive = function(activePath){
			var activePath = activePath.replace('#','')
			activePath = activePath.replace('.','/');
			locationPath = $location.path();
			locationPath = locationPath.replace('/','');
			  // alert(locationPath)
				if(activePath === locationPath){
				   return 'wizard-active';
				}else{
				   return '';
				}
			}
	  }
	function Office365firstsetup($http, $scope, $rootScope, $log, $state, $location, keepVal, SessionService)
	{
		var tabLength = $rootScope.Resourcetabs.length;
		var checkResourceURL = baseUrl + '/resources?check=true';
		var config = {
			url: checkResourceURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
			}
		}
		
		$http(config)
			.then(function success(response) {
			$rootScope.loaderCurrentStatus = 'false';
			if(response.data.type == 'success'){
				if (response.data.data.login[0].trusted == 'N') {
					$scope.TrustedAvailable = true;
					if(tabLength == 2)
						$rootScope.loadWidth = 50;
				} else if (response.data.data.login[0].trusted == 'Y') {
					$scope.TrustedAvailable = false;
					if(tabLength == 2) {
						$rootScope.Resourcetabs.push({ title: 'Reconciliation Rule', tabLink: "Office365addresources.Office365reconattributerule",  tabSerial : "3"});
					}	
				}
			}
			else if(response.data.type == 'error'){
				$scope.toastMessage('toast-error',response.data.message);
			}
			else if(response.data.type == 'warning'){
				$scope.toastMessage('toast-warn',response.data.message);
			}
			
		},function error(response){
			// It will work when the server returns the status "500 - Internal server" or 400 series errors
			$rootScope.loaderCurrentStatus = 'false';
			$scope.errorHandler(response.config.url,response.status);
		});
		$scope.form = {};
		var adVal = keepVal.adGetVal();
		if(adVal != undefined)
		{
			if(tabLength === 3)
				$rootScope.loadWidth = 33;
			$scope.form.resourceName = adVal.resourceName;
			$scope.form.radiobuttonmodel = adVal.radiobuttonmodel;
		}
	    $scope.selectTabService = 0;
		$scope.next = function(Resourcetabs){ 
		keepVal.adStore($scope.form);
		var resourcename = $scope.form.resourceName;           
		var istrusted = $scope.form.radiobuttonmodel;  
		var addResourceuntrustedsecstepURL = baseUrl + '/addoffice/chkrscname';   
		var config = 
		{
			url: addResourceuntrustedsecstepURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
				"cdt-rescname":resourcename,
				"cdt-istrusted": istrusted,
					}
		}
		$http(config)
			.then(function success(response) {
		if(response.data.type == "success")
		{
			var cTab = $scope.selectedIndex + 1;
			if((cTab == '1') && (istrusted == 'N')){
			$rootScope.loadWidth = 66;
			} 
			if((cTab == '1') && (istrusted == 'Y')){
				 $rootScope.loadWidth = 100;
			} 
			tabLength = Resourcetabs.length;
			if(istrusted == 'N'){	
				if(tabLength == '2')
				Resourcetabs.push({ title: 'Reconciliation Rule', tabLink: "Office365addresources.Office365reconattributerule",  tabSerial : "3"});
				} else {
				var tabIndex = Resourcetabs.findIndex(ResourcetabsArray => ResourcetabsArray.tabSerial == '3' );
				if(tabLength == '3')
				Resourcetabs.splice(tabIndex, 1);
				}
				$scope.selectedIndex = Math.min($scope.selectedIndex + 1, 5);
				var nextTab = $scope.selectedIndex;	
				var gotoUrl =  $rootScope.Resourcetabs[nextTab].tabLink;
			$state.go(gotoUrl);	
		}

		else if(response.data.type == "error")
		{
			$scope.toastMessage('toast-error',response.data.message);
			$state.go('ADaddresources.adaddrsc');
		}
			
		else if(response.data.type == "warning"){
			$scope.toastMessage('toast-warn',response.data.message);
			$state.go('ADaddresources.adaddrsc');
			}
		},function error(response){
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				$rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);
			});  
	}
	}      
	function office365setup($http, $scope, $rootScope, $log, $state, $location, keepValsetup,keepVal, SessionService){
		$scope.form = {};
		$scope.selectTabService = 1;
		var adVal = keepValsetup.setupGetVal();
		var adFirstVal = keepVal.adGetVal();
		if(adFirstVal == undefined) {
			$location.url('/Office365addresources/Office365addresource');
			return;
		} else {
			var resourcename = adFirstVal.resourceName;
			var istrustedval = adFirstVal.radiobuttonmodel;
			$scope.form.istrust = adFirstVal.radiobuttonmodel;
		}
		if(adVal != undefined){
			if(Resourcetabs.length == 3)
				$rootScope.loadWidth = 66;
			$scope.form.clientId = adVal.clientId;
			$scope.form.clientSecret = adVal.clientSecret;
			$scope.form.apiVersion = adVal.apiVersion;
			$scope.form.tenantId = adVal.tenantId;
		}
	/*This method loads when it's trusted
	*/
		$scope.addrescsetupsubmit = function(Resourcetabs)
		{ 
		   $rootScope.loaderCurrentStatus = 'true';
		   var clientId = $scope.form.clientId;
		   var clientSecret = $scope.form.clientSecret;
		   var apiVersion = $scope.form.apiVersion;
		   var tenantId = $scope.form.tenantId;     
		   var addResourcetrustFinalURL = baseUrl + '/addoffice/final';
			var config = {
				url: addResourcetrustFinalURL,
				method: "POST",
				headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
					"cdt-id":'6',
					"cdt-rescname":resourcename,
					"cdt-clientid":clientId,
					"cdt-clientsecret":clientSecret, 
					"cdt-apiversion":apiVersion,
					"cdt-istrusted": istrustedval,
					"cdt-tenantid": tenantId,
						}
			}
			$http(config)
				.then(function success(response) {
				$rootScope.loaderCurrentStatus = 'false';
		   if(response.data.type == "success"){
				$scope.toastMessage('toast-success',response.data.message);
				$state.go('resources');
				$scope.addTab('Resources','resources');
			}
			else if(response.data.type == "error"){
				//$rootScope.loaderCurrentStatus = 'false';
				$scope.toastMessage('toast-error',response.data.message);
				//$state.go('resources');
				}
			else if(response.data.type == "warning"){
				//$rootScope.loaderCurrentStatus = 'false';
				$scope.toastMessage('toast-warn',response.data.message);
				//$state.go('resources');
				}
			},function error(response){
				$rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);
			});      
		};
	   
		/*This method loads when it's un trusted
		*/
		$scope.next = function(Resourcetabs) 
		{		
		$rootScope.loaderCurrentStatus = 'true';
		keepValsetup.setupStore($scope.form);
		var clientId = $scope.form.clientId;
		var clientSecret = $scope.form.clientSecret;
		var apiVersion = $scope.form.apiVersion;
		var tenantId = $scope.form.tenantId;     
		var addResourceuntrustedsecstepURL = baseUrl + '/addoffice/chkrscdetails';
		var config = {  
				url: addResourceuntrustedsecstepURL,
				method: "GET",
				headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
					"cdt-clientid":clientId,
					"cdt-clientsecret":clientSecret, 
					"cdt-apiversion":apiVersion,
					"cdt-tenantid": tenantId,
						}
			}
		$http(config)
			.then(function success(response) {
		   if(response.data.type == "success"){
				$rootScope.loaderCurrentStatus = 'false';
				var cTab = $scope.selectedIndex + 1;
					if((cTab == '2') && (istrustedval == 'N')){
						$state.go("Office365addresources.Office365reconattributerule");
						$rootScope.loadWidth = 100;
					} 
					var tabLength = Resourcetabs.length;
					$scope.selectedIndex = Math.min($scope.selectedIndex + 2, 5) ;
					var nextTab = $scope.selectedIndex;	
					var gotoUrl =  $rootScope.Resourcetabs[nextTab].tabLink;
					$state.go(gotoUrl);	
			}
			else if(response.data.type == "error"){
				$rootScope.loaderCurrentStatus = 'false';
				$scope.toastMessage('toast-error',response.data.message);
				$state.go('Office365addresources.Details');
				}
			else if(response.data.type == "warning"){
				$rootScope.loaderCurrentStatus = 'false';
				$scope.toastMessage('toast-warn',response.data.message);
				$state.go('Office365addresources.Details');
				}
			},function error(response){
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				$rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);
			});  
		};
		$scope.previous = function(Resourcetabs) {
			$scope.selectedIndex = Math.max($scope.selectedIndex - 2, 0);
			var prevTab = $scope.selectedIndex;
			var gotoUrl = $rootScope.Resourcetabs[prevTab].tabLink;
			var tabLength = Resourcetabs.length;
			var cTab = $scope.selectedIndex + 1;
			if((cTab == '1') && (tabLength == '3')){
				 $rootScope.loadWidth = 33;
			} else {
				$rootScope.loadWidth = 50;
			}
			$state.go(gotoUrl);
		};  	
	}
	function Office365reconattributeruleCtrl($http, $scope, $log, $rootScope, $state, keepRecon,keepValsetup,keepVal,$mdDialog,$location, SessionService) {	 
		$rootScope.userattributetitle = false;
		$rootScope.loadWidth = 100;
		$rootScope.count=0;
		$scope.form={};
		$rootScope.listAttributes = [];
		$rootScope.finalMappingColumn = {"records": []};
		$scope.selectTabService = 2;
		var adVal = keepValsetup.setupGetVal();
		var adFirstVal = keepVal.adGetVal();
		if(adFirstVal == undefined) {
			$location.url('/Office365addresources/Office365addresource');
			return;
		} 
		else {
			var resourcename = adFirstVal.resourceName;
			var istrustedval = adFirstVal.radiobuttonmodel;
		}
		var clientid = adVal.clientId;
		var clientSecret = adVal.clientSecret;
		var apiVersion = adVal.apiVersion;
		var tenantId = adVal.tenantId;
		$rootScope.count=0;
		  //add button
		$scope.userattributesvalues={"records": []};
		$scope.userattributeaddbutton=function($event){
		$mdDialog.show({
		   controller: addoffice365ReconController,
			controllerAs: 'office365reconrulectrl',
			templateUrl: 'resources/addResource/office365Resource/cloudentix-admin-resources-addResource-Office365-addOffice365ReconRule.html',
			parent: angular.element(document.body),
			targetEvent: $event,
			//controller: mdDialogCtrl,
			clickOutsideToClose:false
		  })
		}
	//delete button
		$scope.Deleterecon=function(index){
			$rootScope.count--;			
			$rootScope.listAttributes.splice(index, 1);
			$rootScope.finalMappingColumn.records.splice(index, 1);
			if($rootScope.listAttributes.length === 0) {
				$rootScope.userattributetitle = false;
			}
		}	
	$scope.previous = function(Resourcetabs) {
	  $scope.selectedIndex = Math.max($scope.selectedIndex + 1, 0);
	  var prevTab = $scope.selectedIndex;
	  var gotoUrl = $rootScope.Resourcetabs[prevTab].tabLink;
	  $state.go(gotoUrl);
	  $rootScope.loadWidth = 50;
	}; 
	$scope.ADresourcesubmit = function() {
		$rootScope.loaderCurrentStatus = 'true';
		var addResourceFinalURL = baseUrl + '/addoffice/final';
		$scope.finalAttribute = {'records':[]};
		angular.forEach($rootScope.finalMappingColumn.records, function(value, key) {
			var array = [];
			var array1 = [];
			if(value["userAttrId"]== '1'){
						$scope.userAttrId = value["userAttrId"];
						array.push(value["concat1"]+','+value["concat2"]);						
					}
					//SubString User Attribute Mapping
					else if(value["userAttrId"]== '2'){
						$scope.userAttrId = value["userAttrId"];
						array.push(value["substringMapping"]+','+value["substring"]);						
					}
					//DirectMapping User Attribute Mapping
					else if(value["userAttrId"]== '3'){
						$scope.userAttrId = value["userAttrId"];
						array.push(value["directmapping"]);
					}
					//Target Attribute Mapping
					//Concat Target Attribute Mapping
					if(value["targetCol"]== '1'){
						$scope.targetuserAttrId = value["targetCol"];
						array1.push(value["targetConcat1"]+','+value["targetConcat2"]);					
					}
					//SubString Target Attribute Mapping
					else if(value["targetCol"]== '2'){
						$scope.targetuserAttrId = value["targetCol"];
						array1.push(value["targetsubstringMapping"]+','+value["targetSubstring"]);						
					}
					//DirectMapping Target Attribute Mapping
					else if(value["targetCol"]== '3'){
						$scope.targetuserAttrId = value["targetCol"];
						array1.push(value["targetdirectMapping"]);
					}
					//array1.push(value["targetCol"]);
					$scope.finalAttribute.records.push({"cloudusrattr":[{"methodid": $scope.userAttrId,"col": array}], "trgtusrattr":[{"methodid":$scope.targetuserAttrId,"col": array1}]});
			});
		var data = angular.toJson($scope.finalAttribute);
		var config = {
			url : addResourceFinalURL,
			method :"POST",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
				"cdt-id": '6',
				"cdt-rescname": resourcename,
				"cdt-clientid": clientid,
				"cdt-clientsecret": clientSecret, 
				"cdt-apiversion": apiVersion,
				"cdt-istrusted": istrustedval,
				"cdt-tenantid": tenantId,
				"cdt-reconattribute": data
					}
				}
				$http(config)
					.then(function success(response) {
						$rootScope.loaderCurrentStatus = 'false';
						if(response.data.type == 'success'){
						$scope.toastMessage('toast-success',response.data.message);
						$state.go('resources');
						$scope.addTab('Resources','resources');
						}
						else if(response.data.type == 'error'){
							$scope.toastMessage('toast-error',response.data.message);
						}
						else if(response.data.type == 'warning'){
							$scope.toastMessage('toast-warn',response.data.message);
						}
					},function error(response) {
					// It will work when the server returns the status "500 - Internal server" or 400 series errors
						$rootScope.loaderCurrentStatus = 'false';
						$scope.errorHandler(response.config.url,response.status);

					});
			};	 
		}
	function addoffice365ReconController($http, $scope, $rootScope, $state,$mdDialog,keepUDM,keepRecon, SessionService){
		$scope.form={};
		var length=$rootScope.listAttributes.length;
		var tableval=keepUDM.primaryTableGetVal();
		var self = this;
		$scope.userattributesvalue = {"records": []};
		$scope.reconruleSelected = '';			
		var addResourceUserMappingMethodURL = baseUrl + '/method';
		var config = {
			url: addResourceUserMappingMethodURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
			}
		}
		$http(config)
			.then(function success(response) { 
			$scope.userResponse = response.data.type;   	
			 $scope.addMappinguserattributes = [];    
			if (response.data.type == "success") {			
				for(var i=0;i<response.data.records[0].dropdownlist.length;i++)
				{
					$scope.addMappinguserattributes.push({"id":response.data.records[0].dropdownlist[i].key,"value":response.data.records[0].dropdownlist[i].value});
					if(response.data.records[0].dropdownlist[i].key=="3"){
						$scope.reconruleSelected=response.data.records[0].dropdownlist[i].value;
					}					
				}								 
			}
			else {
					$scope.managesystemErrorMessage = response.data.message;
				}
		},function error(response) {
			// It will work when the server returns the status "500 - Internal server" or 400 series errors
				$rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);

			});
			var addResourceUserAttributesMappingURL = baseUrl + '/userattributes';
			var config = {
				url: addResourceUserAttributesMappingURL,
				method: "GET",
				headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
				}
			}
			$http(config)
				.then(function success(response) {          
				$scope.resourceuserattributes = [];               
					for(var i=0;i<response.data.records[0].listattributes.length;i++)
					{
						$scope.resourceuserattributes.push({"id":response.data.records[0].listattributes[i].colname,"value":response.data.records[0].listattributes[i].displayname});
					}
			},function error(response) {
			// It will work when the server returns the status "500 - Internal server" or 400 series errors
				$rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);
			});
			
			
			var Office365listColumns = baseUrl + '/addoffice/gettargetcol';
			var config = {
			 url: Office365listColumns,
			 method: "GET",
			 headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
				}
			}
			$http(config)
				.then(function success(response) { 
				$scope.targetcolumns=[];
				angular.forEach(response.data.records[0].targetcolumns, function(value,key) {
					$scope.targetcolumns.push(value); 
				});
			},function error(response) {
			// It will work when the server returns the status "500 - Internal server" or 400 series errors
				$rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);
			});
			self.cancel = function($event) {
				$mdDialog.cancel();
			}
			self.finish = function($event) {
				$rootScope.listAttributes.push({});
				if($scope.userattributesvalue.records[0].userAttrId=='1'){
					var userConcat="concat("+$scope.userattributesvalue.records[0].concat1+","+$scope.userattributesvalue.records[0].concat2+")";
					$scope.attrId=$scope.userattributesvalue.records[0].userAttrId;
					$scope.userAttrConcat=userConcat;
					//console.log($scope.userattributesvalue.records[0].concat1);
					$rootScope.listAttributes[length].userattribute = userConcat;
				}
				else if($scope.userattributesvalue.records[0].userAttrId=='2'){
					var userSubstring="substring("+$scope.userattributesvalue.records[0].substringMapping+","+$scope.userattributesvalue.records[0].substring+")";
					//console.log(userSubstring);
					$rootScope.listAttributes[length].userattribute = userSubstring;
				}
				else if($scope.userattributesvalue.records[0].userAttrId=='3'){
					
					var userDirectMapping="directmapping("+$scope.userattributesvalue.records[0].directmapping+")";
					//console.log(userDirectMapping);
					$rootScope.listAttributes[length].userattribute = userDirectMapping;
				}
				if($scope.userattributesvalue.records[0].targetCol=='1'){
					var targetConcat="concat("+$scope.userattributesvalue.records[0].targetConcat1+","+$scope.userattributesvalue.records[0].targetConcat2+")";
					//console.log(targetConcat);
					$rootScope.listAttributes[length].targetattribute = targetConcat;
				}
				else if($scope.userattributesvalue.records[0].targetCol=='2'){
					var targetSubstringMapping="substring("+$scope.userattributesvalue.records[0].targetsubstringMapping+","+$scope.userattributesvalue.records[0].targetSubstring+")";
					//console.log(targetSubstringMapping);
					$rootScope.listAttributes[length].targetattribute = targetSubstringMapping;
				}
				else if($scope.userattributesvalue.records[0].targetCol=='3'){
					var targetAttrDirectMapping="directmapping("+$scope.userattributesvalue.records[0].targetdirectMapping+")";
					//console.log(targetAttrDirectMapping);
					$rootScope.listAttributes[length].targetattribute = targetAttrDirectMapping;
				}
				$rootScope.finalMappingColumn.records.push($scope.userattributesvalue.records[0]);
				//console.log($rootScope.finalMappingColumn);	
				$mdDialog.hide();
				var arr=[];
			  angular.forEach($rootScope.listAttributes, function(value, key) {
				arr.concat([arr.push(value.userattribute + ' '+value.targetattribute)]);
				});
				var uniqOb = {};
				for (var i in arr)
					uniqOb[arr[i]] = "";
				if (arr.length == Object.keys(uniqOb).length){
				 }
				  else{
					$rootScope.listAttributes.splice(-1, 1);
					$rootScope.finalMappingColumn.records.splice(-1, 1);
					  $mdDialog.show(
						$mdDialog.alert()
						.clickOutsideToClose(false)
						.title('Recon Rule')
						.textContent('Selected Recon Rule already exists. Please select a different User Attributes Mapped Column and Target Attributes Mapped Column')
						.ok('ok')
					);
				  }
				$rootScope.userattributetitle = true;
				$rootScope.count++;

		};

	}
angular
	.module('cloudentixApp')
	.controller('Oracleaddrescourcemainctrl',oracleaddRscMainCtrl)
	.controller('OraclesetupCtrl',oraclesetup)
	.controller('Oracleuserdatamappingcontroller',oracleuserdatamapping)
	.controller('Oraclechildtabledatamappingcontroller',oraclechilddatamapping)
	.controller('oracleuserattrmappingcontroller',oracleUserattrmapping)
	.controller('oracletrusteduserattrmappingcontroller',oracleTrustedUserAttrMapping)
	.controller('oraclelookupTabledataMappingController',oracleLookupTableDataMapping)
	.config(
		['$stateProvider', '$urlRouterProvider',
			function($stateProvider,$urlRouterProvider){
				$urlRouterProvider
				$stateProvider
					.state('Oracleaddresources.oracleaddrsc', {
						url:'/Oracleaddrsc',
						templateUrl: 'resources/addResource/oracle/cloudentix-admin-resources-addResource-oracle-setup.html',
					})
					.state('Oracleaddresources.userdatamapping', {
						url: '/oracleuserdatamapping',
						templateUrl: 'resources/addResource/oracle/cloudentix-admin-resources-addResource-oracle-userdatamapping.html',
					})
					.state('Oracleaddresources.childtabledatamapping', {
						url: '/oraclechildtabledatamapping',
						templateUrl: 'resources/addResource/oracle/cloudentix-admin-resources-addResource-oracle-childtabledatamapping.html',
					})
					//oracle-trusted  
					.state('Oracleaddresources.userattributesmapping', {
						url: '/oracleuserattributesmapping',
						templateUrl: 'resources/addResource/oracle/cloudentix-admin-resources-addResource-oracle-trusteduserattributesmapping.html',
					}) 
					//oracle-untrusted-reconattributerule
					.state('Oracleaddresources.recon', {
						url: '/oraclerecon',
						templateUrl: 'resources/addResource/oracle/cloudentix-admin-resources-addResource-oracle-userattributesmapping.html',
					})
					.state('Oracleaddresources.lookuptabledatamapping', {
						url: '/oraclelookuptabledatamapping',
						templateUrl: 'resources/addResource/oracle/cloudentix-admin-resources-addResource-oracle-lookuptabledatamapping.html',
					});
				}
		])
	.service('keepValue', function(){
	this.mysqlStore = function(x, y){
		this.storemysql = x;
		this.storetablemysql = y;
	}
	this.mysqlGetVal = function(){
		return this.storemysql;
	}
	this.tableGetVal = function(){
		return this.storetablemysql;
	}
	})
	.service('keepUDM', function(){
		this.udmStore = function(x,y){
			this.storeUDM = x;
			this.storeprimarytablemysql = y;
		}
		this.UDMGetVal = function(){
			return this.storeUDM;
		}
		this.primaryTableGetVal = function(){
			return this.storeprimarytablemysql;
		}
	})
	.service('keepCDM', function(){
		this.cdmStore = function(x){
			this.storeCDM = x;
		}
		this.CDMGetVal = function(){
			return this.storeCDM;
		}
	})
	.service('keepRecon', function(){
		this.reconStore = function(x){
			this.storeRecon = x;
		}
		this.reconAttrStore = function(x){
			this.storeAttributeRecon = x;
		}
		this.reconGetVal = function(){
			return this.storeRecon;
		}
		this.reconGetAttr = function(){
			return this.storeAttributeRecon;
		}
	})
	.service('keepTUAM', function(){
		this.tuamStore = function(x){
			this.storeTUAM = x;
		}
		this.tuamGetVal = function(){
			return this.storeTUAM;
		}
	})
	.factory('selectTabService', function(){
		var tabActive = '0';
		return {  
			tabActive: function() { return tabActive; },
			setTabActive: function(x) { tabActive = x; }
			};
		})
	.run(['$rootScope', '$state', '$stateParams',
	function($rootScope, $state, $stateParams) {
		$rootScope.$state = $state;
		$rootScope.$stateParams = $stateParams;
		}
	])
	oracleaddRscMainCtrl.$inject = ['$scope', '$log', '$state', '$rootScope', '$location', 'keepValue', 'keepUDM', 'keepCDM', 'keepRecon', 'keepTUAM', 'SessionService'];
	oraclesetup.$inject = ['$scope','$http','$rootScope', '$state','keepValue', 'SessionService'];
	oracleuserdatamapping.$inject = ['$http', '$scope', '$rootScope', '$state','keepUDM', 'keepValue', '$timeout', '$location', 'SessionService'];
	oraclechilddatamapping.$inject = ['$http','$scope','$state','$rootScope', 'keepValue','keepCDM','keepUDM', '$location', '$timeout', 'SessionService'];
	oracleUserattrmapping.$inject = ['$http', '$scope', '$rootScope', '$state','keepUDM','keepRecon', '$mdDialog', 'keepValue', '$location', 'SessionService'];
	oracleTrustedUserAttrMapping.$inject = ['$http', '$scope', '$rootScope', '$state', 'keepUDM','keepValue', 'keepTUAM', '$location', 'SessionService'];
	oracleLookupTableDataMapping.$inject = ['$http','$scope','$rootScope','$state', 'keepValue', 'keepUDM', 'keepCDM', 'keepRecon', 'keepTUAM', '$mdDialog', '$location', 'SessionService'];
	function oracleaddRscMainCtrl ($scope, $log, $state, $rootScope, $location, keepValue, keepUDM, keepCDM, keepRecon, keepTUAM, SessionService) {
		keepValue.storemysql = undefined;
		keepUDM.storeUDM = undefined;
		keepCDM.storeCDM = undefined;
		keepRecon.storeRecon = undefined;
		keepTUAM.storeTUAM = undefined;
		// keepDM.storeDM = undefined;
		$scope.selectTabService = 0;
	    var Resourcetabs = [
			  { title: 'Setup', tabLink: "Oracleaddresources.oracleaddrsc", tabSerial : "1"},
			  { title: 'User Data Mapping', tabLink: "Oracleaddresources.userdatamapping", tabSerial : "2"},
			  { title: 'Role Data Mapping', tabLink: "Oracleaddresources.childtabledatamapping", tabSerial : "3"},          
			  { title: 'User Attributes Mapping', tabLink: "Oracleaddresources.userattributesmapping", tabSerial : "4"},
			  { title: 'Reference Data Mapping', tabLink: "Oracleaddresources.lookuptabledatamapping", tabSerial : "5"}
			],
		selected = null,
		previous = null;
		$rootScope.Resourcetabs = Resourcetabs;
		$scope.selectedIndex = 0;
		$rootScope.loadWidth = 20;
		$scope.$watch('selectedIndex', function(current, old){
		previous = selected;
		selected = Resourcetabs[current];
		});
		$scope.wizardActive = function(activePath){
		var activePath = activePath.replace('#','')
		activePath = activePath.replace('.','/');
		locationPath = $location.path();
		locationPath = locationPath.replace('/','');
			if(activePath === locationPath){
				return 'wizard-active';
			}else{
				return '';
			}
		}
	}
	  
  	function oraclesetup($scope,$http,$rootScope, $state,keepValue, SessionService){
        var checkResourceURL = baseUrl + '/resources?check=true';
		var config = {
			url: checkResourceURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
			}
		}
		$http(config)
		.then(function success(response) {
			$rootScope.loaderCurrentStatus = 'false';
			if(response.data.type == 'success'){
				if (response.data.data.login[0].trusted == 'N') {
					$scope.TrustedAvailable = true;
				} else if (response.data.data.login[0].trusted == 'Y') {
					$scope.TrustedAvailable = false;
					$rootScope.Resourcetabs[3].title = "Reconciliation Rule"
					$rootScope.Resourcetabs[3].tabLink = "Oracleaddresources.recon"	
				}
			}
			else if(response.data.type == 'error'){
				$scope.toastMessage('toast-error',response.data.message);
			}
			else if(response.data.type == 'warning'){
				$scope.toastMessage('toast-warn',response.data.message);
			}
			
		},function error(response){
			// It will work when the server returns the status "500 - Internal server" or 400 series errors
			$rootScope.loaderCurrentStatus = 'false';
			$scope.errorHandler(response.config.url,response.status);
		});
		$scope.form={};
		var oracleval=keepValue.mysqlGetVal();
        $scope.selectTabService = 0;
		if(oracleval != undefined)
		{
			$scope.form.resourceName = oracleval.resourceName;
			$scope.form.hostName = oracleval.hostName;
			$scope.form.userName = oracleval.userName;
			$scope.form.password = oracleval.password;
			$scope.form.Port = oracleval.Port;
			$scope.form.databaseName = oracleval.databaseName;
			$scope.form.radiobuttonmodel = oracleval.radiobuttonmodel;
		}
		$scope.next = function(Resourcetabs){
            $rootScope.loaderCurrentStatus = 'true';
			var resourcename = $scope.form.resourceName;
			var hostname = $scope.form.hostName;
			var username = $scope.form.userName;
			var password = $scope.form.password;
			var port = $scope.form.Port;
			var databasename = $scope.form.databaseName;     
			var radiobuttonmodel = $scope.form.radiobuttonmodel;
			var addResourceSetupURL = baseUrl + '/addoracle/gettargettables';
			var config = {
			url: addResourceSetupURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                "cdt-rescname":resourcename,
                "cdt-host":hostname,
                "cdt-port":port,
                "cdt-username":username,
                "cdt-pwd":password,
                "cdt-db":databasename, 
                "cdt-istrusted":radiobuttonmodel
				}
			}
		$http(config)
				.then(function success(response) {
            $rootScope.loaderCurrentStatus = 'false';
			if(response.data.type=="success"){
				$scope.resourcetargettables = [];     
                angular.forEach(response.data.records[0].targettables, function(key,value) {
                $scope.resourcetargettables.push(response.data.records[0].targettables[value]);
                }); 
				if(radiobuttonmodel === 'N'){
					var temp;
					temp = Resourcetabs[3].title;
					Resourcetabs[3].title = "Reconciliation Rule"
					Resourcetabs[3].tabLink = "Oracleaddresources.recon"
				} else {
					var temp;
					temp = Resourcetabs[3].title;
					Resourcetabs[3].title = "User Attributes Mapping"
					Resourcetabs[3].tabLink = "Oracleaddresources.userattributesmapping"
				}
					keepValue.mysqlStore($scope.form, $scope.resourcetargettables);
					$scope.selectedIndex = Math.min($scope.selectedIndex + 1, 5) ;
					//selectTabService.setTabActive($scope.selectedIndex);
				var nextTab = $scope.selectedIndex;	
				var gotoUrl =  $rootScope.Resourcetabs[nextTab].tabLink;
				$state.go(gotoUrl);
				$rootScope.loadWidth = 40;
			}
			else if(response.data.type == "error"){
			$scope.toastMessage('toast-error',response.data.message);
			$state.go('Oracleaddresources.oracleaddrsc');
            }
            else if(response.data.type == "warning"){
			$scope.toastMessage('toast-warn',response.data.message);
			$state.go('Oracleaddresources.oracleaddrsc');
            }
		},function error(response){
			// It will work when the server returns the status "500 - Internal server" or 400 series errors
			$rootScope.loaderCurrentStatus = 'false';
			$scope.errorHandler(response.config.url,response.status);
		}); 	
		}
	}
	function oracleuserdatamapping($http, $scope, $rootScope, $state,keepUDM, keepValue, $timeout, $location, SessionService){
		$scope.form = {};
        var oracleVal = keepValue.mysqlGetVal();
        if(oracleVal == undefined) {
            $location.url('/Oracleaddresources/Oracleaddrsc');
			return;
        }
		var udmVal = keepUDM.UDMGetVal();
		var oracleVal=keepValue.mysqlGetVal();
		$scope.istrustedvalfinal = oracleVal.radiobuttonmodel;
		var tableval=keepValue.tableGetVal();
		$scope.selectTabService = 1;
		var countservice = 0;
		$scope.usertable= angular.copy(tableval);
		$scope.getlistofcolumns=function(tableform){
			 $rootScope.loaderCurrentStatus = 'true';
			$scope.form.singleSelectusertablekey = '';
			$scope.form.singleSelectpasswordcolumn = '';
			$scope.form.singleSelectstatuscol = '';
			$scope.form.enableValue = '';
			$scope.form.disableValue = '';
			tableform.$setUntouched();
            tableform.$setPristine(true);
			var addResourceUserDataMappingURL = baseUrl + '/addoracle/gettargetcolumns';
			var resourcetablename = $scope.form.usertablenamemodel;
			var hostname = oracleVal.hostName;
			var username = oracleVal.userName;
			var password = oracleVal.password;
			var port = oracleVal.Port;
			var databasename = oracleVal.databaseName;
			var istrustedval = oracleVal.radiobuttonmodel;
			var config = {
				url : addResourceUserDataMappingURL,
				method : "GET",
				headers : {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
					"cdt-host":hostname,
					"cdt-port":port,
					"cdt-username":username,
					"cdt-pwd":password,
					"cdt-db":databasename, 
					"cdt-istrusted":istrustedval,
					"cdt-tablename":resourcetablename,
				}
			}
			$http(config)
				.then(function success(response) {
				$rootScope.loaderCurrentStatus = 'false';
				$scope.resourcetargetcolumns = [];
				angular.forEach(response.data.records[0].targetcolumns,function(key,value){
					$scope.resourcetargetcolumns.push(response.data.records[0].targetcolumns[value]);
				})
				$scope.usertablekey= angular.copy($scope.resourcetargetcolumns);
				var passwordnone=["None"];
				var passwordcolumn1= angular.copy($scope.resourcetargetcolumns);
				$scope.passwordcolumn=passwordnone.concat(passwordcolumn1);
				if(istrustedval == "Y")
				{
					//console.log("==");
					$scope.statuscolumn= angular.copy($scope.resourcetargetcolumns);
				}
				else{
					var statusone=["None"];
					var statuscolumn1= angular.copy($scope.resourcetargetcolumns);
					$scope.statuscolumn= statusone.concat(statuscolumn1);
				}
				$scope.userrolecolumn= angular.copy($scope.resourcetargetcolumns);
				if(udmVal != undefined && countservice === 0){
					$scope.form.singleSelectusertablekey = udmVal.singleSelectusertablekey;
					$scope.form.singleSelectpasswordcolumn = udmVal.singleSelectpasswordcolumn;
					$scope.form.singleRoleMapping = udmVal.singleRoleMapping;
					$scope.form.singleSelectstatuscol = udmVal.singleSelectstatuscol;
					$scope.form.enableValue = udmVal.enableValue;
					$scope.form.disableValue = udmVal.disableValue;
					$timeout(function () {
						$scope.form.singleSelectedRole = udmVal.singleSelectedRole;
					}, 2000);	
				}
				countservice = countservice + 1;
			},function error(response){
					// It will work when the server returns the status "500 - Internal server" or 400 series errors
					$rootScope.loaderCurrentStatus = 'false';
					$scope.errorHandler(response.config.url,response.status);
				}); 
			
		}
		 $scope.resetStatusValue = function(selectedStatus) {
            if(selectedStatus == 'None') {
                $scope.form.enableValue = '';
                $scope.form.disableValue  = '';
            }
        }
		if(udmVal != undefined){
			$rootScope.loaderCurrentStatus = 'true';
			$scope.form.usertablenamemodel = udmVal.usertablenamemodel;
			$timeout(function () {
					$scope.getlistofcolumns($scope.loginForm);
				}, 1000);
        //$scope.form.singleSelectusertablekey = udmVal.singleSelectusertablekey;
        //$scope.form.singleSelectpasswordcolumn = udmVal.singleSelectpasswordcolumn;
		//$scope.form.singleRoleMapping = udmVal.singleRoleMapping;
		//$scope.form.singleSelectedRole = udmVal.singleSelectedRole;
        //$scope.form.singleSelectstatuscol = udmVal.singleSelectstatuscol;
        //$scope.form.enableValue = udmVal.enableValue;
        //$scope.form.disableValue = udmVal.disableValue;
		}
		$scope.next = function(Resourcetabs) {
			if($scope.form.singleSelectpasswordcolumn=="None") {
				$scope.form.singleSelectpasswordcolumn="";
			}
			if($scope.form.singleSelectstatuscol=="None") {
				$scope.form.singleSelectstatuscol="";
			}
			keepUDM.udmStore($scope.form , $scope.resourcetargetcolumns);
			$scope.selectedIndex = Math.min($scope.selectedIndex + 2, 5) ;
		//	selectTabService.setTabActive($scope.selectedIndex);
			var nextTab = $scope.selectedIndex;	
			var gotoUrl =  $rootScope.Resourcetabs[nextTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 60;
		};		
		$scope.previous = function(Resourcetabs) {
			$scope.selectedIndex = Math.max($scope.selectedIndex - 2, 0);
			//selectTabService.setTabActive($scope.selectedIndex);
			var prevTab = $scope.selectedIndex;
			var gotoUrl = $rootScope.Resourcetabs[prevTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 20;
		};  	
	}
	function oraclechilddatamapping($http,$scope,$state,$rootScope, keepValue,keepCDM,keepUDM, $location, $timeout, SessionService){
		$scope.form = {};
        var oracleVal = keepValue.mysqlGetVal();
        if(oracleVal == undefined) {
            $location.url('/Oracleaddresources/Oracleaddrsc');
			return;
        }
		var udmVal = keepUDM.UDMGetVal();
		$scope.singlerolemapvalue = udmVal.singleRoleMapping;
		var cdmVal = keepCDM.CDMGetVal();
		var tableval=keepValue.tableGetVal();
        $scope.selectTabService = 2;
		$scope.userroletable= angular.copy(tableval);
		$scope.roletablevalue= angular.copy(tableval);
		if($scope.singlerolemapvalue == 'N')
		{
			$scope.getlistofcolumnsforuserrole=function(tableform, useridcol, roleidcol){
			$rootScope.loaderCurrentStatus = 'true';
			$scope.form.useridcolumnmodel = '';
			$scope.form.userroleidcolumnmodel = '';
			tableform.$setUntouched();
            tableform.$setPristine(true);
			var addResourceChildDataMappingURL = baseUrl + '/addoracle/gettargetcolumns';
			var userroletableid = $scope.form.userroletablemodel;
			var hostname = oracleVal.hostName;
			var username = oracleVal.userName;
			var password = oracleVal.password;
			var port = oracleVal.Port;
			var databasename = oracleVal.databaseName;
			var istrustedval = oracleVal.radiobuttonmodel;
			if(userroletableid != undefined){
			var config = {
				url : addResourceChildDataMappingURL,
				method : "GET",
				headers : {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
					"cdt-host":hostname,
					"cdt-port":port,
					"cdt-username":username,
					"cdt-pwd":password,
					"cdt-db":databasename, 
					"cdt-istrusted":istrustedval,
					"cdt-tablename":userroletableid,
				}
			}
			$http(config)
				.then(function success(response) {
				$rootScope.loaderCurrentStatus = 'false';
				$scope.resourcetargetcolumnsuserroletable = [];
				angular.forEach(response.data.records[0].targetcolumns,function(key,value){
					$scope.resourcetargetcolumnsuserroletable.push(response.data.records[0].targetcolumns[value]);
				})
				$scope.useridcolumn= angular.copy($scope.resourcetargetcolumnsuserroletable);
				$scope.userroleidcolumn= angular.copy($scope.resourcetargetcolumnsuserroletable);
				if(useridcol != undefined && roleidcol != undefined) {
					$scope.form.useridcolumnmodel = cdmVal.useridcolumnmodel;
					$scope.form.userroleidcolumnmodel = cdmVal.userroleidcolumnmodel;
				}
			},function error(response){
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				$rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);
				}); 
			}
			
		}		
		}
		$scope.getlistofcolumnsforroletable = function(tableform, roleidcol, rolenamecol){
			$rootScope.loaderCurrentStatus = 'true';
			$scope.form.roleidcolumnmodel = '';
			$scope.form.rolenamecolumnmodel = '';
			tableform.$setUntouched();
            tableform.$setPristine(true);
			var addResourceChildDataMappingURL = baseUrl + '/addoracle/gettargetcolumns';
			var userroletableid = $scope.form.roletablemodel;
			var hostname = oracleVal.hostName;
			var username = oracleVal.userName;
			var password = oracleVal.password;
			var port = oracleVal.Port;
			var databasename = oracleVal.databaseName;
			var istrustedval = oracleVal.radiobuttonmodel;
			var config = {
				url : addResourceChildDataMappingURL,
				method : "GET",
				headers : {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
					"cdt-host":hostname,
					"cdt-port":port,
					"cdt-username":username,
					"cdt-pwd":password,
					"cdt-db":databasename, 
					"cdt-istrusted":istrustedval,
					"cdt-tablename":userroletableid,
				}
			}
			$http(config)
				.then(function success(response) {
				$rootScope.loaderCurrentStatus = 'false';
				$scope.resourcetargetcolumnsroletable = [];
				angular.forEach(response.data.records[0].targetcolumns,function(key,value){
					$scope.resourcetargetcolumnsroletable.push(response.data.records[0].targetcolumns[value]);
				})
				$scope.roleidcolumn= angular.copy($scope.resourcetargetcolumnsroletable);
				$scope.rolenamecolumn= angular.copy($scope.resourcetargetcolumnsroletable);
				if(roleidcol != undefined && rolenamecol != undefined) {
					$scope.form.roleidcolumnmodel = cdmVal.roleidcolumnmodel;
					$scope.form.rolenamecolumnmodel = cdmVal.rolenamecolumnmodel;
				}
			},function error(response){
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				$rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);
				}); 
		}
		$scope.next = function(Resourcetabs) {
			keepCDM.cdmStore($scope.form);
			$scope.selectedIndex = Math.min($scope.selectedIndex + 3, 5) ;
			//selectTabService.setTabActive($scope.selectedIndex);
			var nextTab = $scope.selectedIndex;	
			var gotoUrl =  $rootScope.Resourcetabs[nextTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 80;
		};
		if(cdmVal != undefined){
			if($scope.singlerolemapvalue == 'N'){
			$scope.form.userroletablemodel = cdmVal.userroletablemodel;
			$timeout(function () {
					$scope.getlistofcolumnsforuserrole($scope.loginForm, cdmVal.useridcolumnmodel, cdmVal.userroleidcolumnmodel);
				}, 1000);
			}
			//this for role table
			$scope.form.roletablemodel = cdmVal.roletablemodel;
			$timeout(function () {
						$scope.getlistofcolumnsforroletable($scope.loginForm, cdmVal.roleidcolumnmodel, cdmVal.rolenamecolumnmodel);
					}, 1000);
			}
		
		$scope.previous = function(Resourcetabs){
			$scope.selectedIndex = Math.max($scope.selectedIndex - 0, 1);
			//selectTabService.setTabActive($scope.selectedIndex);
			var prevTab = $scope.selectedIndex;
			var gotoUrl = $rootScope.Resourcetabs[prevTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 40;
		}
		
	}
	
	function oracleUserattrmapping($http, $scope, $rootScope, $state,keepUDM,keepRecon, $mdDialog, keepValue, $location, SessionService) {
        var oracleVal = keepValue.mysqlGetVal();
        if(oracleVal == undefined) {
            $location.url('/Oracleaddresources/Oracleaddrsc');
			return;
        }
		var reconval = keepRecon.reconGetVal();
		var reconvalAttr = keepRecon.reconGetAttr();
		$rootScope.userattributetitle = false;
		$rootScope.count=0;
		$scope.form={};
		$rootScope.listAttributes = [];
		$rootScope.finalMappingColumn = {"records": []};
		$scope.userattributeaddbutton=function($event,$scope){
		$mdDialog.show({
			controller: addoracleReconController,
			controllerAs: 'oraclereconrulectrl',
			templateUrl: 'resources/addResource/oracle/cloudentix-admin-resources-addResource-oracle-addReconRule.html',
			parent: angular.element(document.body),
			targetEvent: $event,
			//controller: mdDialogCtrl,
			clickOutsideToClose:false
		})
		}
		 	 //delete button
		$scope.Deleterecon=function(index){
			$rootScope.count--;			
			$rootScope.listAttributes.splice(index, 1);
			$rootScope.finalMappingColumn.records.splice(index, 1);
            if($rootScope.listAttributes.length == 0) {
                $rootScope.userattributetitle = false;
            }
		}			
		if(reconval != undefined && reconvalAttr != undefined) {
			$rootScope.userattributetitle = true;
			$scope.trustusratt=reconval;
			var length=reconvalAttr.length;
			for(var i = 0; i < length; i++)
			{
				$scope.listAttributes.push({});
				$rootScope.count++;
			}
			for(var count = 0; count < length; count++)
			{					
				$scope.listAttributes[count].userattribute = reconvalAttr[count].userattribute;
				$scope.listAttributes[count].targetattribute = reconvalAttr[count].targetattribute;					
			}
			angular.forEach($scope.trustusratt, function(value, key) {
				$rootScope.finalMappingColumn.records.push(value);
			});			
		}	
		$scope.previous = function(Resourcetabs) {
			$scope.selectedIndex = Math.max($scope.selectedIndex - 1, 2);
			var prevTab = $scope.selectedIndex;
			var gotoUrl = $rootScope.Resourcetabs[prevTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 60;
		}; 		
		$scope.next = function(Resourcetabs){
			keepRecon.reconStore($rootScope.finalMappingColumn.records);
			keepRecon.reconAttrStore($rootScope.listAttributes);
			$scope.selectedIndex = Math.min($scope.selectedIndex + 4, 5) ;
			var nextTab = $scope.selectedIndex;	
			var gotoUrl =  $rootScope.Resourcetabs[nextTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 100;
		}
		
	}
	
	function oracleTrustedUserAttrMapping($http, $scope, $rootScope, $state, keepUDM,keepValue, keepTUAM, $location, SessionService){
		$scope.form={};
		var mssqlval=keepValue.mysqlGetVal();
        if(mssqlval == undefined) {
            $location.url('/Oracleaddresources/Oracleaddrsc');
        }
		$scope.resourcename = mssqlval.resourceName;
        $scope.selectTabService = 4;
		var trustusrattrmappval = keepTUAM.tuamGetVal();
		var tableval=keepUDM.primaryTableGetVal();
		$scope.targetcolumns= angular.copy(tableval);
		$rootScope.loaderCurrentStatus = 'true';
		var addResourceUserAttributesMappingURL = baseUrl + '/userattributes';
		var config = {
			url: addResourceUserAttributesMappingURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
            }
		}
		$scope.reconattribute = {"records": []}; 
		$http(config)
			.then(function success(response) {
			$rootScope.loaderCurrentStatus = 'false';            
            for(var i=0;i<response.data.records[0].listattributes.length;i++)
			{
				$scope.reconattribute.records.push({"id":response.data.records[0].listattributes[i].userattid,"value":response.data.records[0].listattributes[i].displayname,"uniqueflag":response.data.records[0].listattributes[i].uniqueflag});
			}
		},function error(response){
			// It will work when the server returns the status "500 - Internal server" or 400 series errors
			$rootScope.loaderCurrentStatus = 'false';
			$scope.errorHandler(response.config.url,response.status);
				}); 
		$scope.previous = function(Resourcetabs) {
			$scope.selectedIndex = Math.max($scope.selectedIndex - 1, 2);
			//selectTabService.setTabActive($scope.selectedIndex);
			var prevTab = $scope.selectedIndex;
			var gotoUrl = $rootScope.Resourcetabs[prevTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 60;
		}; 
		if(trustusrattrmappval != undefined) {
			$scope.trustusratt=trustusrattrmappval;
			angular.forEach($scope.trustusratt.records, function(value, key) {
				$scope.form[value["userAttrId"]] = value["targetCol"];
			});
		}
		
		$scope.next = function(Resourcetabs) {
			var userAttr = {"records": []};
			angular.forEach($scope.form, function(value, key) {
				if(value != "")
				{
					userAttr.records.push({"userAttrId": key, "targetCol": value});
				}
			});
			keepTUAM.tuamStore(userAttr);
			//console.log("trusted Attr Mapping"+angular.toJson($scope.reconattribute));
			$scope.selectedIndex = Math.min($scope.selectedIndex + 4, 5) ;
			//selectTabService.setTabActive($scope.selectedIndex);
			var nextTab = $scope.selectedIndex;	
			var gotoUrl =  $rootScope.Resourcetabs[nextTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 100;
		}
	}
	function oracleLookupTableDataMapping($http,$scope,$rootScope,$state, keepValue, keepUDM, keepCDM, keepRecon, keepTUAM, $mdDialog, $location, SessionService){
		$scope.lookuptabletitle = false;
        var oracleVal = keepValue.mysqlGetVal();
        if(oracleVal == undefined) {
            $location.url('/Oracleaddresources/Oracleaddrsc');
			return;
        }
		var tableval=keepUDM.primaryTableGetVal();
		$scope.targetlookupcolumns= angular.copy(tableval);
		var tableval=keepValue.tableGetVal();
		var udmVal = keepUDM.UDMGetVal();
		var cdmVal = keepCDM.CDMGetVal();
		$scope.selectTabService = 5;
		$scope.lookuptable= angular.copy(tableval);
		$scope.getlistoflookuptable=function(tableform,lookuptable, id){
			//$scope.form.useridcolumnmodel = '';
			//$scope.form.userroleidcolumnmodel = '';
			$rootScope.loaderCurrentStatus = 'true';
			$scope.lookupvalues.records[id].lookupkeycol = '';
			$scope.lookupvalues.records[id].lookupvalcol  = '';
			tableform.$setUntouched();
            tableform.$setPristine(true);
			var addResourceChildDataMappingURL = baseUrl + '/addoracle/gettargetcolumns';
			var userroletableid = lookuptable;
			var hostname = oracleVal.hostName;
			var username = oracleVal.userName;
			var password = oracleVal.password;
			var port = oracleVal.Port;
			var databasename = oracleVal.databaseName;
			var istrustedval = oracleVal.radiobuttonmodel;
			var config = {
				url : addResourceChildDataMappingURL,
				method : "GET",
				headers : {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
					"cdt-host":hostname,
					"cdt-port":port,
					"cdt-username":username,
					"cdt-pwd":password,
					"cdt-db":databasename, 
					"cdt-istrusted":istrustedval,
					"cdt-tablename":userroletableid,
				}
			}
			$http(config)
				.then(function success(response) {
				$rootScope.loaderCurrentStatus = 'false';
				$scope.resourcetargetcolumnsuserroletable = [];
				angular.forEach(response.data.records[0].targetcolumns,function(key,value){
					$scope.resourcetargetcolumnsuserroletable.push(response.data.records[0].targetcolumns[value]);
				})
				$scope.lookupvalues.records[id].getlooktable = angular.copy($scope.resourcetargetcolumnsuserroletable);
				$scope.lookupvalues.records[id].getlookkey  = angular.copy($scope.resourcetargetcolumnsuserroletable);
			},function error(response){
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				$rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);
				}); 
		}
		$scope.lookupvalues = {"records": []};
		var count = 0;
		$scope.AddLookup = function() {
			$scope.lookuptabletitle=true;
			$scope.lookupvalues.records.push({"id": count});
			count++;
		}
		$scope.CheckDuplicate = function(index) {
			var arr=[];
			angular.forEach($scope.lookupvalues.records, function(value, key) {
				arr.concat([arr.push(value.usrtblcol + ' '+value.lookuptbl)]);
			});
			/ temporary object /
			var uniqOb = {};
			/* create object attribute with name=value in array, this will not keep dupes*/
			for (var i in arr)
				uniqOb[arr[i]] = "";
			/ if object's attributes match array, then no dupes! /
			if (arr.length == Object.keys(uniqOb).length){
			}
			else{
				$scope.lookupvalues.records.splice(index, 1);
				$scope.lookupvalues.records.push({});
				  $mdDialog.show(
					$mdDialog.alert()
					.clickOutsideToClose(false)
					.title('Lookup')
					.textContent('Selected field already exists. Please select a different user attribute and lookup attribute')
					.ok('ok')
				);
			}		
		 };
		$scope.previous = function(Resourcetabs){
			$scope.selectedIndex = Math.max($scope.selectedIndex - 1, 3);
			//selectTabService.setTabActive($scope.selectedIndex);
			var prevTab = $scope.selectedIndex;
			var gotoUrl = $rootScope.Resourcetabs[prevTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 80;
		}
		$scope.DeleteLookup = function(index) {
			if($scope.lookupvalues.records.length == 1) {
				$scope.lookuptabletitle = false;
			}
			$scope.lookupvalues.records.splice(index, 1);
		}
		$scope.AddResourceFinal = function() {
            $rootScope.loaderCurrentStatus = 'true';
			var lookupvalues;
			if($scope.lookupvalues.records.length == 0) {
				lookupvalues = '{"records":[]}';
			} else {
				lookupvalues = {"records": []};
				angular.forEach($scope.lookupvalues.records,function(value, key){
					lookupvalues.records.push({"usrtblcol":value["usrtblcol"], "lookuptbl": value["lookuptbl"], "lookupkeycol": value["lookupkeycol"], "lookupvalcol": value["lookupvalcol"]});
				});
				lookupvalues =angular.toJson(lookupvalues);
			}
			var addResourceFinalURL = baseUrl + '/addoracle/final';
			var mssqlval=keepValue.mysqlGetVal();
			var resourcename = mssqlval.resourceName;
			var hostname = mssqlval.hostName;
			var username = mssqlval.userName;
			var password = mssqlval.password;
			var port = mssqlval.Port;
			var databasename = mssqlval.databaseName;
			var istrustedval = mssqlval.radiobuttonmodel;
			var resourcetablename = udmVal.usertablenamemodel;
			var usertableprimarykey = udmVal.singleSelectusertablekey;
			var passwordcolumn = udmVal.singleSelectpasswordcolumn;
			var singlerolemapping = udmVal.singleRoleMapping;
			var singleSelectedRole = udmVal.singleSelectedRole;
			var statuscolumn = udmVal.singleSelectstatuscol;
			var enableval = udmVal.enableValue;
			var disableval = udmVal.disableValue;
			var userroletable = cdmVal.userroletablemodel;
			var userid = cdmVal.useridcolumnmodel;
			var userroleid = cdmVal.userroleidcolumnmodel;
			var roletable = cdmVal.roletablemodel;
			var roleid = cdmVal.roleidcolumnmodel;
			var rolename = cdmVal.rolenamecolumnmodel;
			var finaluserattributesvalue = '';
			var finalreconattributesvalue = '';
			if(istrustedval === 'N'){
				var reconval = keepRecon.reconGetVal();
                finalreconattributesvalue = {'records':[]};
                angular.forEach(reconval, function(value, key) {
                    //console.log(value +"---"+ key);
                    var array = [];
                    var array1 = [];
					//User Attribute Mapping
					//Concat User Attribute Mapping
					if(value["userAttrId"]== '1'){
						$scope.userAttrId = value["userAttrId"];
						array.push(value["concat1"]+','+value["concat2"]);						
					}
					//SubString User Attribute Mapping
					else if(value["userAttrId"]== '2'){
						$scope.userAttrId = value["userAttrId"];
						array.push(value["substringMapping"]+','+value["substring"]);						
					}
					//DirectMapping User Attribute Mapping
					else if(value["userAttrId"]== '3'){
						$scope.userAttrId = value["userAttrId"];
						array.push(value["directmapping"]);
					}
					//Target Attribute Mapping
					//Concat Target Attribute Mapping
                    if(value["targetCol"]== '1'){
						$scope.targetuserAttrId = value["targetCol"];
						array1.push(value["targetConcat1"]+','+value["targetConcat2"]);					
					}
					//SubString Target Attribute Mapping
					else if(value["targetCol"]== '2'){
						$scope.targetuserAttrId = value["targetCol"];
						array1.push(value["targetsubstringMapping"]+','+value["targetSubstring"]);						
					}
					//DirectMapping Target Attribute Mapping
					else if(value["targetCol"]== '3'){
						$scope.targetuserAttrId = value["targetCol"];
						array1.push(value["targetdirectMapping"]);
					}
                    //array1.push(value["targetCol"]);
                    finalreconattributesvalue.records.push({"cloudusrattr":[{"methodid": $scope.userAttrId,"col": array}], "trgtusrattr":[{"methodid":$scope.targetuserAttrId,"col": array1}]});
                });
				finalreconattributesvalue = angular.toJson(finalreconattributesvalue);
				finaluserattributesvalue = '{"records":[]}';
			}
			else {
				var trustusrattrmappval = keepTUAM.tuamGetVal();
				finaluserattributesvalue = angular.toJson(trustusrattrmappval);
				finalreconattributesvalue = '{"records":[]}';
			}
			var config = {
				url: addResourceFinalURL,
				method: "POST",
				headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
					"cdt-id":'3',
					"cdt-rescname":resourcename,
					"cdt-host":hostname,
					"cdt-username":username,
					"cdt-pwd":password, 
					"cdt-port":port,
					"cdt-istrusted": istrustedval,
					"cdt-db": databasename,
					"cdt-usertbl": resourcetablename,
					"cdt-usertblprimary": usertableprimarykey,
					"cdt-pwdcol": passwordcolumn,
					"cdt-statuscol": statuscolumn,
					"cdt-enable": enableval,
					"cdt-disable": disableval,
					"cdt-userroletbl": userroletable,
					"cdt-userid": userid,
					"cdt-userroleid": userroleid,
					"cdt-roletbl": roletable,
					"cdt-roleid": roleid,
					"cdt-rolename": rolename,
					"cdt-reconattribute":finalreconattributesvalue,
					"cdt-userattribute":finaluserattributesvalue,
					"cdt-lookup":lookupvalues,
					"cdt-usrtblrolid":singleSelectedRole,
					"cdt-singlerole":singlerolemapping,
				}
			}
			$http(config)
				.then(function success(response) {
				$rootScope.loaderCurrentStatus = 'false';
				if(response.data.type == "success"){
					$scope.toastMessage('toast-success',response.data.message);
					$state.go('resources');
                    $scope.addTab('Resources','resources');
					keepValue.storemysql = undefined;
					keepUDM.storeUDM = undefined;
					keepCDM.storeCDM = undefined;
					keepRecon.storeRecon = undefined;
					keepTUAM.storeTUAM = undefined;
					//keepDM.storeDM = undefined;
				}
        
				else if(response.data.type == "error"){
					$rootScope.loaderCurrentStatus = 'false';
					$scope.toastMessage('toast-error',response.data.message);
					//$state.go('resources');
				}
			},function error(response){
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				$rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);
				}); 	
		}
	}
    function addoracleReconController($http, $scope, $rootScope, $state,$mdDialog,keepUDM,keepRecon, SessionService){
		$scope.form={};
		var length=$rootScope.listAttributes.length;
		var tableval=keepUDM.primaryTableGetVal();
		var self = this;		
		$scope.userattributesvalue = {"records": []};	
		$scope.reconruleSelected='';
        $scope.selectTabService = 3;
		$scope.targetcolumns= angular.copy(tableval);
		//Get Method api
		var addResourceUserMappingMethodURL = baseUrl + '/method';
		var config = {
			url: addResourceUserMappingMethodURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
            }
		}
		$http(config)
			.then(function success(response) {
		$scope.userResponse = response.data.type;   		
        $scope.addMappinguserattributes = [];     
		if (response.data.type == "success") {			
            for(var i=0;i<response.data.records[0].dropdownlist.length;i++)
            {
				$scope.addMappinguserattributes.push({"id":response.data.records[0].dropdownlist[i].key,"value":response.data.records[0].dropdownlist[i].value});
				if(response.data.records[0].dropdownlist[i].key=="3"){
					$scope.reconruleSelected=response.data.records[0].dropdownlist[i].value;
				}	
            }
		}
		else {
            $scope.managesystemErrorMessage = response.data.message;
         }
		},function error(response){
			// It will work when the server returns the status "500 - Internal server" or 400 series errors
			$rootScope.loaderCurrentStatus = 'false';
			$scope.errorHandler(response.config.url,response.status);
		}); 	
		//Get userattributes  api		
		var addResourceUserAttributesMappingURL = baseUrl + '/userattributes';
		var config = {
			url: addResourceUserAttributesMappingURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
            }
		}
		$http(config)
			.then(function success(response) {         
            $scope.resourceuserattributes = [];               
            for(var i=0;i<response.data.records[0].listattributes.length;i++)
            {
				$scope.resourceuserattributes.push({"id":response.data.records[0].listattributes[i].colname,"value":response.data.records[0].listattributes[i].displayname});
            }
			},function error(response){
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				$rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);
			}); 	
		$scope.userattributesvalues={"records": []};		
		self.cancel = function($event) {
		$mdDialog.cancel();
		};
		self.finish = function($event) {
			$rootScope.listAttributes.push({});
			$rootScope.userattributetitle = true;
			if($scope.userattributesvalue.records[0].userAttrId=='1'){
				var userConcat="concat("+$scope.userattributesvalue.records[0].concat1+","+$scope.userattributesvalue.records[0].concat2+")";
				$scope.attrId=$scope.userattributesvalue.records[0].userAttrId;
				$scope.userAttrConcat=userConcat;
				//console.log($scope.userattributesvalue.records[0].concat1);
				$rootScope.listAttributes[length].userattribute = userConcat;
			}
			else if($scope.userattributesvalue.records[0].userAttrId=='2'){
				var userSubstring="substring("+$scope.userattributesvalue.records[0].substringMapping+","+$scope.userattributesvalue.records[0].substring+")";
				//console.log(userSubstring);
				$rootScope.listAttributes[length].userattribute = userSubstring;
			}
			else if($scope.userattributesvalue.records[0].userAttrId=='3'){
				var userDirectMapping="directmapping("+$scope.userattributesvalue.records[0].directmapping+")";
				//console.log(userDirectMapping);
				$rootScope.listAttributes[length].userattribute = userDirectMapping;
			}
			if($scope.userattributesvalue.records[0].targetCol=='1'){
				var targetConcat="concat("+$scope.userattributesvalue.records[0].targetConcat1+","+$scope.userattributesvalue.records[0].targetConcat2+")";
				//console.log(targetConcat);
				$rootScope.listAttributes[length].targetattribute = targetConcat;
			}
			else if($scope.userattributesvalue.records[0].targetCol=='2'){
				var targetSubstringMapping="substring("+$scope.userattributesvalue.records[0].targetsubstringMapping+","+$scope.userattributesvalue.records[0].targetSubstring+")";
				//console.log(targetSubstringMapping);
				$rootScope.listAttributes[length].targetattribute = targetSubstringMapping;
			}
			else if($scope.userattributesvalue.records[0].targetCol=='3'){
				var targetAttrDirectMapping="directmapping("+$scope.userattributesvalue.records[0].targetdirectMapping+")";
				//console.log(targetAttrDirectMapping);
				$rootScope.listAttributes[length].targetattribute = targetAttrDirectMapping;
			}
			$rootScope.finalMappingColumn.records.push($scope.userattributesvalue.records[0]);
			//console.log($rootScope.finalMappingColumn);	
			$mdDialog.hide();
			var arr=[];
		  angular.forEach($rootScope.listAttributes, function(value, key) {
			arr.concat([arr.push(value.userattribute + ' '+value.targetattribute)]);
			});
			var uniqOb = {};
			for (var i in arr)
				uniqOb[arr[i]] = "";
			if (arr.length == Object.keys(uniqOb).length){
			 }
			  else{
				$rootScope.count--;	
				$rootScope.listAttributes.splice(-1, 1);
				$rootScope.finalMappingColumn.records.splice(-1, 1);
				  $mdDialog.show(
					$mdDialog.alert()
					.clickOutsideToClose(false)
					.title('Recon Rule')
					.textContent('Selected Recon Rule already exists. Please select a different User Attributes Mapped Column and Target Attributes Mapped Column')
					.ok('ok')
				);
			  }
			$rootScope.count++;

		};
		
	}
	
	
angular
    .module('cloudentixApp')
	.controller('listofattestation', Listof_attestation)
	.run(
        ['$rootScope', '$state', '$stateParams',
            function($rootScope, $state, $stateParams) {    
                $rootScope.$state = $state;
                $rootScope.$stateParams = $stateParams;
            }
        ]
    )
    .config(
        ['$stateProvider', '$urlRouterProvider',
            function($stateProvider, $urlRouterProvider) {
                $urlRouterProvider
                $stateProvider
                .state('attestation.selfattestation', {
                    url: '/selfattestation',
                    controller: function($scope) {
                    },
                    templateUrl: 'attestation/sub-selfattestation/selfattestation.html',
                    data: {
                        'selectedTab': 0
                    }
				})
				.state('attestation.rolemanager', {
                    url: '/rolemanager',
                    controller: function ($scope) {
                    },
                    templateUrl: 'attestation/roleManager/cloudentix-admin-sg-rolemanager.html',
                    data: {
                        'selectedTab': 1
                    }
                })
                .state('attestation.pendingattestation', {
                    url: '/pendingattestation',
                    controller: function($scope) {
                    },
                    templateUrl: 'attestation/sub-pendingattestation/pendingattestation.html',
                    data: {
                        'selectedTab': 2
                    }
                })
                .state('attestation.historyattestation', {
                    url: '/historyattestation',
                    onEnter: function() {
                        void 0;
                    },
                    controller: function($scope) {
                    },
                    templateUrl: 'attestation/sub-historyattestation/historyattestation.html',
                    data: {
                        'selectedTab': 3
                    }
                });
            }
        ]
    );
    Listof_attestation.$inject = ['$scope', '$log', '$location', '$window', '$http', '$state'];
	function Listof_attestation($scope, $log, $location, $window, $http, $state) {
		var attestationtabs = [
			{ title: 'Self Attestation', tabLink: "attestation.selfattestation"},
			{ title: 'Attestation-Role Manager', tabLink: "attestation.rolemanager" },
            { title: 'Pending Attestation', tabLink: "attestation.pendingattestation"},
            { title: 'History Attestation', tabLink: "attestation.historyattestation"}
        ],
		selected = null,
        previous = null;
		$scope.attestationtabs = attestationtabs;
		$scope.selectedIndex = $state.current.data.selectedTab;
	}
/*
 * Cloudentix Core JavaScript Library v1.0
 * http://cloudentix.com/
 *
 * Copyright 2016, Sennovate, Inc.
 * Released under the MIT license
 * http://sennovate.com/license
 *
 * Author : Kannan
 * Last Updated On : 2016-08-04
 */
angular
    .module('cloudentixApp')
    /* add user has defined four controllers
        first controller for define inner tabs
        second controller for user information 
        and third for resource information
        and fourth for role information
    */
	.controller('editUserinfo', editUserInfo)
	.controller('editUserinformation', editUserInformation)
	.controller('editTrustedinformation', editTrustedInformation)
	.controller('editRoleinformation', editRoleInformation)
	.factory('selectTabService', function(scope) {
		scope.tabActive = '0';
		return {
			tabActive: function() { return tabActive; },
			setTabActive: function(x) { tabActive = x; }
		};
	})
    /* service method for maintaining input field values*/
    .service('keepeditInputfields', function() {
		this.storedata = {};
        this.userRoles = [];
        this.storerolesdata = [];
        this.storeTrusteddata = {};
        this.store = function(value) {
			this.storedata = value;
		}
		this.getdata = function() {
			return this.storedata;
		}
        /*
        this contructor functions used for store and get userResource values
        */
		this.storeTrusted = function(Trustedvalue) {
			this.storeTrusteddata = Trustedvalue;
		}
		this.getTrusteddata = function() {
			return this.storeTrusteddata;
		}
        /*
        this contructor functions used for store and get userRole values
        */
		this.storeRoles = function(roles) {
			this.storerolesdata[0] = roles;
		}
		this.getRolesdata = function() {
			return this.storerolesdata[0];
		}
        this.storeuserdata = function(trusted, roles, userroles) {
            this.usertrustedData = trusted;
            this.userRoles[0] = roles;
            this.userRoles[1] = userroles;
        }
        this.getuserTrusteddata = function() {
            return this.usertrustedData;
        }
        this.getuserroles = function() {
            return this.userRoles;
        }
	})
	.run(['$rootScope', '$state', '$stateParams', 
        function($rootScope, $state, $stateParams) {
            $rootScope.$state = $state;
            $rootScope.$stateParams = $stateParams;
        }
    ])
    /*
    stateProvider provides state transition
    it is imporatant for single page application
    */
    .config(
        ['$stateProvider', '$urlRouterProvider',
            function($stateProvider, $urlRouterProvider) {
                $urlRouterProvider
                $stateProvider
                .state('edituser.userinformation', {
                    url: '/userinformation',
                    onEnter: function() {
                        void 0;
                    },
                    controller: function($scope) {

                    },
                    templateUrl: 'users/cloudentix-admin-userinfo.html',
                    data: {
                      'selectedTab': 0
                    }
                })
                .state('edituser.trustedinformation', {
                    url: '/trustedinformation',
                    onEnter: function() {
                        void 0;
                    },
                    controller: function($scope) {

                    },
                    templateUrl: 'users/cloudentix-admin-trusted.html',
                    data: {
                      'selectedTab': 0
                    }
                })
				
                .state('edituser.role', {
                    url: '/role',
                    onEnter: function() {
                        void 0;
                    },
                    controller: function($scope) {

                    },
                    templateUrl: 'users/cloudentix-admin-role.html',
                    data: {
                      'selectedTab': 0
                    }
                });
            }
        ]
    );
    editUserInfo.$inject = ['$http', '$scope', '$log', '$state', '$rootScope', '$location', '$timeout', 'keepeditInputfields', 'SessionService'];
    editUserInformation.$inject = ['$timeout', '$window', '$http', '$scope', '$rootScope', '$log', '$state', 'keepeditInputfields', 'SessionService'];
    editTrustedInformation.$inject = ['$timeout', '$http', '$scope', '$log', '$rootScope', '$state', 'keepeditInputfields', '$location', 'SessionService'];
    editRoleInformation.$inject = ['$http', '$scope', '$log', '$rootScope', '$state', 'keepeditInputfields', '$location', 'SessionService'];
	var baseUrl = sessionStorage.getItem("WS_BASE_URL");
    function editUserInfo($http, $scope, $log, $state, $rootScope, $location, $timeout, keepeditInputfields, SessionService) {
        //base Url to check trusted and untrusted resource available or not
        keepeditInputfields.storedata = {}; 
        keepeditInputfields.storeTrusteddata = {};
        keepeditInputfields.storerolesdata = [];
		$scope.location= $location;
        var checkResourceURL = baseUrl + '/resources?check=true';
			var config = {
				url: checkResourceURL,
				method: "GET",
				headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
				}
			}
			$http(config)
			.success(function(response) {
                /*
                this condition is true if any of untrusted resource not configured 
                */
                if(response.type == 'success') {
                    if (response.data.login[0].trusted == 'N' || response.data.login[0].untrusted == 'N') {
                        if (response.data.login[0].trusted == 'N' && response.data.login[0].untrusted == 'N') {
                           $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure trusted and untrusted resources");
                        } else {
                            if (response.data.login[0].trusted == 'N') {
                                $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure the trusted resource");
                            } else if (response.data.login[0].untrusted === 'N') {
                                $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure an untrusted resource");
                            }
                        }
                    }
                //if two resources configured means it will process otherwise is goes to addresouce page
                    else if(response.data.login[0].trusted == 'Y' && response.data.login[0].untrusted == 'Y') {
                        // set inner tab title and tablink
                        var tabs = [
                            { title: 'User Information', tabLink: "edituser.userinformation",tabSerial:"1"},
                            { title: '', tabLink: "edituser.trustedinformation",tabSerial:"2"},
                            { title: 'Role', tabLink: "edituser.role",tabSerial:"3"}
                        ],
                        selected = null,
                        previous = null;
                        var listResourceURL = baseUrl + '/resources/list';
                        var config = {
                            url: listResourceURL,
                            method: "GET",
                            headers: {
                                "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                            }
                        }
                        $http(config).success(function(response) {          
                            angular.forEach(response.records[0].rscdetails, function(value, key) {
                                if (value["tarflag"] == 'Y') {
                                    sessionStorage.setItem("Trustedresourceid",value["rescid"]);
                                    $scope.resourceName = value["rescname"] + ' Information';
                                }
                            });
                            $scope.dynamicTitle();
                        });
                        $rootScope.editusertabs = tabs;
                        $scope.selectedIndex = 0;
                        $scope.selectTabService = 0;
                        $scope.dynamicTitle = function() {
                           $rootScope.editusertabs[1].title = $scope.resourceName;
                        }
                        $scope.$watch('selectedIndex', function(current, old) {
                            previous = selected;
                            selected = $rootScope.editusertabs[current];             
                        });
                        $scope.wizardActive = function(activePath) {
                            var activePath = activePath.replace('#','')
                            activePath = activePath.replace('.','/');
                            locationPath = $location.path();
                            locationPath = locationPath.replace('/','');
                            if(activePath === locationPath) {
                               return 'wizard-active';
                            } else {
                               return '';
                            }
                        }
                    }
                } else {
                    $scope.toastMessage('toast-error',response.data.message);
                }
			});
    }
    function editUserInformation($timeout, $window, $http, $scope, $rootScope, $log, $state, keepeditInputfields, SessionService) {
        $rootScope.loaderCurrentStatus = 'true';
        $rootScope.edituserMappedcolumn = [];
        var userstart = 0
        $scope.editusercount = function() {
            return userstart++;
        }
        //this scope object has to store user input values
        $scope.edituserinfoFields = [];
        $scope.selectTabService = 1;
        $scope.userguid = localStorage.getItem('userGuid');
        //get user's specific information
        var listfieldsURL = baseUrl + '/users/editlistfields';
        var config = {
            url: listfieldsURL,
            method: "GET",
            headers: {
                "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                "cdt-guid": $scope.userguid
            }
        }
		$http(config)
		.then(function success(response) {
            /*Every user has splitted into three types
            1. user's basic information it will show in userinformation tab
            2. user's resource information it will show in another tab
            3. user's role information
            */
            if(response.data.type == 'success') {
                $scope.edituserMappedcolumn = response.data.records[0].mappedcolumn;
                keepeditInputfields.storeuserdata(response.data.records[0].unmappedcolumn, response.data.records[0].role, response.data.records[0].rolevalue);
				$rootScope.userMultiselectRolecolumn = response.data.records[0].rolemultiselect;
				$rootScope.loadWidth = 33;
                $rootScope.loaderCurrentStatus = 'false';
            } else {
                $rootScope.loaderCurrentStatus = 'false';
                $scope.toastMessage('toast-error', response.data.message);
            }
			$timeout(function() {
				$scope.loadUserinfoService();
			}, 10);
		},function error(response){
            $rootScope.loaderCurrentStatus = 'false';
            $scope.errorHandler(response.config.url,response.status);
        });
        // service has implemented to get user values 
		$scope.loadUserinfoService = function() {
			$scope.putdata = keepeditInputfields.getdata();
			if(Object.keys($scope.putdata).length) {
                angular.forEach($scope.putdata, function(value, key){
                   $scope.edituserinfoFields[key] = value;		
                })
			}
            $rootScope.loadWidth = 33;
            //set progress bar width	
		}
        $scope.next = function(editusertabs, isValid) {
            if(isValid) {
                keepeditInputfields.store($scope.edituserinfoFields);
                $scope.selectedIndex = Math.min($scope.selectedIndex + 1, 2) ;
                //selectTabService.setTabActive($scope.selectedIndex);
                var nextTab = $scope.selectedIndex;	
                var gotoUrl =  $rootScope.editusertabs[nextTab].tabLink;
                $state.go(gotoUrl);
            }
        };
        $scope.previous = function(editusertabs) {
            $scope.selectedIndex = Math.max($scope.selectedIndex - 1, 0);
            //selectTabService.setTabActive($scope.selectedIndex);
            var prevTab = $scope.selectedIndex;
            var gotoUrl = $rootScope.editusertabs[prevTab].tabLink;
            $state.go(gotoUrl);
        }
        $scope.checkUserdata = function(oldData, newdata, index) {
            if(oldData == newdata) {
                $scope.edituserinfoFields[index].Usermodified = false;
            } else {
                $scope.edituserinfoFields[index].Usermodified = true;
            }
        }
    };
    function editTrustedInformation($timeout, $http, $scope, $log, $rootScope, $state, keepeditInputfields, $location, SessionService) {
        //set progress bar width
        $scope.edituserUnmappedcolumn = [];
        $rootScope.loadWidth = 66;
        //start loader
        $scope.selectTabService = 2;
        var userstart = 0
        $scope.editusercount = function() {
            return userstart++;
        }
        $rootScope.loaderCurrentStatus = 'true';
        var checkData = keepeditInputfields.getdata();
        if(!Object.keys(checkData).length) {
            $location.url('/edituser/userinformation');
        } else {
            $scope.edituserUnmappedcolumn = keepeditInputfields.getuserTrusteddata();
        }
        $scope.edituserTrustedFields = [];
        // calls service method to get values
        $scope.putdata = keepeditInputfields.getTrusteddata();
        $scope.loadTrustedinfoService = function() {
            if($scope.putdata != '' && $scope.putdata != undefined && $scope.putdata != null) {
                angular.forEach($scope.putdata, function(value, key){
                    $scope.edituserTrustedFields[key] = value;		
                })
            }
            $rootScope.loaderCurrentStatus = 'false';
        }
        $scope.next = function(editusertabs, isValid) {
			keepeditInputfields.storeTrusted($scope.edituserTrustedFields);
			$scope.selectedIndex = Math.min($scope.selectedIndex + 2, 3) ;
			//selectTabService.setTabActive($scope.selectedIndex);
			var nextTab = $scope.selectedIndex;	
			var gotoUrl =  $rootScope.editusertabs[nextTab].tabLink;
			$state.go(gotoUrl);
        };
        $scope.previous = function(editusertabs) {
            $scope.selectedIndex = Math.max($scope.selectedIndex - 1, 0);
            //selectTabService.setTabActive($scope.selectedIndex);
            var prevTab = $scope.selectedIndex;
            var gotoUrl = $rootScope.editusertabs[prevTab].tabLink;
            $state.go(gotoUrl);
        }; 
        $timeout(function() {
            $scope.loadTrustedinfoService();
        }, 1000);
        $scope.checkUserdata = function(oldData, newdata, index) {
            if(oldData == newdata) {
                $scope.edituserTrustedFields[index].Usermodified = false;
            } else {
                $scope.edituserTrustedFields[index].Usermodified = true;
            }
        }
    }
function editRoleInformation($http, $scope, $log, $rootScope, $state, keepeditInputfields, $location, SessionService) {
        //set progress bar width
        $rootScope.loadWidth = 100;
        $scope.selectTabService = 3;
        var roledata;
        $rootScope.loaderCurrentStatus = 'true';
        var checkData = keepeditInputfields.getdata();
        if(!Object.keys(checkData).length) {
            $location.url('/edituser/userinformation');
        } else {
            roledata = keepeditInputfields.getuserroles();
            $scope.edituserRolecolumn = roledata[0];
            if($rootScope.userMultiselectRolecolumn == 'N') {
				$scope.editsingleRole = roledata[1][0].value;
			} else {
				$scope.userRoles = [];
				angular.forEach(roledata[1], function(value, key) {
					$scope.userRoles[key] = value["value"];
				})
				$scope.editRoles = $scope.userRoles;
			}
        }
        $rootScope.loaderCurrentStatus = 'false';
        // calls service method to get form input values
        $scope.userInfodata = keepeditInputfields.getdata();
        $scope.userTrusteddata = keepeditInputfields.getTrusteddata();
        $scope.userroledata = keepeditInputfields.getRolesdata();
        if($scope.userroledata != undefined) {
		   if($rootScope.userMultiselectRolecolumn == 'N') {
				$scope.editsingleRole = $scope.userroledata;
			} else {
				$scope.editRoles = $scope.userroledata;
			}
        }
        $rootScope.loaderCurrentStatus = 'false';
        var userguid = localStorage.getItem('userGuid');
        var loginuserId = localStorage.getItem("userid");
        //finally get all the form values from service method then call add user API request
        $scope.next = function() {
            $scope.userValues = {"records": []};
            $scope.userroleValues = {"records": []};
            angular.forEach($scope.userInfodata, function(value, key) {
                if(value["Usermodified"] == true) {
                    $scope.userValues.records.push({"colname": value["Userlabel"], "colvalue": value["Uservalue"]});
                }
            }) 
            angular.forEach($scope.userTrusteddata, function(value, key) {
                if(value["Usermodified"] == true) {
                    $scope.userValues.records.push({"colname": value["Userlabel"], "colvalue": value["Uservalue"]});
                }
            })
            var roleModifiedFlag;
			if($rootScope.userMultiselectRolecolumn == 'N') {
				if(roledata[1][0].value != $scope.editsingleRole) {
					roleModifiedFlag = true;	
				}
			} else {
				if(roledata[1].length == $scope.editRoles.length) {
					angular.forEach(roledata[1], function(value, key) {
						data = $scope.editRoles.indexOf(value["value"]);
						if(data == -1) {
							roleModifiedFlag = true;
						}
					});
				} else {
					roleModifiedFlag = true;
				}
			}
            if($scope.userValues.records.length == 0 && roleModifiedFlag == undefined) {
                $scope.toastMessage('toast-warn', 'You have not modified any values');
            } else {
				if($rootScope.userMultiselectRolecolumn == 'N') {
					$scope.userroleValues.records.push({"roleid": $scope.editsingleRole});
				} else {
					for(var i=0;i < $scope.editRoles.length;i++) {
						if($scope.editRoles[i] != '') {
							$scope.userroleValues.records.push({"roleid": $scope.editRoles[i]});
						}
					}
				}
                var userinormation = JSON.stringify($scope.userValues);
                var userRoleinormation = JSON.stringify($scope.userroleValues);
                $rootScope.loaderCurrentStatus = 'true';
                var listURL = baseUrl + '/users/edit'
                var config = {
                    url: listURL,
                    method: "PUT",
                    headers: {
                        "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                        "cdt-loginguid": loginuserId,
                        "cdt-guid": userguid,
                        "cdt-valuejson": userinormation,
                        "cdt-rolejson": userRoleinormation
                    }
                }
                $http(config)
                .then(function success(response) {
                    $rootScope.loaderCurrentStatus = 'false';
                    if (response.data.type == "success") {
                        $scope.toastMessage('toast-success',response.data.message);
                        keepeditInputfields.storedata = {}; 
                        keepeditInputfields.storeTrusteddata = {};
                        keepeditInputfields.storerolesdata = [];
                        $state.go('users');
                        $scope.addTab('Users','users');
                    } else if (response.type == "error") {
                        $scope.toastMessage('toast-error',response.data.message);
                    } else if(response.type == "warning") {
                        $scope.toastMessage('toast-warn',response.data.message);
                    } else {
                        $scope.toastMessage('toast-error',response.data.message);
                    }
                },function error(response){
                    $rootScope.loaderCurrentStatus = 'false';
                    $scope.errorHandler(response.config.url,response.status);
                });
            }
        };
        $scope.previous = function(editusertabs) {
			if($rootScope.userMultiselectRolecolumn == 'N') {
				 keepeditInputfields.storeRoles($scope.editsingleRole);
			} else {
				 keepeditInputfields.storeRoles($scope.editRoles);
			}
            $scope.selectedIndex = Math.max($scope.selectedIndex - 1, 1);
            //selectTabService.setTabActive($scope.selectedIndex);
            var prevTab = $scope.selectedIndex;
            var gotoUrl = $rootScope.editusertabs[prevTab].tabLink;
            $state.go(gotoUrl);
        };
    }
	
angular
    .module('cloudentixApp')
    .service('loaderService', function() {
        this.loadData = function(x) {
            return x;
        }
    })
    /*.factory('loaderService', function(){
      var loadData = true;
      return {
    	loadData: function() { return loadData; },
    	newLoadedData: function(newLoadData) { loadData = newLoadData; }
      };
    })*/

    .config(function($mdThemingProvider) {
        $mdThemingProvider
        $mdThemingProvider
            .theme('default')
            .primaryPalette('indigo');
        /*.accentPalette('grey',{
		'default' : '700'
	})
    .warnPalette('red')*/
        //.backgroundPalette('blue-grey');
    })

    .controller('AppCtrl', AppCtrl)
    .run(
        ['$rootScope', '$state', '$stateParams', '$timeout', '$document', '$location','$window',
            function($rootScope, $state, $stateParams, $timeout, $document, $location, $window) {

                // $rootScope.$state = $state;
                // $rootScope.$stateParams = $stateParams;
                // $rootScope.validatesessionTimedout = 0;
                // void 0;
                
                // // Timeout timer value
                // var TimeOutTimerValue = 1000 * 60 * 60; // 60 minutes
                // // Start a timeout 
                // var TimeOut_Thread = $timeout(function() {
                //     LogoutByTimer()
                // }, TimeOutTimerValue);
                // var bodyElement = angular.element($document);

                // angular.forEach(['keydown', 'keyup', 'click', 'mousemove', 'DOMMouseScroll', 'mousewheel', 'mousedown', 'touchstart', 'touchmove', 'scroll', 'focus'],
                //     function(EventName) {
                //         bodyElement.bind(EventName, function(e) {
                //             TimeOut_Resetter(e)
                //         });

                //     });

                // function LogoutByTimer() {

                //     //if( $rootScope.loaderCurrentStatus = 'false'){
                //     if ($rootScope.loaderCurrentStatus == 'true') {
                //         bodyElement.bind('load', function(e) {
                //             TimeOut_Resetter(e)
                //         });

                //     } else {
                //         void 0;
                //         if ($rootScope.validatesessionTimedout == 0) {
                //             $rootScope.autologoutMessage("For security reasons and protection of your personal data, your session has ended. \nPlease login again.");
                //             //console.log('Logout');
                //         }
                //     }
                // }

                // function TimeOut_Resetter(e) {
                //     //console.log(' ' + e);

                //     //Stop the pending timeout
                //     $timeout.cancel(TimeOut_Thread);

                //     // Reset the timeout
                //     TimeOut_Thread = $timeout(function() {
                //         LogoutByTimer()
                //     }, TimeOutTimerValue);


                // }

                $rootScope.$on('$stateChangeStart', stateChangeListener);
                function stateChangeListener(event, toState, toParams, fromState, fromParams, options){
					var auth = JSON.parse(sessionStorage.getItem('cdt-user-authenticated')) || {};
					if(auth.isAuthenticatedUser){
						//$window.location.href = '../index.html';
						// Redirect to Login page OR logout method here...
                    }
                };

            }
        ]
    )
    .config(
        ['$ocLazyLoadProvider', '$stateProvider', '$urlRouterProvider', '$httpProvider',
            function($ocLazyLoadProvider, $stateProvider, $urlRouterProvider, $httpProvider) {

        
                //$locationProvider.html5Mode(true);
                $urlRouterProvider
                    .when('/', '/dashboard')
                    .otherwise('/dashboard');

                //Config For ocLazyLoading
                $ocLazyLoadProvider.config({
                    'debug': true, // For debugging 'true/false'
                    'events': true, // For Event 'true/false'
                    'modules': [{ // Set modules initially
                        name: 'attestation', // attestation module
                        files: ['attestation/admin.attestation.controllers.js']
                    }, {
                        name: 'dashboard', // dashboard module
                        files: ['dashboard/admin.dashboard.controllers.js']
                    }, {
                        name: 'job', // job module
                        files: ['job/admin.job.controllers.js']
                    }, {
                        name: 'manageSystem', // manageSystem module
                        files: ['manageSystem/admin.manageSystem.controllers.js']
                    }, {
                        name: 'myCloudentix', // myCloudentix module
                        files: ['myCloudentix/admin.myCloudentix.controllers.js']
                    }, {
                        name: 'reports', // reports module
                        files: ['reports/admin.reports.controllers.js']
                    }, {
                        name: 'resources', // resources module
                        files: ['resources/admin.resources.controllers.js']
                    }, {
                        name: 'role', // role module
                        files: ['role/admin.role.controllers.js']
                    }, {
                        name: 'users', // users module
                        files: ['users/admin.users.controllers.js']
                    }, {
						name: 'addataextractiontool', // SG - ADDataExtractionTool Module
						files: ['securityGovernor/dataMaintenance/ADDataExtractionTool/admin.sg.addataextractiontool.controller.js' ]
					}, {
						name: 'sgdashboard', // SG - dashboard Module
						files: ['securityGovernor/dataMaintenance/dashboard/admin.sg.dashboard.controller.js' ]
					}, {
						name: 'acc-duplicateEmployeeId', // SG - acc-duplicateEmployeeId Module
						files: ['securityGovernor/report/accountReport/acc-duplicateEmployeeId/admin.sg.acc-duplicateEmployeeId.controller.js' ]
					}, {
						name: 'acc-expiration', // SG - acc-expiration Module
						files: ['securityGovernor/report/accountReport/acc-expiration/admin.sg.acc-expiration.controller.js' ]
					}, {
						name: 'acc-expirationReport', // SG - acc-expirationReport Module
						files: ['securityGovernor/report/accountReport/acc-expirationReport/admin.sg.acc-expirationReport.controller.js' ]
					}, {
						name: 'acc-mapping', // SG - acc-mapping Module
						files: ['securityGovernor/report/accountReport/acc-mapping/admin.sg.acc-mapping.controller.js' ]
					}, {
						name: 'acc-multipleEmployeeIds', // SG - acc-multipleEmployeeIds Module
						files: ['securityGovernor/report/accountReport/acc-multipleEmployeeIds/admin.sg.acc-multipleEmployeeIds.controller.js' ]
					}, {
						name: 'acc-passwordNotification', // SG - acc-passwordNotification Module
						files: ['securityGovernor/report/accountReport/acc-passwordNotification/admin.sg.acc-passwordNotification.controller.js' ]
					}, {
						name: 'attestationReview', // SG - AttestationReview Module
						files: ['securityGovernor/report/AttestationReview/admin.sg.AttestationReview.controller.js' ]
					}, {
						name: 'active', // SG - DAActive Module
						files: ['securityGovernor/report/domainAdminReport/DAActive/admin.sg.DAActive.controller.js' ]
					}, {
						name: 'inactive', // SG - DAInactive Module
						files: ['securityGovernor/report/domainAdminReport/DAInactive/admin.sg.DAInactive.controller.js' ]
					}, {
						name: 'adgroupjob', // SG - ADGroupForJob Module
						files: ['securityGovernor/report/roleMining/ADGroupForJob/admin.sg.ad-job.controller.js' ]
					}, {
						name: 'bustaffjob', // SG - BUStaffForJob Module
						files: ['securityGovernor/report/roleMining/BUStaffForJob/admin.sg.bu-job.controller.js' ]
					}, {
						name: 'cvuegroupjob', // SG - CVueGroupForJob Module
						files: ['securityGovernor/report/roleMining/CVueGroupForJob/admin.sg.cv-job.controller.js' ]
					}, {
						name: 'jobtitlead', // SG - JobTitleForADGroup Module
						files: ['securityGovernor/report/roleMining/JobTitleForADGroup/admin.sg.jobtitlead.controller.js' ]
					}, {
						name: 'jobtitlecvue', // SG - JobTitleForCVueGroup Module
						files: ['securityGovernor/report/roleMining/JobTitleForCVueGroup/admin.sg.jobtitlecvue.controller.js' ]
					}, {
						name: 'rolemanager', // SG- RoleManager Module
						files: ['securityGovernor/roleManager/admin.sg.rolemanager.controller.js']
					}]
                });

                $stateProvider
                    .state('/', {
                        abstract: true,
                        url: '/dashboard',
                        templateUrl: 'dashboard/cloudentix-admin-dashboard.html',
                        reloadOnSearch: true,
                        controller: function($scope) {
                            $scope.$on('$stateChangeSuccess', function(event, toState, toParams, fromState, fromParams) {
                                $scope.currentTab = toState.data.selectedTab;

                            });
                        }
                    })

                    .state('dashboard', {
                        url: '/dashboard',
                        controller: function($scope) {

                        },
                        templateUrl: 'dashboard/cloudentix-admin-dashboard.html',
                        resolve: {
                          loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                            return $ocLazyLoad.load('dashboard'); // Resolve promise and load before view 
                          }]
                        }
                    })
                    .state('resources', {
                        url: '/resources',
                        //controller: 'ListresourceController',
                        templateUrl: 'resources/cloudentix-admin-listResource.html',
                        resolve: {
                            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                              return $ocLazyLoad.load('resources'); // Resolve promise and load before view 
                            }]
                          }
                    })
                    .state('users', {
                        url: '/users',
                        onEnter: function() {
                            void 0;
                        },
                        controller: function($scope) {

                        },
                        templateUrl: 'users/cloudentix-admin-users.html',
                        resolve: {
                            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                              return $ocLazyLoad.load('users'); // Resolve promise and load before view 
                            }]
                          }
                    })
                    .state('role', {
                        url: '/role',
                        controller: function($scope) {

                        },
                        templateUrl: 'role/cloudentix-admin-role.html',
                        resolve: {
                            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                              return $ocLazyLoad.load('role'); // Resolve promise and load before view 
                            }]
                          }
                    })
                    .state('attestation', {
                        url: '/attestation',
                        controller: function($scope) {

                        },
                        templateUrl: 'attestation/cloudentix-admin-attestation.html',
                        resolve: {
                          loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                            return $ocLazyLoad.load('attestation'); // Resolve promise and load before view 
                          }]
                        }
                    })
                    .state('myCloudentix', {
                        url: '/myCloudentix',
                        controller: function($scope) {

                        },
                        templateUrl: 'myCloudentix/cloudentix-admin-myCloudentix.html',
                        resolve: {
                            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                              return $ocLazyLoad.load('myCloudentix'); // Resolve promise and load before view 
                            }]
                          }
                    })
                    .state('reports', {
                        url: '/reports',
                        controller: function($scope) {

                        },
                        templateUrl: 'reports/cloudentix-admin-reports.html',
                        resolve: {
                            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                              return $ocLazyLoad.load('reports'); // Resolve promise and load before view 
                            }]
                          }
                    })
                    .state('manageSystem', {
                        url: '/manageSystem',
                        //controller: 'ListdataController',
                        templateUrl: 'manageSystem/cloudentix-admin-manageSystem.html',
                        resolve: {
                            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                              return $ocLazyLoad.load('manageSystem'); // Resolve promise and load before view 
                            }]
                          }
                    })
                    .state('job', {
                        url: '/job',
                        //controller: 'ListdataController',
                        templateUrl: 'job/cloudentix-admin-job.html',
                        resolve: {
                            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                              return $ocLazyLoad.load('job'); // Resolve promise and load before view 
                            }]
                          }
                    })
                    .state('jobView', {
                        url: '/jobView',
                        //controller: 'ViewResourceController',
                        templateUrl: 'job/cloudentix-admin-jobview.html',
                    })
                    .state('support', {
                        url: '/support',
                        controller: function($scope) {

                        },
                        templateUrl: 'support/cloudentix-admin-support.html'
					})
					.state('securityGovernor', {
                        url: '/securityGovernor',
						abstract: true,
                        template: '<ui-view></ui-view>'
					})
					.state('securityGovernor.dashboard', {
                        url: '/dashboard',
						templateUrl: 'securityGovernor/dataMaintenance/dashboard/cloudentix-admin-sg-dm-dashboard.html',
						resolve: {
                            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                              return $ocLazyLoad.load('sgdashboard'); // Resolve promise and load before view 
                            }]
                          }
					})
					.state('securityGovernor.addataextractiontool', {
                        url: '/addataextractiontool',
						templateUrl: 'securityGovernor/dataMaintenance/ADDataExtractionTool/cloudentix-admin-sg-dm-addataextractiontool.html',
						resolve: {
                            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                              return $ocLazyLoad.load('addataextractiontool'); // Resolve promise and load before view 
                            }]
                          }
                    })
                    .state('securityGovernor.adgroupjob', {
                        url: '/adgroupjob',
						templateUrl: 'securityGovernor/report/roleMining/ADGroupForJob/cloudentix-admin-sg-ad-job.html',
						resolve: {
                            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                              return $ocLazyLoad.load('adgroupjob'); // Resolve promise and load before view 
                            }]
                          }
					})
					.state('securityGovernor.bustaffjob', {
                        url: '/bustaffjob',
						templateUrl: 'securityGovernor/report/roleMining/BUStaffForJob/cloudentix-admin-sg-bu-job.html',
						resolve: {
                            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                              return $ocLazyLoad.load('bustaffjob'); // Resolve promise and load before view 
                            }]
                          }
					})
					.state('securityGovernor.cvuegroupjob', {
						url: '/cvuegroupjob',
						templateUrl: 'securityGovernor/report/roleMining/CVueGroupForJob/cloudentix-admin-sg-cv-job.html',
						resolve: {
						    loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
						      return $ocLazyLoad.load('cvuegroupjob'); // Resolve promise and load before view 
						    }]
						  }
					})
					.state('securityGovernor.jobtitlead', {
						url: '/jobtitlead',
						templateUrl: 'securityGovernor/report/roleMining/JobTitleForADGroup/cloudentix-admin-sg-jobtitlead.html',
						resolve: {
						    loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
						      return $ocLazyLoad.load('jobtitlead'); // Resolve promise and load before view 
						    }]
						  }
					})
					.state('securityGovernor.jobtitleadstafflist', {
						url: '/jobtitleadstafflist',
						templateUrl: 'securityGovernor/report/roleMining/JobTitleForADGroup/cloudentix-admin-sg-jobtitleadstafflist.html',
						// resolve: {
						//     loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
						//       return $ocLazyLoad.load('job'); // Resolve promise and load before view 
						//     }]
						//   }
					})
					.state('securityGovernor.jobtitlecvue', {
						url: '/jobtitlecvue',
						templateUrl: 'securityGovernor/report/roleMining/JobTitleForCVueGroup/cloudentix-admin-sg-jobtitlecvue.html',
						resolve: {
						    loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
						      return $ocLazyLoad.load('jobtitlecvue'); // Resolve promise and load before view 
						    }]
						  }
					})
					.state('securityGovernor.jobtitlecvuestafflist', {
						url: '/jobtitlecvuestafflist',
						templateUrl: 'securityGovernor/report/roleMining/JobTitleForCVueGroup/cloudentix-admin-sg-jobtitlecvuestafflist.html',
						// resolve: {
						//     loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
						//       return $ocLazyLoad.load('job'); // Resolve promise and load before view 
						//     }]
						//   }
					})
					.state('securityGovernor.attestationReview', {
                        url: '/attestationReview',
						templateUrl: 'securityGovernor/report/AttestationReview/cloudentix-admin-sg-attestationreview.html',
						resolve: {
                            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                              return $ocLazyLoad.load('attestationReview'); // Resolve promise and load before view 
                            }]
                          }
					})
					.state('securityGovernor.attestationschedule', {
						url: '/attestationschedule',
						templateUrl: 'securityGovernor/report/AttestationReview/cloudentix-admin-sg-schedule.html',
						// resolve: {
						//     loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
						//       return $ocLazyLoad.load('job'); // Resolve promise and load before view 
						//     }]
						//   }
					})
					.state('securityGovernor.active', {
						url: '/active',
						templateUrl: 'securityGovernor/report/domainAdminReport/DAActive/cloudentix-admin-sg-DAactive.html',
						resolve: {
						    loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
						      return $ocLazyLoad.load('active'); // Resolve promise and load before view 
						    }]
						  }
					})
					.state('securityGovernor.inactive', {
						url: '/inactive',
						templateUrl: 'securityGovernor/report/domainAdminReport/DAInactive/cloudentix-admin-sg-DAInactive.html',
						resolve: {
						    loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
						      return $ocLazyLoad.load('inactive'); // Resolve promise and load before view 
						    }]
						  }
					})
					.state('securityGovernor.acc-expirationreport', {
						url: '/acc-expirationreport',
						templateUrl: 'securityGovernor/report/accountReport/acc-expirationReport/cloudentix-admin-sg-acc-expirationreport.html',
						resolve: {
						    loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
						      return $ocLazyLoad.load('acc-expirationReport'); // Resolve promise and load before view 
						    }]
						  }
					})
					.state('securityGovernor.acc-duplicateemployeeid', {
						url: '/acc-duplicateemployeeid',
						templateUrl: 'securityGovernor/report/accountReport/acc-duplicateEmployeeId/cloudentix-admin-sg-acc-duplicateemployeeid.html',
						resolve: {
						    loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
						      return $ocLazyLoad.load('acc-duplicateEmployeeId'); // Resolve promise and load before view 
						    }]
						  }
					})
					.state('securityGovernor.acc-expiration', {
						url: '/acc-expiration',
						templateUrl: 'securityGovernor/report/accountReport/acc-expiration/cloudentix-admin-sg-acc-expiration.html',
						resolve: {
						    loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
						      return $ocLazyLoad.load('acc-expiration'); // Resolve promise and load before view 
						    }]
						  }
					})
					.state('securityGovernor.acc-mapping', {
						url: '/acc-mapping',
						templateUrl: 'securityGovernor/report/accountReport/acc-mapping/cloudentix-admin-sg-acc-mapping.html',
						resolve: {
						    loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
						      return $ocLazyLoad.load('acc-mapping'); // Resolve promise and load before view 
						    }]
						  }
					})
					.state('securityGovernor.acc-mappingsub1', {
						url: '/acc-mappingsub1',
						templateUrl: 'securityGovernor/report/accountReport/acc-mapping/cdt-admin-sg-acc-mappingsub1.html',
						// resolve: {
						//     loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
						//       return $ocLazyLoad.load('acc-mapping'); // Resolve promise and load before view 
						//     }]
						//   }
					})
					.state('securityGovernor.acc-mappingsub2', {
						url: '/acc-mappingsub2',
						templateUrl: 'securityGovernor/report/accountReport/acc-mapping/cdt-admin-sg-acc-mappingsub2.html',
						// resolve: {
						//     loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
						//       return $ocLazyLoad.load('acc-mapping'); // Resolve promise and load before view 
						//     }]
						//   }
					})
					.state('securityGovernor.acc-mappingsub3', {
						url: '/acc-mappingsub3',
						templateUrl: 'securityGovernor/report/accountReport/acc-mapping/cdt-admin-sg-acc-mappingsub3.html',
						// resolve: {
						//     loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
						//       return $ocLazyLoad.load('acc-mapping'); // Resolve promise and load before view 
						//     }]
						//   }
					})
					.state('securityGovernor.acc-mappingsub4', {
						url: '/acc-mappingsub4',
						templateUrl: 'securityGovernor/report/accountReport/acc-mapping/cdt-admin-sg-acc-mappingsub4.html',
						// resolve: {
						//     loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
						//       return $ocLazyLoad.load('acc-mapping'); // Resolve promise and load before view 
						//     }]
						//   }
					})
					.state('securityGovernor.acc-mappingsub5', {
						url: '/acc-mappingsub5',
						templateUrl: 'securityGovernor/report/accountReport/acc-mapping/cdt-admin-sg-acc-mappingsub5.html',
						// resolve: {
						//     loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
						//       return $ocLazyLoad.load('acc-mapping'); // Resolve promise and load before view 
						//     }]
						//   }
					})
					.state('securityGovernor.acc-mappingsub6', {
						url: '/acc-mappingsub6',
						templateUrl: 'securityGovernor/report/accountReport/acc-mapping/cdt-admin-sg-acc-mappingsub6.html',
						// resolve: {
						//     loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
						//       return $ocLazyLoad.load('acc-mapping'); // Resolve promise and load before view 
						//     }]
						//   }
					})
					.state('securityGovernor.acc-mappingsub7', {
						url: '/acc-mappingsub7',
						templateUrl: 'securityGovernor/report/accountReport/acc-mapping/cdt-admin-sg-acc-mappingsub7.html',
						// resolve: {
						//     loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
						//       return $ocLazyLoad.load('acc-mapping'); // Resolve promise and load before view 
						//     }]
						//   }
					})
					.state('securityGovernor.acc-mappingsub8', {
						url: '/acc-mappingsub8',
						templateUrl: 'securityGovernor/report/accountReport/acc-mapping/cdt-admin-sg-acc-mappingsub8.html',
						// resolve: {
						//     loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
						//       return $ocLazyLoad.load('acc-mapping'); // Resolve promise and load before view 
						//     }]
						//   }
					})
					.state('securityGovernor.acc-mappingsub9', {
						url: '/acc-mappingsub9',
						templateUrl: 'securityGovernor/report/accountReport/acc-mapping/cdt-admin-sg-acc-mappingsub9.html',
						resolve: {
						    loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
						      return $ocLazyLoad.load('acc-mapping'); // Resolve promise and load before view 
						    }]
						  }
					})
					.state('securityGovernor.acc-multipleemployeeids', {
						url: '/acc-multipleemployeeids',
						templateUrl: 'securityGovernor/report/accountReport/acc-multipleEmployeeIds/cloudentix-admin-sg-acc-multipleemployeeids.html',
						resolve: {
						    loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
						      return $ocLazyLoad.load('acc-multipleEmployeeIds'); // Resolve promise and load before view 
						    }]
						  }
					})
					.state('securityGovernor.acc-passwordnotification', {
						url: '/acc-passwordnotification',
						templateUrl: 'securityGovernor/report/accountReport/acc-passwordNotification/cloudentix-admin-sg-acc-passwordnotification.html',
						resolve: {
						    loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
						      return $ocLazyLoad.load('acc-passwordNotification'); // Resolve promise and load before view 
						    }]
						  }
					})
					.state('securityGovernor.rolemanager', {
						url: '/rolemanager',
						templateUrl: 'securityGovernor/roleManager/cloudentix-admin-sg-rolemanager.html',
						resolve: {
						    loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
						      return $ocLazyLoad.load('rolemanager'); // Resolve promise and load before view 
						    }]
						  }
					})
                    .state('changePassword', {
                        url: '/changePassword',
                        onEnter: function() {

                        },
                        controller: 'ChangePasswordCtrl',
                        controllerAs: 'changePasswordCtrl',
                        templateUrl: '../change-password.html'
                    })

                    .state('addresourcestype', {
                        url: '/addresourcestype',
                        //controller: 'ViewResourceController',
                        templateUrl: 'resources/addResource/cloudentix-admin-resources-mainResourcePage.html',
                    })
                    .state('MySqladdresources', {
                        url: '/MySqladdresources',
                        //controller: 'addrescourcemainctrl',
                        templateUrl: 'resources/addResource/mysql/cloudentix-admin-resources-addResource-mysql-steps.html',
                    })
                    .state('ADaddresources', {
                        url: '/ADaddresource',
                        templateUrl: 'resources/addResource/activedirectoryResource/cloudentix-admin-resources-addResource-AD-steps.html',
                    })
                    .state('MsSqladdresources', {
                        url: '/MsSqladdresources',
                        templateUrl: 'resources/addResource/mssql/cloudentix-admin-resources-addResource-mssql-steps.html',
                    })
                    .state('Oracleaddresources', {
                        url: '/Oracleaddresources',
                        templateUrl: 'resources/addResource/oracle/cloudentix-admin-resources-addResource-oracle-steps.html',
                    })
                    .state('Office365addresources', {
                        url: '/Office365addresource',
                        templateUrl: 'resources/addResource/office365Resource/cloudentix-admin-resources-addOffice365Resource-steps.html',
                    })
                    .state('viewResource', {
                        url: '/viewresource',
                        templateUrl: 'resources/cloudentix-admin-resource-viewResource.html',
                    })

                    .state('roleView', {
                        url: '/roleView',
                        //controller: 'ViewResourceController',
                        templateUrl: 'role/cloudentix-admin-roleview.html',
                    })

                    .state('adduser', {
                        url: '/adduser',
                        //controller: '',
                        templateUrl: 'users/cloudentix-admin-adduser.html',
                    })
                    .state('edituser', {
                        url: '/edituser',
                        templateUrl: 'users/cloudentix-admin-edituser.html',
                    })
                    .state('viewuser', {
                        url: '/viewuser',
                        //controller: '',
                        templateUrl: 'users/cloudentix-admin-viewuser.html'
                    })
                    .state('viewuserResource', {
                        url: '/viewuserResource',
                        //controller: 'ViewResourceController',
                        templateUrl: 'users/cloudentix-admin-viewuserResource.html'
                    })
                    .state('reportView', {
                        url: '/reportView',
                        //controller: '',
                        templateUrl: 'reports/cloudentix-admin-accessPolicy.html'
                    })
                    .state('datainconsistency', {
                        url: '/datainconsistency',
                        //controller: '',
                        templateUrl: 'reports/cloudentix-admin-datainConsistency.html'
                    })
                    /* For Dashboard Reports */
                    .state('accesspolicyviolationissue', {
                        url: '/accesspolicyviolationissue',
                        //controller: '',
                        templateUrl: 'dashboard/cloudentix-admin-accessPolicy.html'
                    })
                    .state('userprovisioningissue', {
                        url: '/userprovisioningissue',
                        //controller: '',
                        templateUrl: 'dashboard/cloudentix-admin-userprovisioningissue.html'
                    })
                    .state('accesspolicyevaluationissue', {
                        url: '/accesspolicyevaluationissue',
                        //controller: '',
                        templateUrl: 'dashboard/cloudentix-admin-accesspolicyevaluationissue.html'
                    })
                    .state('approvalpolicyevaluationissue', {
                        url: '/approvalpolicyevaluationissue',
                        //controller: '',
                        templateUrl: 'dashboard/cloudentix-admin-approvalpolicyevaluationissue.html'
                    })
                    .state('usernotProvisioned', {
                        url: '/usernotProvisioned',
                        //controller: '',
                        templateUrl: 'manageSystem/User_Provision/cloudentix-admin-userNotProvision.html'
                    })
                    .state('userProvisioned', {
                        url: '/userProvisioned',
                        //controller: '',
                        templateUrl: 'manageSystem/User_Provision/cloudentix-admin-userProvision.html'
                    });
                    
                    $httpProvider.interceptors.push("InterceptorService");

            }
        ]
    );

    AppCtrl.$inject = ['$scope', '$location', '$mdSidenav', '$mdDialog', '$state', '$mdToast', '$document', 'loaderService', '$rootScope', 'SessionService'];
function AppCtrl($scope, $location, $mdSidenav, $mdDialog, $state, $mdToast, $document, loaderService, $rootScope, SessionService) {
    // $scope.loaderService = loaderService;
    $rootScope.loginuser = '';
    $rootScope.loadStatus = loaderService.loadData(false);
    //console.log($location.hash);
    //alert($scope.loadStatus);
    //var username = sessionStorage.getItem("firstname");
    //this.username = username;
    var usertype = localStorage.getItem("usertype");
    if (usertype == 'Admin') {
        var username = "Administrator"
        this.username = username;
    } else {
        var username = localStorage.getItem("firstname");
        this.username = username;
    }


    $scope.toastMessage = function(type, msg) {
        var icon;
        if (type == 'toast-success') {
            icon = 'done';
        } else if (type == 'toast-error') {
            icon = 'error_outline';
        } else if (type == 'toast-warn') {
            icon = 'warning';
        } else {
            icon = 'info_outline';
        }
        $mdToast.show({
            template: '<md-toast class="md-toast ' + type + '"><div class="md-toast-content"><i class="material-icons">' + icon + '</i>&nbsp;&nbsp;' + msg + '</div></md-toast>',
            hideDelay: 3000,
            position: 'top right'
        });
    };

    $scope.showSimpleToast = function() {
        $mdToast.show({
            template: '<md-toast class="md-toast toast-info"><div class="md-toast-content"><i class="material-icons">verified_user</i>&nbsp;&nbsp;Welcome ' + username + '!</div></md-toast>',
            hideDelay: 3000,
            position: 'top right'
        });
    };



    $scope.showSimpleToast(this.click);
    //$scope.toastMessage('toast-error','Hi')	;
    var originatorEv;

    this.openMenu = function($mdOpenMenu, ev) {
        originatorEv = ev;
        $mdOpenMenu(ev);
    };

    originatorEv = null;

    $scope.toggleSidenav = function(menuId) {
        $mdSidenav(menuId).toggle();
    };

    $scope.sidebarActive = function(activePath, defaultPath) {
        activePath = activePath.replace('#', '');
        locationPath = $location.path();
        if (locationPath === defaultPath) {
            return 'sidebar-active';
        } else {
            locationPath = locationPath.replace('/', '');
            if (activePath === locationPath) {
                return 'sidebar-active';
            } else {
                return '';
            }
        }
    }

    var redirect = sessionStorage.getItem('url');
    if (redirect == null) {

        if (localStorage.getItem("selectedTab") == null) {
            if (sessionStorage.getItem('mailurl') != null) {
                var tabs = [];
                tabs.push({
                    title: "My Cloudentix",
                    tabLink: "myCloudentix.pendingapproval",
                    disabled: false
                });
            } else if (sessionStorage.getItem('mailurl') == null) {
                var tabs = [];
                tabs.push({
                    title: 'Dashboard',
                    tabLink: "dashboard",
                    disabled: false
                });
            }
        } else {
            if (localStorage.getItem("autologout") == "true") {
                var tabs = [];
                tabs.push({
                    title: 'Dashboard',
                    tabLink: "dashboard",
                    disabled: false
                });
            } else {
                var tabs = [];
                tabs.push(JSON.parse(localStorage.getItem("selectedTab")));
            }
        }
    } else {

        var tabs = [];
        tabs.push(JSON.parse(sessionStorage.getItem("TabDetails")));
    }
    var selected = null,
        previous = null;
    $rootScope.tabs = tabs;
    $scope.selectedIndex = 0;
    $scope.$watch('selectedIndex', function(current, old) {
        //console.log( $scope.selectedIndex);
        previous = selected;
        selected = tabs[current];
        $rootScope.selectedtab = tabs[current];
        localStorage.setItem('selectedTab', JSON.stringify($rootScope.selectedtab));
        /* if ( old + 1 && (old != current)) $log.debug('Goodbye ' + previous.title + '!');
         if ( current + 1 )                $log.debug('Hello ' + selected.title + '!');*/
    });
    $rootScope.addTab = function(title, view, userid, resId, typeId, resName) {
        //alert(userid)
        if (title == 'View Resources') {
            sessionStorage.setItem('trustedValue', userid);
            sessionStorage.setItem("resourceid", resId);
            sessionStorage.setItem("typeId", typeId);
            sessionStorage.setItem("resName", resName);
        }
        //console.log(title);
        if (userid != undefined && userid != '') {
            sessionStorage.setItem('userGuid', userid);
        }
        var tabLength = tabs.length;

        var tempTab = 0;
        for (var i = 0; i < tabLength; i++) {
            //console.log(tabs[i].title);
            if ((tabs[i].title == title) && (tabs[i].tabLink == view)) {
                tempTab = 1;

            }
        }

        if (tempTab == 0) {
            tabs.push({
                title: title,
                tabLink: view,
                disabled: false
            });

        } else {

            var tabIndex = tabs.findIndex(tabArray => tabArray.title == title);
            $scope.selectedIndex = tabIndex;
        }
        //$state.go(view);
    };
    $rootScope.removeTab = function(tab) {
        var index = tabs.indexOf(tab);
        var prevTab = index - 1;
        var nextTab = index + 1;
        if (index > 0) {
            var newUrl = tabs[prevTab].tabLink;
            $state.go(newUrl);
            $scope.selectedIndex = prevTab;
            tabs.splice(index, 1);
        } else {
            var newUrl = tabs[nextTab].tabLink;
            $state.go(newUrl);
            $scope.selectedIndex = index;
            tabs.splice(index, 1);
        }
    };
    $scope.resouceconfigureMessage = function(content) {
        $mdDialog.show({
            controller: resourceConfiguredModal,
            templateUrl: 'resouceConfigure/resouceConfiguremodal.html',
            parent: angular.element(document.body),
            clickOutsideToClose: false,
            locals: {
                items: content
            },
        })
    }
    $scope.errorHandler = function(urlvalue, status) {
        void 0
        if (status === 404) {
            $mdDialog.show({
                controller: errorHandleModel,
                templateUrl: 'resouceConfigure/404.html',
                parent: angular.element(document.body),
                clickOutsideToClose: true,
                locals: {
                    url: urlvalue
                },
            })
        }
        if (status === 500) {
            $mdDialog.show({
                controller: errorHandleModelISE,
                templateUrl: 'resouceConfigure/500.html',
                parent: angular.element(document.body),
                clickOutsideToClose: true,
                locals: {
                    url: urlvalue
                },
            })
        }
        if (status === 400) {
            $scope.toastMessage('toast-error', 'Invalid header param or missing header param');
        }
        if (status === 401) {
            $scope.toastMessage('toast-error', "User can't access the api without authentication");
        }
        if (status === undefined) {
            $scope.toastMessage('toast-error', urlvalue);
        }
    }
    $rootScope.autologoutMessage = function(content1) {
        $mdDialog.show({
            controller: autologout,
            templateUrl: 'logout.html',
            parent: angular.element(document.body),
            clickOutsideToClose: false,
            locals: {
                autologoutMsg: content1
            },
        })
    };
    //$route.reload();
}
autologout.$inject = ['$scope', '$state', '$mdDialog', '$rootScope', 'autologoutMsg', '$rootScope', '$http', '$window', '$location', 'SessionService'];
function autologout($scope, $state, $mdDialog, $rootScope, autologoutMsg, $rootScope, $http, $window, $location, SessionService) {

    $scope.autologoutMessage = autologoutMsg;
    $rootScope.validatesessionTimedout = 1;
    if (localStorage.getItem("username") != null) {
        $rootScope.loginuser = localStorage.getItem("username");
        $rootScope.reLoginPath = $location.url().replace('/', '');
    }
    //sessionStorage.clear();
    //localStorage.clear();


    // console.log($location.url())

    void 0;

    $scope.closelogout = function() {
        var logoutURL = baseUrl + "/logout";
        var config = {
            url: logoutURL,
            method: "GET",
            dataType: 'json',
            async: false,
            headers: {
                "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                "cdt-uname": $rootScope.loginuser
            }
        }

        $http(config).then(function success(response) {
            $mdDialog.hide();
            localStorage.setItem("autologout", "true");
            sessionStorage.setItem("url", $location.url().replace('/', ''));
            sessionStorage.setItem("TabDetails", JSON.stringify($rootScope.selectedtab));
            $window.location.href = '../index.html';
        }, function error(response) {});
    };
}
resourceConfiguredModal.$inject = ['$scope', '$state', '$mdDialog', '$rootScope', 'items', '$rootScope'];
function resourceConfiguredModal($scope, $state, $mdDialog, $rootScope, items, $rootScope) {

    $scope.resourceMessage = items;
    $scope.closeResourceMessage = function() {
        $mdDialog.hide();
        $state.go("addresourcestype");
        $rootScope.addTab('Add Resource', 'addresourcestype');
    };
}
errorHandleModel.$inject = ['$scope', '$state', '$mdDialog', '$rootScope', 'url', '$window'];
function errorHandleModel($scope, $state, $mdDialog, $rootScope, url, $window) {

    $scope.url = url;
    $scope.closeerrorMessage = function() {
        $mdDialog.hide();
        $window.location.href = '../index.html';
        //$state.go("addresourcestype");
        //$rootScope.addTab('Add Resource', 'addresourcestype'); 
    };
}
errorHandleModelISE.$inject = ['$scope', '$state', '$mdDialog', '$rootScope', 'url', '$window'];
function errorHandleModelISE($scope, $state, $mdDialog, $rootScope, url, $window) {

    $scope.url = url;
    $scope.closeerrorMessage = function() {
        $mdDialog.hide();
        $window.location.href = '../index.html';
        //$state.go("addresourcestype");
        //$rootScope.addTab('Add Resource', 'addresourcestype'); 
    };
    $scope.previoustab = function() {
        $mdDialog.hide();
    }
}
angular
	.module('cloudentixApp')
	.controller('loadImages',loadimage)
	.value("dbid",{name: ''});
	loadimage.$inject = ['$http','$scope','$rootScope', 'dbid', 'SessionService'];
	function loadimage($http,$scope,$rootScope, dbid, SessionService)
	{
		var checkResourceUrl = baseUrl +'/resources';
		var config = {
			url: checkResourceUrl,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
		}
		}
		$http(config)
		.then(function success(response) {
			var len = response.data.records.length;
			var sref= ['MySqladdresources.mysqladdrsc','MsSqladdresources.mssqladdrsc','Oracleaddresources.oracleaddrsc','ADaddresources.adaddrsc','Salesforceaddresources.salesforceaddrsc','Office365addresources.office365addrsc'];
			var tabname= ['MySql AddResource','MsSqlAddResource','OracleAddResource','Active Directory AddResource','Salesforce AddResource','Office365AddResource'];
			$scope.imageload = [];
			for(var count=0;count<len;count++)
			{
				if(response.data.records[count].display === "Y")
				{
					$scope.imageload.push({
					id : response.data.records[count].id,
					image : response.data.records[count].image,
					sref : sref[count],
					tabname : tabname[count]
					});
				}
			}

		},function error(response) {
			$rootScope.loaderCurrentStatus = 'false';
            $scope.errorHandler(response.config.url,response.status);
      });
	$scope.setimgattr = function(tabname, sref) {
		if(tabname.length > 10){
			tabname = (tabname.slice(0,10)+'...');
		}
	  $scope.addTab(tabname, sref);
	}
	
	}
angular
    .module('cloudentixApp')
	.controller('manageSystemcontrols', managesystemcontrols)
	.run(
        ['$rootScope', '$state', '$stateParams',
            function($rootScope, $state, $stateParams) {  
                $rootScope.$state = $state;
                $rootScope.$stateParams = $stateParams;
            }
        ]
    )
    .config(
        ['$stateProvider', '$urlRouterProvider',
            function($stateProvider, $urlRouterProvider) {
                $urlRouterProvider
                $stateProvider
                .state('manageSystem.userattributes', {
                    url: '/userattributes',
                    controller: function($scope) {
                    },
                    templateUrl: 'manageSystem/cloudentix-admin-managesystemAttributes.html',
                    data: {
                        'selectedTab': 0
                    }
                })
                .state('manageSystem.setfrequency', {
                    url: '/setfrequency',
                    controller: function($scope) {
                    },
                    templateUrl: 'manageSystem/cloudentix-admin-setFrequency.html',
                    data: {
                        'selectedTab': 1
                    }
                })
            }
        ]
    );
    managesystemcontrols.$inject = ['$scope', '$log', '$location', '$window', '$http', '$state'];
	function managesystemcontrols($scope, $log, $location, $window, $http, $state) {
		var manageSystemtabs = [
            { title: 'User Attributes', tabLink: "manageSystem.userattributes"},
            { title: 'Set Frequency', tabLink: "manageSystem.setfrequency"}
        ],
		selected = null,
        previous = null;
		$scope.manageSystemtabs = manageSystemtabs;
		$scope.selectedIndex = $state.current.data.selectedTab;
	}

angular
    .module('cloudentixApp')
	.controller('mycloudentixtab', mycloudentixtab)

	  .run(
      ['$rootScope', '$state', '$stateParams',
        function($rootScope, $state, $stateParams) {
                
          $rootScope.$state = $state;
          $rootScope.$stateParams = $stateParams;
        }
      ]
    )
    .config(
      ['$stateProvider', '$urlRouterProvider',
        function($stateProvider, $urlRouterProvider) {

          $urlRouterProvider
          $stateProvider

			
          .state('myCloudentix.pendingapproval', {
              url: '/pendingapproval',
             controller: function($scope) {

              },
              templateUrl: 'myCloudentix/sub-myCloudentix/cloudentix-admin-myCloudentix-pendingapproval.html',
              data: {
				  'selectedTab': 0
				}
            })
            .state('myCloudentix.accessrequests', {
              url: '/accessrequests',
              controller: function($scope) {

              },
              templateUrl: 'myCloudentix/sub-myCloudentix/cloudentix-admin-myCloudentix-requestaccess.html',
              data: {
				  'selectedTab': 1
				}
            })
       
		}
      ]
    );
    mycloudentixtab.$inject = ['$scope', '$log', '$location', '$window', '$http', '$state'];
		function mycloudentixtab($scope, $log, $location, $window, $http, $state) {
			var cloudentixtabs = [
          { title: 'Pending Approval', tabLink: "myCloudentix.pendingapproval"},
		  { title: 'List of Access Requests', tabLink: "myCloudentix.accessrequests"}
        ],
		 selected = null,
        previous = null;
		$scope.cloudentixtabs = cloudentixtabs;
		$scope.selectedIndex = $state.current.data.selectedTab;
		//$scope.selectedIndex = 0;
		/* $scope.attestationtabs = [];
		 attestationtabs.push (
          { title: 'Self Attestion', tabLink: "attestation.selfattestion"},
		  { title: 'Pending Attestation', tabLink: "attestation.pendingattestation"},
		  { title: 'History Attestation', tabLink: "attestation.historyattestation"}
        );
		console.log(attestationtabs);
		//$scope.attestationtabs = attestationtabs;*/
	}

angular
    .module('cloudentixApp')
	.controller('roleviewtab', roleviewtab)

	  .run(
      ['$rootScope', '$state', '$stateParams',
        function($rootScope, $state, $stateParams) {
                
          $rootScope.$state = $state;
          $rootScope.$stateParams = $stateParams;
        }
      ]
    )
    .config(
      ['$stateProvider', '$urlRouterProvider',
        function($stateProvider, $urlRouterProvider) {

          $urlRouterProvider
          $stateProvider

			
          .state('roleView.accesspolicy', {
              url: '/accesspolicy',
             controller: function($scope) {

              },
              templateUrl: 'role/sub-role/cloudentix-admin-role-accesspolicy.html',
              data: {
				  'selectedTab': 0
				}
            })
            .state('roleView.approvalpolicy', {
              url: '/approvalpolicy',
              controller: function($scope) {

              },
              templateUrl: 'role/sub-role/cloudentix-admin-role-approvalpolicy.html',
              data: {
				  'selectedTab': 1
				}
            })
       
		}
      ]
    );
    roleviewtab.$inject = ['$scope', '$log', '$location', '$window', '$http', '$state'];
		function roleviewtab($scope, $log, $location, $window, $http, $state) {
        
        var resourcetype = localStorage.getItem("RescType");
        if(resourcetype == 'Y'){
        var roletabs = [
          //{ title: 'Access Policy', tabLink: "roleView.accesspolicy"},
		  { title: 'Approval Policy', tabLink: "roleView.approvalpolicy"}
        ],selected = null,
        previous = null;
		$scope.roletabs = roletabs;
		$scope.selectedIndex = $state.current.data.selectedTab;;
		var rolename = localStorage.getItem("roleValue");

$scope.rolename = rolename;
        }else{
			 var roletabs = [
          { title: 'Access Policy', tabLink: "roleView.accesspolicy"},
		  { title: 'Approval Policy', tabLink: "roleView.approvalpolicy"}
        ]
        //$scope.roletabs.push({ title: 'Access Policy', tabLink: "roleView.accesspolicy"})
        selected = null,
        previous = null;
		$scope.roletabs = roletabs;
		$scope.selectedIndex = $state.current.data.selectedTab;;
		var rolename = localStorage.getItem("roleValue");
		var resourcename = localStorage.getItem("RescName");

$scope.rolename = rolename;
$scope.resourcename = resourcename;
        }
		 
		/* $scope.attestationtabs = [];
		 attestationtabs.push (
          { title: 'Self Attestion', tabLink: "attestation.selfattestion"},
		  { title: 'Pending Attestation', tabLink: "attestation.pendingattestation"},
		  { title: 'History Attestation', tabLink: "attestation.historyattestation"}
        );
		console.log(attestationtabs);
		//$scope.attestationtabs = attestationtabs;*/
	}
/*
 * Cloudentix Core JavaScript Library v1.0
 * http://cloudentix.com/
 *
 * Copyright 2016, Sennovate, Inc.
 * Released under the MIT license
 * http://sennovate.com/license
 *
 * Author : Kannan
 * Last Updated On : 2016-08-04
 */
angular
    .module('cloudentixApp')
    /* add user has defined four controllers
        first controller for define inner tabs
        second controller for user information 
        and third for resource information
        and fourth for role information
    */
	.controller('addAduser', addaduser)
	.controller('adUserinformation', adUserInformation)
	.controller('adTrustedinformation', adTrustedInformation)
	.controller('adRoleinformation', adRoleInformation)
	.factory('selectTabService', function() {
		var tabActive = '0';
		return {
			tabActive: function() { return tabActive; },
			setTabActive: function(x) { tabActive = x; }
		};
	})
    /* service method for maintaining input field values*/
    .service('keepInputfields', function() {
        // this is used for store userInformation input field values
		this.storedata = {};
        // this is used for store resourceInformation input field values
		this.storeTrusteddata = {};
        // this is used for store userRole input field values
		this.storerolesdata = { listroles: [] };
        /*
        this contructor functions used for store and get userInformation values
        */
		this.store = function(key, value) {
			this.storedata[key] = value;
		}
		this.getdata = function() {
			this.getdata1 = this.storedata;
			return this.getdata1;
		}
        /*
        this contructor functions used for store and get userResource values
        */
		this.storeTrusted = function(key, value) {
			this.storeTrusteddata[key] = value;
		}
		this.getTrusteddata = function() {
			this.gettrustedData = this.storeTrusteddata;
			return this.gettrustedData;
		}
        /*
        this contructor functions used for store and get userRole values
        */
		this.storeRoles = function(roles) {
			this.storerolesdata.listroles[0] = roles;
		}
		this.getRolesdata = function() {
			this.getrolesData = this.storerolesdata.listroles[0];
			return this.getrolesData;
		}
	})
	.run(['$rootScope', '$state', '$stateParams', 
        function($rootScope, $state, $stateParams) {
            $rootScope.$state = $state;
            $rootScope.$stateParams = $stateParams;
        }
    ])
    /*
    stateProvider provides state transition
    it is imporatant for single page application
    */
    .config(
        ['$stateProvider', '$urlRouterProvider',
            function($stateProvider, $urlRouterProvider) {
                $urlRouterProvider
                $stateProvider
                .state('adduser.userinformation', {
                    url: '/userinformation',
                    onEnter: function() {
                        void 0;
                    },
                    controller: function($scope) {

                    },
                    templateUrl: 'users/cloudentix-admin-userinfo.html',
                    data: {
                      'selectedTab': 0
                    }
                })
                .state('adduser.trustedinformation', {
                    url: '/trustedinformation',
                    onEnter: function() {
                        void 0;
                    },
                    controller: function($scope) {

                    },
                    templateUrl: 'users/cloudentix-admin-trusted.html',
                    data: {
                      'selectedTab': 0
                    }
                })
                .state('adduser.role', {
                    url: '/role',
                    onEnter: function() {
                        void 0;
                    },
                    controller: function($scope) {

                    },
                    templateUrl: 'users/cloudentix-admin-role.html',
                    data: {
                      'selectedTab': 0
                    }
                });
            }
        ]
    );
    addaduser.$inject = ['$http', '$scope', '$log', '$state', '$rootScope', '$location', '$timeout', 'SessionService'];
    adUserInformation.$inject = ['$timeout', '$window', '$http', '$scope', '$rootScope', '$log', '$state', 'keepInputfields', 'SessionService'];
    adTrustedInformation.$inject = ['$timeout', '$http', '$scope', '$log', '$rootScope', '$state', 'keepInputfields', '$location', 'SessionService'];
    adRoleInformation.$inject = ['$http', '$scope', '$log', '$rootScope', '$state', 'keepInputfields', '$location', 'SessionService'];
	var baseUrl = sessionStorage.getItem("WS_BASE_URL");
    function addaduser($http, $scope, $log, $state, $rootScope, $location, $timeout, SessionService) {
        //base Url to check trusted and untrusted resource available or not
        $scope.location= $location;
        var checkResourceURL = baseUrl + '/resources?check=true';
			var config = {
				url: checkResourceURL,
				method: "GET",
				headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
				}
			}
			$http(config)
			.success(function(response) {
                /*
                this condition is true if any of untrusted resource not configured 
                */
                if(response.type == 'success') {
                    if (response.data.login[0].trusted == 'N' || response.data.login[0].untrusted == 'N') {
                        if (response.data.login[0].trusted == 'N' && response.data.login[0].untrusted == 'N') {
                           $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure trusted and untrusted resources");
                        } else {
                            if (response.data.login[0].trusted == 'N') {
                                $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure the trusted resource");
                            } else if (response.data.login[0].untrusted === 'N') {
                                $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure an untrusted resource");
                            }
                        }
                    }
                //if two resources configured means it will process otherwise is goes to addresouce page
                    else if(response.data.login[0].trusted == 'Y' && response.data.login[0].untrusted == 'Y') {
                        // set inner tab title and tablink
                        var tabs = [
                            { title: 'User Information', tabLink: "adduser.userinformation",tabSerial:"1"},
                            { title: '', tabLink: "adduser.trustedinformation",tabSerial:"2"},
                            { title: 'Role', tabLink: "adduser.role",tabSerial:"3"}
                        ],
                        selected = null,
                        previous = null;
                        var listResourceURL = baseUrl + '/resources/list';
                        var config = {
                            url: listResourceURL,
                            method: "GET",
                            headers: {
                                "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                            }
                        }
                        $http(config).success(function(response) {        
                            angular.forEach(response.records[0].rscdetails, function(value, key) {
                                if (value["tarflag"] == 'Y') {
                                    sessionStorage.setItem("Trustedresourceid",value["rescid"]);
                                    $scope.resourceName = value["rescname"] + ' Information';
                                }
                            });
                            $scope.dynamicTitle();
                        });
                        $rootScope.usertabs = tabs;
                        $scope.selectedIndex = 0;
                        $scope.selectTabService = 0;
                        $scope.$watch('selectedIndex', function(current, old) {
                            previous = selected;
                            selected = $rootScope.usertabs[current];             
                        });
                        $scope.dynamicTitle = function() {
                            $rootScope.usertabs[1].title = $scope.resourceName;
                        }
                        $scope.wizardActive = function(activePath) {
                            var activePath = activePath.replace('#','')
                            activePath = activePath.replace('.','/');
                            locationPath = $location.path();
                            locationPath = locationPath.replace('/','');
                            if(activePath === locationPath) {
                               return 'wizard-active';
                            } else {
                               return '';
                            }
                        }
                    } 
                } else {
                    $scope.toastMessage('toast-error',response.data.message);
                }
			});
    }
    function adUserInformation($timeout, $window, $http, $scope, $rootScope, $log, $state, keepInputfields, SessionService) {
        
        //this scope object has to store user input values
        $scope.userinfoFields = {};
        //get user's specific information
        $scope.selectTabService = 1;
        
        var listfieldsURL = baseUrl + '/users/listfields'
        
        var config = {
            url: listfieldsURL,
            method: "GET",
            headers: {
                "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
            }
        }
        $rootScope.loaderCurrentStatus = 'true';
		$http(config)
		.then(function success(response) {
            /*Every user has splitted into three types
            1. user's basic information it will show in userinformation tab
            2. user's resource information it will show in another tab
            3. user's role information
            */
            if(response.data.type == 'success') {
                $rootScope.userMappedcolumn = response.data.records[0].mappedcolumn;
                $rootScope.userUnmappedcolumn = response.data.records[0].unmappedcolumn;
                $rootScope.userRolecolumn = response.data.records[0].role;
				$rootScope.userMultiselectRolecolumn = response.data.records[0].rolemultiselect;
                $timeout(function() {
                    $scope.loadUserinfoService();
                }, 10);
            } else {
                $rootScope.loaderCurrentStatus = 'false';
                $scope.toastMessage('toast-error', response.data.message);
            }
		},function error(response){
            $rootScope.loaderCurrentStatus = 'false';
            $scope.errorHandler(response.config.url,response.status);
        });
        // service has implemented to get form input values 
		$scope.loadUserinfoService = function() {
			$scope.putdata = keepInputfields.getdata();
			if($scope.putdata != '' && $scope.putdata != undefined && $scope.putdata != null) {
				angular.forEach($scope.putdata, function(value, key){
						$scope.userinfoFields[key] = value;	
				})
			}
            //set progress bar width
			$rootScope.loadWidth = 33;
			$rootScope.loaderCurrentStatus = 'false';
		}
        $scope.next = function(usertabs, isValid) {
            if(isValid) {
                angular.forEach($scope.userinfoFields, function(value, key){
                    if(value == 'None') {
                        value = '';
                    }
                    //service method used to store form input values when user click submit the form
                    keepInputfields.store(key, value);
                });
                $scope.selectedIndex = Math.min($scope.selectedIndex + 1, 2) ;
                //selectTabService.setTabActive($scope.selectedIndex);
                var nextTab = $scope.selectedIndex;	
                var gotoUrl =  $rootScope.usertabs[nextTab].tabLink;
                $state.go(gotoUrl);
            }
        };
        $scope.previous = function(usertabs) {
            $scope.selectedIndex = Math.max($scope.selectedIndex - 1, 0);
            //selectTabService.setTabActive($scope.selectedIndex);
            var prevTab = $scope.selectedIndex;
            var gotoUrl = $rootScope.usertabs[prevTab].tabLink;
            $state.go(gotoUrl);
        };
    };
    function adTrustedInformation($timeout, $http, $scope, $log, $rootScope, $state, keepInputfields, $location, SessionService) {
        //set progress bar width
        $rootScope.loadWidth = 66;
        $scope.user = {};
        $scope.selectTabService = 2;
        // calls service method to get values
        $rootScope.loaderCurrentStatus = 'true';
        $scope.loadTrustedinfoService = function() {
            if($scope.putdata != '' && $scope.putdata != undefined && $scope.putdata != null) {
                angular.forEach($scope.putdata, function(value, key){
                        $scope.user[key] = value;		
                })
            }
           $rootScope.loaderCurrentStatus = 'false';
        }
        $scope.next = function(usertabs, isValid) {
			angular.forEach($scope.user, function(value, key) {
                // store form input values in service 
				keepInputfields.storeTrusted(key, value);
			});
			$scope.selectedIndex = Math.min($scope.selectedIndex + 2, 3) ;
			//selectTabService.setTabActive($scope.selectedIndex);
			var nextTab = $scope.selectedIndex;	
			var gotoUrl =  $rootScope.usertabs[nextTab].tabLink;
			$state.go(gotoUrl);
        };
        $scope.previous = function(usertabs) {
            $scope.selectedIndex = Math.max($scope.selectedIndex - 1, 0);
            //selectTabService.setTabActive($scope.selectedIndex);
            var prevTab = $scope.selectedIndex;
            var gotoUrl = $rootScope.usertabs[prevTab].tabLink;
            $state.go(gotoUrl);
        }; 
        $scope.putdata = keepInputfields.getTrusteddata();
        var checkData = keepInputfields.getdata();
        if(!Object.keys(checkData).length) {
            $state.go('adduser.userinformation');
        } else {
            $timeout(function() {
                $scope.loadTrustedinfoService();
            }, 1000);
        }
    }
    function adRoleInformation($http, $scope, $log, $rootScope, $state, keepInputfields, $location, SessionService) {
        //set progress bar width
        $rootScope.loadWidth = 100;
        $rootScope.loaderCurrentStatus = 'true';
        var checkData = keepInputfields.getdata();
        if(!Object.keys(checkData).length) {
            $location.url('/adduser/userinformation');
        }
        // calls service method to get form input values
        $scope.selectTabService = 3;
        $scope.userInfodata = keepInputfields.getdata();
        $scope.userTrusteddata = keepInputfields.getTrusteddata();
        $scope.userroledata = keepInputfields.getRolesdata();
        if($scope.userroledata != '' && $scope.userroledata != undefined && $scope.userroledata != null) {
            if($rootScope.userMultiselectRolecolumn == 'Y') {
				$scope.Roles = $scope.userroledata;
			} else {
				$scope.singleRole = $scope.userroledata;
			}
        }
        $rootScope.loaderCurrentStatus = 'false';
        var trustedResourceID = sessionStorage.getItem("Trustedresourceid");
        //finally get all the form values from service method then call add user API request
        $scope.next = function() {
            $scope.userValues = {"records": []};
            $scope.userroleValues = {"records": []};
            angular.forEach($scope.userInfodata, function(value, key) {
                $scope.userValues.records.push({"colname": key, "colvalue": value});
            })	
            angular.forEach($scope.userTrusteddata, function(value, key) {
                $scope.userValues.records.push({"colname": key, "colvalue": value});
            })
			if($rootScope.userMultiselectRolecolumn == 'Y') {
				for(var i=0;i < $scope.Roles.length;i++) {
					$scope.userroleValues.records.push({"roleid": $scope.Roles[i]});
				}
			} else {
				$scope.userroleValues.records.push({"roleid": $scope.singleRole});
			}
            var userinormation = JSON.stringify($scope.userValues);
            var userRoleinormation = JSON.stringify($scope.userroleValues);
            $rootScope.loaderCurrentStatus = 'true';
            var listURL = baseUrl + '/users';
            var userid = localStorage.getItem("userid");
            var config = {
                url: listURL,
                method: "POST",
                headers: {
                    "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                    "cdt-rscid": trustedResourceID,
                    "cdt-valuejson": userinormation,
                    "cdt-rolejson": userRoleinormation,
                    "cdt-loginguid" : userid
                }
            }
            $http(config)
            .then(function success(response) {
                $rootScope.loaderCurrentStatus = 'false';
                if (response.data.type == "success") {
                    $scope.toastMessage('toast-success',response.data.message);
                    keepInputfields.storedata = {}; 
                    keepInputfields.storeTrusteddata = {};
                    keepInputfields.storerolesdata.listroles = [];
                    $state.go('users');
                    $scope.addTab('Users','users');
                } else if (response.data.type == "error") {
                    $scope.toastMessage('toast-error',response.data.message);
                } else if(response.data.type == "warning") {
                    $scope.toastMessage('toast-warn',response.data.message);
                } else {
                    $scope.toastMessage('toast-error',response.data.message);
                }
            },function error(response){
                $rootScope.loaderCurrentStatus = 'false';
                $scope.errorHandler(response.config.url,response.status);
            });
        };
        $scope.previous = function(usertabs) {
			if($rootScope.userMultiselectRolecolumn == 'Y') {
				keepInputfields.storeRoles($scope.Roles);
			} else {
				keepInputfields.storeRoles($scope.singleRole);
			}
            $scope.selectedIndex = Math.max($scope.selectedIndex - 1, 1);
            //selectTabService.setTabActive($scope.selectedIndex);
            var prevTab = $scope.selectedIndex;
            var gotoUrl = $rootScope.usertabs[prevTab].tabLink;
            $state.go(gotoUrl);
        };  
    }

angular
    .module('cloudentixApp')
	.controller('viewResourceController', viewResourceCtrl)

	  .run(
      ['$rootScope', '$state', '$stateParams',
        function($rootScope, $state, $stateParams) {
                
          $rootScope.$state = $state;
          $rootScope.$stateParams = $stateParams;
        }
      ]
    )
    .config(
      ['$stateProvider', '$urlRouterProvider',
        function($stateProvider, $urlRouterProvider) {

          $urlRouterProvider
          $stateProvider

			
          .state('viewResource.prepopulate', {
              url: '/viewResource/Prepopulate',
             controller: function($scope) {

              },
              templateUrl: 'resources/viewResource/prepopulate/cloudentix-admin-viewResourcePrepopulate.html',
              data: {
				  'selectedTab': 0
				}
            })
            .state('viewResource.role', {
              url: '/viewResource/Roles',
             controller: function($scope) {

              },
              templateUrl: 'resources/viewResource/cloudentix-admin-viewResourceRoles.html',
              data: {
				  'selectedTab': 0
				}
            }) 
            .state('viewResource.lookup', {
              url: '/viewResource/lookup',
             controller: function($scope) {

              },
              templateUrl: 'resources/viewResource/cloudentix-admin-viewResourceLookup.html',
              data: {
				  'selectedTab': 0
				}
            })
            .state('viewResource.users', {
              url: '/viewResource/Users',
             controller: function($scope) {

              },
              templateUrl: 'resources/viewResource/cloudentix-admin-viewResourceUsers.html',
              data: {
				  'selectedTab': 0
				}
            })
            .state('viewResource.reconciliation', {
              url: '/viewResource/reconciliation',
             controller: function($scope) {

              },
              templateUrl: 'resources/viewResource/cloudentix-admin-viewResourcerecon.html',
              data: {
				  'selectedTab': 0
				}
            })
            .state('viewResource.setup', {
              url: '/viewResource/setup',
             controller: function($scope) {

              },
              templateUrl: 'resources/viewResource/cloudentix-admin-viewResourceSetup.html',
              data: {
				  'selectedTab': 0
				}
            })
            
       
		}
      ]
    );
    viewResourceCtrl.$inject = ['$scope', '$log', '$location', '$window', '$http', '$state'];
		function viewResourceCtrl($scope, $log, $location, $window, $http, $state) {
			var viewResourceTabs = [
          { title: 'Roles', tabLink: "viewResource.role"},
          { title: 'Lookup', tabLink: "viewResource.lookup"},
          { title: 'Users', tabLink: "viewResource.users"},
          { title: 'Reconciliation', tabLink: "viewResource.reconciliation"},
          { title: 'Setup', tabLink: "viewResource.setup"},
		  
        ],
		 selected = null,
        previous = null;
		$scope.viewResourceTabs = viewResourceTabs;
		$scope.selectedIndex = 0;
		
        var resourceDetails = JSON.parse(localStorage.getItem("ResourceDetails"));
        //console.log(a.resourcename);
        $scope.resourcename = resourceDetails.resourcename;
		if(resourceDetails.trustedtype === 'N'){
        viewResourceTabs.splice(0,0,{ title: 'Prepopulate', tabLink: "viewResource.prepopulate"});
			$state.go('viewResource.prepopulate');
		}
        else{
            $state.go('viewResource.role');
        }
	}
angular
    .module('cloudentixApp')
	.controller('viewUsercontrols', viewusercontrols)
	.run(
        ['$rootScope', '$state', '$stateParams',
            function($rootScope, $state, $stateParams) {  
                $rootScope.$state = $state;
                $rootScope.$stateParams = $stateParams;
            }
        ]
    )
    .config(
        ['$stateProvider', '$urlRouterProvider',
            function($stateProvider, $urlRouterProvider) {
                $urlRouterProvider
                $stateProvider
                .state('viewuser.userbasicinformation', {
                    url: '/userbasicinformation',
                    controller: function($scope) {
                    },
                    templateUrl: 'users/cloudentix-admin-userinformatiom.html',
                    data: {
                        'selectedTab': 0
                    }
                })
                .state('viewuser.role', {
                    url: '/role',
                    controller: function($scope) {
                    },
                    templateUrl: 'users/cloudentix-admin-userrole.html',
                    data: {
                        'selectedTab': 1
                    }
                })
                .state('viewuser.resource', {
                    url: '/resource',
                    controller: function($scope) {
                    },
                    templateUrl: 'users/cloudentix-admin-userresource.html',
                    data: {
                        'selectedTab': 2
                    }
                });
            }
        ]
    );
    viewusercontrols.$inject = ['$scope', '$log', '$location', '$window', '$http', '$state'];
	function viewusercontrols($scope, $log, $location, $window, $http, $state) {
		var viewusertabs = [
            { title: 'User Information', tabLink: "viewuser.userbasicinformation"},
            { title: 'Role', tabLink: "viewuser.role"},
            { title: 'Resource', tabLink: "viewuser.resource"}
        ],
		selected = null,
        previous = null;
		$scope.viewusertabs = viewusertabs;
        $scope.selectedTabs = {};
		$scope.selectedTabs.selectedIndex = $state.current.data.selectedTab;
	}