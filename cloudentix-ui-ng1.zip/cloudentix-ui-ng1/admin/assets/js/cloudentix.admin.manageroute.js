angular
    .module('cloudentixApp')
	.controller('manageSystemcontrols', managesystemcontrols)
	.run(
        ['$rootScope', '$state', '$stateParams',
            function($rootScope, $state, $stateParams) {  
                $rootScope.$state = $state;
                $rootScope.$stateParams = $stateParams;
            }
        ]
    )
    .config(
        ['$stateProvider', '$urlRouterProvider',
            function($stateProvider, $urlRouterProvider) {
                $urlRouterProvider
                $stateProvider
                .state('manageSystem.userattributes', {
                    url: '/userattributes',
                    controller: function($scope) {
                    },
                    templateUrl: 'manageSystem/cloudentix-admin-managesystemAttributes.html',
                    data: {
                        'selectedTab': 0
                    }
                })
                .state('manageSystem.setfrequency', {
                    url: '/setfrequency',
                    controller: function($scope) {
                    },
                    templateUrl: 'manageSystem/cloudentix-admin-setFrequency.html',
                    data: {
                        'selectedTab': 1
                    }
                })
            }
        ]
    );
    managesystemcontrols.$inject = ['$scope', '$log', '$location', '$window', '$http', '$state'];
	function managesystemcontrols($scope, $log, $location, $window, $http, $state) {
		var manageSystemtabs = [
            { title: 'User Attributes', tabLink: "manageSystem.userattributes"},
            { title: 'Set Frequency', tabLink: "manageSystem.setfrequency"}
        ],
		selected = null,
        previous = null;
		$scope.manageSystemtabs = manageSystemtabs;
		$scope.selectedIndex = $state.current.data.selectedTab;
	}