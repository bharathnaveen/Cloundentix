
angular
    .module('cloudentixApp')
	.controller('roleviewtab', roleviewtab)

	  .run(
      ['$rootScope', '$state', '$stateParams',
        function($rootScope, $state, $stateParams) {
                
          $rootScope.$state = $state;
          $rootScope.$stateParams = $stateParams;
        }
      ]
    )
    .config(
      ['$stateProvider', '$urlRouterProvider',
        function($stateProvider, $urlRouterProvider) {

          $urlRouterProvider
          $stateProvider

			
          .state('roleView.accesspolicy', {
              url: '/accesspolicy',
             controller: function($scope) {

              },
              templateUrl: 'role/sub-role/cloudentix-admin-role-accesspolicy.html',
              data: {
				  'selectedTab': 0
				}
            })
            .state('roleView.approvalpolicy', {
              url: '/approvalpolicy',
              controller: function($scope) {

              },
              templateUrl: 'role/sub-role/cloudentix-admin-role-approvalpolicy.html',
              data: {
				  'selectedTab': 1
				}
            })
       
		}
      ]
    );
    roleviewtab.$inject = ['$scope', '$log', '$location', '$window', '$http', '$state'];
		function roleviewtab($scope, $log, $location, $window, $http, $state) {
        
        var resourcetype = localStorage.getItem("RescType");
        if(resourcetype == 'Y'){
        var roletabs = [
          //{ title: 'Access Policy', tabLink: "roleView.accesspolicy"},
		  { title: 'Approval Policy', tabLink: "roleView.approvalpolicy"}
        ],selected = null,
        previous = null;
		$scope.roletabs = roletabs;
		$scope.selectedIndex = $state.current.data.selectedTab;;
		var rolename = localStorage.getItem("roleValue");

$scope.rolename = rolename;
        }else{
			 var roletabs = [
          { title: 'Access Policy', tabLink: "roleView.accesspolicy"},
		  { title: 'Approval Policy', tabLink: "roleView.approvalpolicy"}
        ]
        //$scope.roletabs.push({ title: 'Access Policy', tabLink: "roleView.accesspolicy"})
        selected = null,
        previous = null;
		$scope.roletabs = roletabs;
		$scope.selectedIndex = $state.current.data.selectedTab;;
		var rolename = localStorage.getItem("roleValue");
		var resourcename = localStorage.getItem("RescName");

$scope.rolename = rolename;
$scope.resourcename = resourcename;
        }
		 
		/* $scope.attestationtabs = [];
		 attestationtabs.push (
          { title: 'Self Attestion', tabLink: "attestation.selfattestion"},
		  { title: 'Pending Attestation', tabLink: "attestation.pendingattestation"},
		  { title: 'History Attestation', tabLink: "attestation.historyattestation"}
        );
		console.log(attestationtabs);
		//$scope.attestationtabs = attestationtabs;*/
	}