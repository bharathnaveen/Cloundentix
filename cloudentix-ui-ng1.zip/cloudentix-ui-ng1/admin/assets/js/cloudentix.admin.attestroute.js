angular
    .module('cloudentixApp')
    .controller('listofattestation', Listof_attestation)
    .run(
    ['$rootScope', '$state', '$stateParams',
        function ($rootScope, $state, $stateParams) {
            $rootScope.$state = $state;
            $rootScope.$stateParams = $stateParams;
        }
    ]
    )
    .config(
    ['$stateProvider', '$urlRouterProvider',
        function ($stateProvider, $urlRouterProvider) {
            $urlRouterProvider
            $stateProvider
                
                .state('attestation.selfattestation', {
                    url: '/selfattestation',
                    controller: function ($scope) {
                    },
                    templateUrl: 'attestation/sub-selfattestation/selfattestation.html',
                    data: {
                        'selectedTab': 0
                    }
                })
                .state('attestation.rolemanager', {
                    url: '/rolemanager',
                    controller: function ($scope) {
                    },
                    templateUrl: 'attestation/roleManager/cloudentix-admin-sg-rolemanager.html',
                    data: {
                        'selectedTab': 1
                    }
                })
                .state('attestation.pendingattestation', {
                    url: '/pendingattestation',
                    controller: function ($scope) {
                    },
                    templateUrl: 'attestation/sub-pendingattestation/pendingattestation.html',
                    data: {
                        'selectedTab': 2
                    }
                })
                .state('attestation.historyattestation', {
                    url: '/historyattestation',
                    controller: function ($scope) {
                    },
                    templateUrl: 'attestation/sub-historyattestation/historyattestation.html',
                    data: {
                        'selectedTab': 3
                    }
                });



        }
    ]
    );
Listof_attestation.$inject = ['$scope', '$log', '$location', '$window', '$http', '$state'];
function Listof_attestation($scope, $log, $location, $window, $http, $state) {
    var attestationtabs = [

        { title: 'Attestation-Reportee', tabLink: "attestation.selfattestation" },
        { title: 'Attestation-Role Manager', tabLink: "attestation.rolemanager" },
        { title: 'Attestation-Global Status ', tabLink: "attestation.pendingattestation" },
        { title: 'Attestation-History', tabLink: "attestation.historyattestation" }

    ],
        selected = null,
        previous = null;
    $scope.attestationtabs = attestationtabs;
    // $scope.selectedTabs = {};
    $scope.selectedIndex = $state.current.data.selectedTab;
}