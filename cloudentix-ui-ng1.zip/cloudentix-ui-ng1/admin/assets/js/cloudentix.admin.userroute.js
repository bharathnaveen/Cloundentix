/*
 * Cloudentix Core JavaScript Library v1.0
 * http://cloudentix.com/
 *
 * Copyright 2016, Sennovate, Inc.
 * Released under the MIT license
 * http://sennovate.com/license
 *
 * Author : Kannan
 * Last Updated On : 2016-08-04
 */
angular
    .module('cloudentixApp')
    /* add user has defined four controllers
        first controller for define inner tabs
        second controller for user information 
        and third for resource information
        and fourth for role information
    */
	.controller('addAduser', addaduser)
	.controller('adUserinformation', adUserInformation)
	.controller('adTrustedinformation', adTrustedInformation)
	.controller('adRoleinformation', adRoleInformation)
	.factory('selectTabService', function() {
		var tabActive = '0';
		return {
			tabActive: function() { return tabActive; },
			setTabActive: function(x) { tabActive = x; }
		};
	})
    /* service method for maintaining input field values*/
    .service('keepInputfields', function() {
        // this is used for store userInformation input field values
		this.storedata = {};
        // this is used for store resourceInformation input field values
		this.storeTrusteddata = {};
        // this is used for store userRole input field values
		this.storerolesdata = { listroles: [] };
        /*
        this contructor functions used for store and get userInformation values
        */
		this.store = function(key, value) {
			this.storedata[key] = value;
		}
		this.getdata = function() {
			this.getdata1 = this.storedata;
			return this.getdata1;
		}
        /*
        this contructor functions used for store and get userResource values
        */
		this.storeTrusted = function(key, value) {
			this.storeTrusteddata[key] = value;
		}
		this.getTrusteddata = function() {
			this.gettrustedData = this.storeTrusteddata;
			return this.gettrustedData;
		}
        /*
        this contructor functions used for store and get userRole values
        */
		this.storeRoles = function(roles) {
			this.storerolesdata.listroles[0] = roles;
		}
		this.getRolesdata = function() {
			this.getrolesData = this.storerolesdata.listroles[0];
			return this.getrolesData;
		}
	})
	.run(['$rootScope', '$state', '$stateParams', 
        function($rootScope, $state, $stateParams) {
            $rootScope.$state = $state;
            $rootScope.$stateParams = $stateParams;
        }
    ])
    /*
    stateProvider provides state transition
    it is imporatant for single page application
    */
    .config(
        ['$stateProvider', '$urlRouterProvider',
            function($stateProvider, $urlRouterProvider) {
                $urlRouterProvider
                $stateProvider
                .state('adduser.userinformation', {
                    url: '/userinformation',
                    onEnter: function() {
                        void 0;
                    },
                    controller: function($scope) {

                    },
                    templateUrl: 'users/cloudentix-admin-userinfo.html',
                    data: {
                      'selectedTab': 0
                    }
                })
                .state('adduser.trustedinformation', {
                    url: '/trustedinformation',
                    onEnter: function() {
                        void 0;
                    },
                    controller: function($scope) {

                    },
                    templateUrl: 'users/cloudentix-admin-trusted.html',
                    data: {
                      'selectedTab': 0
                    }
                })
                .state('adduser.role', {
                    url: '/role',
                    onEnter: function() {
                        void 0;
                    },
                    controller: function($scope) {

                    },
                    templateUrl: 'users/cloudentix-admin-role.html',
                    data: {
                      'selectedTab': 0
                    }
                });
            }
        ]
    );
    addaduser.$inject = ['$http', '$scope', '$log', '$state', '$rootScope', '$location', '$timeout', 'SessionService'];
    adUserInformation.$inject = ['$timeout', '$window', '$http', '$scope', '$rootScope', '$log', '$state', 'keepInputfields', 'SessionService'];
    adTrustedInformation.$inject = ['$timeout', '$http', '$scope', '$log', '$rootScope', '$state', 'keepInputfields', '$location', 'SessionService'];
    adRoleInformation.$inject = ['$http', '$scope', '$log', '$rootScope', '$state', 'keepInputfields', '$location', 'SessionService'];
	var baseUrl = sessionStorage.getItem("WS_BASE_URL");
    function addaduser($http, $scope, $log, $state, $rootScope, $location, $timeout, SessionService) {
        //base Url to check trusted and untrusted resource available or not
        $scope.location= $location;
        var checkResourceURL = baseUrl + '/resources?check=true';
			var config = {
				url: checkResourceURL,
				method: "GET",
				headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
				}
			}
			$http(config)
			.success(function(response) {
                /*
                this condition is true if any of untrusted resource not configured 
                */
                if(response.type == 'success') {
                    if (response.data.login[0].trusted == 'N' || response.data.login[0].untrusted == 'N') {
                        if (response.data.login[0].trusted == 'N' && response.data.login[0].untrusted == 'N') {
                           $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure trusted and untrusted resources");
                        } else {
                            if (response.data.login[0].trusted == 'N') {
                                $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure the trusted resource");
                            } else if (response.data.login[0].untrusted === 'N') {
                                $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure an untrusted resource");
                            }
                        }
                    }
                //if two resources configured means it will process otherwise is goes to addresouce page
                    else if(response.data.login[0].trusted == 'Y' && response.data.login[0].untrusted == 'Y') {
                        // set inner tab title and tablink
                        var tabs = [
                            { title: 'User Information', tabLink: "adduser.userinformation",tabSerial:"1"},
                            { title: '', tabLink: "adduser.trustedinformation",tabSerial:"2"},
                            { title: 'Role', tabLink: "adduser.role",tabSerial:"3"}
                        ],
                        selected = null,
                        previous = null;
                        var listResourceURL = baseUrl + '/resources/list';
                        var config = {
                            url: listResourceURL,
                            method: "GET",
                            headers: {
                                "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                            }
                        }
                        $http(config).success(function(response) {        
                            angular.forEach(response.records[0].rscdetails, function(value, key) {
                                if (value["tarflag"] == 'Y') {
                                    sessionStorage.setItem("Trustedresourceid",value["rescid"]);
                                    $scope.resourceName = value["rescname"] + ' Information';
                                }
                            });
                            $scope.dynamicTitle();
                        });
                        $rootScope.usertabs = tabs;
                        $scope.selectedIndex = 0;
                        $scope.selectTabService = 0;
                        $scope.$watch('selectedIndex', function(current, old) {
                            previous = selected;
                            selected = $rootScope.usertabs[current];             
                        });
                        $scope.dynamicTitle = function() {
                            $rootScope.usertabs[1].title = $scope.resourceName;
                        }
                        $scope.wizardActive = function(activePath) {
                            var activePath = activePath.replace('#','')
                            activePath = activePath.replace('.','/');
                            locationPath = $location.path();
                            locationPath = locationPath.replace('/','');
                            if(activePath === locationPath) {
                               return 'wizard-active';
                            } else {
                               return '';
                            }
                        }
                    } 
                } else {
                    $scope.toastMessage('toast-error',response.data.message);
                }
			});
    }
    function adUserInformation($timeout, $window, $http, $scope, $rootScope, $log, $state, keepInputfields, SessionService) {
        
        //this scope object has to store user input values
        $scope.userinfoFields = {};
        //get user's specific information
        $scope.selectTabService = 1;
        
        var listfieldsURL = baseUrl + '/users/listfields'
        
        var config = {
            url: listfieldsURL,
            method: "GET",
            headers: {
                "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
            }
        }
        $rootScope.loaderCurrentStatus = 'true';
		$http(config)
		.then(function success(response) {
            /*Every user has splitted into three types
            1. user's basic information it will show in userinformation tab
            2. user's resource information it will show in another tab
            3. user's role information
            */
            if(response.data.type == 'success') {
                $rootScope.userMappedcolumn = response.data.records[0].mappedcolumn;
                $rootScope.userUnmappedcolumn = response.data.records[0].unmappedcolumn;
                $rootScope.userRolecolumn = response.data.records[0].role;
				$rootScope.userMultiselectRolecolumn = response.data.records[0].rolemultiselect;
                $timeout(function() {
                    $scope.loadUserinfoService();
                }, 10);
            } else {
                $rootScope.loaderCurrentStatus = 'false';
                $scope.toastMessage('toast-error', response.data.message);
            }
		},function error(response){
            $rootScope.loaderCurrentStatus = 'false';
            $scope.errorHandler(response.config.url,response.status);
        });
        // service has implemented to get form input values 
		$scope.loadUserinfoService = function() {
			$scope.putdata = keepInputfields.getdata();
			if($scope.putdata != '' && $scope.putdata != undefined && $scope.putdata != null) {
				angular.forEach($scope.putdata, function(value, key){
						$scope.userinfoFields[key] = value;	
				})
			}
            //set progress bar width
			$rootScope.loadWidth = 33;
			$rootScope.loaderCurrentStatus = 'false';
		}
        $scope.next = function(usertabs, isValid) {
            if(isValid) {
                angular.forEach($scope.userinfoFields, function(value, key){
                    if(value == 'None') {
                        value = '';
                    }
                    //service method used to store form input values when user click submit the form
                    keepInputfields.store(key, value);
                });
                $scope.selectedIndex = Math.min($scope.selectedIndex + 1, 2) ;
                //selectTabService.setTabActive($scope.selectedIndex);
                var nextTab = $scope.selectedIndex;	
                var gotoUrl =  $rootScope.usertabs[nextTab].tabLink;
                $state.go(gotoUrl);
            }
        };
        $scope.previous = function(usertabs) {
            $scope.selectedIndex = Math.max($scope.selectedIndex - 1, 0);
            //selectTabService.setTabActive($scope.selectedIndex);
            var prevTab = $scope.selectedIndex;
            var gotoUrl = $rootScope.usertabs[prevTab].tabLink;
            $state.go(gotoUrl);
        };
    };
    function adTrustedInformation($timeout, $http, $scope, $log, $rootScope, $state, keepInputfields, $location, SessionService) {
        //set progress bar width
        $rootScope.loadWidth = 66;
        $scope.user = {};
        $scope.selectTabService = 2;
        // calls service method to get values
        $rootScope.loaderCurrentStatus = 'true';
        $scope.loadTrustedinfoService = function() {
            if($scope.putdata != '' && $scope.putdata != undefined && $scope.putdata != null) {
                angular.forEach($scope.putdata, function(value, key){
                        $scope.user[key] = value;		
                })
            }
           $rootScope.loaderCurrentStatus = 'false';
        }
        $scope.next = function(usertabs, isValid) {
			angular.forEach($scope.user, function(value, key) {
                // store form input values in service 
				keepInputfields.storeTrusted(key, value);
			});
			$scope.selectedIndex = Math.min($scope.selectedIndex + 2, 3) ;
			//selectTabService.setTabActive($scope.selectedIndex);
			var nextTab = $scope.selectedIndex;	
			var gotoUrl =  $rootScope.usertabs[nextTab].tabLink;
			$state.go(gotoUrl);
        };
        $scope.previous = function(usertabs) {
            $scope.selectedIndex = Math.max($scope.selectedIndex - 1, 0);
            //selectTabService.setTabActive($scope.selectedIndex);
            var prevTab = $scope.selectedIndex;
            var gotoUrl = $rootScope.usertabs[prevTab].tabLink;
            $state.go(gotoUrl);
        }; 
        $scope.putdata = keepInputfields.getTrusteddata();
        var checkData = keepInputfields.getdata();
        if(!Object.keys(checkData).length) {
            $state.go('adduser.userinformation');
        } else {
            $timeout(function() {
                $scope.loadTrustedinfoService();
            }, 1000);
        }
    }
    function adRoleInformation($http, $scope, $log, $rootScope, $state, keepInputfields, $location, SessionService) {
        //set progress bar width
        $rootScope.loadWidth = 100;
        $rootScope.loaderCurrentStatus = 'true';
        var checkData = keepInputfields.getdata();
        if(!Object.keys(checkData).length) {
            $location.url('/adduser/userinformation');
        }
        // calls service method to get form input values
        $scope.selectTabService = 3;
        $scope.userInfodata = keepInputfields.getdata();
        $scope.userTrusteddata = keepInputfields.getTrusteddata();
        $scope.userroledata = keepInputfields.getRolesdata();
        if($scope.userroledata != '' && $scope.userroledata != undefined && $scope.userroledata != null) {
            if($rootScope.userMultiselectRolecolumn == 'Y') {
				$scope.Roles = $scope.userroledata;
			} else {
				$scope.singleRole = $scope.userroledata;
			}
        }
        $rootScope.loaderCurrentStatus = 'false';
        var trustedResourceID = sessionStorage.getItem("Trustedresourceid");
        //finally get all the form values from service method then call add user API request
        $scope.next = function() {
            $scope.userValues = {"records": []};
            $scope.userroleValues = {"records": []};
            angular.forEach($scope.userInfodata, function(value, key) {
                $scope.userValues.records.push({"colname": key, "colvalue": value});
            })	
            angular.forEach($scope.userTrusteddata, function(value, key) {
                $scope.userValues.records.push({"colname": key, "colvalue": value});
            })
			if($rootScope.userMultiselectRolecolumn == 'Y') {
				for(var i=0;i < $scope.Roles.length;i++) {
					$scope.userroleValues.records.push({"roleid": $scope.Roles[i]});
				}
			} else {
				$scope.userroleValues.records.push({"roleid": $scope.singleRole});
			}
            var userinormation = JSON.stringify($scope.userValues);
            var userRoleinormation = JSON.stringify($scope.userroleValues);
            $rootScope.loaderCurrentStatus = 'true';
            var listURL = baseUrl + '/users';
            var userid = localStorage.getItem("userid");
            var config = {
                url: listURL,
                method: "POST",
                headers: {
                    "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                    "cdt-rscid": trustedResourceID,
                    "cdt-valuejson": userinormation,
                    "cdt-rolejson": userRoleinormation,
                    "cdt-loginguid" : userid
                }
            }
            $http(config)
            .then(function success(response) {
                $rootScope.loaderCurrentStatus = 'false';
                if (response.data.type == "success") {
                    $scope.toastMessage('toast-success',response.data.message);
                    keepInputfields.storedata = {}; 
                    keepInputfields.storeTrusteddata = {};
                    keepInputfields.storerolesdata.listroles = [];
                    $state.go('users');
                    $scope.addTab('Users','users');
                } else if (response.data.type == "error") {
                    $scope.toastMessage('toast-error',response.data.message);
                } else if(response.data.type == "warning") {
                    $scope.toastMessage('toast-warn',response.data.message);
                } else {
                    $scope.toastMessage('toast-error',response.data.message);
                }
            },function error(response){
                $rootScope.loaderCurrentStatus = 'false';
                $scope.errorHandler(response.config.url,response.status);
            });
        };
        $scope.previous = function(usertabs) {
			if($rootScope.userMultiselectRolecolumn == 'Y') {
				keepInputfields.storeRoles($scope.Roles);
			} else {
				keepInputfields.storeRoles($scope.singleRole);
			}
            $scope.selectedIndex = Math.max($scope.selectedIndex - 1, 1);
            //selectTabService.setTabActive($scope.selectedIndex);
            var prevTab = $scope.selectedIndex;
            var gotoUrl = $rootScope.usertabs[prevTab].tabLink;
            $state.go(gotoUrl);
        };  
    }