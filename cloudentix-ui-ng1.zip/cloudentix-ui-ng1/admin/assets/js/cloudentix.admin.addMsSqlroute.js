angular
	.module('cloudentixApp')
	.controller('MsSqladdrescourcemainctrl',mssqladdRscMainCtrl)
	.controller('MsSqladdresourcemysqlsetupCtrl',mssqlsetup)
	.controller('MsSqluserdatamappingcontroller',mssqluserdatamapping)
	.controller('MsSqlchildtabledatamappingcontroller',mssqlchilddatamapping)
	.controller('MsSqluserattrmappingcontroller',mssqlUserattrmapping)
	.controller('MsSqltrusteduserattrmappingcontroller',mssqlTrustedUserAttrMapping)
	.controller('MsSqllookupTabledataMappingController',mssqlLookupTableDataMapping)

	.config(
		['$stateProvider', '$urlRouterProvider',
			function($stateProvider,$urlRouterProvider){
				$urlRouterProvider
				$stateProvider
					.state('MsSqladdresources.mssqladdrsc', {
						url:'/mssqladdrsc',
						templateUrl: 'resources/addResource/mssql/cloudentix-admin-resources-addResource-mssql-setup.html',
					})
					.state('MsSqladdresources.userdatamapping', {
						url: '/mssqluserdatamapping',
						templateUrl: 'resources/addResource/mssql/cloudentix-admin-resources-addResource-mssql-userdatamapping.html',
					})
					.state('MsSqladdresources.childtabledatamapping', {
						url: '/mssqlchildtabledatamapping',
						templateUrl: 'resources/addResource/mssql/cloudentix-admin-resources-addResource-mssql-childtabledatamapping.html',
					})
					//mssql-trusted  
					.state('MsSqladdresources.userattributesmapping', {
						url: '/mssqluserattributesmapping',
						templateUrl: 'resources/addResource/mssql/cloudentix-admin-resources-addResource-mssql-trusteduserattributesmapping.html',
					}) 
            
					//mssql-untrusted-reconattributerule
					.state('MsSqladdresources.recon', {
						url: '/mssqlrecon',
						templateUrl: 'resources/addResource/mssql/cloudentix-admin-resources-addResource-mssql-userattributesmapping.html',
					})
					.state('MsSqladdresources.lookuptabledatamapping', {
						url: '/mssqllookuptabledatamapping',
						templateUrl: 'resources/addResource/mssql/cloudentix-admin-resources-addResource-mssql-lookuptabledatamapping.html',
					});
			}
		]
	)
	.service('keepValue', function(){
		this.mysqlStore = function(x, y){
			this.storemysql = x;
			this.storetablemysql = y;
		}
		this.mysqlGetVal = function(){
			return this.storemysql;
		}
		this.tableGetVal = function(){
			return this.storetablemysql;
		}
	  })
	.service('keepUDM', function(){
		this.udmStore = function(x,y){
			this.storeUDM = x;
			this.storeprimarytablemysql = y;
	  }
	  this.UDMGetVal = function(){
			return this.storeUDM;
	  }
	  this.primaryTableGetVal = function(){
			return this.storeprimarytablemysql;
	  }
	})
	.service('keepCDM', function(){
		this.cdmStore = function(x){
			this.storeCDM = x;
		}
		this.CDMGetVal = function(){
			return this.storeCDM;
		}
	})
	.service('keepRecon', function(){
		this.reconStore = function(x){
			this.storeRecon = x;
		}
		this.reconAttrStore = function(x){
			this.storeAttributeRecon = x;
		}
		this.reconGetVal = function(){
			return this.storeRecon;
		}
		this.reconGetAttr = function(){
			return this.storeAttributeRecon;
		}
	})
	.service('keepTUAM', function(){
		this.tuamStore = function(x){
			this.storeTUAM = x;
		}
		this.tuamGetVal = function(){
			return this.storeTUAM;
		}
	})
	  .factory('selectTabService', function(){
		var tabActive = '0';
		return {  
		tabActive: function() { return tabActive; },
		setTabActive: function(x) { tabActive = x; }
			};
		})
	.run(['$rootScope', '$state', '$stateParams',
        function($rootScope, $state, $stateParams) {
            $rootScope.$state = $state;
            $rootScope.$stateParams = $stateParams;
			}
		])
		mssqladdRscMainCtrl.$inject = ['$scope', '$log', '$state', '$rootScope', '$location', 'keepValue', 'keepUDM', 'keepCDM', 'keepRecon', 'keepTUAM', 'SessionService'];
		mssqlsetup.$inject = ['$scope','$http','$rootScope', '$state','keepValue', 'SessionService'];
		mssqluserdatamapping.$inject = ['$http', '$scope', '$rootScope', '$state','keepUDM', 'keepValue', '$timeout', '$location', 'SessionService'];
		mssqlchilddatamapping.$inject = ['$http','$scope','$state','$rootScope', 'keepValue','keepCDM','keepUDM', '$timeout', '$location', 'SessionService'];
		mssqlUserattrmapping.$inject = ['$http', '$scope', '$rootScope', '$state','keepUDM','keepRecon', '$mdDialog', 'keepValue', '$location', 'SessionService'];
		mssqlTrustedUserAttrMapping.$inject = ['$http', '$scope', '$rootScope', '$state', 'keepUDM','keepValue','keepTUAM', '$location', 'SessionService'];
		mssqlLookupTableDataMapping.$inject = ['$http','$scope','$rootScope','$state', 'keepValue', 'keepUDM', 'keepCDM', 'keepRecon','keepTUAM', '$mdDialog', '$location', 'SessionService'];
	function mssqladdRscMainCtrl ($scope, $log, $state, $rootScope, $location, keepValue, keepUDM, keepCDM, keepRecon, keepTUAM, SessionService) {
		keepValue.storemysql = undefined;
		keepUDM.storeUDM = undefined;
		keepCDM.storeCDM = undefined;
		keepRecon.storeRecon = undefined;
		keepTUAM.storeTUAM = undefined;
		// keepDM.storeDM = undefined;
		$scope.selectTabService = 0;
		var Resourcetabs = [
			{ title: 'Setup', tabLink: "MsSqladdresources.mssqladdrsc", tabSerial : "1"},
			{ title: 'User Data Mapping', tabLink: "MsSqladdresources.userdatamapping", tabSerial : "2"},
			{ title: 'Role Data Mapping', tabLink: "MsSqladdresources.childtabledatamapping", tabSerial : "3"},          
			{ title: 'User Attributes Mapping', tabLink: "MsSqladdresources.userattributesmapping", tabSerial : "4"},
			{ title: 'Reference Data Mapping', tabLink: "MsSqladdresources.lookuptabledatamapping", tabSerial : "5"}
		],
        selected = null,
        previous = null;
		$rootScope.Resourcetabs = Resourcetabs;
		$scope.selectedIndex = 0;
		$rootScope.loadWidth = 20;
		$scope.$watch('selectedIndex', function(current, old){
			//console.log( $scope.selectedIndex);
			previous = selected;
			selected = Resourcetabs[current];
		});
	
	$scope.wizardActive = function(activePath){
        var activePath = activePath.replace('#','')
		activePath = activePath.replace('.','/');
		locationPath = $location.path();
		   locationPath = locationPath.replace('/','');
			if(activePath === locationPath){
			   return 'wizard-active';
			}else{
			   return '';
			}
        }
    
	}
  
  	function mssqlsetup($scope,$http,$rootScope, $state,keepValue, SessionService){
        var checkResourceURL = baseUrl + '/resources?check=true';
		var config = {
			url: checkResourceURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
			}
		}
       	$http(config)
		.then(function success(response) {
			$rootScope.loaderCurrentStatus = 'false';
			if(response.data.type == 'success'){
				if (response.data.data.login[0].trusted == 'N') {
					$scope.TrustedAvailable = true;
				} else if (response.data.data.login[0].trusted == 'Y') {
					$scope.TrustedAvailable = false;
					$rootScope.Resourcetabs[3].title = "Reconciliation Rule"
					$rootScope.Resourcetabs[3].tabLink = "MsSqladdresources.recon"	
				}
			}
			else if(response.data.type == 'error'){
				$scope.toastMessage('toast-error',response.data.message);
			}
			else if(response.data.type == 'warning'){
				$scope.toastMessage('toast-warn',response.data.message);
			}
			
		},function error(response){
			// It will work when the server returns the status "500 - Internal server" or 400 series errors
			$rootScope.loaderCurrentStatus = 'false';
			$scope.errorHandler(response.config.url,response.status);
		});
		$scope.form={};
		var mssqlval=keepValue.mysqlGetVal();
        $scope.selectTabService = 0;
		if(mssqlval != undefined)
		{
			$scope.form.resourceName = mssqlval.resourceName;
			$scope.form.hostName = mssqlval.hostName;
			$scope.form.userName = mssqlval.userName;
			$scope.form.password = mssqlval.password;
			$scope.form.Port = mssqlval.Port;
			$scope.form.databaseName = mssqlval.databaseName;
			$scope.form.radiobuttonmodel = mssqlval.radiobuttonmodel;
		}
		$scope.next = function(Resourcetabs){
            $rootScope.loaderCurrentStatus = 'true';
			var resourcename = $scope.form.resourceName;
			var hostname = $scope.form.hostName;
			var username = $scope.form.userName;
			var password = $scope.form.password;
			var port = $scope.form.Port;
			var databasename = $scope.form.databaseName;     
			var radiobuttonmodel = $scope.form.radiobuttonmodel;
			
			var addResourceSetupURL = baseUrl + '/addmssql/gettargettables';
			var config = {
			url: addResourceSetupURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                "cdt-rescname":resourcename,
                "cdt-host":hostname,
                "cdt-port":port,
                "cdt-username":username,
                "cdt-pwd":password,
                "cdt-db":databasename, 
                "cdt-istrusted":radiobuttonmodel
				}
			}
		$http(config)
			.then(function success(response) {
            $rootScope.loaderCurrentStatus = 'false';
			if(response.data.type=="success"){
				$scope.resourcetargettables = [];     
                angular.forEach(response.data.records[0].targettables, function(key,value) {
                $scope.resourcetargettables.push(response.data.records[0].targettables[value]);
                }); 
				if(radiobuttonmodel === 'N'){
					var temp;
					temp = Resourcetabs[3].title;
					Resourcetabs[3].title = "Reconciliation Rule"
					Resourcetabs[3].tabLink = "MsSqladdresources.recon"
				} else {
					var temp;
					temp = Resourcetabs[3].title;
					Resourcetabs[3].title = "User Attributes Mapping"
					Resourcetabs[3].tabLink = "MsSqladdresources.userattributesmapping"
				}
				keepValue.mysqlStore($scope.form, $scope.resourcetargettables);
				$scope.selectedIndex = Math.min($scope.selectedIndex + 1, 5) ;
				//selectTabService.setTabActive($scope.selectedIndex);
				var nextTab = $scope.selectedIndex;	
				var gotoUrl =  $rootScope.Resourcetabs[nextTab].tabLink;
				$state.go(gotoUrl);
				$rootScope.loadWidth = 40;
			}
			else if(response.data.type == "error"){
			$scope.toastMessage('toast-error',response.data.message);
			$state.go('MsSqladdresources.mssqladdrsc');
            }
            else if(response.data.type == "warning"){
			$scope.toastMessage('toast-warn',response.data.message);
			$state.go('MsSqladdresources.mssqladdrsc');
            }
		},function error(response){
			// It will work when the server returns the status "500 - Internal server" or 400 series errors
			$rootScope.loaderCurrentStatus = 'false';
			$scope.errorHandler(response.config.url,response.status);
		});
		}
	}
	function mssqluserdatamapping($http, $scope, $rootScope, $state,keepUDM, keepValue, $timeout, $location, SessionService){
		$scope.form = {};
		$scope.userdatamappingform = {};
        var mssqlVal = keepValue.mysqlGetVal();
        if(mssqlVal == undefined) {
            $location.url('/MsSqladdresources/mssqladdrsc');
			return;
        }
		var udmVal = keepUDM.UDMGetVal();
		$scope.istrustedvalfinal = mssqlVal.radiobuttonmodel;
		var tableval=keepValue.tableGetVal();
		$scope.selectTabService = 1;
		var countservice = 0;
		$scope.usertable= angular.copy(tableval);
		$scope.getlistofcolumns=function(tableform){
            $rootScope.loaderCurrentStatus = 'true';
			$scope.form.singleSelectusertablekey = '';
			$scope.form.singleSelectpasswordcolumn = '';
			$scope.form.singleSelectstatuscol = '';
			$scope.form.enableValue = '';
			$scope.form.disableValue = '';
			tableform.$setUntouched();
            tableform.$setPristine(true);
			var addResourceUserDataMappingURL = baseUrl + '/addmssql/gettargetcolumns';
			var resourcetablename = $scope.form.usertablenamemodel;
			var hostname = mssqlVal.hostName;
			var username = mssqlVal.userName;
			var password = mssqlVal.password;
			var port = mssqlVal.Port;
			var databasename = mssqlVal.databaseName;
			var istrustedval = mssqlVal.radiobuttonmodel;
			
			var config = {
				url : addResourceUserDataMappingURL,
				method : "GET",
				headers : {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
					"cdt-host":hostname,
					"cdt-port":port,
					"cdt-username":username,
					"cdt-pwd":password,
					"cdt-db":databasename, 
					"cdt-istrusted":istrustedval,
					"cdt-tablename":resourcetablename,
				}
			}
			$http(config)
				.then(function success(response) {
                $rootScope.loaderCurrentStatus = 'false';
				$scope.resourcetargetcolumns = [];
				angular.forEach(response.data.records[0].targetcolumns,function(key,value){
					$scope.resourcetargetcolumns.push(response.data.records[0].targetcolumns[value]);
				})
				$scope.usertablekey= angular.copy($scope.resourcetargetcolumns);
				var passwordnone=["None"];
				var passwordcolumn1= angular.copy($scope.resourcetargetcolumns);
				$scope.passwordcolumn=passwordnone.concat(passwordcolumn1);
				if(istrustedval == "Y")
				{
					$scope.statuscolumn= angular.copy($scope.resourcetargetcolumns);
				}
				else{
					var statusone=["None"];
					var statuscolumn1= angular.copy($scope.resourcetargetcolumns);
					$scope.statuscolumn= statusone.concat(statuscolumn1);
				}
				$scope.userrolecolumn= angular.copy($scope.resourcetargetcolumns);
				if(udmVal != undefined && countservice === 0){
					$scope.form.singleSelectusertablekey = udmVal.singleSelectusertablekey;
					$scope.form.singleSelectpasswordcolumn = udmVal.singleSelectpasswordcolumn;
					$scope.form.singleRoleMapping = udmVal.singleRoleMapping;
					$scope.form.singleSelectstatuscol = udmVal.singleSelectstatuscol;
					$scope.form.enableValue = udmVal.enableValue;
					$scope.form.disableValue = udmVal.disableValue;
					$timeout(function () {
						$scope.form.singleSelectedRole = udmVal.singleSelectedRole;
					}, 1000);	
				}
				countservice = countservice + 1;
			},function error(response){
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				$rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);
		});
		}
		$scope.resetStatusValue = function(selectedStatus) {
            if(selectedStatus == 'None') {
                $scope.form.enableValue = '';
                $scope.form.disableValue  = '';
            }
        }
		if(udmVal != undefined){
		$rootScope.loaderCurrentStatus = 'true';	
		$scope.form.usertablenamemodel = udmVal.usertablenamemodel;
		$timeout(function () {
				$scope.getlistofcolumns($scope.userdatamappingform.loginForm);
            }, 1000);
        //$scope.form.singleSelectusertablekey = udmVal.singleSelectusertablekey;
        //$scope.form.singleSelectpasswordcolumn = udmVal.singleSelectpasswordcolumn;
		//$scope.form.singleRoleMapping = udmVal.singleRoleMapping;
		//$scope.form.singleSelectedRole = udmVal.singleSelectedRole;
        //$scope.form.singleSelectstatuscol = udmVal.singleSelectstatuscol;
        //$scope.form.enableValue = udmVal.enableValue;
        //$scope.form.disableValue = udmVal.disableValue;
		}
		$scope.next = function(Resourcetabs) {
			if($scope.form.singleSelectpasswordcolumn=="None") {
				$scope.form.singleSelectpasswordcolumn="";
			}
			if($scope.form.singleSelectstatuscol=="None") {
				$scope.form.singleSelectstatuscol="";
			}
			keepUDM.udmStore($scope.form , $scope.resourcetargetcolumns);
			$scope.selectedIndex = Math.min($scope.selectedIndex + 2, 5) ;
			var nextTab = $scope.selectedIndex;	
			var gotoUrl =  $rootScope.Resourcetabs[nextTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 60;
		};		
		$scope.previous = function(Resourcetabs) {
			$scope.selectedIndex = Math.max($scope.selectedIndex - 2, 0);
			var prevTab = $scope.selectedIndex;
			var gotoUrl = $rootScope.Resourcetabs[prevTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 20;
		};  	
	}
	function mssqlchilddatamapping($http,$scope,$state,$rootScope, keepValue,keepCDM,keepUDM, $timeout, $location, SessionService){
		$scope.form = {};
        var mssqlVal = keepValue.mysqlGetVal();
        if(mssqlVal == undefined) {
            $location.url('/MsSqladdresources/mssqladdrsc');
			return;
        }
		var udmVal = keepUDM.UDMGetVal();
		$scope.singlerolemapvalue = udmVal.singleRoleMapping;
		var cdmVal = keepCDM.CDMGetVal();
		var tableval=keepValue.tableGetVal();
        $scope.selectTabService = 2;
		$scope.userroletable= angular.copy(tableval);
		$scope.roletablevalue= angular.copy(tableval);
		if($scope.singlerolemapvalue == 'N')
		{
		$scope.getlistofcolumnsforuserrole=function(tableform, useridcol, roleidcol){
            $rootScope.loaderCurrentStatus = 'true';
			$scope.form.useridcolumnmodel = '';
			$scope.form.userroleidcolumnmodel = '';
			tableform.$setUntouched();
            tableform.$setPristine(true);
			var addResourceChildDataMappingURL = baseUrl + '/addmssql/gettargetcolumns';
			var userroletableid = $scope.form.userroletablemodel;
			var hostname = mssqlVal.hostName;
			var username = mssqlVal.userName;
			var password = mssqlVal.password;
			var port = mssqlVal.Port;
			var databasename = mssqlVal.databaseName;
			var istrustedval = mssqlVal.radiobuttonmodel;
			if(userroletableid != undefined){
				var config = {
					url : addResourceChildDataMappingURL,
					method : "GET",
					headers : {
						"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
						"cdt-host":hostname,
						"cdt-port":port,
						"cdt-username":username,
						"cdt-pwd":password,
						"cdt-db":databasename, 
						"cdt-istrusted":istrustedval,
						"cdt-tablename":userroletableid,
					}
				}
				$http(config)
					.then(function success(response) {
					$rootScope.loaderCurrentStatus = 'false';
					$scope.resourcetargetcolumnsuserroletable = [];
					angular.forEach(response.data.records[0].targetcolumns,function(key,value){
						$scope.resourcetargetcolumnsuserroletable.push(response.data.records[0].targetcolumns[value]);
					})
					$scope.useridcolumn= angular.copy($scope.resourcetargetcolumnsuserroletable);
					$scope.userroleidcolumn= angular.copy($scope.resourcetargetcolumnsuserroletable);
					if(useridcol != undefined && roleidcol != undefined) {
						$scope.form.useridcolumnmodel = cdmVal.useridcolumnmodel;
						$scope.form.userroleidcolumnmodel = cdmVal.userroleidcolumnmodel;
					}
				},function error(response){
					// It will work when the server returns the status "500 - Internal server" or 400 series errors
					$rootScope.loaderCurrentStatus = 'false';
					$scope.errorHandler(response.config.url,response.status);
				});
			}
		}		
		}
		$scope.getlistofcolumnsforroletable = function(tableform, roleidcol, rolenamecol){
            $rootScope.loaderCurrentStatus = 'true';
			$scope.form.roleidcolumnmodel = '';
			$scope.form.rolenamecolumnmodel = '';
			tableform.$setUntouched();
            tableform.$setPristine(true);
			var addResourceChildDataMappingURL = baseUrl + '/addmssql/gettargetcolumns';
			var userroletableid = $scope.form.roletablemodel;
			var hostname = mssqlVal.hostName;
			var username = mssqlVal.userName;
			var password = mssqlVal.password;
			var port = mssqlVal.Port;
			var databasename = mssqlVal.databaseName;
			var istrustedval = mssqlVal.radiobuttonmodel;
			var config = {
				url : addResourceChildDataMappingURL,
				method : "GET",
				headers : {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
					"cdt-host":hostname,
					"cdt-port":port,
					"cdt-username":username,
					"cdt-pwd":password,
					"cdt-db":databasename, 
					"cdt-istrusted":istrustedval,
					"cdt-tablename":userroletableid,
				}
			}
			$http(config)
				.then(function success(response) {
                $rootScope.loaderCurrentStatus = 'false';
				$scope.resourcetargetcolumnsroletable = [];
				angular.forEach(response.data.records[0].targetcolumns,function(key,value){
					$scope.resourcetargetcolumnsroletable.push(response.data.records[0].targetcolumns[value]);
				})
				$scope.roleidcolumn= angular.copy($scope.resourcetargetcolumnsroletable);
				$scope.rolenamecolumn= angular.copy($scope.resourcetargetcolumnsroletable);
				if(roleidcol != undefined && rolenamecol != undefined) {
					$scope.form.roleidcolumnmodel = cdmVal.roleidcolumnmodel;
					$scope.form.rolenamecolumnmodel = cdmVal.rolenamecolumnmodel;
				}
			},function error(response){
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				$rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);
			});
		}
		$scope.next = function(Resourcetabs) {
			keepCDM.cdmStore($scope.form);
			$scope.selectedIndex = Math.min($scope.selectedIndex + 3, 5) ;
			//selectTabService.setTabActive($scope.selectedIndex);
			var nextTab = $scope.selectedIndex;	
			var gotoUrl =  $rootScope.Resourcetabs[nextTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 80;
		};
		if(cdmVal != undefined){
			 $rootScope.loaderCurrentStatus = 'true';
			if($scope.singlerolemapvalue == 'N'){
			$scope.form.userroletablemodel = cdmVal.userroletablemodel;
			$timeout(function () {
					$scope.getlistofcolumnsforuserrole($scope.childdatamappingform.loginForm, cdmVal.useridcolumnmodel, cdmVal.userroleidcolumnmodel);
				}, 1000);
			}
			//this for role table
			$scope.form.roletablemodel = cdmVal.roletablemodel;
			$timeout(function () {
						$scope.getlistofcolumnsforroletable($scope.childdatamappingform.loginForm, cdmVal.roleidcolumnmodel, cdmVal.rolenamecolumnmodel);
					}, 1000);
			}
		
			$scope.previous = function(Resourcetabs){
				$scope.selectedIndex = Math.max($scope.selectedIndex - 0, 1);
				//selectTabService.setTabActive($scope.selectedIndex);
				var prevTab = $scope.selectedIndex;
				var gotoUrl = $rootScope.Resourcetabs[prevTab].tabLink;
				$state.go(gotoUrl);
				$rootScope.loadWidth = 40;
			}
	}
	
	function mssqlUserattrmapping($http, $scope, $rootScope, $state,keepUDM,keepRecon, $mdDialog, keepValue, $location, SessionService){
        var mssqlVal = keepValue.mysqlGetVal();
		$rootScope.userattributetitle = false;
        if(mssqlVal == undefined) {
            $location.url('/MsSqladdresources/mssqladdrsc');
			return;
        }
		var reconval = keepRecon.reconGetVal();
		var reconvalAttr = keepRecon.reconGetAttr();
		$rootScope.count=0;
		$scope.form={};
		$rootScope.listAttributes = [];
		$rootScope.finalMappingColumn = {"records": []};
		$scope.userattributeaddbutton=function($event,$scope){
		$mdDialog.show({
			controller: addmsSqlReconController,
			controllerAs: 'msSqlreconrulectrl',
			templateUrl: 'resources/addResource/mssql/cloudentix-admin-resources-addResource-mssql-addReconRule.html',
			parent: angular.element(document.body),
			targetEvent: $event,
			//controller: mdDialogCtrl,
			clickOutsideToClose:false
		})
		}
		 	 //delete button
		$scope.Deleterecon=function(index){
			$rootScope.count--;			
			$rootScope.listAttributes.splice(index, 1);
			$rootScope.finalMappingColumn.records.splice(index, 1);
            if($rootScope.listAttributes.length == 0) {
                $rootScope.userattributetitle = false;
            }
		}			
		if(reconval != undefined && reconvalAttr != undefined) {
			$rootScope.userattributetitle = true;
			$scope.trustusratt=reconval;
			var length=reconvalAttr.length;
			for(var i = 0; i < length; i++)
			{
				$scope.listAttributes.push({});
				$rootScope.count++;
			}
			for(var count = 0; count < length; count++)
			{					
				$scope.listAttributes[count].userattribute = reconvalAttr[count].userattribute;
				$scope.listAttributes[count].targetattribute = reconvalAttr[count].targetattribute;					
			}
			angular.forEach($scope.trustusratt, function(value, key) {
				$rootScope.finalMappingColumn.records.push(value);
			});			
		}	
		$scope.previous = function(Resourcetabs) {
			$scope.selectedIndex = Math.max($scope.selectedIndex - 1, 2);
			var prevTab = $scope.selectedIndex;
			var gotoUrl = $rootScope.Resourcetabs[prevTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 60;
		}; 		
		$scope.next = function(Resourcetabs){
			keepRecon.reconStore($rootScope.finalMappingColumn.records);
			keepRecon.reconAttrStore($rootScope.listAttributes);
			$scope.selectedIndex = Math.min($scope.selectedIndex + 4, 5) ;
			var nextTab = $scope.selectedIndex;	
			var gotoUrl =  $rootScope.Resourcetabs[nextTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 100;
		}	
	}
	
	function mssqlTrustedUserAttrMapping($http, $scope, $rootScope, $state, keepUDM,keepValue,keepTUAM, $location, SessionService){
		$scope.form={};
		var mssqlVal = keepValue.mysqlGetVal();
        if(mssqlVal == undefined) {
            $location.url('/MsSqladdresources/mssqladdrsc');
			return;
        }
		$scope.resourcename = mssqlVal.resourceName;
        $scope.selectTabService = 4;
		var trustusrattrmappval = keepTUAM.tuamGetVal();
		var tableval=keepUDM.primaryTableGetVal();
		$scope.targetcolumns= angular.copy(tableval);
        $rootScope.loaderCurrentStatus = 'true';
		var addResourceUserAttributesMappingURL = baseUrl + '/userattributes';
		var config = {
			url: addResourceUserAttributesMappingURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
            }
		}
		$scope.reconattribute = {"records": []}; 
		$http(config)
			.then(function success(response) {
			$rootScope.loaderCurrentStatus = 'false';
            for(var i=0;i<response.data.records[0].listattributes.length;i++)
			{
				$scope.reconattribute.records.push({"id":response.data.records[0].listattributes[i].userattid,"value":response.data.records[0].listattributes[i].displayname,"uniqueflag":response.data.records[0].listattributes[i].uniqueflag});
			}
		},function error(response){
			// It will work when the server returns the status "500 - Internal server" or 400 series errors
			$rootScope.loaderCurrentStatus = 'false';
			$scope.errorHandler(response.config.url,response.status);
		});
		$scope.previous = function(Resourcetabs) {
			$scope.selectedIndex = Math.max($scope.selectedIndex - 1, 2);
			var prevTab = $scope.selectedIndex;
			var gotoUrl = $rootScope.Resourcetabs[prevTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 60;

		}; 
		if(trustusrattrmappval != undefined) {
			$scope.trustusratt=trustusrattrmappval;
			angular.forEach($scope.trustusratt.records, function(value, key) {
				$scope.form[value["userAttrId"]] = value["targetCol"];
			});
			
		}
		
		$scope.next = function(Resourcetabs) {
			var userAttr = {"records": []};
			angular.forEach($scope.form, function(value, key) {
				if(value != "")
				{
					userAttr.records.push({"userAttrId": key, "targetCol": value});
				}
			});
			keepTUAM.tuamStore(userAttr);
			//console.log("trusted Attr Mapping"+angular.toJson($scope.reconattribute));
			$scope.selectedIndex = Math.min($scope.selectedIndex + 4, 5) ;
			//selectTabService.setTabActive($scope.selectedIndex);
			var nextTab = $scope.selectedIndex;	
			var gotoUrl =  $rootScope.Resourcetabs[nextTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 100;
		}
	}
	function mssqlLookupTableDataMapping($http,$scope,$rootScope,$state, keepValue, keepUDM, keepCDM, keepRecon,keepTUAM, $mdDialog, $location, SessionService){
		$scope.lookuptabletitle = false;
        var mssqlVal = keepValue.mysqlGetVal();
        if(mssqlVal == undefined) {
            $location.url('/MsSqladdresources/mssqladdrsc');
			return;
        }
		var tableval=keepUDM.primaryTableGetVal();
		$scope.targetlookupcolumns= angular.copy(tableval);
		var tableval=keepValue.tableGetVal();
		var udmVal = keepUDM.UDMGetVal();
		var cdmVal = keepCDM.CDMGetVal();
		
		$scope.selectTabService = 5;
		$scope.lookuptable= angular.copy(tableval);
		
		$scope.getlistoflookuptable=function(tableform,lookuptable, id){
            $rootScope.loaderCurrentStatus = 'true';
			$scope.lookupvalues.records[id].lookupkeycol = '';
			$scope.lookupvalues.records[id].lookupvalcol  = '';
			tableform.$setUntouched();
            tableform.$setPristine(true);
			var addResourceChildDataMappingURL = baseUrl + '/addmssql/gettargetcolumns';
			var userroletableid = lookuptable;
			var hostname = mssqlVal.hostName;
			var username = mssqlVal.userName;
			var password = mssqlVal.password;
			var port = mssqlVal.Port;
			var databasename = mssqlVal.databaseName;
			var istrustedval = mssqlVal.radiobuttonmodel;
			var config = {
				url : addResourceChildDataMappingURL,
				method : "GET",
				headers : {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
               
					"cdt-host":hostname,
					"cdt-port":port,
					"cdt-username":username,
					"cdt-pwd":password,
					"cdt-db":databasename, 
					"cdt-istrusted":istrustedval,
					"cdt-tablename":userroletableid,
				}
			}
			$http(config)
				.then(function success(response) {
                $rootScope.loaderCurrentStatus = 'false';
				$scope.resourcetargetcolumnsuserroletable = [];
				angular.forEach(response.data.records[0].targetcolumns,function(key,value){
					$scope.resourcetargetcolumnsuserroletable.push(response.data.records[0].targetcolumns[value]);
				})
				$scope.lookupvalues.records[id].getlooktable = angular.copy($scope.resourcetargetcolumnsuserroletable);
				$scope.lookupvalues.records[id].getlookkey  = angular.copy($scope.resourcetargetcolumnsuserroletable);
			},function error(response){
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				$rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);
			});
		}
		$scope.lookupvalues = {"records": []};
		var count = 0;
		$scope.AddLookup = function() {
			$scope.lookuptabletitle=true;
			$scope.lookupvalues.records.push({"id": count});
			count++;
		}
		$scope.CheckDuplicate = function(index) {
			var arr=[];
			angular.forEach($scope.lookupvalues.records, function(value, key) {
				arr.concat([arr.push(value.usrtblcol + ' '+value.lookuptbl)]);
			});
			// temporary object 
			var uniqOb = {};
			/* create object attribute with name=value in array, this will not keep dupes*/
			for (var i in arr)
				uniqOb[arr[i]] = "";
			// if object's attributes match array, then no dupes! 
			if (arr.length == Object.keys(uniqOb).length){
			}
			else{
				$scope.lookupvalues.records.splice(index, 1);
				$scope.lookupvalues.records.push({});
				  $mdDialog.show(
					$mdDialog.alert()
					.clickOutsideToClose(false)
					.title('Lookup')
					.textContent('Selected field already exists. Please select a different user attribute and lookup attribute')
					.ok('ok')
				);
			}		
		 };
		$scope.previous = function(Resourcetabs){
			$scope.selectedIndex = Math.max($scope.selectedIndex - 1, 3);
			//selectTabService.setTabActive($scope.selectedIndex);
			var prevTab = $scope.selectedIndex;
			var gotoUrl = $rootScope.Resourcetabs[prevTab].tabLink;
			$state.go(gotoUrl);
			$rootScope.loadWidth = 80;
		}
		$scope.DeleteLookup = function(index) {
			if($scope.lookupvalues.records.length == 1) {
				$scope.lookuptabletitle = false;
			}
			$scope.lookupvalues.records.splice(index, 1);
		}
		$scope.AddResourceFinal = function() {
            $rootScope.loaderCurrentStatus = 'true';
			var lookupvalues;
			if($scope.lookupvalues.records.length == 0) {
				lookupvalues = '{"records":[]}';
			} else {
				lookupvalues = {"records": []};
				angular.forEach($scope.lookupvalues.records,function(value, key){
					lookupvalues.records.push({"usrtblcol":value["usrtblcol"], "lookuptbl": value["lookuptbl"], "lookupkeycol": value["lookupkeycol"], "lookupvalcol": value["lookupvalcol"]});
				});
				lookupvalues =angular.toJson(lookupvalues);
			}
			var addResourceFinalURL = baseUrl + '/addmssql/final';
			var mssqlval=keepValue.mysqlGetVal();
			var resourcename = mssqlval.resourceName;
			var hostname = mssqlval.hostName;
			var username = mssqlval.userName;
			var password = mssqlval.password;
			var port = mssqlval.Port;
			var databasename = mssqlval.databaseName;
			var istrustedval = mssqlval.radiobuttonmodel;
			var resourcetablename = udmVal.usertablenamemodel;
			var usertableprimarykey = udmVal.singleSelectusertablekey;
			var passwordcolumn = udmVal.singleSelectpasswordcolumn;
			var singlerolemapping = udmVal.singleRoleMapping;
			var singleSelectedRole = udmVal.singleSelectedRole;
			var statuscolumn = udmVal.singleSelectstatuscol;
			var enableval = udmVal.enableValue;
			var disableval = udmVal.disableValue;
			var userroletable = cdmVal.userroletablemodel;
			var userid = cdmVal.useridcolumnmodel;
			var userroleid = cdmVal.userroleidcolumnmodel;
			var roletable = cdmVal.roletablemodel;
			var roleid = cdmVal.roleidcolumnmodel;
			var rolename = cdmVal.rolenamecolumnmodel;
			var finaluserattributesvalue = '';
			var finalreconattributesvalue = '';
			if(istrustedval === 'N'){
				var reconval = keepRecon.reconGetVal();
                finalreconattributesvalue = {'records':[]};
                angular.forEach(reconval, function(value, key) {
                    //console.log(value +"---"+ key);
                    var array = [];
                    var array1 = [];
					//User Attribute Mapping
					//Concat User Attribute Mapping
					if(value["userAttrId"]== '1'){
						$scope.userAttrId = value["userAttrId"];
						array.push(value["concat1"]+','+value["concat2"]);						
					}
					//SubString User Attribute Mapping
					else if(value["userAttrId"]== '2'){
						$scope.userAttrId = value["userAttrId"];
						array.push(value["substringMapping"]+','+value["substring"]);						
					}
					//DirectMapping User Attribute Mapping
					else if(value["userAttrId"]== '3'){
						$scope.userAttrId = value["userAttrId"];
						array.push(value["directmapping"]);
					}
					//Target Attribute Mapping
					//Concat Target Attribute Mapping
                    if(value["targetCol"]== '1'){
						$scope.targetuserAttrId = value["targetCol"];
						array1.push(value["targetConcat1"]+','+value["targetConcat2"]);					
					}
					//SubString Target Attribute Mapping
					else if(value["targetCol"]== '2'){
						$scope.targetuserAttrId = value["targetCol"];
						array1.push(value["targetsubstringMapping"]+','+value["targetSubstring"]);						
					}
					//DirectMapping Target Attribute Mapping
					else if(value["targetCol"]== '3'){
						$scope.targetuserAttrId = value["targetCol"];
						array1.push(value["targetdirectMapping"]);
					}
                    //array1.push(value["targetCol"]);
                    finalreconattributesvalue.records.push({"cloudusrattr":[{"methodid": $scope.userAttrId,"col": array}], "trgtusrattr":[{"methodid":$scope.targetuserAttrId,"col": array1}]});
                });
				finalreconattributesvalue = angular.toJson(finalreconattributesvalue);
				finaluserattributesvalue = '{"records":[]}';
			}
			else {
				var trustusrattrmappval = keepTUAM.tuamGetVal();
				finaluserattributesvalue = angular.toJson(trustusrattrmappval);
				finalreconattributesvalue = '{"records":[]}';
			}
			
			
			var config = {
				url: addResourceFinalURL,
				method: "POST",
				headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
					"cdt-id":'2',
					"cdt-rescname":resourcename,
					"cdt-host":hostname,
					"cdt-username":username,
					"cdt-pwd":password, 
					"cdt-port":port,
					"cdt-istrusted": istrustedval,
					"cdt-db": databasename,
					"cdt-usertbl": resourcetablename,
					"cdt-usertblprimary": usertableprimarykey,
					"cdt-pwdcol": passwordcolumn,
					"cdt-statuscol": statuscolumn,
					"cdt-enable": enableval,
					"cdt-disable": disableval,
					"cdt-userroletbl": userroletable,
					"cdt-userid": userid,
					"cdt-userroleid": userroleid,
					"cdt-roletbl": roletable,
					"cdt-roleid": roleid,
					"cdt-rolename": rolename,
					"cdt-reconattribute":finalreconattributesvalue,
					"cdt-userattribute":finaluserattributesvalue,
					"cdt-lookup":lookupvalues,
					"cdt-usrtblrolid":singleSelectedRole,
					"cdt-singlerole":singlerolemapping,
				}
			}
			$http(config)
				.then(function success(response) {
             $rootScope.loaderCurrentStatus = 'false';
				if(response.data.type == "success"){
					$scope.toastMessage('toast-success',response.data.message);
					$state.go('resources');
                    $scope.addTab('Resources','resources');
					keepValue.storemysql = undefined;
					keepUDM.storeUDM = undefined;
					keepCDM.storeCDM = undefined;
					keepRecon.storeRecon = undefined;
					keepTUAM.storeTUAM = undefined;
					//keepDM.storeDM = undefined;
				}
				else if(response.data.type == "error"){
					$rootScope.loaderCurrentStatus = 'false';
					$scope.toastMessage('toast-error',response.data.message);
					//$state.go('resources');
				}
			},function error(response){
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				$rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);
		});
		}
	}
    function addmsSqlReconController($http, $scope, $rootScope, $state,$mdDialog,keepUDM,keepRecon, SessionService){
		$scope.form={};
		var length=$rootScope.listAttributes.length;
		var tableval=keepUDM.primaryTableGetVal();
		var self = this;		
		$scope.userattributesvalue = {"records": []};	
		$scope.reconruleSelected='';
        $scope.selectTabService = 3;
		$scope.targetcolumns= angular.copy(tableval);
		//Get Method api
		var addResourceUserMappingMethodURL = baseUrl + '/method';
		var config = {
			url: addResourceUserMappingMethodURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
            }
		}
		$http(config)
			.then(function success(response) { 
		$scope.userResponse = response.data.type;   		
        $scope.addMappinguserattributes = [];     
		if (response.data.type == "success") {			
            for(var i=0;i<response.data.records[0].dropdownlist.length;i++)
            {
				$scope.addMappinguserattributes.push({"id":response.data.records[0].dropdownlist[i].key,"value":response.data.records[0].dropdownlist[i].value});
				if(response.data.records[0].dropdownlist[i].key=="3"){
					$scope.reconruleSelected=response.data.records[0].dropdownlist[i].value;
				}	
            }
			//console.log("addMappinguserattributes"+$scope.addMappinguserattributes);
			//console.log("addMappinguserattributes"+$scope.userResponse);
		}
		else {
            $scope.managesystemErrorMessage = response.data.message;
         }
		},function error(response){
			// It will work when the server returns the status "500 - Internal server" or 400 series errors
			$rootScope.loaderCurrentStatus = 'false';
			$scope.errorHandler(response.config.url,response.status);
		});
		//Get userattributes  api		
		var addResourceUserAttributesMappingURL = baseUrl + '/userattributes';
		var config = {
			url: addResourceUserAttributesMappingURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
            }
		}
		$http(config)
			.then(function success(response) {       
            $scope.resourceuserattributes = [];               
            for(var i=0;i<response.data.records[0].listattributes.length;i++)
            {
				$scope.resourceuserattributes.push({"id":response.data.records[0].listattributes[i].colname,"value":response.data.records[0].listattributes[i].displayname});
            }
				//console.log("resourceuserattributes"+$scope.resourceuserattributes);
		},function error(response){
			// It will work when the server returns the status "500 - Internal server" or 400 series errors
			$rootScope.loaderCurrentStatus = 'false';
			$scope.errorHandler(response.config.url,response.status);
		});
		$scope.userattributesvalues={"records": []};		
		self.cancel = function($event) {
		$mdDialog.cancel();
		};
		self.finish = function($event) {
			$rootScope.listAttributes.push({});
			$rootScope.userattributetitle = true;
			if($scope.userattributesvalue.records[0].userAttrId=='1'){
				var userConcat="concat("+$scope.userattributesvalue.records[0].concat1+","+$scope.userattributesvalue.records[0].concat2+")";
				$scope.attrId=$scope.userattributesvalue.records[0].userAttrId;
				$scope.userAttrConcat=userConcat;
				//console.log($scope.userattributesvalue.records[0].concat1);
				$rootScope.listAttributes[length].userattribute = userConcat;
			}
			else if($scope.userattributesvalue.records[0].userAttrId=='2'){
				var userSubstring="substring("+$scope.userattributesvalue.records[0].substringMapping+","+$scope.userattributesvalue.records[0].substring+")";
				//console.log(userSubstring);
				$rootScope.listAttributes[length].userattribute = userSubstring;
			}
			else if($scope.userattributesvalue.records[0].userAttrId=='3'){
				var userDirectMapping="directmapping("+$scope.userattributesvalue.records[0].directmapping+")";
				//console.log(userDirectMapping);
				$rootScope.listAttributes[length].userattribute = userDirectMapping;
			}
			if($scope.userattributesvalue.records[0].targetCol=='1'){
				var targetConcat="concat("+$scope.userattributesvalue.records[0].targetConcat1+","+$scope.userattributesvalue.records[0].targetConcat2+")";
				//console.log(targetConcat);
				$rootScope.listAttributes[length].targetattribute = targetConcat;
			}
			else if($scope.userattributesvalue.records[0].targetCol=='2'){
				var targetSubstringMapping="substring("+$scope.userattributesvalue.records[0].targetsubstringMapping+","+$scope.userattributesvalue.records[0].targetSubstring+")";
				//console.log(targetSubstringMapping);
				$rootScope.listAttributes[length].targetattribute = targetSubstringMapping;
			}
			else if($scope.userattributesvalue.records[0].targetCol=='3'){
				var targetAttrDirectMapping="directmapping("+$scope.userattributesvalue.records[0].targetdirectMapping+")";
				//console.log(targetAttrDirectMapping);
				$rootScope.listAttributes[length].targetattribute = targetAttrDirectMapping;
			}
			$rootScope.finalMappingColumn.records.push($scope.userattributesvalue.records[0]);
			//console.log($rootScope.finalMappingColumn);	
			$mdDialog.hide();
			var arr=[];
		  angular.forEach($rootScope.listAttributes, function(value, key) {
			arr.concat([arr.push(value.userattribute + ' '+value.targetattribute)]);
			});
			//console.log(arr);
			var uniqOb = {};
			for (var i in arr)
				uniqOb[arr[i]] = "";
			if (arr.length == Object.keys(uniqOb).length){
			 }
			  else{
				$rootScope.count--;
				$rootScope.listAttributes.splice(-1, 1);
				$rootScope.finalMappingColumn.records.splice(-1, 1);
				  $mdDialog.show(
					$mdDialog.alert()
					.clickOutsideToClose(false)
					.title('Recon Rule')
					.textContent('Selected Recon Rule already exists. Please select a different User Attributes Mapped Column and Target Attributes Mapped Column')
					.ok('ok')
				);
			  }
			$rootScope.count++;

		};
		
	}
	