angular
    .module('cloudentixApp')
    .service('loaderService', function () {
        this.loadData = function (x) {
            return x;
        }
    })
    /*.factory('loaderService', function(){
      var loadData = true;
      return {
    	loadData: function() { return loadData; },
    	newLoadedData: function(newLoadData) { loadData = newLoadData; }
      };
    })*/

    .config(function ($mdThemingProvider) {
        $mdThemingProvider
        $mdThemingProvider
            .theme('default')
            .primaryPalette('indigo');
        /*.accentPalette('grey',{
		'default' : '700'
	})
    .warnPalette('red')*/
        //.backgroundPalette('blue-grey');
    })

    .controller('AppCtrl', AppCtrl)
    .run(
    ['$rootScope', '$state', '$stateParams', '$timeout', '$document', '$location', '$window',
        function ($rootScope, $state, $stateParams, $timeout, $document, $location, $window) {

            // $rootScope.$state = $state;
            // $rootScope.$stateParams = $stateParams;
            // $rootScope.validatesessionTimedout = 0;
            // void 0;

            // // Timeout timer value
            // var TimeOutTimerValue = 1000 * 60 * 60; // 60 minutes
            // // Start a timeout 
            // var TimeOut_Thread = $timeout(function() {
            //     LogoutByTimer()
            // }, TimeOutTimerValue);
            // var bodyElement = angular.element($document);

            // angular.forEach(['keydown', 'keyup', 'click', 'mousemove', 'DOMMouseScroll', 'mousewheel', 'mousedown', 'touchstart', 'touchmove', 'scroll', 'focus'],
            //     function(EventName) {
            //         bodyElement.bind(EventName, function(e) {
            //             TimeOut_Resetter(e)
            //         });

            //     });

            // function LogoutByTimer() {

            //     //if( $rootScope.loaderCurrentStatus = 'false'){
            //     if ($rootScope.loaderCurrentStatus == 'true') {
            //         bodyElement.bind('load', function(e) {
            //             TimeOut_Resetter(e)
            //         });

            //     } else {
            //         void 0;
            //         if ($rootScope.validatesessionTimedout == 0) {
            //             $rootScope.autologoutMessage("For security reasons and protection of your personal data, your session has ended. \nPlease login again.");
            //             //console.log('Logout');
            //         }
            //     }
            // }

            // function TimeOut_Resetter(e) {
            //     //console.log(' ' + e);

            //     //Stop the pending timeout
            //     $timeout.cancel(TimeOut_Thread);

            //     // Reset the timeout
            //     TimeOut_Thread = $timeout(function() {
            //         LogoutByTimer()
            //     }, TimeOutTimerValue);


            // }

            $rootScope.$on('$stateChangeStart', stateChangeListener);
            function stateChangeListener(event, toState, toParams, fromState, fromParams, options) {
                var auth = JSON.parse(sessionStorage.getItem('cdt-user-authenticated')) || {};
                if (auth.isAuthenticatedUser) {
                    //$window.location.href = '../index.html';
                    // Redirect to Login page OR logout method here...
                }
            };

        }
    ]
    )
    .config(
    ['$ocLazyLoadProvider', '$stateProvider', '$urlRouterProvider', '$httpProvider',
        function ($ocLazyLoadProvider, $stateProvider, $urlRouterProvider, $httpProvider) {


            //$locationProvider.html5Mode(true);
            $urlRouterProvider
                .when('/', '/dashboard')
                .otherwise('/dashboard');

            //Config For ocLazyLoading
            $ocLazyLoadProvider.config({
                'debug': true, // For debugging 'true/false'
                'events': true, // For Event 'true/false'
                'modules': [{ // Set modules initially
                    name: 'attestation', // attestation module
                    files: ['attestation/admin.attestation.controllers.js']
                }, {
                    name: 'dashboard', // dashboard module
                    files: ['dashboard/admin.dashboard.controllers.js']
                }, {
                    name: 'job', // job module
                    files: ['job/admin.job.controllers.js']
                }, {
                    name: 'manageSystem', // manageSystem module
                    files: ['manageSystem/admin.manageSystem.controllers.js']
                }, {
                    name: 'myCloudentix', // myCloudentix module
                    files: ['myCloudentix/admin.myCloudentix.controllers.js']
                }, {
                    name: 'reports', // reports module
                    files: ['reports/admin.reports.controllers.js']
                }, {
                    name: 'resources', // resources module
                    files: ['resources/admin.resources.controllers.js']
                }, {
                    name: 'role', // role module
                    files: ['role/admin.role.controllers.js']
                }, {
                    name: 'users', // users module
                    files: ['users/admin.users.controllers.js']
                }, {
                    name: 'support', // support module
                    files: ['support/admin.support.controllers.js']
                }, {
                    name: 'addataextractiontool', // SG - ADDataExtractionTool Module
                    files: ['securityGovernor/dataMaintenance/ADDataExtractionTool/admin.sg.addataextractiontool.controller.js' ]
                }, {
                    name: 'sgdashboard', // SG - dashboard Module
                    files: ['securityGovernor/dataMaintenance/dashboard/admin.sg.dashboard.controller.js' ]
                }, {
                    name: 'acc-duplicateEmployeeId', // SG - acc-duplicateEmployeeId Module
                    files: ['securityGovernor/report/accountReport/acc-duplicateEmployeeId/admin.sg.acc-duplicateEmployeeId.controller.js' ]
                }, {
                    name: 'acc-expiration', // SG - acc-expiration Module
                    files: ['securityGovernor/report/accountReport/acc-expiration/admin.sg.acc-expiration.controller.js' ]
                }, {
                    name: 'acc-expirationReport', // SG - acc-expirationReport Module
                    files: ['securityGovernor/report/accountReport/acc-expirationReport/admin.sg.acc-expirationReport.controller.js' ]
                }, {
                    name: 'acc-mapping', // SG - acc-mapping Module
                    files: ['securityGovernor/report/accountReport/acc-mapping/admin.sg.acc-mapping.controller.js' ]
                }, {
                    name: 'acc-multipleEmployeeIds', // SG - acc-multipleEmployeeIds Module
                    files: ['securityGovernor/report/accountReport/acc-multipleEmployeeIds/admin.sg.acc-multipleEmployeeIds.controller.js' ]
                }, {
                    name: 'acc-passwordNotification', // SG - acc-passwordNotification Module
                    files: ['securityGovernor/report/accountReport/acc-passwordNotification/admin.sg.acc-passwordNotification.controller.js' ]
                }, {
                    name: 'attestationReview', // SG - AttestationReview Module
                    files: ['securityGovernor/report/AttestationReview/admin.sg.AttestationReview.controller.js' ]
                }, {
                    name: 'active', // SG - DAActive Module
                    files: ['securityGovernor/report/domainAdminReport/DAActive/admin.sg.DAActive.controller.js' ]
                }, {
                    name: 'inactive', // SG - DAInactive Module
                    files: ['securityGovernor/report/domainAdminReport/DAInactive/admin.sg.DAInactive.controller.js' ]
                }, {
                    name: 'adgroupjob', // SG - ADGroupForJob Module
                    files: ['securityGovernor/report/roleMining/ADGroupForJob/admin.sg.ad-job.controller.js' ]
                }, {
                    name: 'bustaffjob', // SG - BUStaffForJob Module
                    files: ['securityGovernor/report/roleMining/BUStaffForJob/admin.sg.bu-job.controller.js' ]
                }, {
                    name: 'cvuegroupjob', // SG - CVueGroupForJob Module
                    files: ['securityGovernor/report/roleMining/CVueGroupForJob/admin.sg.cv-job.controller.js' ]
                }, {
                    name: 'jobtitlead', // SG - JobTitleForADGroup Module
                    files: ['securityGovernor/report/roleMining/JobTitleForADGroup/admin.sg.jobtitlead.controller.js' ]
                }, {
                    name: 'jobtitlecvue', // SG - JobTitleForCVueGroup Module
                    files: ['securityGovernor/report/roleMining/JobTitleForCVueGroup/admin.sg.jobtitlecvue.controller.js' ]
                }
                // {
                //     name: 'rolemanager', // SG- RoleManager Module
                //     files: ['securityGovernor/roleManager/admin.sg.rolemanager.controller.js']
                // }
            ]
            });

            $stateProvider
                .state('/', {
                    abstract: true,
                    url: '/dashboard',
                    templateUrl: 'dashboard/cloudentix-admin-dashboard.html',
                    reloadOnSearch: true,
                    controller: function ($scope) {
                        $scope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams) {
                            $scope.currentTab = toState.data.selectedTab;

                        });
                    }
                })

                .state('dashboard', {
                    url: '/dashboard',
                    controller: function ($scope) {

                    },
                    templateUrl: 'dashboard/cloudentix-admin-dashboard.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                            return $ocLazyLoad.load('dashboard'); // Resolve promise and load before view 
                        }]
                    }
                })
                .state('resources', {
                    url: '/resources',
                    //controller: 'ListresourceController',
                    templateUrl: 'resources/cloudentix-admin-listResource.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                            return $ocLazyLoad.load('resources'); // Resolve promise and load before view 
                        }]
                    }
                })
                .state('users', {
                    url: '/users',
                    onEnter: function () {
                        void 0;
                    },
                    controller: function ($scope) {

                    },
                    templateUrl: 'users/cloudentix-admin-users.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                            return $ocLazyLoad.load('users'); // Resolve promise and load before view 
                        }]
                    }
                })
                .state('role', {
                    url: '/role',
                    controller: function ($scope) {

                    },
                    templateUrl: 'role/cloudentix-admin-role.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                            return $ocLazyLoad.load('role'); // Resolve promise and load before view 
                        }]
                    }
                })
                .state('attestation', {
                    url: '/attestation',
                    controller: function ($scope) {

                    },
                    templateUrl: 'attestation/cloudentix-admin-attestation.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                            return $ocLazyLoad.load('attestation'); // Resolve promise and load before view 
                        }]
                    }
                })
                .state('myCloudentix', {
                    url: '/myCloudentix',
                    controller: function ($scope) {

                    },
                    templateUrl: 'myCloudentix/cloudentix-admin-myCloudentix.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                            return $ocLazyLoad.load('myCloudentix'); // Resolve promise and load before view 
                        }]
                    }
                })
                .state('reports', {
                    url: '/reports',
                    controller: function ($scope) {

                    },
                    templateUrl: 'reports/cloudentix-admin-reports.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                            return $ocLazyLoad.load('reports'); // Resolve promise and load before view 
                        }]
                    }
                })
                .state('manageSystem', {
                    url: '/manageSystem',
                    //controller: 'ListdataController',
                    templateUrl: 'manageSystem/cloudentix-admin-manageSystem.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                            return $ocLazyLoad.load('manageSystem'); // Resolve promise and load before view 
                        }]
                    }
                })
                .state('job', {
                    url: '/job',
                    //controller: 'ListdataController',
                    templateUrl: 'job/cloudentix-admin-job.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                            return $ocLazyLoad.load('job'); // Resolve promise and load before view 
                        }]
                    }
                })
                .state('jobView', {
                    url: '/jobView',
                    //controller: 'ViewResourceController',
                    templateUrl: 'job/cloudentix-admin-jobview.html',
                })
                .state('support', {
                    url: '/support',
                    templateUrl: 'support/cloudentix-admin-support.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                            return $ocLazyLoad.load('support'); // Resolve promise and load before view 
                        }]
                    }
                })
                .state('ticketstatus', {
                    url: '/ticketstatus',
                    templateUrl: 'support/cloudentix-admin-ticketstatus.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                            return $ocLazyLoad.load('support'); // Resolve promise and load before view 
                        }]
                    }
                })
                .state('securityGovernor', {
                    url: '/securityGovernor',
                    abstract: true,
                    template: '<ui-view></ui-view>'
                })
                .state('securityGovernor.dashboard', {
                    url: '/dashboard',
                    templateUrl: 'securityGovernor/dataMaintenance/dashboard/cloudentix-admin-sg-dm-dashboard.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                          return $ocLazyLoad.load('sgdashboard'); // Resolve promise and load before view 
                        }]
                      }
                })
                .state('securityGovernor.addataextractiontool', {
                    url: '/addataextractiontool',
                    templateUrl: 'securityGovernor/dataMaintenance/ADDataExtractionTool/cloudentix-admin-sg-dm-addataextractiontool.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                          return $ocLazyLoad.load('addataextractiontool'); // Resolve promise and load before view 
                        }]
                      }
                })
                .state('securityGovernor.adgroupjob', {
                    url: '/adgroupjob',
                    templateUrl: 'securityGovernor/report/roleMining/ADGroupForJob/cloudentix-admin-sg-ad-job.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                          return $ocLazyLoad.load('adgroupjob'); // Resolve promise and load before view 
                        }]
                      }
                })
                .state('securityGovernor.bustaffjob', {
                    url: '/bustaffjob',
                    templateUrl: 'securityGovernor/report/roleMining/BUStaffForJob/cloudentix-admin-sg-bu-job.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                          return $ocLazyLoad.load('bustaffjob'); // Resolve promise and load before view 
                        }]
                      }
                })
                .state('securityGovernor.cvuegroupjob', {
                    url: '/cvuegroupjob',
                    templateUrl: 'securityGovernor/report/roleMining/CVueGroupForJob/cloudentix-admin-sg-cv-job.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                          return $ocLazyLoad.load('cvuegroupjob'); // Resolve promise and load before view 
                        }]
                      }
                })
                .state('securityGovernor.jobtitlead', {
                    url: '/jobtitlead',
                    templateUrl: 'securityGovernor/report/roleMining/JobTitleForADGroup/cloudentix-admin-sg-jobtitlead.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                          return $ocLazyLoad.load('jobtitlead'); // Resolve promise and load before view 
                        }]
                      }
                })
                .state('securityGovernor.jobtitleadstafflist', {
                    url: '/jobtitleadstafflist',
                    templateUrl: 'securityGovernor/report/roleMining/JobTitleForADGroup/cloudentix-admin-sg-jobtitleadstafflist.html',
                    // resolve: {
                    //     loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    //       return $ocLazyLoad.load('job'); // Resolve promise and load before view 
                    //     }]
                    //   }
                })
                .state('securityGovernor.jobtitlecvue', {
                    url: '/jobtitlecvue',
                    templateUrl: 'securityGovernor/report/roleMining/JobTitleForCVueGroup/cloudentix-admin-sg-jobtitlecvue.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                          return $ocLazyLoad.load('jobtitlecvue'); // Resolve promise and load before view 
                        }]
                      }
                })
                .state('securityGovernor.jobtitlecvuestafflist', {
                    url: '/jobtitlecvuestafflist/?staffid&db&job',
                    templateUrl: 'securityGovernor/report/roleMining/JobTitleForCVueGroup/cloudentix-admin-sg-jobtitlecvuestafflist.html',
                    // resolve: {
                    //     loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    //       return $ocLazyLoad.load('job'); // Resolve promise and load before view 
                    //     }]
                    //   }
                })
                .state('securityGovernor.attestationReview', {
                    url: '/attestationReview',
                    templateUrl: 'securityGovernor/report/AttestationReview/cloudentix-admin-sg-attestationreview.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                          return $ocLazyLoad.load('attestationReview'); // Resolve promise and load before view 
                        }]
                      }
                })
                .state('securityGovernor.attestationschedule', {
                    url: '/attestationschedule',
                    templateUrl: 'securityGovernor/report/AttestationReview/cloudentix-admin-sg-schedule.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                          return $ocLazyLoad.load('attestationReview'); // Resolve promise and load before view 
                        }]
                      }
                })
                .state('securityGovernor.active', {
                    url: '/active',
                    templateUrl: 'securityGovernor/report/domainAdminReport/DAActive/cloudentix-admin-sg-DAactive.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                          return $ocLazyLoad.load('active'); // Resolve promise and load before view 
                        }]
                      }
                })
                .state('securityGovernor.inactive', {
                    url: '/inactive',
                    templateUrl: 'securityGovernor/report/domainAdminReport/DAInactive/cloudentix-admin-sg-DAInactive.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                          return $ocLazyLoad.load('inactive'); // Resolve promise and load before view 
                        }]
                      }
                })
                .state('securityGovernor.acc-expirationreport', {
                    url: '/acc-expirationreport',
                    templateUrl: 'securityGovernor/report/accountReport/acc-expirationReport/cloudentix-admin-sg-acc-expirationreport.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                          return $ocLazyLoad.load('acc-expirationReport'); // Resolve promise and load before view 
                        }]
                      }
                })
                .state('securityGovernor.acc-duplicateemployeeid', {
                    url: '/acc-duplicateemployeeid',
                    templateUrl: 'securityGovernor/report/accountReport/acc-duplicateEmployeeId/cloudentix-admin-sg-acc-duplicateemployeeid.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                          return $ocLazyLoad.load('acc-duplicateEmployeeId'); // Resolve promise and load before view 
                        }]
                      }
                })
                .state('securityGovernor.acc-expiration', {
                    url: '/acc-expiration',
                    templateUrl: 'securityGovernor/report/accountReport/acc-expiration/cloudentix-admin-sg-acc-expiration.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                          return $ocLazyLoad.load('acc-expiration'); // Resolve promise and load before view 
                        }]
                      }
                })
                .state('securityGovernor.acc-mapping', {
                    url: '/acc-mapping',
                    templateUrl: 'securityGovernor/report/accountReport/acc-mapping/cloudentix-admin-sg-acc-mapping.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                          return $ocLazyLoad.load('acc-mapping'); // Resolve promise and load before view 
                        }]
                      }
                })
                .state('securityGovernor.acc-mappingsub1', {
                    url: '/acc-mappingsub1/?db&option',
                    templateUrl: 'securityGovernor/report/accountReport/acc-mapping/cdt-admin-sg-acc-mappingsub1.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                          return $ocLazyLoad.load('acc-mapping'); // Resolve promise and load before view 
                        }]
                      }
                })
                .state('securityGovernor.acc-mappingsub2', {
                    url: '/acc-mappingsub2/?db&option',
                    templateUrl: 'securityGovernor/report/accountReport/acc-mapping/cdt-admin-sg-acc-mappingsub2.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                          return $ocLazyLoad.load('acc-mapping'); // Resolve promise and load before view 
                        }]
                      }
                })
                .state('securityGovernor.acc-mappingsub3', {
                    url: '/acc-mappingsub3/?db&option',
                    templateUrl: 'securityGovernor/report/accountReport/acc-mapping/cdt-admin-sg-acc-mappingsub3.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                          return $ocLazyLoad.load('acc-mapping'); // Resolve promise and load before view 
                        }]
                      }
                })
                .state('securityGovernor.acc-mappingsub4', {
                    url: '/acc-mappingsub4/?db&option',
                    templateUrl: 'securityGovernor/report/accountReport/acc-mapping/cdt-admin-sg-acc-mappingsub4.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                          return $ocLazyLoad.load('acc-mapping'); // Resolve promise and load before view 
                        }]
                      }
                })
                .state('securityGovernor.acc-mappingsub5', {
                    url: '/acc-mappingsub5/?db&option',
                    templateUrl: 'securityGovernor/report/accountReport/acc-mapping/cdt-admin-sg-acc-mappingsub5.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                          return $ocLazyLoad.load('acc-mapping'); // Resolve promise and load before view 
                        }]
                      }
                })
                .state('securityGovernor.acc-mappingsub6', {
                    url: '/acc-mappingsub6/?db&option',
                    templateUrl: 'securityGovernor/report/accountReport/acc-mapping/cdt-admin-sg-acc-mappingsub6.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                          return $ocLazyLoad.load('acc-mapping'); // Resolve promise and load before view 
                        }]
                      }
                })
                .state('securityGovernor.acc-mappingsub7', {
                    url: '/acc-mappingsub7/?db&option',
                    templateUrl: 'securityGovernor/report/accountReport/acc-mapping/cdt-admin-sg-acc-mappingsub7.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                          return $ocLazyLoad.load('acc-mapping'); // Resolve promise and load before view 
                        }]
                      }
                })
                .state('securityGovernor.acc-mappingsub8', {
                    url: '/acc-mappingsub8/?db&option',
                    templateUrl: 'securityGovernor/report/accountReport/acc-mapping/cdt-admin-sg-acc-mappingsub8.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                          return $ocLazyLoad.load('acc-mapping'); // Resolve promise and load before view 
                        }]
                      }
                })
                .state('securityGovernor.acc-mappingsub9', {
                    url: '/acc-mappingsub9/?db&option',
                    templateUrl: 'securityGovernor/report/accountReport/acc-mapping/cdt-admin-sg-acc-mappingsub9.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                          return $ocLazyLoad.load('acc-mapping'); // Resolve promise and load before view 
                        }]
                      }
                })
                .state('securityGovernor.acc-mappingsearch', {
                    url: '/acc-mappingsearch/?db&search',
                    templateUrl: 'securityGovernor/report/accountReport/acc-mapping/cdt-admin-sg-acc-mappingsearch.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                          return $ocLazyLoad.load('acc-mapping'); // Resolve promise and load before view 
                        }]
                      }
                })
                .state('securityGovernor.acc-multipleemployeeids', {
                    url: '/acc-multipleemployeeids',
                    templateUrl: 'securityGovernor/report/accountReport/acc-multipleEmployeeIds/cloudentix-admin-sg-acc-multipleemployeeids.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                          return $ocLazyLoad.load('acc-multipleEmployeeIds'); // Resolve promise and load before view 
                        }]
                      }
                })
                .state('securityGovernor.acc-passwordnotification', {
                    url: '/acc-passwordnotification',
                    templateUrl: 'securityGovernor/report/accountReport/acc-passwordNotification/cloudentix-admin-sg-acc-passwordnotification.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                          return $ocLazyLoad.load('acc-passwordNotification'); // Resolve promise and load before view 
                        }]
                      }
                })
                // .state('securityGovernor.rolemanager', {
                //     url: '/rolemanager',
                //     templateUrl: 'securityGovernor/roleManager/cloudentix-admin-sg-rolemanager.html',
                //     resolve: {
                //         loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                //           return $ocLazyLoad.load('rolemanager'); // Resolve promise and load before view 
                //         }]
                //       }
                // })
                .state('rejectedroles', {
                    url: '/rejectedroles',
                    templateUrl: 'attestation/roleManager/cloudentix-admin-sg-rejectedroles.html'
                })
                .state('changePassword', {
                    url: '/changePassword',
                    onEnter: function () {

                    },
                    controller: 'ChangePasswordCtrl',
                    controllerAs: 'changePasswordCtrl',
                    templateUrl: '../change-password.html'
                })

                .state('addresourcestype', {
                    url: '/addresourcestype',
                    //controller: 'ViewResourceController',
                    templateUrl: 'resources/addResource/cloudentix-admin-resources-mainResourcePage.html',
                })
                .state('MySqladdresources', {
                    url: '/MySqladdresources',
                    //controller: 'addrescourcemainctrl',
                    templateUrl: 'resources/addResource/mysql/cloudentix-admin-resources-addResource-mysql-steps.html',
                })
                .state('ADaddresources', {
                    url: '/ADaddresource',
                    templateUrl: 'resources/addResource/activedirectoryResource/cloudentix-admin-resources-addResource-AD-steps.html',
                })
                .state('MsSqladdresources', {
                    url: '/MsSqladdresources',
                    templateUrl: 'resources/addResource/mssql/cloudentix-admin-resources-addResource-mssql-steps.html',
                })
                .state('Oracleaddresources', {
                    url: '/Oracleaddresources',
                    templateUrl: 'resources/addResource/oracle/cloudentix-admin-resources-addResource-oracle-steps.html',
                })
                .state('Office365addresources', {
                    url: '/Office365addresource',
                    templateUrl: 'resources/addResource/office365Resource/cloudentix-admin-resources-addOffice365Resource-steps.html',
                })
                .state('viewResource', {
                    url: '/viewresource',
                    templateUrl: 'resources/cloudentix-admin-resource-viewResource.html',
                })

                .state('roleView', {
                    url: '/roleView',
                    //controller: 'ViewResourceController',
                    templateUrl: 'role/cloudentix-admin-roleview.html',
                })

                .state('adduser', {
                    url: '/adduser',
                    //controller: '',
                    templateUrl: 'users/cloudentix-admin-adduser.html',
                })
                .state('edituser', {
                    url: '/edituser',
                    templateUrl: 'users/cloudentix-admin-edituser.html',
                })
                .state('viewuser', {
                    url: '/viewuser',
                    //controller: '',
                    templateUrl: 'users/cloudentix-admin-viewuser.html'
                })
                .state('viewuserResource', {
                    url: '/viewuserResource',
                    //controller: 'ViewResourceController',
                    templateUrl: 'users/cloudentix-admin-viewuserResource.html'
                })
                .state('reportView', {
                    url: '/reportView',
                    //controller: '',
                    templateUrl: 'reports/cloudentix-admin-accessPolicy.html'
                })
                .state('usercloudentix', {
                    url: '/usercloudentix',
                    //controller: '',
                    templateUrl: 'reports/cloudentix-admin-userCloudentix.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                            return $ocLazyLoad.load('reports'); // Resolve promise and load before view 
                        }]
                    }
                })
                .state('usertarget', {
                    url: '/usertarget',
                    //controller: '',
                    templateUrl: 'reports/cloudentix-admin-usertarget.html',
                    resolve: {
                        loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                            return $ocLazyLoad.load('reports'); // Resolve promise and load before view 
                        }]
                    }
                })
                /* For Dashboard Reports */
                .state('accesspolicyviolationissue', {
                    url: '/accesspolicyviolationissue',
                    //controller: '',
                    templateUrl: 'dashboard/cloudentix-admin-accessPolicy.html'
                })
                .state('userprovisioningissue', {
                    url: '/userprovisioningissue',
                    //controller: '',
                    templateUrl: 'dashboard/cloudentix-admin-userprovisioningissue.html'
                })
                .state('accesspolicyevaluationissue', {
                    url: '/accesspolicyevaluationissue',
                    //controller: '',
                    templateUrl: 'dashboard/cloudentix-admin-accesspolicyevaluationissue.html'
                })
                .state('approvalpolicyevaluationissue', {
                    url: '/approvalpolicyevaluationissue',
                    //controller: '',
                    templateUrl: 'dashboard/cloudentix-admin-approvalpolicyevaluationissue.html'
                })
                .state('usernotProvisioned', {
                    url: '/usernotProvisioned',
                    //controller: '',
                    templateUrl: 'manageSystem/User_Provision/cloudentix-admin-userNotProvision.html'
                })
                .state('userProvisioned', {
                    url: '/userProvisioned',
                    //controller: '',
                    templateUrl: 'manageSystem/User_Provision/cloudentix-admin-userProvision.html'
                });

            $httpProvider.interceptors.push("InterceptorService");

        }
    ]
    );

AppCtrl.$inject = ['$scope', '$location', '$mdSidenav', '$mdDialog', '$state', '$mdToast', '$document', 'loaderService', '$rootScope', 'SessionService'];
function AppCtrl($scope, $location, $mdSidenav, $mdDialog, $state, $mdToast, $document, loaderService, $rootScope, SessionService) {
    // $scope.loaderService = loaderService;
    $rootScope.loginuser = '';
    $rootScope.loadStatus = loaderService.loadData(false);
    //console.log($location.hash);
    //alert($scope.loadStatus);
    //var username = sessionStorage.getItem("firstname");
    //this.username = username;
    var usertype = localStorage.getItem("usertype");
    if (usertype == 'Admin') {
        var username = "Administrator"
        this.username = username;
    } else {
        var username = localStorage.getItem("firstname");
        this.username = username;
    }


    $scope.toastMessage = function (type, msg) {
        var icon;
        if (type == 'toast-success') {
            icon = 'done';
        } else if (type == 'toast-error') {
            icon = 'error_outline';
        } else if (type == 'toast-warn') {
            icon = 'warning';
        } else {
            icon = 'info_outline';
        }
        $mdToast.show({
            template: '<md-toast class="md-toast ' + type + '"><div class="md-toast-content"><i class="material-icons">' + icon + '</i>&nbsp;&nbsp;' + msg + '</div></md-toast>',
            hideDelay: 3000,
            position: 'top right'
        });
    };

    $scope.showSimpleToast = function () {
        $mdToast.show({
            template: '<md-toast class="md-toast toast-info"><div class="md-toast-content"><i class="material-icons">verified_user</i>&nbsp;&nbsp;Welcome ' + username + '!</div></md-toast>',
            hideDelay: 3000,
            position: 'top right'
        });
    };



    $scope.showSimpleToast(this.click);
    //$scope.toastMessage('toast-error','Hi')	;
    var originatorEv;

    this.openMenu = function ($mdOpenMenu, ev) {
        originatorEv = ev;
        $mdOpenMenu(ev);
    };

    originatorEv = null;

    $scope.toggleSidenav = function (menuId) {
        $mdSidenav(menuId).toggle();
    };

    $scope.sidebarActive = function (activePath, defaultPath) {
        activePath = activePath.replace('#', '');
        locationPath = $location.path();
        if (locationPath === defaultPath) {
            return 'sidebar-active';
        } else {
            locationPath = locationPath.replace('/', '');
            if (activePath === locationPath) {
                return 'sidebar-active';
            } else {
                return '';
            }
        }
    }

    var redirect = sessionStorage.getItem('url');
    if (redirect == null) {

        if (localStorage.getItem("selectedTab") == null) {
            if (sessionStorage.getItem('mailurl') != null) {
                var tabs = [];
                tabs.push({
                    title: "My Cloudentix",
                    tabLink: "myCloudentix.pendingapproval",
                    disabled: false
                });
            } else if (sessionStorage.getItem('mailurl') == null) {
                var tabs = [];
                tabs.push({
                    title: 'Dashboard',
                    tabLink: "dashboard",
                    disabled: false
                });
            }
        } else {
            if (localStorage.getItem("autologout") == "true") {
                var tabs = [];
                tabs.push({
                    title: 'Dashboard',
                    tabLink: "dashboard",
                    disabled: false
                });
            } else {
                var tabs = [];
                tabs.push(JSON.parse(localStorage.getItem("selectedTab")));
            }
        }
    } else {

        var tabs = [];
        tabs.push(JSON.parse(sessionStorage.getItem("TabDetails")));
    }
    var selected = null,
        previous = null;
    $rootScope.tabs = tabs;
    $scope.selectedIndex = 0;
    $scope.$watch('selectedIndex', function (current, old) {
        //console.log( $scope.selectedIndex);
        previous = selected;
        selected = tabs[current];
        $rootScope.selectedtab = tabs[current];
        localStorage.setItem('selectedTab', JSON.stringify($rootScope.selectedtab));
        /* if ( old + 1 && (old != current)) $log.debug('Goodbye ' + previous.title + '!');
         if ( current + 1 )                $log.debug('Hello ' + selected.title + '!');*/
    });
    $rootScope.addTab = function (title, view, userid, resId, typeId, resName) {
        //alert(userid)
        if (title == 'View Resources') {
            sessionStorage.setItem('trustedValue', userid);
            sessionStorage.setItem("resourceid", resId);
            sessionStorage.setItem("typeId", typeId);
            sessionStorage.setItem("resName", resName);
        }
        //console.log(title);
        if (userid != undefined && userid != '') {
            sessionStorage.setItem('userGuid', userid);
        }
        var tabLength = tabs.length;

        var tempTab = 0;
        for (var i = 0; i < tabLength; i++) {
            //console.log(tabs[i].title);
            if ((tabs[i].title == title) && (tabs[i].tabLink == view)) {
                tempTab = 1;

            }
        }

        if (tempTab == 0) {
            tabs.push({
                title: title,
                tabLink: view,
                disabled: false
            });

        } else {

            var tabIndex = tabs.findIndex(tabArray => tabArray.title == title);
            $scope.selectedIndex = tabIndex;
        }
        //$state.go(view);
    };
    $rootScope.removeTab = function (tab) {
        var index = tabs.indexOf(tab);
        var prevTab = index - 1;
        var nextTab = index + 1;
        if (index > 0) {
            var newUrl = tabs[prevTab].tabLink;
            $state.go(newUrl);
            $scope.selectedIndex = prevTab;
            tabs.splice(index, 1);
        } else {
            var newUrl = tabs[nextTab].tabLink;
            $state.go(newUrl);
            $scope.selectedIndex = index;
            tabs.splice(index, 1);
        }
    };
    $scope.resouceconfigureMessage = function (content) {
        $mdDialog.show({
            controller: resourceConfiguredModal,
            templateUrl: 'resouceConfigure/resouceConfiguremodal.html',
            parent: angular.element(document.body),
            clickOutsideToClose: false,
            locals: {
                items: content
            },
        })
    }
    $scope.errorHandler = function (urlvalue, status) {
        void 0
        if (status === 404) {
            $mdDialog.show({
                controller: errorHandleModel,
                templateUrl: 'resouceConfigure/404.html',
                parent: angular.element(document.body),
                clickOutsideToClose: true,
                locals: {
                    url: urlvalue
                },
            })
        }
        if (status === 500) {
            $mdDialog.show({
                controller: errorHandleModelISE,
                templateUrl: 'resouceConfigure/500.html',
                parent: angular.element(document.body),
                clickOutsideToClose: true,
                locals: {
                    url: urlvalue
                },
            })
        }
        if (status === 400) {
            $scope.toastMessage('toast-error', 'Invalid header param or missing header param');
        }
        if (status === 401) {
            $scope.toastMessage('toast-error', "User can't access the api without authentication");
        }
        if (status === undefined) {
            $scope.toastMessage('toast-error', urlvalue);
        }
    }
    $rootScope.autologoutMessage = function (content1) {
        $mdDialog.show({
            controller: autologout,
            templateUrl: 'logout.html',
            parent: angular.element(document.body),
            clickOutsideToClose: false,
            locals: {
                autologoutMsg: content1
            },
        })
    };
    //$route.reload();
}
autologout.$inject = ['$scope', '$state', '$mdDialog', '$rootScope', 'autologoutMsg', '$rootScope', '$http', '$window', '$location', 'SessionService'];
function autologout($scope, $state, $mdDialog, $rootScope, autologoutMsg, $rootScope, $http, $window, $location, SessionService) {

    $scope.autologoutMessage = autologoutMsg;
    $rootScope.validatesessionTimedout = 1;
    if (localStorage.getItem("username") != null) {
        $rootScope.loginuser = localStorage.getItem("username");
        $rootScope.reLoginPath = $location.url().replace('/', '');
    }
    //sessionStorage.clear();
    //localStorage.clear();


    // console.log($location.url())

    void 0;

    $scope.closelogout = function () {
        var logoutURL = baseUrl + "/logout";
        var config = {
            url: logoutURL,
            method: "GET",
            dataType: 'json',
            async: false,
            headers: {
                "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                "cdt-uname": $rootScope.loginuser
            }
        }

        $http(config).then(function success(response) {
            $mdDialog.hide();
            localStorage.setItem("autologout", "true");
            sessionStorage.setItem("url", $location.url().replace('/', ''));
            sessionStorage.setItem("TabDetails", JSON.stringify($rootScope.selectedtab));
            $window.location.href = '../index.html';
        }, function error(response) { });
    };
}
resourceConfiguredModal.$inject = ['$scope', '$state', '$mdDialog', '$rootScope', 'items', '$rootScope'];
function resourceConfiguredModal($scope, $state, $mdDialog, $rootScope, items, $rootScope) {

    $scope.resourceMessage = items;
    $scope.closeResourceMessage = function () {
        $mdDialog.hide();
        $state.go("addresourcestype");
        $rootScope.addTab('Add Resource', 'addresourcestype');
    };
}
errorHandleModel.$inject = ['$scope', '$state', '$mdDialog', '$rootScope', 'url', '$window'];
function errorHandleModel($scope, $state, $mdDialog, $rootScope, url, $window) {

    $scope.url = url;
    $scope.closeerrorMessage = function () {
        $mdDialog.hide();
        $window.location.href = '../index.html';
        //$state.go("addresourcestype");
        //$rootScope.addTab('Add Resource', 'addresourcestype'); 
    };
}
errorHandleModelISE.$inject = ['$scope', '$state', '$mdDialog', '$rootScope', 'url', '$window'];
function errorHandleModelISE($scope, $state, $mdDialog, $rootScope, url, $window) {

    $scope.url = url;
    $scope.closeerrorMessage = function () {
        $mdDialog.hide();
        $window.location.href = '../index.html';
        //$state.go("addresourcestype");
        //$rootScope.addTab('Add Resource', 'addresourcestype'); 
    };
    $scope.previoustab = function () {
        $mdDialog.hide();
    }
}