angular
    .module('cloudentixApp')
	.controller('ADaddresourcemainctrl', adMain)
    .controller('ADaddresourcefirstsetupCtrl', adFirstSetup)
	.controller('ADaddresourcesetupCtrl', adSetup)
	.controller('ADuserattrmappingcontroller', adReconAttributeRole)
	.service('keepVal', function(){
		this.adStore = function(x){
		  this.storeAD = x;
		}
		this.adGetVal = function(){
		  return this.storeAD;
		}
	})
	.service('keepValsetup', function(){
		this.setupStore = function(x){
		  this.storesetup = x;
		}
		this.setupGetVal = function(){
		  return this.storesetup;
		}
	})
	.factory('selectTabService', function(){
		var tabActive = '0';
		return {  
			tabActive: function() { return tabActive; },
			setTabActive: function(x) { tabActive = x; }
		};
		})
	.run(['$rootScope', '$state', '$stateParams',
        function($rootScope, $state, $stateParams) {
            $rootScope.$state = $state;
            $rootScope.$stateParams = $stateParams;
        }
    ])
	.config(
        ['$stateProvider', '$urlRouterProvider',
            function($stateProvider, $urlRouterProvider) {
                $urlRouterProvider
                $stateProvider
                .state('ADaddresources.adaddrsc', {
                    url: '/ADaddresource',
                    templateUrl: 'resources/addResource/activedirectoryResource/cloudentix-admin-resources-addResource-AD-setup-inital.html',
                })
				.state('ADaddresources.Details', {
					url: '/adDetails',
					templateUrl: 'resources/addResource/activedirectoryResource/cloudentix-admin-resources-addResource-AD-setup.html'
				})
				.state('ADaddresources.ADreconattributerule', {
					url: '/ADreconattributerule',
					templateUrl: 'resources/addResource/activedirectoryResource/cloudentix-admin-resources-addResource-AD-reconattributerule.html'
				})
            }
        ]
	);
	adMain.$inject = ['$scope', '$log', '$state', '$rootScope', '$location', 'keepVal', 'keepValsetup', 'SessionService'];
	adFirstSetup.$inject = ['$http', '$scope', '$rootScope', '$log', '$state', '$location', 'keepVal', 'SessionService'];
	adSetup.$inject = ['$http', '$scope', '$rootScope', '$log', '$state', '$location', 'keepValsetup', 'keepVal', 'SessionService'];
	adReconAttributeRole.$inject = ['$http', '$scope', '$log', '$rootScope', '$state', 'keepRecon', 'keepValsetup', 'keepVal', '$mdDialog', '$location', 'SessionService'];
	var  Resourcetabs;
	function adMain($scope, $log, $state, $rootScope, $location, keepVal, keepValsetup, SessionService) {
		keepVal.storeAD = undefined;
		keepValsetup.storesetup = undefined;
		Resourcetabs = [
			{ title: 'Setup', tabLink: "ADaddresources.adaddrsc", tabSerial : "1"},
			{ title: 'Resource Details', tabLink: "ADaddresources.Details", tabSerial : "2"}
			/*{ title: 'Reconciliation Rule', tabLink: "ADaddresources.ADreconattributerule", tabSerial : "2"}*/     
		],
		selected = null,
		previous = null;
		$rootScope.Resourcetabs = Resourcetabs;
		$scope.selectedIndex = 0;
		$rootScope.loadWidth = 33;
		$scope.selectTabService = 0;
		$scope.$watch('selectedIndex', function(current, old){
			previous = selected;
			selected = Resourcetabs[current];
		});
		$scope.wizardActive = function(activePath){
			var activePath = activePath.replace('#','')
			activePath = activePath.replace('.','/');
			locationPath = $location.path();
			locationPath = locationPath.replace('/','');
			if(activePath === locationPath){
				return 'wizard-active';
			} 
			else {
				return '';
			}  
		}
	}
	function  adFirstSetup($http, $scope, $rootScope, $log, $state, $location, keepVal, SessionService) {
		var tabLength = $rootScope.Resourcetabs.length;
		var checkResourceURL = baseUrl + '/resources?check=true';
		var config = {
			url: checkResourceURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
			}
		}
		$http(config)
		.then(function success(response) {
			$rootScope.loaderCurrentStatus = 'false';
			if(response.data.type == 'success'){
				if (response.data.data.login[0].trusted == 'N') {
					$scope.TrustedAvailable = true;
					if(tabLength == 2)
						$rootScope.loadWidth = 50;
				} else if (response.data.data.login[0].trusted == 'Y') {
					$scope.TrustedAvailable = false;
					if(tabLength == 2) {
						$rootScope.Resourcetabs.push({ title: 'Reconciliation Rule', tabLink: "ADaddresources.ADreconattributerule",  tabSerial : "3"});
					}	
				}
			}
			else if(response.data.type == 'error'){
				$scope.toastMessage('toast-error',response.data.message);
			}
			else if(response.data.type == 'warning'){
				$scope.toastMessage('toast-warn',response.data.message);
			}
			
		},function error(response){
			// It will work when the server returns the status "500 - Internal server" or 400 series errors
			$rootScope.loaderCurrentStatus = 'false';
			$scope.errorHandler(response.config.url,response.status);
		});
		$scope.form = {};
		var adVal = keepVal.adGetVal();
		if(adVal != undefined) {
			if(tabLength === 3)
				$rootScope.loadWidth = 33;
			$scope.form.resourceName = adVal.resourceName;
			$scope.form.radiobuttonmodel = adVal.radiobuttonmodel;
		}
		$scope.selectTabService = 0;
		$scope.next = function(Resourcetabs){ 
			keepVal.adStore($scope.form);
			var resourcename = $scope.form.resourceName;           
			var istrusted = $scope.form.radiobuttonmodel;
			var addResourceuntrustedsecstepURL = baseUrl + '/addrscAD/chkrscname';   
			var config = 
			{
				url: addResourceuntrustedsecstepURL,
				method: "GET",
				headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
					"cdt-rescname":resourcename,
					"cdt-istrusted": istrusted,
						}
			}
			$http(config)
				.then(function success(response) {
			if(response.data.type == "success")
			{
				var cTab = $scope.selectedIndex + 1;
				if((cTab == '1') && (istrusted == 'N')){
				$rootScope.loadWidth = 66;
				} 
				if((cTab == '1') && (istrusted == 'Y')){
					 $rootScope.loadWidth = 100;
				} 
				tabLength = Resourcetabs.length;
				
				if(istrusted == 'N'){	
					if(tabLength == '2')
					Resourcetabs.push({ title: 'Reconciliation Rule', tabLink: "ADaddresources.ADreconattributerule",  tabSerial : "3"});
					} else {
					var tabIndex = Resourcetabs.findIndex(ResourcetabsArray => ResourcetabsArray.tabSerial == '3' );
					if(tabLength == '3')
					Resourcetabs.splice(tabIndex, 1);
					}
					$scope.selectedIndex = Math.min($scope.selectedIndex + 1, 5);
					var nextTab = $scope.selectedIndex;	
					var gotoUrl =  $rootScope.Resourcetabs[nextTab].tabLink;
				$state.go(gotoUrl);	
			}
			else if(response.data.type == "error")
			{
				$scope.toastMessage('toast-error',response.data.message);
				$state.go('ADaddresources.adaddrsc');
			}	
			else if(response.data.type == "warning"){
				$scope.toastMessage('toast-warn',response.data.message);
				$state.go('ADaddresources.adaddrsc');
				}
			},function error(response){
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				$rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);
				});  
		}
	}
		     
   function  adSetup($http, $scope, $rootScope, $log, $state, $location, keepValsetup,keepVal, SessionService){
        $scope.form = {};
        $scope.selectTabService = 1;
        var adVal = keepValsetup.setupGetVal();
        var adFirstVal = keepVal.adGetVal();
        if(adFirstVal == undefined) {
            $location.url('/ADaddresources/ADaddresource');
        } else {
            var resourcename = adFirstVal.resourceName;
            var istrustedval = adFirstVal.radiobuttonmodel;
            $scope.form.istrust = adFirstVal.radiobuttonmodel;
        }
        if(adVal != undefined){
			if(Resourcetabs.length == 3)
				$rootScope.loadWidth = 66;
            $scope.form.hostName = adVal.hostName;
            $scope.form.userName = adVal.userName;
            $scope.form.password = adVal.password;
            $scope.form.Port = adVal.Port;
            $scope.form.databaseName = adVal.databaseName;
        }
	/*This method load when it's trusted
	*/
		$scope.addrescsetupsubmit = function(Resourcetabs)
	    { 
			$rootScope.loaderCurrentStatus = 'true';
			var hostname = $scope.form.hostName;
			var username = $scope.form.userName;
			var password = $scope.form.password;
			var port = $scope.form.Port;
			var databasename = $scope.form.databaseName;     
			var addResourcetrustFinalURL = baseUrl + '/addrscAD/final';
			var config = {
				url: addResourcetrustFinalURL,
				method: "POST",
				headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
					"cdt-id":'4',
					"cdt-rescname":resourcename,
					"cdt-host":hostname,
					"cdt-username":username,
					"cdt-pwd":password, 
					"cdt-port":port,
					"cdt-istrusted": istrustedval,
					"cdt-dns": databasename,
						}
			}
			$http(config)
				.then(function success(response) {
					 $rootScope.loaderCurrentStatus = 'false';
		   if(response.data.type == "success"){
				$scope.toastMessage('toast-success',response.data.message);
				$state.go('resources');
				$scope.addTab('Resources','resources');
			}
			else if(response.data.type == "error"){
				$scope.toastMessage('toast-error',response.data.message);
				}
			else if(response.data.type == "warning"){
				$scope.toastMessage('toast-warn',response.data.message);
				}
			},function error(response) {
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);

		  });     
		};
       
	  /*This method loads when it's un trusted
	  */
		$scope.next = function(Resourcetabs) 
		{		
		$rootScope.loaderCurrentStatus = 'true';
		keepValsetup.setupStore($scope.form);
		var hostname = $scope.form.hostName;
		var username = $scope.form.userName;
		var password = $scope.form.password;
		var port = $scope.form.Port;
		var databasename = $scope.form.databaseName;     
		
		var addResourceuntrustedsecstepURL = baseUrl + '/addrscAD/chkrscdetails';
		var config = {  
				url: addResourceuntrustedsecstepURL,
				method: "GET",
				headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
					"cdt-host":hostname,
					"cdt-username":username,
					"cdt-pwd":password, 
					"cdt-port":port,
					"cdt-dns": databasename,
						}
			}
			$http(config)
				.then(function success(response) {
					$rootScope.loaderCurrentStatus = 'false';
				if(response.data.type == "success"){
					var cTab = $scope.selectedIndex + 1;
					if((cTab == '2') && (istrustedval == 'N')){
						$state.go("ADaddresources. ADreconattributerule");
						$rootScope.loadWidth = 100;
					} 
					var tabLength = Resourcetabs.length;
					$scope.selectedIndex = Math.min($scope.selectedIndex + 2, 5) ;

					var nextTab = $scope.selectedIndex;	
					var gotoUrl =  $rootScope.Resourcetabs[nextTab].tabLink;
					if($location.path() == '/ADaddresources/ adDetails'){
						$rootScope.loadWidth = 100;
						$state.go("ADaddresources.ADreconattributerule");
					}else{
						$state.go(gotoUrl);	
					}
			}
			else if(response.data.type == "error"){
				$scope.toastMessage('toast-error',response.data.message);
				$state.go('ADaddresources.Details');
			}	
			else if(response.data.type == "warning"){
				$scope.toastMessage('toast-warn',response.data.message);
				$state.go('ADaddresources.Details');
				}	
			},function error(response) {
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				$rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);

			});
		};
		$scope.previous = function(Resourcetabs) {
			$scope.selectedIndex = Math.max($scope.selectedIndex - 2, 0);
			var prevTab = $scope.selectedIndex;
			var gotoUrl = $rootScope.Resourcetabs[prevTab].tabLink;
			var tabLength = Resourcetabs.length;
			var cTab = $scope.selectedIndex + 1;
			if((cTab == '1') && (tabLength == '3')){
				 $rootScope.loadWidth = 33;
			} else {
				$rootScope.loadWidth = 50;
			}
			$state.go(gotoUrl);
		};  	
	}
	function  adReconAttributeRole($http, $scope, $log, $rootScope, $state, keepRecon, keepValsetup, keepVal, $mdDialog, $location, SessionService) {	 
		$rootScope.userattributetitle = false;
		$rootScope.loadWidth = 100;
		$rootScope.count=0;
		$scope.form={};
		$rootScope.listAttributes = [];
		$rootScope.finalMappingColumn = {"records": []};
		$scope.selectTabService = 2;
		var adVal = keepValsetup.setupGetVal();
		var adFirstVal = keepVal.adGetVal();
		if(adFirstVal == undefined) {
			$location.url('/ADaddresources/ADaddresource');
		} else {
			var resourcename = adFirstVal.resourceName;
			var istrustedval = adFirstVal.radiobuttonmodel;
		}
		var hostname = adVal.hostName;
		var username = adVal.userName;
		var password = adVal.password;
		var port = adVal.Port;
		var databasename = adVal.databaseName;
		$rootScope.count=0;
		  //add button
		$scope.userattributesvalues={"records": []};
		$scope.userattributeaddbutton=function($event,$scope){
		$mdDialog.show({
		   controller: addADReconController,
			controllerAs: 'adreconrulectrl',
			templateUrl: 'resources/addResource/activedirectoryResource/cloudentix-admin-resources-addResource-AD-reconRule.html',
			parent: angular.element(document.body),
			targetEvent: $event,
			clickOutsideToClose:false
		  })
		}
		//delete button
		$scope.Deleterecon=function(index){
			$rootScope.count--;			
			$rootScope.listAttributes.splice(index, 1);
			$rootScope.finalMappingColumn.records.splice(index, 1);
			if($rootScope.listAttributes.length === 0) {
				$rootScope.userattributetitle = false;
			}
		}	
		$scope.previous = function(Resourcetabs) {
		  $scope.selectedIndex = Math.max($scope.selectedIndex + 1, 0);
		  var prevTab = $scope.selectedIndex;
		  var gotoUrl = $rootScope.Resourcetabs[prevTab].tabLink;
		  $state.go(gotoUrl);
		  $rootScope.loadWidth = 50;

		}; 
		$scope.ADresourcesubmit = function() {
			$rootScope.loaderCurrentStatus = 'true';
			var addResourceFinalURL = baseUrl + '/addrscAD/final';
			$scope.finalAttribute = {'records':[]};
			angular.forEach($rootScope.finalMappingColumn.records, function(value, key) {
				var array = [];
				var array1 = [];
				if(value["userAttrId"]== '1'){
							$scope.userAttrId = value["userAttrId"];
							array.push(value["concat1"]+','+value["concat2"]);						
						}
						//SubString User Attribute Mapping
						else if(value["userAttrId"]== '2'){
							$scope.userAttrId = value["userAttrId"];
							array.push(value["substringMapping"]+','+value["substring"]);						
						}
						//DirectMapping User Attribute Mapping
						else if(value["userAttrId"]== '3'){
							$scope.userAttrId = value["userAttrId"];
							array.push(value["directmapping"]);
						}
						//Target Attribute Mapping
						//Concat Target Attribute Mapping
						if(value["targetCol"]== '1'){
							$scope.targetuserAttrId = value["targetCol"];
							array1.push(value["targetConcat1"]+','+value["targetConcat2"]);					
						}
						//SubString Target Attribute Mapping
						else if(value["targetCol"]== '2'){
							$scope.targetuserAttrId = value["targetCol"];
							array1.push(value["targetsubstringMapping"]+','+value["targetSubstring"]);						
						}
						//DirectMapping Target Attribute Mapping
						else if(value["targetCol"]== '3'){
							$scope.targetuserAttrId = value["targetCol"];
							array1.push(value["targetdirectMapping"]);
						}
						//array1.push(value["targetCol"]);
						$scope.finalAttribute.records.push({"cloudusrattr":[{"methodid": $scope.userAttrId,"col": array}], "trgtusrattr":[{"methodid":$scope.targetuserAttrId,"col": array1}]});
				   
			   // array.push(value["userAttrId"]);
				//array1.push(value["targetCol"]);
				//$scope.finalAttribute.records.push({"cloudusrattr":[{"methodid": '3',"col": array}], "trgtusrattr":[{"methodid":"3","col": array1}]});
			});
			var data = angular.toJson($scope.finalAttribute);
			//console.log(angular.toJson($scope.finalAttribute));
			// console.log(resourcename +" "+istrustedval+" "+hostname+" "+username+" "+password+" "+port+" "+databasename)
			var config = {
				url : addResourceFinalURL,
				method :"POST",
				headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
					"cdt-id": '4',
					"cdt-rescname": resourcename,
					"cdt-host": hostname,
					"cdt-username": username,
					"cdt-pwd": password, 
					"cdt-port": port,
					"cdt-istrusted": istrustedval,
					"cdt-dns": databasename,
					"cdt-reconattribute": data,
					"cdt-singlerole": 'N'
				}
			}				
			$http(config)
				.then(function success(response) {
					$rootScope.loaderCurrentStatus = 'false';
				if(response.data.type == "success"){
					$scope.toastMessage('toast-success',response.data.message);
					$state.go('resources');
					$scope.addTab('Resources','resources');
					}
			
				else if(response.data.type == "error"){
					$rootScope.loaderCurrentStatus = 'false';
					$scope.toastMessage('toast-error',response.data.message);
					}
				
				else if(response.data.type == "warning"){
					$rootScope.loaderCurrentStatus = 'false';
					$scope.toastMessage('toast-warn',response.data.message);
					}
			},function error(response) {
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);
			});		 
		};	 
	}
	function addADReconController($http, $scope, $rootScope, $state,$mdDialog,keepUDM,keepRecon, SessionService){
		$scope.form={};
		var length=$rootScope.listAttributes.length;
		var tableval=keepUDM.primaryTableGetVal();
		var self = this;
		$scope.userattributesvalue = {"records": []};
		$scope.reconruleSelected = '';					
		var addResourceUserMappingMethodURL = baseUrl + '/method';
		var config = {
			url: addResourceUserMappingMethodURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
			}
		}
		$http(config)
			.then(function success(response) {
			$rootScope.loaderCurrentStatus = 'false';
			$scope.userResponse = response.data.type;   	
			$scope.addMappinguserattributes = [];     
			if (response.data.type == "success") {			
				for(var i=0;i<response.data.records[0].dropdownlist.length;i++)
				{
					$scope.addMappinguserattributes.push({"id":response.data.records[0].dropdownlist[i].key,"value":response.data.records[0].dropdownlist[i].value});
					if(response.data.records[0].dropdownlist[i].key=="3"){
						$scope.reconruleSelected=response.data.records[0].dropdownlist[i].value;
					}	
				}
				}
				else {
						$scope.managesystemErrorMessage = response.message;
					}
			},function error(response) {
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);

		  });	
			var addResourceUserAttributesMappingURL = baseUrl + '/userattributes';
			var config = {
				url: addResourceUserAttributesMappingURL,
				method: "GET",
				headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
				}
			}
			$http(config)
				.then(function success(response) {        
				$scope.resourceuserattributes = [];               
					for(var i=0;i<response.data.records[0].listattributes.length;i++)
					{
						$scope.resourceuserattributes.push({"id":response.data.records[0].listattributes[i].colname,"value":response.data.records[0].listattributes[i].displayname});
					}
			},function error(response) {
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				rootScope.loaderCurrentStatus = 'false';
				$scope.errorHandler(response.config.url,response.status);

		  });
			var AdlistColumns = baseUrl + '/addrscAD/gettargetcol';
			var config = {
			url: AdlistColumns,
			method: "GET",
			headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
				}
			}
			$http(config)
				.then(function success(response) {
				$scope.targetcolumns=[];
				angular.forEach(response.data.records[0].targetcolumns, function(value,key) {
					$scope.targetcolumns.push(value); 
				});
			},function error(response) {
				// It will work when the server returns the status "500 - Internal server" or 400 series errors
				$scope.errorHandler(response.config.url,response.status);
		  });
		self.cancel = function($event) {
		  $mdDialog.cancel();
		}
		self.finish = function($event) {
			$rootScope.listAttributes.push({});
			if($scope.userattributesvalue.records[0].userAttrId=='1'){
				var userConcat="concat("+$scope.userattributesvalue.records[0].concat1+","+$scope.userattributesvalue.records[0].concat2+")";
				$scope.attrId=$scope.userattributesvalue.records[0].userAttrId;
				$scope.userAttrConcat=userConcat;
				//console.log($scope.userattributesvalue.records[0].concat1);
				$rootScope.listAttributes[length].userattribute = userConcat;
			}
			else if($scope.userattributesvalue.records[0].userAttrId=='2'){
				var userSubstring="substring("+$scope.userattributesvalue.records[0].substringMapping+","+$scope.userattributesvalue.records[0].substring+")";
				//console.log(userSubstring);
				$rootScope.listAttributes[length].userattribute = userSubstring;
			}
			else if($scope.userattributesvalue.records[0].userAttrId=='3'){
				var userDirectMapping="directmapping("+$scope.userattributesvalue.records[0].directmapping+")";
				//console.log(userDirectMapping);
				$rootScope.listAttributes[length].userattribute = userDirectMapping;
			}
			if($scope.userattributesvalue.records[0].targetCol=='1'){
				var targetConcat="concat("+$scope.userattributesvalue.records[0].targetConcat1+","+$scope.userattributesvalue.records[0].targetConcat2+")";
				//console.log(targetConcat);
				$rootScope.listAttributes[length].targetattribute = targetConcat;
			}
			else if($scope.userattributesvalue.records[0].targetCol=='2'){
				var targetSubstringMapping="substring("+$scope.userattributesvalue.records[0].targetsubstringMapping+","+$scope.userattributesvalue.records[0].targetSubstring+")";
				//console.log(targetSubstringMapping);
				$rootScope.listAttributes[length].targetattribute = targetSubstringMapping;
			}
			else if($scope.userattributesvalue.records[0].targetCol=='3'){
				var targetAttrDirectMapping="directmapping("+$scope.userattributesvalue.records[0].targetdirectMapping+")";
				//console.log(targetAttrDirectMapping);
				$rootScope.listAttributes[length].targetattribute = targetAttrDirectMapping;
			}
			$rootScope.finalMappingColumn.records.push($scope.userattributesvalue.records[0]);
			//console.log($rootScope.finalMappingColumn);	
			$mdDialog.hide();
			var arr=[];
			angular.forEach($rootScope.listAttributes, function(value, key) {
			arr.concat([arr.push(value.userattribute + ' '+value.targetattribute)]);
			});
			//console.log(arr);
			var uniqOb = {};
			for (var i in arr)
				uniqOb[arr[i]] = "";
			if (arr.length == Object.keys(uniqOb).length){
			}
			else{
			$rootScope.listAttributes.splice(-1, 1);
			$rootScope.finalMappingColumn.records.splice(-1, 1);
			  $mdDialog.show(
				$mdDialog.alert()
				.clickOutsideToClose(false)
				.title('Recon Rule')
				.textContent('Selected Recon Rule already exists. Please select a different User Attributes Mapped Column and Target Attributes Mapped Column')
				.ok('ok')
			);
			}
			$rootScope.userattributetitle = true;
			$rootScope.count++;
		};

	}