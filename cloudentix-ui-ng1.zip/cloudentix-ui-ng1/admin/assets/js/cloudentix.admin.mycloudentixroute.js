
angular
    .module('cloudentixApp')
	.controller('mycloudentixtab', mycloudentixtab)

	  .run(
      ['$rootScope', '$state', '$stateParams',
        function($rootScope, $state, $stateParams) {
                
          $rootScope.$state = $state;
          $rootScope.$stateParams = $stateParams;
        }
      ]
    )
    .config(
      ['$stateProvider', '$urlRouterProvider',
        function($stateProvider, $urlRouterProvider) {

          $urlRouterProvider
          $stateProvider

			
          .state('myCloudentix.pendingapproval', {
              url: '/pendingapproval',
             controller: function($scope) {

              },
              templateUrl: 'myCloudentix/sub-myCloudentix/cloudentix-admin-myCloudentix-pendingapproval.html',
              data: {
				  'selectedTab': 0
				}
            })
            .state('myCloudentix.accessrequests', {
              url: '/accessrequests',
              controller: function($scope) {

              },
              templateUrl: 'myCloudentix/sub-myCloudentix/cloudentix-admin-myCloudentix-requestaccess.html',
              data: {
				  'selectedTab': 1
				}
            })
       
		}
      ]
    );
    mycloudentixtab.$inject = ['$scope', '$log', '$location', '$window', '$http', '$state'];
		function mycloudentixtab($scope, $log, $location, $window, $http, $state) {
			var cloudentixtabs = [
          { title: 'Pending Approval', tabLink: "myCloudentix.pendingapproval"},
		  { title: 'List of Access Requests', tabLink: "myCloudentix.accessrequests"}
        ],
		 selected = null,
        previous = null;
		$scope.cloudentixtabs = cloudentixtabs;
		$scope.selectedIndex = $state.current.data.selectedTab;
		//$scope.selectedIndex = 0;
		/* $scope.attestationtabs = [];
		 attestationtabs.push (
          { title: 'Self Attestion', tabLink: "attestation.selfattestion"},
		  { title: 'Pending Attestation', tabLink: "attestation.pendingattestation"},
		  { title: 'History Attestation', tabLink: "attestation.historyattestation"}
        );
		console.log(attestationtabs);
		//$scope.attestationtabs = attestationtabs;*/
	}