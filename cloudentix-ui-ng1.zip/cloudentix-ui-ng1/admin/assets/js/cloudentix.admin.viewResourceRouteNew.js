
angular
    .module('cloudentixApp')
	.controller('viewResourceController', viewResourceCtrl)

	  .run(
      ['$rootScope', '$state', '$stateParams',
        function($rootScope, $state, $stateParams) {
                
          $rootScope.$state = $state;
          $rootScope.$stateParams = $stateParams;
        }
      ]
    )
    .config(
      ['$stateProvider', '$urlRouterProvider',
        function($stateProvider, $urlRouterProvider) {

          $urlRouterProvider
          $stateProvider

			
          .state('viewResource.prepopulate', {
              url: '/viewResource/Prepopulate',
             controller: function($scope) {

              },
              templateUrl: 'resources/viewResource/prepopulate/cloudentix-admin-viewResourcePrepopulate.html',
              data: {
				  'selectedTab': 0
				}
            })
            .state('viewResource.role', {
              url: '/viewResource/Roles',
             controller: function($scope) {

              },
              templateUrl: 'resources/viewResource/cloudentix-admin-viewResourceRoles.html',
              data: {
				  'selectedTab': 0
				}
            }) 
            .state('viewResource.lookup', {
              url: '/viewResource/lookup',
             controller: function($scope) {

              },
              templateUrl: 'resources/viewResource/cloudentix-admin-viewResourceLookup.html',
              data: {
				  'selectedTab': 0
				}
            })
            .state('viewResource.users', {
              url: '/viewResource/Users',
             controller: function($scope) {

              },
              templateUrl: 'resources/viewResource/cloudentix-admin-viewResourceUsers.html',
              data: {
				  'selectedTab': 0
				}
            })
            .state('viewResource.reconciliation', {
              url: '/viewResource/reconciliation',
             controller: function($scope) {

              },
              templateUrl: 'resources/viewResource/cloudentix-admin-viewResourcerecon.html',
              data: {
				  'selectedTab': 0
				}
            })
            .state('viewResource.setup', {
              url: '/viewResource/setup',
             controller: function($scope) {

              },
              templateUrl: 'resources/viewResource/cloudentix-admin-viewResourceSetup.html',
              data: {
				  'selectedTab': 0
				}
            })
            
       
		}
      ]
    );
    viewResourceCtrl.$inject = ['$scope', '$log', '$location', '$window', '$http', '$state'];
		function viewResourceCtrl($scope, $log, $location, $window, $http, $state) {
			var viewResourceTabs = [
          { title: 'Roles', tabLink: "viewResource.role"},
          { title: 'Lookup', tabLink: "viewResource.lookup"},
          { title: 'Users', tabLink: "viewResource.users"},
          { title: 'Reconciliation', tabLink: "viewResource.reconciliation"},
          { title: 'Setup', tabLink: "viewResource.setup"},
		  
        ],
		 selected = null,
        previous = null;
		$scope.viewResourceTabs = viewResourceTabs;
		$scope.selectedIndex = 0;
		
        var resourceDetails = JSON.parse(localStorage.getItem("ResourceDetails"));
        //console.log(a.resourcename);
        $scope.resourcename = resourceDetails.resourcename;
		if(resourceDetails.trustedtype === 'N'){
        viewResourceTabs.splice(0,0,{ title: 'Prepopulate', tabLink: "viewResource.prepopulate"});
			$state.go('viewResource.prepopulate');
		}
        else{
            $state.go('viewResource.role');
        }
	}