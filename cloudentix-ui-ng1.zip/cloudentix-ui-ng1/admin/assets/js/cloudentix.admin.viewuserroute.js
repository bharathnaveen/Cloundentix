angular
    .module('cloudentixApp')
	.controller('viewUsercontrols', viewusercontrols)
	.run(
        ['$rootScope', '$state', '$stateParams',
            function($rootScope, $state, $stateParams) {  
                $rootScope.$state = $state;
                $rootScope.$stateParams = $stateParams;
            }
        ]
    )
    .config(
        ['$stateProvider', '$urlRouterProvider',
            function($stateProvider, $urlRouterProvider) {
                $urlRouterProvider
                $stateProvider
                .state('viewuser.userbasicinformation', {
                    url: '/userbasicinformation',
                    controller: function($scope) {
                    },
                    templateUrl: 'users/cloudentix-admin-userinformatiom.html',
                    data: {
                        'selectedTab': 0
                    }
                })
                .state('viewuser.role', {
                    url: '/role',
                    controller: function($scope) {
                    },
                    templateUrl: 'users/cloudentix-admin-userrole.html',
                    data: {
                        'selectedTab': 1
                    }
                })
                .state('viewuser.resource', {
                    url: '/resource',
                    controller: function($scope) {
                    },
                    templateUrl: 'users/cloudentix-admin-userresource.html',
                    data: {
                        'selectedTab': 2
                    }
                });
            }
        ]
    );
    viewusercontrols.$inject = ['$scope', '$log', '$location', '$window', '$http', '$state'];
	function viewusercontrols($scope, $log, $location, $window, $http, $state) {
		var viewusertabs = [
            { title: 'User Information', tabLink: "viewuser.userbasicinformation"},
            { title: 'Role', tabLink: "viewuser.role"},
            { title: 'Resource', tabLink: "viewuser.resource"}
        ],
		selected = null,
        previous = null;
		$scope.viewusertabs = viewusertabs;
        $scope.selectedTabs = {};
		$scope.selectedTabs.selectedIndex = $state.current.data.selectedTab;
	}