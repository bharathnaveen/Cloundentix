/*
 * Cloudentix Core JavaScript Library v1.0
 * http://cloudentix.com/
 *
 * Copyright 2016, Sennovate, Inc.
 * Released under the MIT license
 * http://sennovate.com/license
 *
 * Author : Kannan
 * Last Updated On : 2016-08-04
 */
angular
    .module('cloudentixApp')
    /* add user has defined four controllers
        first controller for define inner tabs
        second controller for user information 
        and third for resource information
        and fourth for role information
    */
	.controller('editUserinfo', editUserInfo)
	.controller('editUserinformation', editUserInformation)
	.controller('editTrustedinformation', editTrustedInformation)
	.controller('editRoleinformation', editRoleInformation)
	.factory('selectTabService', function(scope) {
		scope.tabActive = '0';
		return {
			tabActive: function() { return tabActive; },
			setTabActive: function(x) { tabActive = x; }
		};
	})
    /* service method for maintaining input field values*/
    .service('keepeditInputfields', function() {
		this.storedata = {};
        this.userRoles = [];
        this.storerolesdata = [];
        this.storeTrusteddata = {};
        this.store = function(value) {
			this.storedata = value;
		}
		this.getdata = function() {
			return this.storedata;
		}
        /*
        this contructor functions used for store and get userResource values
        */
		this.storeTrusted = function(Trustedvalue) {
			this.storeTrusteddata = Trustedvalue;
		}
		this.getTrusteddata = function() {
			return this.storeTrusteddata;
		}
        /*
        this contructor functions used for store and get userRole values
        */
		this.storeRoles = function(roles) {
			this.storerolesdata[0] = roles;
		}
		this.getRolesdata = function() {
			return this.storerolesdata[0];
		}
        this.storeuserdata = function(trusted, roles, userroles) {
            this.usertrustedData = trusted;
            this.userRoles[0] = roles;
            this.userRoles[1] = userroles;
        }
        this.getuserTrusteddata = function() {
            return this.usertrustedData;
        }
        this.getuserroles = function() {
            return this.userRoles;
        }
	})
	.run(['$rootScope', '$state', '$stateParams', 
        function($rootScope, $state, $stateParams) {
            $rootScope.$state = $state;
            $rootScope.$stateParams = $stateParams;
        }
    ])
    /*
    stateProvider provides state transition
    it is imporatant for single page application
    */
    .config(
        ['$stateProvider', '$urlRouterProvider',
            function($stateProvider, $urlRouterProvider) {
                $urlRouterProvider
                $stateProvider
                .state('edituser.userinformation', {
                    url: '/userinformation',
                    onEnter: function() {
                        void 0;
                    },
                    controller: function($scope) {

                    },
                    templateUrl: 'users/cloudentix-admin-userinfo.html',
                    data: {
                      'selectedTab': 0
                    }
                })
                .state('edituser.trustedinformation', {
                    url: '/trustedinformation',
                    onEnter: function() {
                        void 0;
                    },
                    controller: function($scope) {

                    },
                    templateUrl: 'users/cloudentix-admin-trusted.html',
                    data: {
                      'selectedTab': 0
                    }
                })
				
                .state('edituser.role', {
                    url: '/role',
                    onEnter: function() {
                        void 0;
                    },
                    controller: function($scope) {

                    },
                    templateUrl: 'users/cloudentix-admin-role.html',
                    data: {
                      'selectedTab': 0
                    }
                });
            }
        ]
    );
    editUserInfo.$inject = ['$http', '$scope', '$log', '$state', '$rootScope', '$location', '$timeout', 'keepeditInputfields', 'SessionService'];
    editUserInformation.$inject = ['$timeout', '$window', '$http', '$scope', '$rootScope', '$log', '$state', 'keepeditInputfields', 'SessionService'];
    editTrustedInformation.$inject = ['$timeout', '$http', '$scope', '$log', '$rootScope', '$state', 'keepeditInputfields', '$location', 'SessionService'];
    editRoleInformation.$inject = ['$http', '$scope', '$log', '$rootScope', '$state', 'keepeditInputfields', '$location', 'SessionService'];
	var baseUrl = sessionStorage.getItem("WS_BASE_URL");
    function editUserInfo($http, $scope, $log, $state, $rootScope, $location, $timeout, keepeditInputfields, SessionService) {
        //base Url to check trusted and untrusted resource available or not
        keepeditInputfields.storedata = {}; 
        keepeditInputfields.storeTrusteddata = {};
        keepeditInputfields.storerolesdata = [];
		$scope.location= $location;
        var checkResourceURL = baseUrl + '/resources?check=true';
			var config = {
				url: checkResourceURL,
				method: "GET",
				headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
				}
			}
			$http(config)
			.success(function(response) {
                /*
                this condition is true if any of untrusted resource not configured 
                */
                if(response.type == 'success') {
                    if (response.data.login[0].trusted == 'N' || response.data.login[0].untrusted == 'N') {
                        if (response.data.login[0].trusted == 'N' && response.data.login[0].untrusted == 'N') {
                           $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure trusted and untrusted resources");
                        } else {
                            if (response.data.login[0].trusted == 'N') {
                                $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure the trusted resource");
                            } else if (response.data.login[0].untrusted === 'N') {
                                $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure an untrusted resource");
                            }
                        }
                    }
                //if two resources configured means it will process otherwise is goes to addresouce page
                    else if(response.data.login[0].trusted == 'Y' && response.data.login[0].untrusted == 'Y') {
                        // set inner tab title and tablink
                        var tabs = [
                            { title: 'User Information', tabLink: "edituser.userinformation",tabSerial:"1"},
                            { title: '', tabLink: "edituser.trustedinformation",tabSerial:"2"},
                            { title: 'Role', tabLink: "edituser.role",tabSerial:"3"}
                        ],
                        selected = null,
                        previous = null;
                        var listResourceURL = baseUrl + '/resources/list';
                        var config = {
                            url: listResourceURL,
                            method: "GET",
                            headers: {
                                "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                            }
                        }
                        $http(config).success(function(response) {          
                            angular.forEach(response.records[0].rscdetails, function(value, key) {
                                if (value["tarflag"] == 'Y') {
                                    sessionStorage.setItem("Trustedresourceid",value["rescid"]);
                                    $scope.resourceName = value["rescname"] + ' Information';
                                }
                            });
                            $scope.dynamicTitle();
                        });
                        $rootScope.editusertabs = tabs;
                        $scope.selectedIndex = 0;
                        $scope.selectTabService = 0;
                        $scope.dynamicTitle = function() {
                           $rootScope.editusertabs[1].title = $scope.resourceName;
                        }
                        $scope.$watch('selectedIndex', function(current, old) {
                            previous = selected;
                            selected = $rootScope.editusertabs[current];             
                        });
                        $scope.wizardActive = function(activePath) {
                            var activePath = activePath.replace('#','')
                            activePath = activePath.replace('.','/');
                            locationPath = $location.path();
                            locationPath = locationPath.replace('/','');
                            if(activePath === locationPath) {
                               return 'wizard-active';
                            } else {
                               return '';
                            }
                        }
                    }
                } else {
                    $scope.toastMessage('toast-error',response.data.message);
                }
			});
    }
    function editUserInformation($timeout, $window, $http, $scope, $rootScope, $log, $state, keepeditInputfields, SessionService) {
        $rootScope.loaderCurrentStatus = 'true';
        $rootScope.edituserMappedcolumn = [];
        var userstart = 0
        $scope.editusercount = function() {
            return userstart++;
        }
        //this scope object has to store user input values
        $scope.edituserinfoFields = [];
        $scope.selectTabService = 1;
        $scope.userguid = localStorage.getItem('userGuid');
        //get user's specific information
        var listfieldsURL = baseUrl + '/users/editlistfields';
        var config = {
            url: listfieldsURL,
            method: "GET",
            headers: {
                "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                "cdt-guid": $scope.userguid
            }
        }
		$http(config)
		.then(function success(response) {
            /*Every user has splitted into three types
            1. user's basic information it will show in userinformation tab
            2. user's resource information it will show in another tab
            3. user's role information
            */
            if(response.data.type == 'success') {
                $scope.edituserMappedcolumn = response.data.records[0].mappedcolumn;
                keepeditInputfields.storeuserdata(response.data.records[0].unmappedcolumn, response.data.records[0].role, response.data.records[0].rolevalue);
				$rootScope.userMultiselectRolecolumn = response.data.records[0].rolemultiselect;
				$rootScope.loadWidth = 33;
                $rootScope.loaderCurrentStatus = 'false';
            } else {
                $rootScope.loaderCurrentStatus = 'false';
                $scope.toastMessage('toast-error', response.data.message);
            }
			$timeout(function() {
				$scope.loadUserinfoService();
			}, 10);
		},function error(response){
            $rootScope.loaderCurrentStatus = 'false';
            $scope.errorHandler(response.config.url,response.status);
        });
        // service has implemented to get user values 
		$scope.loadUserinfoService = function() {
			$scope.putdata = keepeditInputfields.getdata();
			if(Object.keys($scope.putdata).length) {
                angular.forEach($scope.putdata, function(value, key){
                   $scope.edituserinfoFields[key] = value;		
                })
			}
            $rootScope.loadWidth = 33;
            //set progress bar width	
		}
        $scope.next = function(editusertabs, isValid) {
            if(isValid) {
                keepeditInputfields.store($scope.edituserinfoFields);
                $scope.selectedIndex = Math.min($scope.selectedIndex + 1, 2) ;
                //selectTabService.setTabActive($scope.selectedIndex);
                var nextTab = $scope.selectedIndex;	
                var gotoUrl =  $rootScope.editusertabs[nextTab].tabLink;
                $state.go(gotoUrl);
            }
        };
        $scope.previous = function(editusertabs) {
            $scope.selectedIndex = Math.max($scope.selectedIndex - 1, 0);
            //selectTabService.setTabActive($scope.selectedIndex);
            var prevTab = $scope.selectedIndex;
            var gotoUrl = $rootScope.editusertabs[prevTab].tabLink;
            $state.go(gotoUrl);
        }
        $scope.checkUserdata = function(oldData, newdata, index) {
            if(oldData == newdata) {
                $scope.edituserinfoFields[index].Usermodified = false;
            } else {
                $scope.edituserinfoFields[index].Usermodified = true;
            }
        }
    };
    function editTrustedInformation($timeout, $http, $scope, $log, $rootScope, $state, keepeditInputfields, $location, SessionService) {
        //set progress bar width
        $scope.edituserUnmappedcolumn = [];
        $rootScope.loadWidth = 66;
        //start loader
        $scope.selectTabService = 2;
        var userstart = 0
        $scope.editusercount = function() {
            return userstart++;
        }
        $rootScope.loaderCurrentStatus = 'true';
        var checkData = keepeditInputfields.getdata();
        if(!Object.keys(checkData).length) {
            $location.url('/edituser/userinformation');
        } else {
            $scope.edituserUnmappedcolumn = keepeditInputfields.getuserTrusteddata();
        }
        $scope.edituserTrustedFields = [];
        // calls service method to get values
        $scope.putdata = keepeditInputfields.getTrusteddata();
        $scope.loadTrustedinfoService = function() {
            if($scope.putdata != '' && $scope.putdata != undefined && $scope.putdata != null) {
                angular.forEach($scope.putdata, function(value, key){
                    $scope.edituserTrustedFields[key] = value;		
                })
            }
            $rootScope.loaderCurrentStatus = 'false';
        }
        $scope.next = function(editusertabs, isValid) {
			keepeditInputfields.storeTrusted($scope.edituserTrustedFields);
			$scope.selectedIndex = Math.min($scope.selectedIndex + 2, 3) ;
			//selectTabService.setTabActive($scope.selectedIndex);
			var nextTab = $scope.selectedIndex;	
			var gotoUrl =  $rootScope.editusertabs[nextTab].tabLink;
			$state.go(gotoUrl);
        };
        $scope.previous = function(editusertabs) {
            $scope.selectedIndex = Math.max($scope.selectedIndex - 1, 0);
            //selectTabService.setTabActive($scope.selectedIndex);
            var prevTab = $scope.selectedIndex;
            var gotoUrl = $rootScope.editusertabs[prevTab].tabLink;
            $state.go(gotoUrl);
        }; 
        $timeout(function() {
            $scope.loadTrustedinfoService();
        }, 1000);
        $scope.checkUserdata = function(oldData, newdata, index) {
            if(oldData == newdata) {
                $scope.edituserTrustedFields[index].Usermodified = false;
            } else {
                $scope.edituserTrustedFields[index].Usermodified = true;
            }
        }
    }
function editRoleInformation($http, $scope, $log, $rootScope, $state, keepeditInputfields, $location, SessionService) {
        //set progress bar width
        $rootScope.loadWidth = 100;
        $scope.selectTabService = 3;
        var roledata;
        $rootScope.loaderCurrentStatus = 'true';
        var checkData = keepeditInputfields.getdata();
        if(!Object.keys(checkData).length) {
            $location.url('/edituser/userinformation');
        } else {
            roledata = keepeditInputfields.getuserroles();
            $scope.edituserRolecolumn = roledata[0];
            if($rootScope.userMultiselectRolecolumn == 'N') {
				$scope.editsingleRole = roledata[1][0].value;
			} else {
				$scope.userRoles = [];
				angular.forEach(roledata[1], function(value, key) {
					$scope.userRoles[key] = value["value"];
				})
				$scope.editRoles = $scope.userRoles;
			}
        }
        $rootScope.loaderCurrentStatus = 'false';
        // calls service method to get form input values
        $scope.userInfodata = keepeditInputfields.getdata();
        $scope.userTrusteddata = keepeditInputfields.getTrusteddata();
        $scope.userroledata = keepeditInputfields.getRolesdata();
        if($scope.userroledata != undefined) {
		   if($rootScope.userMultiselectRolecolumn == 'N') {
				$scope.editsingleRole = $scope.userroledata;
			} else {
				$scope.editRoles = $scope.userroledata;
			}
        }
        $rootScope.loaderCurrentStatus = 'false';
        var userguid = localStorage.getItem('userGuid');
        var loginuserId = localStorage.getItem("userid");
        //finally get all the form values from service method then call add user API request
        $scope.next = function() {
            $scope.userValues = {"records": []};
            $scope.userroleValues = {"records": []};
            angular.forEach($scope.userInfodata, function(value, key) {
                if(value["Usermodified"] == true) {
                    $scope.userValues.records.push({"colname": value["Userlabel"], "colvalue": value["Uservalue"]});
                }
            }) 
            angular.forEach($scope.userTrusteddata, function(value, key) {
                if(value["Usermodified"] == true) {
                    $scope.userValues.records.push({"colname": value["Userlabel"], "colvalue": value["Uservalue"]});
                }
            })
            var roleModifiedFlag;
			if($rootScope.userMultiselectRolecolumn == 'N') {
				if(roledata[1][0].value != $scope.editsingleRole) {
					roleModifiedFlag = true;	
				}
			} else {
				if(roledata[1].length == $scope.editRoles.length) {
					angular.forEach(roledata[1], function(value, key) {
						data = $scope.editRoles.indexOf(value["value"]);
						if(data == -1) {
							roleModifiedFlag = true;
						}
					});
				} else {
					roleModifiedFlag = true;
				}
			}
            if($scope.userValues.records.length == 0 && roleModifiedFlag == undefined) {
                $scope.toastMessage('toast-warn', 'You have not modified any values');
            } else {
				if($rootScope.userMultiselectRolecolumn == 'N') {
					$scope.userroleValues.records.push({"roleid": $scope.editsingleRole});
				} else {
					for(var i=0;i < $scope.editRoles.length;i++) {
						if($scope.editRoles[i] != '') {
							$scope.userroleValues.records.push({"roleid": $scope.editRoles[i]});
						}
					}
				}
                var userinormation = JSON.stringify($scope.userValues);
                var userRoleinormation = JSON.stringify($scope.userroleValues);
                $rootScope.loaderCurrentStatus = 'true';
                var listURL = baseUrl + '/users/edit'
                var config = {
                    url: listURL,
                    method: "PUT",
                    headers: {
                        "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                        "cdt-loginguid": loginuserId,
                        "cdt-guid": userguid,
                        "cdt-valuejson": userinormation,
                        "cdt-rolejson": userRoleinormation
                    }
                }
                $http(config)
                .then(function success(response) {
                    $rootScope.loaderCurrentStatus = 'false';
                    if (response.data.type == "success") {
                        $scope.toastMessage('toast-success',response.data.message);
                        keepeditInputfields.storedata = {}; 
                        keepeditInputfields.storeTrusteddata = {};
                        keepeditInputfields.storerolesdata = [];
                        $state.go('users');
                        $scope.addTab('Users','users');
                    } else if (response.type == "error") {
                        $scope.toastMessage('toast-error',response.data.message);
                    } else if(response.type == "warning") {
                        $scope.toastMessage('toast-warn',response.data.message);
                    } else {
                        $scope.toastMessage('toast-error',response.data.message);
                    }
                },function error(response){
                    $rootScope.loaderCurrentStatus = 'false';
                    $scope.errorHandler(response.config.url,response.status);
                });
            }
        };
        $scope.previous = function(editusertabs) {
			if($rootScope.userMultiselectRolecolumn == 'N') {
				 keepeditInputfields.storeRoles($scope.editsingleRole);
			} else {
				 keepeditInputfields.storeRoles($scope.editRoles);
			}
            $scope.selectedIndex = Math.max($scope.selectedIndex - 1, 1);
            //selectTabService.setTabActive($scope.selectedIndex);
            var prevTab = $scope.selectedIndex;
            var gotoUrl = $rootScope.editusertabs[prevTab].tabLink;
            $state.go(gotoUrl);
        };
    }
	