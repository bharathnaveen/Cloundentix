angular
	.module('cloudentixApp')
	.controller('loadImages',loadimage)
	.value("dbid",{name: ''});
	loadimage.$inject = ['$http','$scope','$rootScope', 'dbid', 'SessionService'];
	function loadimage($http,$scope,$rootScope, dbid, SessionService)
	{
		var checkResourceUrl = baseUrl +'/resources';
		var config = {
			url: checkResourceUrl,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
		}
		}
		$http(config)
		.then(function success(response) {
			var len = response.data.records.length;
			var sref= ['MySqladdresources.mysqladdrsc','MsSqladdresources.mssqladdrsc','Oracleaddresources.oracleaddrsc','ADaddresources.adaddrsc','Salesforceaddresources.salesforceaddrsc','Office365addresources.office365addrsc'];
			var tabname= ['MySql AddResource','MsSqlAddResource','OracleAddResource','Active Directory AddResource','Salesforce AddResource','Office365AddResource'];
			$scope.imageload = [];
			for(var count=0;count<len;count++)
			{
				if(response.data.records[count].display === "Y")
				{
					$scope.imageload.push({
					id : response.data.records[count].id,
					image : response.data.records[count].image,
					sref : sref[count],
					tabname : tabname[count]
					});
				}
			}

		},function error(response) {
			$rootScope.loaderCurrentStatus = 'false';
            $scope.errorHandler(response.config.url,response.status);
      });
	$scope.setimgattr = function(tabname, sref) {
		if(tabname.length > 10){
			tabname = (tabname.slice(0,10)+'...');
		}
	  $scope.addTab(tabname, sref);
	}
	
	}