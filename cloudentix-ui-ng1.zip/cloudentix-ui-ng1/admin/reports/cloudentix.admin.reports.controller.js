angular.module('cloudentixApp')
    .controller('listofReportController', listofReportController);
listofReportController.$inject = ['$rootScope', '$scope', '$http', '$state', 'SessionService'];

function listofReportController($rootScope, $scope, $http, $state, SessionService) {
    var baseUrl = sessionStorage.getItem("WS_BASE_URL");
    var checkResourceURL = baseUrl + '/resources?check=true';
    var config = {
        url: checkResourceURL,
        method: "GET",
        headers: {
            "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
        }
    }
    $http(config).success(function (response) {
        if (response.type === 'success') {
            if (response.data.login[0].trusted == 'N' || response.data.login[0].untrusted == 'N') {
                if (response.data.login[0].trusted == 'N' && response.data.login[0].untrusted == 'N') {
                    $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure trusted and untrusted resources");
                } else {
                    if (response.data.login[0].trusted == 'N') {
                        $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure the trusted resource");
                    } else if (response.data.login[0].untrusted === 'N') {
                        $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure an untrusted resource");
                    }
                }
            }
            else if (response.data.login[0].trusted == 'Y' && response.data.login[0].untrusted == 'Y') {
                $rootScope.loaderCurrentStatus = 'true';
                var endPoint = baseUrl + "/reports/listreports";
                var config = {
                    url: endPoint,
                    method: "GET",
                    headers: {
                        "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                    }
                };
                $http(config).success(function (response) {
                    $scope.reportList = [];
                    $rootScope.loaderCurrentStatus = 'false';
                    if (response.type == 'success') {
                        angular.forEach(response.records[0].dropdownlist, function (value, key) {
                            $scope.reportList.push({ "reportKey": value["key"], "reportValue": value["value"], "reportDescription": value["description"] });
                        });
                    }
                }).error(function (response) {
                    $rootScope.loaderCurrentStatus = 'false';
                    $scope.errorHandler(response.config.url, response.status);
                });
                $scope.reportView = function (reports) {
                    localStorage.setItem('selectedReportDetails', JSON.stringify(reports));
                    $state.go("reportView");
                    $scope.addTab('Report: View', 'reportView');
                }
            }
        } else {
            $rootScope.loaderCurrentStatus = 'false';
            $scope.errorHandler(response.message, response.status);

        }
    });
}