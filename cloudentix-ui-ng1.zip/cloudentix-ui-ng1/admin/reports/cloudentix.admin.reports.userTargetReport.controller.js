// angular.module('cloudentixApp')
//     .controller('UserTargetReportController', UserTargetReportController);

// UserTargetReportController.$inject = ['$scope', '$rootScope', '$http', '$timeout', 'SessionService'];

// function UserTargetReportController($scope, $rootScope, $http, $timeout, SessionService) {
//     var baseUrl = sessionStorage.getItem("WS_BASE_URL");
//     var userid = sessionStorage.getItem("userid");

//     $scope.getUserTarget = function () {
//         var userTargetURL = baseUrl + '/reports/newlyprovisioneduserstarget';
//         $rootScope.loaderCurrentStatus = 'true';
//         var config = {
//             url: userTargetURL,
//             method: "GET",
//             headers: {
//                 "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
//                 "cdt-loginguid": userid,
//             }
//         };
//         $http(config).success(function (response) {
//             $rootScope.loaderCurrentStatus = 'false';
//             $scope.userTarget = response.records[0].columnvalue;
//             console.log($scope.userTarget, 'User Target Res');
//         }).error(function (data) {
//             console.log(data.toString());
//         });
//     }
//     $scope.getUserTarget();
// };