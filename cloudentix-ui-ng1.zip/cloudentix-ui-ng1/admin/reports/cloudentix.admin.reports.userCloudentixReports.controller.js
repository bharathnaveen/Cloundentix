angular.module('cloudentixApp')
	.controller('UserCloudentixReportController', UserCloudentixReportController)
	.controller('updateColumnController', updateColumnController);

UserCloudentixReportController.$inject = ['$scope', '$rootScope', '$window', '$mdDialog', 'SGtoastService', 'SGdataService'];
updateColumnController.$inject = ['$http', '$scope', '$rootScope', '$mdDialog', '$mdToast', 'SessionService', 'SGdataService'];

function UserCloudentixReportController($scope, $rootScope, $window, $mdDialog, SGtoastService, SGdataService) {


	$scope.selected = [];
	$scope.limitOptions = [10, 25, 50, 100];

	$scope.options = {
		rowSelection: false,
		multiSelect: false,
		autoSelect: true,
		decapitate: false,
		largeEditDialog: true,
		boundaryLinks: true,
		limitSelect: true,
		pageSelect: true
	};

	$scope.query = {
		order: 'name',
		limit: 10,
		page: 1
	};

	$scope.subject = "Newly Provisioned User Cloudentix";
	$scope.username = sessionStorage.getItem('cdt-uname');
	$scope.message = "Please find the attached Security Governor Report 'Newly Provisioned User Cloudentix'.";
	$scope.getMailDetails = function (username, mailCC, mailBCC, subject, message) {
		var mailTo = document.getElementById("To").value.split(/[ ,]+/);
		var mailCC = document.getElementById("CC").value.split(/[ ,]+/);
		var mailBCC = document.getElementById("BCC").value.split(/[ ,]+/);
		var mailURL = '/newlyprousercloudentix';
		var mailJSON = {
			mail_to: mailTo,
			mail_cc: mailCC,
			mail_bcc: mailBCC,
			subject: subject,
			message: message
		}
		var headerObj = {
			username: sessionStorage.getItem('cdt-uname'),
			mail: JSON.stringify(mailJSON)
		}
		var params = {
			start: 1,
			end: 10,
			format: 'mail'
		}
		$rootScope.loaderCurrentStatus = 'true';
		SGdataService.getData(mailURL, headerObj, params).then(successHandler, errorHandler);

		function successHandler(response) {
			$scope.sgMailData = response;
			$rootScope.loaderCurrentStatus = 'false';
			SGtoastService.toastmessage('toast-info', response.message);
            if (response.message == "Mail Sent Successfully") {
                $state.go('securityGovernor.usercloudentix');
            }
		}
	}

	$scope.getPDF = function () {
		var getPDFURL = '/newlyprousercloudentix';
		$rootScope.loaderCurrentStatus = 'true';
		var headerObj = {
			username: sessionStorage.getItem('cdt-uname')
			// mail: JSON.stringify(mailJSON)
		}
		var params = {
			start: 1,
			end: 10,
			format: 'pdf'
		}

		SGdataService.getData(getPDFURL, headerObj, params).then(successHandler, errorHandler);

		function successHandler(response) {
			$scope.sgPDF = response;
			// var pathname = new URL($scope.sgPDF.url).pathname;
			// var path = pathname.substr(1, 100);
			// var fileName = path;
			// var a = document.createElement("a");
			// document.body.appendChild(a);
			// var file = new Blob([$scope.sgPDF.url], { type: 'application/pdf' });
			// var fileURL = $window.URL.createObjectURL(file);
			// a.href = fileURL;
			// a.download = fileName;
			// a.click();
			$rootScope.loaderCurrentStatus = 'false';
		}
	}

	$scope.getPrint = function () {
		var getPrintURL = '/newlyprousercloudentix';
		$rootScope.loaderCurrentStatus = 'true';
		var headerObj = {
			username: sessionStorage.getItem('cdt-uname')
		}
		var params = {
			start: 1,
			end: 10,
			format: 'pdf'
		}

		SGdataService.getData(getPrintURL, headerObj, params).then(successHandler, errorHandler);

		function successHandler(response) {
			$scope.sgPrint = response;
			var parent = $window.open('', '_blank');
			$window.open($scope.sgPrint.url, '_blank');
			parent.close();
			$rootScope.loaderCurrentStatus = 'false';
		}
	}

	$scope.getUserCloudentix = function (startrecord, endrecord) {
		$rootScope.loaderCurrentStatus = 'true';
		var url = '/newlyprousercloudentix';

		var headerObj = {
			username: sessionStorage.getItem('cdt-uname')
		}

		if (startrecord) {
			var params = {
				start: startrecord,
				end: endrecord,
				format: 'html'
			}
		} else {
			var params = {
				start: 1,
				end: 10,
				format: 'html'
			}
		}
		SGdataService.getData(url, headerObj, params).then(successHandler, errorHandler);

		function successHandler(response) {
			$scope.userCloudentix = response;
			$scope.getPDF();
			$rootScope.loaderCurrentStatus = 'false';
		}
	}

	$scope.status = '  ';
	$scope.customFullscreen = false;

	$scope.showAdvanced = function (ev) {
		$mdDialog.show({
			controller: UserCloudentixReportController,
			templateUrl: '../admin/reports/cloudentix-newlyprousercdtmail-modal-popup.html',
			parent: angular.element(document.body),
			targetEvent: ev,
			clickOutsideToClose: true,
			fullscreen: $scope.customFullscreen // Only for -xs, -sm breakpoints.
		})
	};

	$scope.updateReportColumns = function (ev) {
		$mdDialog.show({
			controller: updateColumnController,
			templateUrl: 'reports/cloudentix-admin-updatecolumn.html',
			parent: angular.element(document.body),
			targetEvent: ev,
			clickOutsideToClose: true,
			fullscreen: $scope.customFullscreen // Only for -xs, -sm breakpoints.
		})
	};

	$scope.cancel = function () {
		$mdDialog.cancel();
	};

	$scope.onPaginate = function () {
		var startrecord = ($scope.query.page * $scope.query.limit) - $scope.query.limit + 1;
		var endrecord = $scope.query.page * $scope.query.limit;
		$scope.getUserCloudentix(startrecord, endrecord);
	}

	$scope.toggleLimitOptions = function () {
		$scope.limitOptions = $scope.limitOptions ? undefined : [10, 25, 50, 100];
	};

	$scope.logItem = function (item) {
		console.log(item.name, 'was selected');
	};

	$scope.logOrder = function (order) {
		console.log('order: ', order);
	};

	$scope.logPagination = function (page, limit) {
		console.log('page: ', page);
		console.log('limit: ', limit);
	}

	function errorHandler(e) {
		console.log(e.toString());
	}
	$scope.getUserCloudentix();
}

function updateColumnController($http, $scope, $rootScope, $mdDialog, $mdToast, SessionService, SGdataService) {
	// contains a whole list of reports - ngRepeat
	$scope.listofColumns = [];
	// before update -  onload - right
	$scope.getColumns = [];
	$rootScope.loaderCurrentStatus = 'true';
	var url = '/getcolnames';
	SGdataService.getData(url).then(successHandler, errorHandler);

	function successHandler(response) {
		$rootScope.loaderCurrentStatus = 'false';
		//$scope.getColumns = [];
		angular.forEach(response, function (value, key) {
			$scope.listofColumns.push({
				"targetcolumn": value.name
			});
		});
		angular.forEach(response, function (value, key) {
			$scope.getColumns[key] = value["value"];
		});
		$scope.listofColumns = $scope.listofColumns.filter(function (elm, idx) {
			return $scope.getColumns.indexOf(elm.targetcolumn) === -1;
		});
		$scope.choosenReportsColumn = $scope.getColumns;
	}
	$scope.updatecolumnclose = function () {
		$mdDialog.hide();
	};
	$scope.updatecolumnhide = function () {
		$mdDialog.cancel();
	};
	$scope.addReport = function (value) {
		$scope.getColumns = $scope.getColumns.concat(value);
		$scope.listofColumns = $scope.listofColumns.filter(function (elm, idx) {
			if (value.indexOf(elm.targetcolumn) === -1) {
				$scope.listofColumns.push(elm);
				return true;
			}
			return false;
		});
		$scope.choosenReportsColumn = $scope.getColumns;
	}
	$scope.removeReport = function (selectItem) {
		$scope.getColumns = $scope.getColumns.filter(function (elm, idx) {
			console.log(elm, "elm value");
			return selectItem.indexOf(elm) === -1;
		});
		var selectItem = selectItem.map(function (elm) {
			elm = {
				targetcolumn: elm
			};
			return elm;
		});
		$scope.listofColumns = $scope.listofColumns.concat(selectItem);
	}

	$scope.submitupdateColumns = function (startrecord, endrecord) {
		$rootScope.loaderCurrentStatus = 'true';
		$scope.postselectedColumns = [];
		for (var i = 0; i < $scope.getColumns.length; i++) {
			$scope.postselectedColumns.push($scope.getColumns[i]);
		}
		var json = JSON.stringify($scope.postselectedColumns, function (key, value) {
			if (key === "$$hashKey") {
				return undefined;
			}
			return value;
		});

		if (startrecord) {
			var params = {
				start: startrecord,
				end: endrecord,
				format: 'html'
			}
		} else {
			var params = {
				start: 1,
				end: 10,
				format: 'html'
			}
		}

		var postColumnUrl = '/newlyprousercloudentix';
		SGdataService.saveUpdateColumn(postColumnUrl, params, json).then(successHandler, errorHandler);

		function successHandler(response) {
			$rootScope.UpdateuserCloudentixColumn = response;
			//$scope.getPDF();
			$rootScope.loaderCurrentStatus = 'false';
			// var icon;
			// if (response.type == 'success') {
			// 	icon = 'done';
			// 	$mdDialog.hide();
			// 	// $rootScope.getReportsData();
			// } else if (response.type == 'error') {
			// 	icon = 'error_outline';
			// } else if (response.type == 'warn') {
			// 	icon = 'warning';
			// } else {
			// 	icon = 'info_outline';
			// }
			// $mdToast.show({
			// 	template: '<md-toast class="md-toast toast-' + response.type + '"><div class="md-toast-content"><i class="material-icons">' + icon + '</i>&nbsp;&nbsp; ' + response.message + '!</div></md-toast>',
			// 	hideDelay: 3000,
			// 	position: 'top right'
			// });
		}
	}

	$scope.onUpdatePaginate = function () {
		var startrecord = ($scope.query.page * $scope.query.limit) - $scope.query.limit + 1;
		var endrecord = $scope.query.page * $scope.query.limit;
		$scope.submitupdateColumns(startrecord, endrecord);
	}

	function errorHandler(e) {
		console.log(e.toString());
	}
}