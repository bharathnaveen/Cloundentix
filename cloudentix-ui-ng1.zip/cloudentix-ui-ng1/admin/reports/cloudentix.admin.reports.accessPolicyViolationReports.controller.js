angular.module('cloudentixApp')
    .controller('accesspolicyReportController', accesspolicyReportController)
    .controller('updateColumnController', updateColumnController)
accesspolicyReportController.$inject = ['$rootScope', '$scope', '$http', '$filter', '$mdDialog', 'SessionService'];
updateColumnController.$inject = ['$http', '$scope', '$rootScope', 'resourceid', 'reportid', '$mdDialog', '$mdToast', 'reportTitle', 'SessionService'];

function accesspolicyReportController($rootScope, $scope, $http, $filter, $mdDialog, SessionService) {
    var baseUrl = sessionStorage.getItem("WS_BASE_URL");
    var checkResourceURL = baseUrl + '/resources?check=true';
    var config = {
        url: checkResourceURL,
        method: "GET",
        headers: {
            "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
        }
    }
    $http(config).success(function (response) {
        if (response.type === 'success') {
            if (response.data.login[0].trusted == 'N' || response.data.login[0].untrusted == 'N') {
                if (response.data.login[0].trusted == 'N' && response.data.login[0].untrusted == 'N') {
                    $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure trusted and untrusted resources");
                } else {
                    if (response.data.login[0].trusted == 'N') {
                        $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure the trusted resource");
                    } else if (response.data.login[0].untrusted === 'N') {
                        $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure an untrusted resource");
                    }
                }
            } else if (response.data.login[0].trusted == 'Y' && response.data.login[0].untrusted == 'Y') {
                'use strict';
                // $rootScope.loaderCurrentStatus = 'true';
                $scope.reportsResponse = '';
                $scope.selected = [];
                $scope.limitOptions = [3, 10, 25, 50, 100];
                $scope.options = {
                    rowSelection: false,
                    multiSelect: false,
                    autoSelect: true,
                    decapitate: false,
                    largeEditDialog: true,
                    boundaryLinks: true,
                    limitSelect: true,
                    pageSelect: true
                };
                $scope.query = {
                    order: 'name',
                    limit: 10,
                    page: 1
                };
                $scope.toggleLimitOptions = function () {
                    $scope.limitOptions = $scope.limitOptions ? undefined : [10, 25, 50, 100];
                };
                $scope.getTypes = function () {
                    return ['Candy', 'Ice cream', 'Other', 'Pastry'];
                };
                $scope.logItem = function (item) {
                    void 0;
                };
                $scope.logOrder = function (order) {
                    void 0;
                };
                $scope.logPagination = function (page, limit) {
                    void 0;
                    void 0;
                }
                var accesspolicy = baseUrl + '/reports/listresource';
                var reportsDetails = JSON.parse(localStorage.getItem('selectedReportDetails'));
                $scope.selectedreportDescription = reportsDetails.reportDescription
                $scope.selectedreportKey = reportsDetails.reportKey;
                $scope.selectedreporttitle = reportsDetails.reportValue;
                if ($scope.selectedreporttitle == 'AD Account Expiration Report' || $scope.selectedreporttitle == 'AD User Password Expiration Report' || $scope.selectedreporttitle == 'Access Policy Violation Report') {
                    $rootScope.loaderCurrentStatus = 'true';
                    var config = {
                        url: accesspolicy,
                        method: "GET",
                        headers: {
                            "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                            "cdt-reportid": $scope.selectedreportKey
                        }
                    };
                    $http(config).success(function (response) {
                        $rootScope.loaderCurrentStatus = 'false';
                        if (response.type === "success") {
                            if (response.records[0].dropdownlist.length === 1) {
                                $scope.selectedResourcekey = response.records[0].dropdownlist[0].key;
                                $scope.selectedResourcetitle = response.records[0].dropdownlist[0].value;
                                $scope.reportResourcestatus = false;
                                $scope.enabledate = true;
                                if ($scope.selectedreporttitle == 'AD User Password Expiration Report') {
                                    $scope.getadPasswordExpiration();
                                } else if ($scope.selectedreporttitle == 'Access Policy Violation Report') {
                                    $scope.accessPolicy();
                                }
                            } else {
                                $scope.reportResourcestatus = true;
                                $scope.reportResources = [];
                                angular.forEach(response.records[0].dropdownlist, function (value, key) {
                                    $scope.reportResources.push({
                                        'key': value['key'],
                                        'value': value['value']
                                    });
                                });
                            }

                        } else {
                            $scope.reportsResponse = response.type;
                            $scope.reportsMessage = response.message;
                        }
                    }).error(function (data) {
                        void 0;
                        $rootScope.loaderCurrentStatus = 'false';
                        $scope.errorHandler(response.config.url, response.status);
                    });
                }
                $scope.getselectedResource = function (resourcekey) {
                    $scope.selectedResourcekey = resourcekey;
                    $scope.enabledate = true;
                    $scope.reportstartDate = null;
                    $scope.reportendDate = null;
                    $scope.reportsResponse = 'changes';
                    if ($scope.selectedreporttitle == 'AD User Password Expiration Report') {
                        $scope.getadPasswordExpiration();
                    } else if ($scope.selectedreporttitle == 'Access Policy Violation Report') {
                        $scope.accessPolicy();
                    }
                }
                var newval, oldval, newValues1;
                var accesspolicyViolation = baseUrl + '/reports/accesspolicyviolation';
                $scope.accessPolicy = function () {
                    var loginuserId = localStorage.getItem("userid");
                    $rootScope.loaderCurrentStatus = 'true';
                    var config = {
                        url: accesspolicyViolation,
                        method: "GET",
                        headers: {
                            "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                            "cdt-loginguid": loginuserId,
                            "cdt-rscid": $scope.selectedResourcekey
                        }
                    };
                    $http(config).success(function (response) {
                        $rootScope.loaderCurrentStatus = 'false';
                        $scope.reportsResponse = response.type;
                        if (response.type === "success") {
                            var parsedData = JSON.parse(response.records[0].columnvalue);
                            $scope.reportsTablecolumnkey = [];
                            $scope.duplicateReportsTablecolumndata = [];
                            angular.forEach(parsedData[0], function (value, key) {
                                $scope.reportsTablecolumnkey.push({
                                    'title': key,
                                    "dataKey": key
                                });
                            });
                            $scope.reportsTablecolumndata = [];
                            angular.forEach(parsedData, function (value, keys) {
                                $scope.reportsTablecolumndata.push({
                                    "id": keys
                                });
                                angular.forEach(value, function (value, key) {
                                    if (value == null) {
                                        $scope.reportsTablecolumndata[keys][key] = JSON.stringify(value);
                                    } else {
                                        $scope.reportsTablecolumndata[keys][key] = value;
                                    }
                                });
                                delete $scope.reportsTablecolumndata[keys]["id"];
                            });
                            $scope.duplicateReportsTablecolumndata = angular.copy($scope.reportsTablecolumndata);
                        } else {
                            $scope.reportsMessage = response.message;
                        }
                    }).error(function (response) {
                        void 0;
                        $rootScope.loaderCurrentStatus = 'false';
                        $scope.errorHandler(response.config.url, response.status);
                    });
                }
                var duplicateMailid = baseUrl + '/reports/duplicateemailvalue';
                $scope.getDuplicateMailId = function () {
                    $scope.query.limit = '3';
                    var loginuserId = localStorage.getItem("userid");
                    $rootScope.loaderCurrentStatus = 'true';
                    var config = {
                        url: duplicateMailid,
                        method: "GET",
                        headers: {
                            "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                            "cdt-loginguid": loginuserId
                        }
                    };
                    $http(config).success(function (response) {
                        $scope.reportsResponse = response.type;
                        $rootScope.loaderCurrentStatus = 'false';
                        $scope.duplicateReportsTablecolumndata = [];
                        if (response.type === "success") {
                            $scope.reportsTablecolumnkey = [];
                            var parsedData = JSON.parse(response.records[0].duplicateemailrecords[0].duplicateemailrecordslist);
                            angular.forEach(parsedData[0], function (value, key) {
                                $scope.reportsTablecolumnkey.push({
                                    'title': key,
                                    "dataKey": key
                                });
                            });
                            $scope.reportsTablecolumndata = [];
                            angular.forEach(response.records[0].duplicateemailrecords, function (value, keys) {
                                $scope.reportsTablecolumndata.push({
                                    "id": keys
                                });
                                if (value.email == '' || value.email) {
                                    $scope.reportsTablecolumndata[keys]["email"] = value.email;
                                }
                                if (value.duplicateemailrecordslist) {
                                    var parsedtableData = JSON.parse(value.duplicateemailrecordslist);
                                    $scope.reportsTablecolumndata[keys]["duplicateemailrecordslist"] = {};
                                    angular.forEach(parsedtableData, function (value, key) {
                                        $scope.reportsTablecolumndata[keys]["duplicateemailrecordslist"][key] = value;
                                    });
                                }
                                delete $scope.reportsTablecolumndata[keys]["id"];
                            });
                            $scope.duplicateReportsTablecolumndata = angular.copy($scope.reportsTablecolumndata);
                            $scope.duplicateemailData = [];
                            $scope.duplicateemailtitle = [];
                            var count = 0,
                                totalobjectLength;
                            angular.forEach($scope.reportsTablecolumndata, function (value, key) {
                                totalobjectLength = 0;
                                angular.forEach(value.duplicateemailrecordslist, function (value, key) {
                                    $scope.duplicateemailData.push({
                                        "id": key
                                    });
                                    angular.forEach(value, function (value, key) {
                                        //console.log(value +"-----------"+ key);
                                        $scope.duplicateemailData[count][key] = value
                                    });
                                    count++;
                                    totalobjectLength++;
                                });
                                $scope.duplicateemailtitle.push({
                                    "email": $scope.reportsTablecolumndata[key].email,
                                    "count": totalobjectLength
                                });
                            });
                        } else {
                            $scope.reportsMessage = response.message;
                        }
                    }).error(function (response) {
                        void 0;
                        $rootScope.loaderCurrentStatus = 'false';
                        $scope.errorHandler(response.config.url, response.status);
                    });
                }
                var userPasswordreport = baseUrl + '/reports/adpasswordexpreport';
                $scope.getadPasswordExpiration = function () {
                    var loginuserId = localStorage.getItem("userid");
                    $rootScope.loaderCurrentStatus = 'true';
                    var config = {
                        url: userPasswordreport,
                        method: "GET",
                        headers: {
                            "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                            "cdt-rscid": $scope.selectedResourcekey,
                            "cdt-loginguid": loginuserId
                        }
                    };
                    $http(config).success(function (response) {
                        $rootScope.loaderCurrentStatus = 'false';
                        $scope.reportsResponse = response.type;
                        $scope.duplicateReportsTablecolumndata = [];
                        if (response.type === "success") {
                            var parsedData = JSON.parse(response.records[0].columnvalue);
                            $scope.reportsTablecolumnkey = [];
                            angular.forEach(parsedData.values[0], function (value, key) {
                                $scope.reportsTablecolumnkey.push({
                                    'title': key,
                                    "dataKey": key
                                });
                            });
                            $scope.reportsTablecolumndata = [];
                            var parsedData = JSON.parse(response.records[0].columnvalue);
                            angular.forEach(parsedData.values, function (value, keys) {
                                $scope.reportsTablecolumndata.push({
                                    "id": keys
                                });
                                angular.forEach(value, function (value, key) {
                                    if (value == null) {
                                        $scope.reportsTablecolumndata[keys][key] = JSON.stringify(value);
                                    } else {
                                        $scope.reportsTablecolumndata[keys][key] = value;
                                    }
                                });
                                delete $scope.reportsTablecolumndata[keys]["id"];
                            });
                            $scope.duplicateReportsTablecolumndata = angular.copy($scope.reportsTablecolumndata);
                        } else {
                            $scope.reportsMessage = response.message;
                        }
                    }).error(function (response) {
                        void 0;
                        $rootScope.loaderCurrentStatus = 'false';
                        $scope.errorHandler(response.config.url, response.status);
                    });
                }
                $rootScope.getReportsData = function () {
                    var loginuserId = localStorage.getItem("userid");
                    var startdate = $filter('date')($scope.reportstartDate, 'yyyy/MM/dd');
                    var enddate = $filter('date')($scope.reportendDate, 'yyyy/MM/dd');
                    var adaccountExpirationreport = baseUrl + '/reports/adaccountexpreport';
                    var config = {
                        url: adaccountExpirationreport,
                        method: "GET",
                        headers: {
                            "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                            "cdt-rscid": $scope.selectedResourcekey,
                            "cdt-loginguid": loginuserId,
                            "cdt-startdate": startdate,
                            "cdt-enddate": enddate
                        }
                    };
                    $http(config).success(function (response) {
                        $scope.reportsResponse = response.type;
                        $scope.reportsMessage = response.message;
                        if (response.type === "success") {
                            $scope.reportsTablecolumnkey = [];
                            $scope.reportsTablecolumndata = [];
                            $scope.duplicateReportsTablecolumndata = [];
                            var parseddata = JSON.parse(response.records[0].columnvalue);
                            void 0;
                            angular.forEach(parseddata.values[0], function (value, key) {
                                $scope.reportsTablecolumnkey.push({
                                    'title': key,
                                    "dataKey": key
                                });
                            });
                            var keyData;
                            for (var j = 0; j < parseddata.values.length; j++) {
                                $scope.reportsTablecolumndata.push({
                                    "id": j
                                });
                                for (var k = 0; k < $scope.reportsTablecolumnkey.length; k++) {
                                    if (parseddata.values[j][$scope.reportsTablecolumnkey[k].dataKey] === null) {
                                        keyData = JSON.stringify(parseddata.values[j][$scope.reportsTablecolumnkey[k].dataKey]);
                                    } else {
                                        keyData = parseddata.values[j][$scope.reportsTablecolumnkey[k].dataKey];
                                    }
                                    $scope.reportsTablecolumndata[j][$scope.reportsTablecolumnkey[k].dataKey] = keyData;
                                }
                                delete $scope.reportsTablecolumndata[j]["id"];
                            }
                            $scope.duplicateReportsTablecolumndata = angular.copy($scope.reportsTablecolumndata);
                        }
                    }).error(function (response) {
                        void 0;
                        $rootScope.loaderCurrentStatus = 'false';
                        $scope.errorHandler(response.config.url, response.status);
                    });
                }
                $scope.$watch('query.filter', function (newValue, oldValue) {
                    if (newValue == '') {
                        $scope.reportsTablecolumndata = $scope.duplicateReportsTablecolumndata;
                    }
                    if (newValue) {
                        $scope.items = $filter('filter')($scope.duplicateReportsTablecolumndata, newValue);
                        $scope.reportsTablecolumndata = $scope.items;
                    }
                });
                $scope.exportPdf = function () {
                    void 0;
                    var startdate = $filter('date')($scope.reportstartDate, 'yyyy/MM/dd');
                    var enddate = $filter('date')($scope.reportendDate, 'yyyy/MM/dd');
                    var reporttitle = $scope.selectedreporttitle;
                    var headerImgData = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAREAAABOCAYAAAAHOyIYAAAgAElEQVR4nO1dd3hUVdp/wcJaFhsqmXGVVWxEsUQyzGTuOVex46e7n6IUaZn0mUlPsKCLFdta191V97OsuiqIFAEhCSSk9zItCb0lBJTeAuHM+/1x7sncmZSZRNyw7v09z3mSzLzn3HNP7nnv2w+ABg0aNGjQoEGDBg0aNGjQoEGDBg0aNGjQoEGDBg0aNGjQoEGDBg0aNGjQoEGDBg2/SsyZ5z7z7XnF1767oHD8+0uqk95f7njm/ZWeF99f7njmvSXVSW/NKxz/9rzia+fMc5850HPVoEHDKYKR9uVDbkxfdP9NmQv/Efl8QfPt77uP3/tZC/5x3l4cP/8A/s93h/DBbw/gXV/tRfmTFjS/5z4+5vmC5vD0hf+4OnXx+JH25UMG+h40aNAwABj9+spzxmZ+kzxubp7nkX9tx2k5DKcXIFoKEeOLEWOLEKMLEWOKvJhQjBij/G0pRIwvRJyRy/CPX27HcXPzPGMyv0kenbnynIG+Jw0aNPybYJj13UO3v5TrnrRwL1rWcOYws9CLiSUMk8oYxpYxjC9naK/kLamCN2sFQ2s5w4RShpZCL0YXIsYWIj723V68/aVc923ZCx4c6HvToEHDL4iR9uVDxmZ//d4fP9uEMQrziC5imFjO0F7F0FrF0F7DMLWOYXItQ3sdw7R63lLqGKbVMUyrZZhcrdCXM4wpZjhzDaJlDeJDn23EW9O/fk9TcTRo+BXCPLfoAvPsRblTvj+EMYWIMwsZxpRyhmCr4QwjvYFhuoNhqoNhmoNhhpO3dOVnmoNhSgPDFIWpJNcytCnMJK6I4Yw1iBOXHELz7EW5xjmlFw70PWvQoOEkQZ6Tfz7509KS6TnHOQMpYmirZJhay9BWxxlHppNhioNhhothtpv/zHLzlu5imObin2W6OFNJcTC013PmY61mGFfB0FLM0FKIOD2nA+947vtSeU7++QN97xo0aPi5mDDvNPrskuUzc45jdCFiXCnDlGqGtlqG1nqGWQpzSHcxnOVmmOribZaHM45UF8NMN8NsD/+ZqmIoGS4uoaQ2cMnEXi3sJYiPrziOUc8sWQ4T5p020EugQYOGnwFp9sLnJy85gI8XIEYXM0ytYZhUyzC5gTOQFCdnDpluhikuhukKw0hxMrQ6OHPJdvOW5WaYoUgmqS6GyU6GyQ6GaYqqY69jmFjFcKYikUxdcgDJ0wtfGOg10KBBQz8hv5h/2wP/t7YjtgjRUsIwRWEgKQ7OQFIVRpGmUl0yFUah/j1bYRwpLv63YDqdTMXJx0ppYJhcx+0k8aUMY4oQH/pk3Qn6fN6YgV4LDRo09APjXitYZclHjC32oq3SJ4FYGxgmNfhUlUw3ZyRqtSXN5WMm6ULqcHIVRtBmqRiKUImSGxgm1TBMqmQYW+xFSz7iXa+tWTXQa6FBg4Y+4vbXSumkeTtwZiGitZxhbBW3XaS7GNocPskjQyVtZLoZZnk4I8lwc5Um2ekzrArGku5iaHcyTHL4vktVjK5pToZpDdxzE1/G0FKEOHFeG971Wikd6DXRoEFDH3Df2xVfRq/2YlKpFxMqeaxHhqLCPOHhmz/d7W8szfbwz5Kd/LN0N8NEB/87M0CNSVMYSbrbp+JkubmalO702UcSS71oyffi/W9X/Gug10SDBg0hYvxfHRc8/PnGnxJKEGPLeJBYcgNnINkK0xBqi93pYwLCsJqiMIhkJ0Ob06fKJDRw6aOTybh86k688p3dydCuxJgk1jCMK2OYUIr4yBebfhr/1y0XDPTaaNCgIQQ8+HcPmbl8P1pKEFOqGSbXc2NqtsIghPs2TfldSCQpTt4yPIiZzYhpTYg2D6LVzdtMB2Ksi3+e1YiYodhK0t2+Me1OrtKIOJLUGoaJ5YjTfjiA971XccdAr01/ceWVV54XHh7+4KhRo14fMWLEbwZ6PqcaRowYcf6oUaPuu+GGG/4WHh5++UDPR8PPgDTnh9Hj31j1laWIob3Ki/YAd+4sj2/jZymu3CxFIkn2IKZ6EGPL92H0yg2YtLgWsxeW4TMLi/FPC4vw2cUlmL64GmNXNOPM4t2Y6ELMakbMdHs7GZGwpaQ6eeRrYg2fR0KJF+9/v9xjfubbP5tnL3ngFA9EGwIAZgCYDABzAGARAGwDAASANuX7/2YMBoA7ACAGAF4BgGUA0AJ8fRAArh64qZ1y0AHAoIGeRFCEz5l3Jnny2+l3vLCscMI/G09MyzuKSRVetFUztNZx1SJZYSBCDRG2kCw3wxQ3YrIHMaFgGz6zqAS/WlmAZWXl2OSox01Nbtyytgm3rGvCTc0eXOtyYHVlBS7MLcDnFhfijJyNGOfwYlYTYoqLu4xnebhKk+zgUlBiNUN7pZdLJKs68OFvWvHuN0u2mZ+Y/w6ZnXv9QK9fN/g9ABwG36ZQtwb4T3goflmcCQD1AHAUuq7PPgAIG7ipnTL4HQAUAMBBACgBgKsGdDa9wTTru4fGvbiifuK3uzCmEDG+DDG+HDGlhksBIpw92838pIVUEd7ehGirPYRPLSrFVcWl2LppPe5q3Y4tLdtx27ZtuHXrVtyyZYvStuLWrVuxZft23Nnagju2bMSy8gqcvbAIpxbvxrQmxHQXt408oUg5GU6u1iTXMkyoYJhY5sWEEl5aYPLyY/jA3+oOj8n85i15Tv6wgV5LFc4AgCuUNg4A9oJvk5QO4LxOFQwCgPMB4ELga1QNvvXZpXz+346PwZ+5fjOw0+kG8pz8c6Xsbz568LPNGLsGcUYhYmIpw8QKhslKUFmaEk2a6fK5cjPcDBMcihu3CTGp9Ef8y5LV2Lp5A+7b/RO2tbX1qe356Sf8qWULfpVTiImFrZjoRrTU+xhJsmJkTVKygBOreFmBqUW8nEBsEeLjy47i3a+uWm946ru7Bnpde4ALfA+DFvPSFR+Cb322A8C5AzudXxQXh0i3GvyZSMUvNqP+gLy45nd3PLe0fNLSo2gpRIwtYhhbyiNFbTVchbA1cFdrmmLzEOHsNic3rmY1Ilqr9uOHS/Px0O5duH//ftyzZ49f279/Px45dACPHtyPRw/sw6MHD+DBAwe60O3dtw+PHdyHy4oq8PH8NrQ4EaPrFRewiwe2ZboY2ht4pnBMFcPYCoYJ5QzjSxjGFyHGrEG8/wN3x9iseYkDvb7dwAG+h2HZAM/lVMRH4FufjQDwazQ83wkAKwGgErhNKBimgT8Tif/lptZHkBfX/O72l3Iao1d5cfoaRGspz6C11zC01vKMXLFpOxmIiAFRfmZ5vGh1nMDXl5Xi4T0/4qFDh3D//v2d7cDBg3j8yGFs2boFcytq8YvVFfjZ6gpcXFyN7qZmbD+4Hw9306fj4H78y/ISnFLVjikuLyYpWcGJDdxWktjApZKUBh6QllDDMKmK4bRihnFF/H4mfLkVzU/MzxjodQ5ALfgehu8GeC6nItRMZC1wdfDXgnOBMw9xf1V96Hs/ALwMAA/9AvPqH+6bUz6UPr+iekaeF2OKEBPKeCGhxBqGtnquOmSpDKcZKhuIiOnIcjNMa0JMyWnGjevW4fFj7Xjw4MHOdvjwYTx2aD8uL6nCjJVujC3djbE17RhTcwxnlB9AS84G/DC3HPfuasP29qN+fdvb27F1yyZM/KEJ7Y3YGU+SpsSRpCkuYSGVWJTCR5ZKXppgRiHDuCLE//18MxpnLZo80OutQgX4HiItaK4r1EykEQB+TZnb54O/TSxnYKfzM3HnnO8/m7S8HeOLeEq/rVpJqGtQYjOcvnyWNMVwmuz0hbfP8jDMbvRiXG07flFQhdjRjkeOHPFreOwofp5bgtPyd2ByE2Kah7tws9xezG7kLt2Y6sP44uJiPPDTLjx27Jhff2/7YXx9ZTU+Xsswpt4X7RpTz+cg4lMSGxhG13Gjr62eV1OLLWcYX8wwtgjx7r/UH7zv5bxRA73mCkrA9xB9OrBTOSWhZiIuCE3c/0/B2QCwGXz3t2hAZ/NzsLDU84cHv2jFmYWISWUME6qUCmMObvtIUBLqRNKckEJsKsYyy8MwswnRumoTbt68GRk7ge3t7Z0NvQyrnW5MyN+GSY3IA8cU6cHq4MbSTDfDzEbEmJoj+PeccsRjR/HYsWO+MVgHfppfjY9XH0eb04s2pU+cIomIXJsUF0NLPY8nSXZwW0l8NcO4coZxxV6cnIt432v5BXPmzDkVHkg1E/nHAM/lVISaifzaXOBDAGA9+O7vq4GdTj+xadOm30z52NE0ZRVibDHPkLXX8WAuUW0svoFLHkICyfaoclvUn7kR5+bWIzt6CI8fP97ZOjo68MSRQ/jM8lpMcGFnWHymqn5IqsrLM6sZMa6wDfMq6hAR8cSJE4iIyA7vx7krazHW6cUMRRIS6pSQQuyKmiMklVTFFRxXy2NKEssYRhcijv/6J/yuvHniSV7OwcAt7DrlZyhn6KiZyEf9vO7pADAMAPQAcEmI1+0NQwHgrD72uRh+XqDcb4Gv20UBn6u9M7X9HFv9f+lvIOKF0L17WT320D6OeToANIHv/j7px7zOAoDzQqD75ZjvV0Xrpj44bw9OL0S0VvBU+3QlmCtTlb8ivDAZCsOwOvzT9bM8Xoyracf5JfWI6MWOjo7Ohoi4duNmtKzahmlNiEkO3t/m4FKDsG0kO/lnSQ6GsS7ExJx1WOVw4aG9u3FHawt+kl+NSVX7MdHp7YyEFRKRGMeiqDaxiis4RfEiCe+NvZphYinDSXmIMV801eXn559+EpbRDPxhbwIeEHUQAH4CgGYAmAcAjwLfJN2hEPrHRM4GgEkAsBB4ROdxZYxjALABuJF2Ri/XDcRFwONW3gWALQBwTxD6wcDjOB4FbsvZBQA39WH+AHwDzASAfADYDwAnAGAPcGbxDgAYwF8Sqezj+AQAPgOArQDQAb6AtRIAeAqCB65dADx69l0AaAWANNV3YQDwFnDv2k/K/FsAIBcALBC6AbgBfPf3Zoh9zgUAIwC8BNzY/HYvtFcDwPvA1/TREMe/Bvj6vw4An02cOFHXK3XSvLWFk/O8OLOYx4DY6rh0keLkzEIYLdMVVUYk2FmVeJBsJVI1qxExpmQ3ljubuNTAWGdDRFxW5cJJJQcx3YOdNULsTp7Jq068U9cayWhEjFmzA5OWudCeuw5T645gogu5yuL0qTAJDl+yn3D9xjf4kvzSlQzjDAcvtZhYzjChBPGBr3bh8tpNP6eMgAT+Pvt28G3mwDathzH6w0QeBm5kROAh838BgGQAeBIAlgZctxkAejpuIwUA5gNAHfCNoO4X1Q39MAD4O/B4lk3QNar0uhDnPxg4g9sEnOFWKPMuA4BDqvG8wDen+LskxPFvBoDlSp964JvNBjyMXr1pW6Crd8MEAJ8DZ1h7Au4vWaG5CXypCj21QgC4LMg89cDd1qLPUuAbfRIATAWAWABIBS7hGIAHmZUCZ2jqa73WzdhXA3+eAqOjbUHmdBoArFHRfz9hwoSe41dq1u8a+dCXO47HFCE/C6aWqzEiMlTkvwgJJEtRIbKVzZrt8ak5WU2IMau34doNmxAR0ev1djZExM8K69FS24GWem7DEKUT1cbaFIWRpDgZxjZwlSTeiZjahDirGdGq2EGylJiUWR4ugYi+QrUROTZC7cpwc6aX6mSYWMtwZjnDpFIv/mHpcXz5h43vBlnU7nAR+MTsZuB5HtcDwHAAuBwAZAB4FQB2qP4Zcg9j9ZWJvKSifwa6j5u4FQBqwP/hsXdD9wbw2JRc8Gd+XgC4sRv6y4A/6EuBP2jqPkcAYEQI85eAbwQEgGeBq19q6IBvHPXa9YWJJIBv41i7+f40AMhWjdkBAPepvn8IOJNcBVwiU19/MnDmegi4tPcRADwPXFKphq7zLYOu/5/BwBnCh9Bz+kNgG6Zcux44E2wP+P7pbu5zTg/jnwAuofWEJ8H3crqlFzqOL8q2TP/jokMYV4KdtpA0JRdGMAmxMYUnJkWVGyMMrOkublSNz9uEra2t2BUM31tdj6kub6fkkuTgjEJ4WNJVUkiKYGJuH6OIa/BXX0SyX6bKNiJUImEvSXVxWsGk0l28gHR8FbeNPL4aMX7Btvo+GlivBAC3stALoHfbgR74Wx6h58SxvjCRp1W0zwehvRg4g1M/QON7of9CRXcUeI5PMHyt6rMfgqsH6cAfYgSAPwahvQK4mtMXJmJX0b4chPb/VLRboXu7wnXA1UNBtxgAdgKXSALtP4OAS5uBGzcwnOBS4M/EBuAqhpreCdy4LtpHwBn92QFjPBZwjaxu5n42cPuPEThDVNOv7+F+I4Ez1X3AX0TB8XJuy7uPrejAmBIv2lVp/WJzCslAvcHT3b6iQyLJrpOJ5G7AH3ft7JaJvLGqAafXezslg1mqKmfqluX2FW5OdfnUHSG1JDb4ChwJ1cquYiJ2pcyisJEI5if62xu4xJVYwTCuGPGR+T8e8Gz+MdSkrrPA98bZBKHZG9KAb5ye8ndCZSJjAYApdFsgNMPnPeD/8GwAgJ6OJH1TRbcX+MMeDO+o+vwEPd8jAMAfVLS96fBqnA3+hufemMj14Nvwe4LMBQDgNvCtJwJAXDc0w8A/jgOBq5K9IT6A/p8B3w8Gf+mkXkUbauHx0QHX6E7KVGMI8BgUdZ+/BdCcCwAeCP6y8UfW8rZlU1d5Ma5UiUpVKpQJO0KKSjIQXhT1m18wkVQXw6xmxOicTbhjx45umIgX/1bQgDanF61OLlXENagMnyrjamDLdHsxs4mrNHbFsyOYRZYilYiQ+0SHvzQixlZXTUusZ5haz9BayZnIwwsPYO3WfbeFuGSpqn/CMyH2SQKuHvSU8xEqE1FHNr4T4rUB/DchAsDjPdC9qqLZAaF5MV5X9WmBnpnqOeBzZR6FvmWd/lV1jd6YyAcquuUhjHsWcAlELWUEYhgA/KiiCSUt4SzwL11QHIRebaN5NYTxAQBugOAMMBCXAH/xqZ8FdQ0eoZ6nhDgHjtmr9pVOW+3FuDIemZpUzzeaUCXEW9wW8LddpSIIiSW7GXFG3jZct2lLN0wE8dPCBoytPY7ZHm8nI4pv4N4UUaRZXeU9zcVdxtE1x9CSuwltK5vRVrEH0xqxUx0S8xRSUlyDL+4kVmFUfvVeXbyQdFoDP6ozptiLjy49grXbDtJgazVnzpwzwd8dZw5xmW8AbiDryQsUChO5DnzeBQSAR0K8NgC3C6gfnPk90L2iotkCPUssasxV9dkEPUtHE1V01aFOXIHaO9MTE/kt+NtQQt2M5ao+HugaDXsBcPUlVBVJQG1sd0Lv7tX+MJHA5yE6xH4y+NRJBB68B8CfJwRuNO8bZhccqpy8youxZdy1m9zgs4lkqN7yiQ7f215IJmLzCgkluxExtvgnrHQ3d+udyat142NFezHegZ12FeE2FmqHXWkpToaZHi/a647ge3k1uH3bVty9qw2XllRjUv4WTFOC1YSNRthZbAoDyXT7mIwoEi1UsnRRPqCaoaXIixOXt2P19oO3B1uruXPn3qJa/FBtBqEgFCYSKCIb+jD+zeD/1nJD96Hjr6lo1kNoMR8vqPqshZ7jU75U0X3Zh7kDhMZEjOC/Pukhjl2s6rMNujLOC4AXihI0T4U47jxVn2Ch+v1hIteCv1F7aoj9ALgtTb1WHwFX/wqhP3lJTxccyn8sz4tJFQwTqhUmorIn2FQqg/gpqrH7SSIuHicSU3UUF5TyOBF1sJnXy3D79m2YvGoj2jyIsYqHxurwN9Cqz6dJdCM+ubQGj+7b3entQWT4eUEVxtUcxUyPFxMa/NUu4YZOdPCmzusRElOmi9t+7NU8evWx5cewuvVoUKnilVdeeVy18KEYEUNFKEzkbfD/xwe3mvtwAfAYDtG3Dbo3qqltIk3Qs+SkhpqJ9MScBoG/3v9WH+YOEBoTCcxqbQNuvKwAgCLghsUc4CrhSuCSQqD3qgW6GjDPA393amaIc/5c1SdYqH5/mMjV4G/w7Usu2BngL4GJl0aglyw0PF9y5KsJucqh2cqxD6nCHuL0SR5qL4jYpKJie7rKBhHnRHw1pw47Dh/Ao0eP+jXWfhjfyanCZBfDWR5fxKlNCTxTtyQP4rS8bVjlcCN6WecYXsawwdOEloIdaHdztUYEvQlGlOxkGF3vk57UDCrZqZQwqOfJhQklXnx02fET7h3HgubRzJ07N0O16IeAV5c6GQiFiXwK/v/0sX0Y/3TwxZQgcB0/MCoUAOA9FY0HQstRUTORnkLSzwF/28MbfZg7QGhMRP2/ESpELvhctatVLQ8AfgAepPcP4GpcAnDPROD8A5lIqBKOmonUB6E9GUwk1CAygRsBYLeqvwu6MtDQ8E9nx9OPrGSYUOZjIsIYmez0/W5TNqRQY4RRVWzazohTD6I1byOuX78O24/6Z+EeO3oUm5rX4vTvPZjQiJjm8vpJH512iyZES8VB/L+cEuw4fNBvjI72diyudWBs0S7MVkomCsOu8CJlKEwuS8X8xHxTlUpsaYphNabQi3G5Ha27du0KWuhm7ty5s1SLzoDbOk4GiiA4E1G7IxH6Yj3nUL91t0L3D4x6szpCHFfNRGp6oDkP/O0VH4Y8aw51Fa+emMgT4L8+lj5eoyf0l4mo3eXBbED9tYmo1ZlgHqPuMB/816x/KRfF2ztuf3QFw7gShpYKbnC0KdKIUGvSlUAtUc1d2DCEO9aqhK4nK3aMmJp2/Di3FNsP7OtSYOjooQO4srgCp3zfiJPrvJjoQcxoRExvRG7naEScWbobX1lYgLt3tHQpZtR+cB9+nFuOSfXHMMPt7WQUaYpEIhiaulSBKF1gU8LfUx3cxWutYDhlFcPnyk+sCGWtXnnllZSARf/ffi16V4SSO6O2VyD4h1+HAnXNkp6qYP1TRRNqyr3aGNtTLYyzwT9oKzfkWXOoH/aemEgi+K9PqAbQYAi0iYTKRL6C4OstcDKYSLCYm0BMAO4xPAD+69bXcQDa2vAcyyq2LbaQp8qn1jGMr+exGFkenxtVhLgL5iFsJiL8Xag+WW6GyY2ISTnrsLa2Dvfv3Ys7d+7EXbt2dbaDe3djTX0DPrekDC0rmtGyphUthTsxMX8LPrm8Fhfml+LuHS24e/fuzr47d+3CvXv2YLPHjTFLPWhvxM64EiEFZbp5tnGaSlpSq2KpLiUr2cHQWs0wrpThhJUMv13LkoOvFMDcuXMfDljwv/Z5wbtHKEzEEnDteX0Y/0zwzxR9vwe6f6lo1kFoSXzqOJGe8loGgb8ktAtCSxgTUOvvPTGR8eC/Piv7MH5vCGQi3QV1dQe1YbW3urmDwL88Zqiq3vXg72Xpy+a/BbhjoAoAIsA/3WEH8IjhvuGDBvbG1DyGMaUMU2sZRtcwjKv31QvJdPvUGfGWF8xEeGbSxZteuFqdXnx6USluWdeEu3buxJaWFr/2466d+GPLVnQ4HJhXUo4risqwrKoGN69fi3t27cTWHTv86Nva2nDX1k34yuJCtDYcx0yPt1MCEXYaocqkqhhcXAN3I4sAtGQHPxTcWsVw+hqGsXns8PrdGJJt44UXXrga/N1qocZSBIO6KNHHPdAExgXshNA3Yhjw/BTRd1wPdGomshVCc/EuhuAbHKCrTaenWJVAXAw8ejLYNS4DHnYv6A5AfzZDV1wE/nEi2SH2W6jqU9QLXWAWb6jxPzcAlyREv1Bd/sOBu+L3A8BI5bPAF9T3IY7lw+Z9+HtLHjs8fQ23E1hrffEiqaq8E+HiFdKHYCbiaMwsN9+wWW6GdhdifF07vrG0GDc3e3BHS4uqqruvtWzfjm2tLdjW2oKtLdsDqr/z1tqyHVs2rMV3FqzEpKr9mOZBP1VLuJrFvBKUiFY1TYbi2o2p5V6oxDKGE/MY/s1x4pM+LNUg8OV8iPZSnxe8K9Sqxhc90AwGnoehvnaosQHqt3QZ9KymqG0PByF4xOpN4B+y3RsTeQT8594MoUX7Bto6ervGygDauSGMHwyXgL8B8skQ+4nkPwRuOO8JZwKX+gRtqM/jzeB/r6F4Z84CnxE/MOnw+4DxQvVC+fBVE3th2iqGMSUMU5Rq7pmKhyY7gImI4zGFQTPT7cv0TVJqnT7hYZjoQoyvPYpzFhZhRVkZtmzeiFs2b8YNGzaE1LZs3oytWzZiTWUFPrcgHy0VBzDZgxjf4GNiwjMkIlID83pEy3QxjKtjOKOKB5lZihjGrmZHNuzCvh6ENCFgsY8DwP/0ecF9GATckyDG+7YX2ocCrr0WQrOof6eaa2/xJWojabAH8yrgbzT127C3NP2zwX+zIPAqXr0VXb4TODNTZ8v2Zl+4K2D8YwBwdy/03c0xEDrwtxvMDnEsdbBZb+rMEOCpCKEwHDXGgP+9xobQR+Q5dVdu4HLwZ5bHAYCGOBeO1lY8O6OI1U0vYJhUzhPU0h0ME5TqYCKeI0VlXxCBXlluX8btLI/PM2JzMrQ4EGMdXkxe4cYPv8/D8tJS3Njowq0b1uHmjRtw04YNuHHDety4YT1u2rABN29cj1s2rMP1HheWlpbi+4ty0bLEgQmODsxuwk5DakwDv2aKiomlBDA2EROS7uLG1KRahgmVDO3lDGMKGKbks1AfCDUGgb+oisDF6JlB+snQfYbrIPC3VwQL1/4s4NrBPB2PqmiDeSwC7Qo7oOuDNBi4J+BH4BJUXzw6gUxQSBa3g3+Q00XA3/i7gOv66nD2YNdQ0wqJakaQPhS4yiF3890V4O9KDfWZUauoDb3QDQb/l8hx4Ml1AjcBzxAPdD1L4H+fs4LMR9iunNBzVPHMgDFbAaBvJUTtecdGpRWyn2IK+UFQMVU8sjO+njOTwCzbDJUaI6JN1cFnCQ4e0h7T4MUkD6Kt7gjac5rwqe8K8b1FufjtD6twxap8zMsvwNzVBfhDXj7O/yEP/744D59dWIRJK5vRWnsE05sR09xeP69LQoMv9kN8LrJ9hfSR7ebemAwnZyC2an4A+EIypNcAABBxSURBVJR8hokFJ1ZHfFDd36rh50PXcz8QePRjOvCkNwm4CP8S+AKtAutzDAKeKam2V6wH/uD2pHKcBfwNrr7uP4FnFgfS2ZTv9wPAlBDu6zfAjW3qsU8AVxPeAs6whCdBBCe9oaLdB8EfutnQdd0QeFzKD8BjOvYCZ1Impc+3KrqDwGuj9FRBbAj4GzVFKwOuGj0A/H/zkDIXYbTdBN1vrvsCxpkHwb1Wg8HfWLoXfPaH7vBJN/MtAu7FYsBjWdRM5Fzouo5FwCOoAwMEh4DPs8cgeKqGkFrVjCRjypQpY4L08yG9oOP2zGJ2wFLIMLqUYVotj+5MUyqdpatiMdS5NCIqNEE55jJJKRIU2+CLcE108ELM6Y2IMdVHcXrRbrTkt2D86q1oK9iK9sJWtJbtRntdO6Y1ImY0Iya7vJ1JdSJOxerwJdeJKmspTn7tzuhUF2cg6Q5eZGlGBY+FmbSaobWQNc9Ydmh4yIvSPc4CrnOrjX49tRbwFzf1wDdrYK0K0bzAD2laBt2HIZ8GAH8C/+zSDuAP0pfA9VvhUVgA3JIfKq6ErpGcgW0x+KJ1AwsgHQMeF1EGvDpWd4gF/3yUwOYCf6ZY0Q3NAeBvVX034w8CLsn82E2/wLYf+FtafUj4w8r8q8HfAyLaRuX7b6B7hnIudH0u9gNnWCuhqzH+KvAvTKRuK8HHGKYCVwkDs4rVbQf41JU08I9xea+buQbiUuBqst+4kydP/iCEvj5kFXRIWSWsxbKGYVIZw/hKfkxlfK1ybKVy7oyoXypUhxQli1YEqYlNLk6rS3Rwlcfm5CHyTzRxhmL1IFrdiAkuxDgnYlwDD2cXIfbCSJqsGi/Z6fMWpTh910x38nN6xfGa6fUMYyq4O/fxfIYpxazJsqK9t7dCnxAWFnaFTqez6nS6r/R6fbler3fq9foGvV6/Sq/Xv63X6x+49NJL/bwcQ4cOvTAsLOwpvV6frtPponU63SS9Xj9BtLCwsKk6nc6m0+ms0EvoeVhY2BVhYWEper1+gV6vr9fpdJv0ev1anU6Xq9Ppnr3kkktG9+eedDrd2Xq9PlGv1y/V6/X1er3eodPp1uh0uvd0Ot2dAbQP6fX66cOHD39k+PDhj4i56/X6p4cNG9ajd+Siiy7S6/X6DL1ev0yZe51Op1ui0+myzjvvvAtUpIN0Ot3EsLCwqXq9/oHhw4ePDwsLe1in01n0en3G0KFDezxSc9iwYWF6vT5Rp9N9rdfrK/V6vVO5To5er387LCzsf/V6fZfI3eHDh0eGhYU9pdPprMp1O/83Op1usl6vT9DpdLOU/0+XqN5LL730nLCwsLjhw4dP0+v1E1TrYtfr9RmBz4OYa1hY2Is6na5ImWeRTqd77fzzz+9kODqdLkqn02XrdLqYwGdGp9NNUp6lTJ1O9xgAgF6vH6fX6xOU7y3qsXrDJZdccpVy/RVhYWGpYWFht02dOjUUT50/EvPar3y+8kSerZjhlDU8MCuhkseRJIpDrOr5ZrUqSXsJDfxcmrh6zmSsSnHnZAf/PcvFMKaOH36VouqX6fJvWUrLUCJlE5Tgt0wXZxDC2GtTHaRlb/Adp5nRwNBWyzC1hqtl0cUMpxcwzC45kRedc/hkuP16hFLcaECqkf9ClesHwS9/P/+W9TpFKvsHxX/KPEPChHnzTnu+nKU+Wc7akooZTi3kRteESl57JL6av+njapQjGWp5DdOkOn7chL3e99nMaoYxNTys3lrHv8twcFUpqY5hQi3/mVTH+1hqOL2tnjMFu0KX4eDn4CTW8ujaDAe/Vmo9d92m1fHjPu2VXPqIXsPQXsyOzC7pmCPPOSkFmTVo0NBX2HIO616r7njhmUq2NbVUOUmuhOH0Yn54dlwFP67SWqWoPjX8Z2oNwxnlPFvWUsHw8TKG0RVKtfUq/ru1imFqNU/Lj63kqkeiMlaacgymRaFLqVEO7K5imKLQx1fyvnEVDG0V/MzguGKGthKGmWXs2DMVJ75MyTvWL7FegwYNJxkzFu49/4miE5OeLT8xb1Yp2x5XyNCyhuHUAoYT8xlGFzKcWMB/TingzGZmIcNphTwu49F8hlPXcJrphTxi9LF8/vmUNZzGUsTpp61hOLmA4SRlvBnKmDMLGUYX+Y//eAGfR3whQ2sRO/Z0OaubXdbxYsLKYycrQU6DBg0nGx9U7zlvybrjY5dtPBGzaCN756t17Mv5G7zzv17Hvl6wkX327Xr26Tfr2aeLN7JP5ys/v9vIPl2o/PxqPf99sfLZfIX+m/X8e9Hve4VejLFwI6dZqOq3cD3759KN7MXvN554ZHFT+7Xw6zohTYMGDRr+ezF16tRzrFbrA3a7fYbdbo+22+13x8XFDbPZbBNsNlv2hAkTftbh3HFxcZcnJyc/abPZ/A7aSkpKGmmz2e6z2Wz3xMXFqd23kJycbLLZbC8nJCSM+JnXPsNqtd4aFxfX33gjAOBrlJSU1Bc3fCAG2Wy2P9jt9tl9mYvVag1PSEjoXyEiDRr+HXj11VcjR11/fe7YMWNix3DQsZGRnxrGjJlpMBimGiIjXcFH6R3XXnvtbw0GQ1FkZKRfYtwtt9xysSEycvXYyMjvwsPD/dzAkZGRvzdERrZGRkb29bQ+MBgMo8aMGUMAAEaPHn3J2MjIPMMNN1wKAKdFRkY+EBEREazCfBeMGTNmisFgWAv9P6h80NgxYx4zREZu7G2MiIiI88bedtuDoMS2jI2M/NRgMPSlVq8GDf8+7Nmz57xHHn64KcpguF/9uSRJYbLROFKOihorE1Kg/k4eM2b46NGjA+MRAjdF59+jR48+R7755vMpIZ/JktTlVDdCyN+oJP1Z/VlkZORFcnj4uZTSMtlk6rSZGY3GC+Wbb+4SR2EwGIaGh4d3lkSglL4ZMOZpADDYaDSeJVO63mQyXQJcnR6s9BscHh5+pszjfbqTuk6jkvRnmdI2Sul93XwPUVFRv1XPAYAzhKioqM4ERtlkuoESUikDnK7QDoqIiDgjIiLiDPEZIcRECWkIGKdTchk5cuQQSZIuVn9311136X5VLmcN/zlYsmTJoxG33trU0/ey2WymhKwCUDY2IXNkSUqghHxGCIkODw8/k0rSq4SQtwAAqNk8lRKSYzQaL1T63ytLUgKl9GVKSCshpEtGMyXkA0LIXACAiIiIs6nZPJUQkkIp/VimtM1kMl2hjD2TSlIspfRdheYWSsgySmk2pfRDSmkVIYSMHj36HErIYkpIDiFkGjWbJ1FKcyVJuphSaqSUbqOUPksImUwJWUYImSWPGPEbQsh0mZBPIyMjuwS2SZJEqdk8kxBipZR2FmuilBopIcsppU/JhPydUlolm813AgAQQh4lhLwgE7KCSlKs8tktlJCK0aNHnyMT8golZLFsMFwmjx07ghLyjSRJlBASTyldJ0tSKiHkbpmQRbIkPaLMY5xyrU+pJD0nG40jqSQ9SyUpMTU19S/r1q37OQe1a9DQd3z88cdpEbfeWtvT95IkRQkmQin9iBCSAgBgMpmuooTslseOHUEIsVJCFgAAEEKulildr7wtx1NKPxdjyYSsoJQmBV6DEvIBlaSXFJo3hLRiNBovpJQ65TFjhstm8wOUkBzlTX0jJWSn0Wi8kBJSQgiZFRERcQaVpGcopT/II0b8RibkU5mQv5hMpqtkg+EymdL18pgxwwkh18uUuiiltxsMhqGUkHcoIR8AACjMptuiQYSQtwghN5pMpisoIbslSRoFACCPGPEbSkiJTMjs8PDwMymlT1FCcpT1kpQ1fFim1AUAIJtMN1NKqwAAoqKiwimlm4xG41mRkZEXKWtwmsLcKqKiosKVOeYQQqaYzeabZEK+HTly5BCj0XgWpfQ+Kkl/NptMrwAALFu27Ga32x1KgSoNGk4e8vPz77wtIuJwdyoCgMJElDevTKlLNptl8R0lpFKSpHsIIdMppZ8AcFWHElKhfP+OTMgTnfSUfkIlqcsJcGpJRKa0WjaZblb1KTKZTJcQQl6glBbJkjSDEBIvEzJn5MiRQyghywkh9ytzHd+5gSXpJULI0wBczaCEVEiSdHFERMQZMiHlQtqQjcaRlNLGyMjIiwghGfKIEV1KHpjN5itlQlYQQmZRScqihNQQQjrzWyghS4SKQym9jxKyUpnPQ4SQpxXJrVIZ6yaFiQxS6H8ghDwmSdI9kiRFKZ+NCZB2PieEPEglKY0S4lftTo6Kuo0SUmKOiqp66YUX3mxtbe1fEWcNGvqL6urqMywzZ5aZxo79Vg7I/zEajWcpTCQfAIASUkglqbPYj0xIuclkukoR8ecDABBCbqSUOgEAKKXPUkp/EPSU0jJZkmIAuNoi9HxFFXlTuUaFkEQkSQqTKd2s2EaSxRtcDUrISsFEZEl6hFK6UBnzTZmQOQDcJkMJqTEYDEMjIiLOpoQ0mM3mC1RjLKCU/osQ0lnTJCIi4myxHsp9GDvv22S6Waa0TTBeSun3kiTdI+YgE7KIEPI7SogbAMBsNl9DKa1T1ud69X1QSv9ICamhlCaL60mSRCkhhSqa+ZIkjSeEPCrWVsBsNl8DAIPuvffeEXfdeWftmjVr+lKXRYOGk4N333334ttuvXUBJWQJISSFEBJNKX2KEEIopUmUEI9sNI4khBBKSK0sSX+gkhQrVBtF5WmhkvQcIeR1SsgGs9kcIUlSGCXETSn9mBBioZQWUUrfVUTxfxFCppnN5sspIYWUkGWywXCZogJtI4S8TilNopSuo5ROUAyzpTIh/5AlKUYR7y+nhNQq0s5phJBHZUqrDQbDpYSQeEpIsyxJE5V5txBCHgSA0yghNZSQL00m01XK/MdTQloiIiLEW3yQonrdRSkdQwmpEVICAJcmZErbCCGvR0VFhVNCaimlT8kAp0uS9LBMSLkkSZGUkGZlTTJkStdLkjSaEDJFpnQ9IeRGAG4UpYRsoGbzJDG+bDReJ1PaRiXpObPZfI1MSDkh5C355pvPlwkpkAn5glIaJ0kSpZKUZTabU8aNG3d7Wlra3La2Ns0VrGHgIBuN10mSNF6SpHGEkN8BwCBJkkZFRUWFG41GPQCA0WjUU0rvIoT4xUtERUWFS5J0T0RExHmEkKvFBo2IiDhPNpvvlQ2GywwGw1BJkkaNHDlyiMlkuspoNF5oMpkukU2mGwghNwqPg2w0jpTN5nvl8PBzjUajXjYar1PGOoNSepdsNssGg2GowWC4NCoqKjwqKiocAE6Tw8PPjYqKCheqCqVUMpvNl8tjx45Q7uNaAADZYLiMUnq7kITMZvOVhBCr+n4IIdcbDIahiqR1o9lsvlL13e9lo/E68bkkSaNkk+kGGeB0OTz8XNlkusFoNF5ICPk9IeSO8PDwM81m8zUmk+kKs9l8jSRJo4SxWBlvljBEqz67UY6Kuk2OiBimrO1omUsqgwkhd0iSNM5gMAw1Go0XSkbjuPvvvpts27YtlIPjNWjQcLJBCJlODIa+lt88OdceO/Z6Yjb35VQ8DRo0nCowm83XEEIWBEoh/y4QQt6gkvSJwWAIVmhbgwYNpyLWrVs3pLGx8RoYoByuxsbGEW63u8diTRo0aNCgQYMGDRo0aNCgQYMGDRo0aNCgQYMGDRr+0/D/EC549QmfVgEAAAAASUVORK5CYII='
                    var doc = new jsPDF('landscape', 'pt');
                    var time = $filter('date')(new Date(), 'medium');
                    var header = function (data) {
                        if (data.pageCount == 1) {
                            doc.setFontSize(12);
                            doc.setTextColor(150);
                            doc.setFontStyle('normal');
                            doc.addImage(headerImgData, 'PNG', data.settings.margin.left, 40, 130, 40);
                            doc.setFontSize(15);
                            doc.setTextColor(40);
                            doc.text(reporttitle, data.settings.margin.left + 250, 60);
                            doc.setFontSize(12);
                            doc.setTextColor(150);
                            doc.text(time, data.settings.margin.left + 625, 60);
                            doc.line(40, 85, 798, 85);
                            if ($scope.selectedreportKey == '3') {
                                doc.text("Start Date : " + startdate, data.settings.margin.left, 100);
                                doc.text("End Date : " + enddate, data.settings.margin.left + 640, 100);
                            }
                        }
                    };
                    var totalPagesExp = "{total_pages_count_string}";
                    var footer = function (data) {
                        var str = "Page " + data.pageCount;
                        // Total page number plugin only available in jspdf v1.0+
                        if (typeof doc.putTotalPages === 'function') {
                            str = str + " of " + totalPagesExp;
                        }
                        doc.setFontSize(12);
                        doc.setTextColor(40);
                        doc.text(str, data.settings.margin.left + 680, doc.internal.pageSize.height - 30);
                        doc.text('Powered by Cloudentix \u00a9 2014 - 2018', data.settings.margin.left, doc.internal.pageSize.height - 30);
                    };
                    var options = {
                        beforePageContent: header,
                        afterPageContent: footer,
                        theme: "grid",
                        margin: {
                            top: 110,
                            bottom: 50
                        },
                        printHeaders: true,
                        styles: {
                            overflow: 'linebreak'
                        }
                        //columnStyles: {email: {columnWidth: 'wrap'}}
                    };
                    if ($scope.selectedreporttitle === 'Duplicate Email Id Report') {
                        doc.setFontSize(12);
                        var mail = 0,
                            countlimit = 0;
                        doc.autoTable($scope.reportsTablecolumnkey, $scope.duplicateemailData, {
                            theme: 'grid',
                            beforePageContent: header,
                            afterPageContent: footer,
                            theme: "grid",
                            margin: {
                                top: 110,
                                bottom: 50
                            },
                            printHeaders: true,
                            styles: {
                                overflow: 'linebreak'
                            },
                            drawRow: function (row, data) {
                                doc.setFontStyle('bold');
                                doc.setFontSize(10);
                                if (mail < $scope.duplicateemailtitle.length) {

                                    if (row.index === 0) {
                                        doc.setTextColor(200, 0, 0);
                                        doc.rect(data.settings.margin.left, row.y, data.table.width, 20, 'S');
                                        doc.autoTableText("Email ID : " + $scope.duplicateemailtitle[mail].email, data.settings.margin.left + data.table.width / 2, row.y + row.height / 2, {
                                            halign: 'center',
                                            valign: 'middle'
                                        });
                                        data.cursor.y += 20;
                                        mail = 0;
                                        countlimit += parseInt($scope.duplicateemailtitle[mail].count);
                                    } else if (row.index === countlimit) {
                                        mail++;;
                                        doc.setTextColor(200, 0, 0);
                                        doc.rect(data.settings.margin.left, row.y, data.table.width, 20, 'S');
                                        doc.autoTableText("Email ID : " + $scope.duplicateemailtitle[mail].email, data.settings.margin.left + data.table.width / 2, row.y + row.height / 2, {
                                            halign: 'center',
                                            valign: 'middle'
                                        });
                                        data.cursor.y += 20;
                                        countlimit += parseInt($scope.duplicateemailtitle[mail].count);
                                    }
                                }
                            }
                        });
                    } else {
                        doc.autoTable($scope.reportsTablecolumnkey, $scope.reportsTablecolumndata, options);
                    }
                    if (typeof doc.putTotalPages === 'function') {
                        doc.putTotalPages(totalPagesExp);
                    }
                    setTimeout(function () {
                        doc.save(reporttitle + ".pdf");
                    }, 1000);
                }
                $scope.exportCsv = function () {
                    //var reporttitle = sessionStorage.getItem("selectedReporttitle");
                    var JSONData, ReportTitle, ShowLabel;
                    JSONData = angular.toJson($scope.reportsTablecolumndata);
                    ReportTitle = $scope.selectedreporttitle;
                    ShowLabel = true;
                    var arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData;
                    if ($scope.selectedreporttitle === 'Duplicate Email Id Report') {
                        var CSV = '';
                        //Set Report title in first row or line

                        CSV += ReportTitle + '\r\n\n';

                        //This condition will generate the Label/Header
                        if (ShowLabel) {
                            var row = "";

                            //This loop will extract the label from 1st index of on array
                            row += 'Email,';
                            for (var index in arrData[0].duplicateemailrecordslist[0]) {

                                //Now convert each value to string and comma-seprated
                                row += index + ',';

                            }

                            row = row.slice(0, -1);

                            //append Label row with line break
                            CSV += row + '\r\n';
                        }

                        //1st loop is to extract each row
                        for (var i = 0; i < arrData.length; i++) {

                            for (var index in arrData[i].duplicateemailrecordslist) {
                                var row = "";
                                row += arrData[i].email + ',';
                                for (var datas in arrData[i].duplicateemailrecordslist[index]) {
                                    row += arrData[i]["duplicateemailrecordslist"][index][datas] + ',';
                                }
                                row.slice(0, row.length - 1);
                                CSV += row + '\r\n';
                            }
                            //add a line break after each row
                        }

                        if (CSV == '') {
                            //alert("Invalid data");
                            return;
                        }
                    } else {
                        var CSV = '';
                        //Set Report title in first row or line

                        CSV += ReportTitle + '\r\n\n';

                        //This condition will generate the Label/Header
                        if (ShowLabel) {
                            var row = "";

                            //This loop will extract the label from 1st index of on array
                            for (var index in arrData[0]) {

                                //Now convert each value to string and comma-seprated
                                row += index + ',';

                            }

                            row = row.slice(0, -1);

                            //append Label row with line break
                            CSV += row + '\r\n';
                        }

                        //1st loop is to extract each row
                        for (var i = 0; i < arrData.length; i++) {
                            var row = "";

                            //2nd loop will extract each column and convert it in string comma-seprated
                            for (var index in arrData[i]) {
                                row += '"' + arrData[i][index] + '",';
                            }

                            row.slice(0, row.length - 1);

                            //add a line break after each row
                            CSV += row + '\r\n';
                        }

                        if (CSV == '') {
                            //alert("Invalid data");
                            return;
                        }
                    }
                    //Generate a file name
                    var fileName = '';
                    //this will remove the blank-spaces from the title and replace it with an underscore
                    fileName += ReportTitle.replace(/ /g, "_");

                    //Initialize file format you want csv or xls
                    var uri = 'data:text/csv;charset=utf-8,' + escape(CSV);

                    // Now the little tricky part.
                    // you can use either>> window.open(uri);
                    // but this will not work in some browsers
                    // or you will not get the correct file extension    

                    //this trick will generate a temp <a /> tag
                    var link = document.createElement("a");
                    link.href = uri;

                    //set the visibility hidden so it will not effect on your web-layout
                    link.style = "visibility:hidden";
                    link.download = fileName + ".csv";

                    //this part will append the anchor tag and remove it after automatic click
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                }
                $scope.exportXml = function () {
                    var reporttitle = $scope.selectedreporttitle;
                    var JSONData, ReportTitle;
                    JSONData = angular.toJson($scope.reportsTablecolumndata);
                    ReportTitle = reporttitle;
                    var arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData;
                    if ($scope.selectedreporttitle === 'Duplicate Email Id Report') {
                        var CSV = '';
                        //Set Report title in first row or line

                        CSV += '<?xml version="1.0"?>' + '\r\n';
                        CSV += '<organization>\r\n';
                        //1st loop is to extract each row
                        var count = 0,
                            removedspace, email;
                        for (var i = 0; i < arrData.length; i++) {
                            count = i + 1;
                            var row = "<record>\r\n";
                            //2nd loop will extract each column and convert it in string comma-seprated
                            for (var index in arrData[i].duplicateemailrecordslist) {
                                email = String(arrData[i].email);
                                row += "<email emailId = " + "'" + email + "'" + ">\r\n";
                                for (var datas in arrData[i].duplicateemailrecordslist[index]) {
                                    removedspace = datas.toString();
                                    removedspace = removedspace.replace(/ /g, '');
                                    void 0
                                    row += '<' + removedspace + '>' + arrData[i]["duplicateemailrecordslist"][index][datas] + '</' + removedspace + '>\r\n';
                                }
                                row += "</email>\r\n";
                            }
                            row += "</record>\r\n";
                            CSV += row + '\r\n';
                        }
                        CSV += '</organization>';
                    } else {
                        var CSV = '';
                        //Set Report title in first row or line

                        CSV += '<?xml version="1.0"?>' + '\r\n';
                        CSV += '<organization>\r\n';
                        //1st loop is to extract each row
                        var removedspace;
                        for (var i = 0; i < arrData.length; i++) {
                            var row = "<employee>\r\n";

                            //2nd loop will extract each column and convert it in string comma-seprated
                            for (var index in arrData[i]) {
                                removedspace = index.toString();
                                removedspace = removedspace.replace(/ /g, '');
                                row += '<' + removedspace + '>' + arrData[i][index] + '</' + removedspace + '>\r\n';
                            }
                            row += "</employee>\r\n";
                            CSV += row + '\r\n';
                        }
                        CSV += '</organization>';
                    }
                    //Generate a file name
                    var fileName = '';
                    //this will remove the blank-spaces from the title and replace it with an underscore
                    fileName += ReportTitle.replace(/ /g, "_");

                    //Initialize file format you want csv or xls
                    var uri = 'data:text/xml;charset=utf-8,' + escape(CSV);

                    // Now the little tricky part.
                    // you can use either>> window.open(uri);
                    // but this will not work in some browsers
                    // or you will not get the correct file extension    

                    //this trick will generate a temp <a /> tag
                    var link = document.createElement("a");
                    link.href = uri;

                    //set the visibility hidden so it will not effect on your web-layout
                    link.style = "visibility:hidden";
                    link.download = fileName + ".xml";

                    //this part will append the anchor tag and remove it after automatic click
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                }
                $scope.updateReportColumns = function () {
                    $mdDialog.show({
                        controller: updateColumnController,
                        locals: {
                            resourceid: $scope.selectedResourcekey,
                            reportid: $scope.selectedreportKey,
                            reportTitle: $scope.selectedreporttitle
                        },
                        templateUrl: 'reports/cloudentix-admin-updatecolumn.html',
                        parent: angular.element(document.body),
                        clickOutsideToClose: false
                    }).finally(function () {
                        if ($scope.selectedreporttitle == 'Access Policy Violation Report') {
                            $scope.accessPolicy();
                        }
                        if ($scope.selectedreporttitle == 'AD User Password Expiration Report') {
                            $scope.getadPasswordExpiration();
                        }
                        if ($scope.selectedreporttitle == 'Duplicate Email Id Report') {
                            $scope.getDuplicateMailId();
                        }
                        if ($scope.selectedreporttitle == 'AD Account Expiration Report') {
                            $rootScope.getReportsData();
                        }
                    });
                }
                if ($scope.selectedreporttitle == 'Duplicate Email Id Report') {
                    $scope.getDuplicateMailId();
                }
            }
        } else {
            $rootScope.loaderCurrentStatus = 'false';
            $scope.errorHandler(response.message, response.status);
        }
    });
}

function updateColumnController($http, $scope, $rootScope, resourceid, reportid, $mdDialog, $mdToast, reportTitle, SessionService) {
    var loginuserId = localStorage.getItem("userid");
    // contains a whole list of reports - ngRepeat
    $scope.listofColumns = [];
    // before update -  onload - right
    $scope.getColumns = [];
    $rootScope.loaderCurrentStatus = 'true';
    var getColumnUrl = baseUrl + '/reports/reportcolumns';
    if (reportTitle == 'Access Policy Violation Report' || reportTitle == 'AD User Password Expiration Report' || reportTitle == 'AD Account Expiration Report') {
        var config = {
            url: getColumnUrl,
            method: "GET",
            headers: {
                "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                "cdt-loginguid": loginuserId,
                "cdt-reportid": reportid,
                "cdt-rscid": resourceid
            }
        };
    } else {
        var config = {
            url: getColumnUrl,
            method: "GET",
            headers: {
                "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                "cdt-loginguid": loginuserId,
                "cdt-reportid": reportid,
                "cdt-rscid": '0'
            }
        };
    }
    $http(config).success(function (response) {
        $rootScope.loaderCurrentStatus = 'false';
        $scope.getColumns = [];
        if (response.type === "success") {
            angular.forEach(response.records[0].columnname, function (value, key) {
                $scope.listofColumns.push({
                    "targetcolumn": value
                });
            });
            angular.forEach(response.records[0].dropdownlist, function (value, key) {
                $scope.getColumns[key] = value["value"];
            });
            $scope.listofColumns = $scope.listofColumns.filter(function (elm, idx) {
                return $scope.getColumns.indexOf(elm.targetcolumn) === -1;
            });
            $scope.choosenReportsColumn = $scope.getColumns;
        }
    }).error(function (response) {
        $rootScope.loaderCurrentStatus = 'false';
        $scope.errorHandler(response.config.url, response.status);
    });
    $scope.updatecolumnclose = function () {
        $mdDialog.hide();
    };
    $scope.updatecolumnhide = function () {
        $mdDialog.cancel();
    };
    $scope.addReport = function (value) {
        $scope.getColumns = $scope.getColumns.concat(value);
        $scope.listofColumns = $scope.listofColumns.filter(function (elm, idx) {
            if (value.indexOf(elm.targetcolumn) === -1) {
                $scope.listofColumns.push(elm);
                return true;
            }
            return false;
        });
        $scope.choosenReportsColumn = $scope.getColumns;
    }
    $scope.removeReport = function (selectItem) {
        $scope.getColumns = $scope.getColumns.filter(function (elm, idx) {
            console.log(elm, "elm value");
            return selectItem.indexOf(elm) === -1;
        });
        var selectItem = selectItem.map(function (elm) {
            elm = {
                targetcolumn: elm
            };
            return elm;
        });
        $scope.listofColumns = $scope.listofColumns.concat(selectItem);
    }
    $scope.submitupdateColumns = function (isValid) {
        if (isValid) {
            $scope.postselectedColumns = {
                "records": []
            };
            for (var i = 0; i < $scope.getColumns.length; i++) {
                $scope.postselectedColumns.records.push({
                    "trgtcol": $scope.getColumns[i]
                });
            }
            var submitColumns = JSON.stringify($scope.postselectedColumns);
            console.log(submitColumns, "inside http");
            var postColumnUrl = baseUrl + '/reports/reportcolumns';
            if (reportTitle == 'Access Policy Violation Report' || reportTitle == 'AD User Password Expiration Report' || reportTitle == 'AD Account Expiration Report') {
                var config = {
                    url: postColumnUrl,
                    method: "POST",
                    headers: {
                        "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                        "cdt-loginguid": loginuserId,
                        "cdt-reportid": reportid,
                        "cdt-rscid": resourceid,
                        "cdt-reportcolumns": submitColumns
                    }
                };
            } else {
                var config = {
                    url: postColumnUrl,
                    method: "POST",
                    headers: {
                        "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                        "cdt-loginguid": loginuserId,
                        "cdt-reportid": reportid,
                        "cdt-rscid": '0',
                        "cdt-reportcolumns": submitColumns
                    }
                };
            }
            $http(config).success(function (response) {
                var icon;
                if (response.type == 'success') {
                    icon = 'done';
                    $mdDialog.hide();
                    // $rootScope.getReportsData();
                } else if (response.type == 'error') {
                    icon = 'error_outline';
                } else if (response.type == 'warn') {
                    icon = 'warning';
                } else {
                    icon = 'info_outline';
                }
                $mdToast.show({
                    template: '<md-toast class="md-toast toast-' + response.type + '"><div class="md-toast-content"><i class="material-icons">' + icon + '</i>&nbsp;&nbsp; ' + response.message + '!</div></md-toast>',
                    hideDelay: 3000,
                    position: 'top right'
                });
            }).error(function (response) {
                $rootScope.loaderCurrentStatus = 'false';
                $scope.errorHandler(response.config.url, response.status);
            });
        }
    }
}