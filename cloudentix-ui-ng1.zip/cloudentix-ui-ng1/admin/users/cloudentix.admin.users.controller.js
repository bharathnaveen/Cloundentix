/*
 * Cloudentix Core JavaScript Library v1.0
 * http://cloudentix.com/
 *
 * Copyright 2016, Sennovate, Inc.
 * Released under the MIT license
 * http://sennovate.com/license
 *
 * Author : Kannan
 * Last Updated On : 2016-08-04
 */

/*
    list user begins:
    *we defined listusers name of controller function
    *then injected needful directives in controller function
*/

angular.module('cloudentixApp')
    .controller('listusers', listusers);
listusers.$inject = ['$rootScope', '$scope', '$log', '$location', '$window', '$http', '$mdDialog', '$mdMedia', '$mdToast', '$document', '$route', '$timeout', '$state', 'keepInputfields', '$filter', 'SessionService'];

function listusers($rootScope, $scope, $log, $location, $window, $http, $mdDialog, $mdMedia, $mdToast, $document, $route, $timeout, $state, keepInputfields, $filter, SessionService) {
    'use strict';
    var baseUrl = sessionStorage.getItem("WS_BASE_URL");
    /* base Url for list resource */
    var checkResourceURL = baseUrl + '/resources?check=true';
    var config = {
        url: checkResourceURL,
        method: "GET",
        headers: {
            "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
        }
    }
    $http(config)
        .success(function (response) {
            /*  check two resources (trusted and untrusted)available in if not it is navigated to add resource */
            if (response.type == 'success') {
                if (response.data.login[0].trusted == 'N' || response.data.login[0].untrusted == 'N') {
                    if (response.data.login[0].trusted == 'N' && response.data.login[0].untrusted == 'N') {
                        $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure trusted and untrusted resources");
                    } else {
                        if (response.data.login[0].trusted == 'N') {
                            $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure the trusted resource");
                        } else if (response.data.login[0].untrusted === 'N') {
                            $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure an untrusted resource");
                        }
                    }
                }
                /* if two resources (trusted and untrusted) is configured then proceeds*/
                else if (response.data.login[0].trusted == 'Y' && response.data.login[0].untrusted == 'Y') {
                    /* it clear service data */
                    keepInputfields.storedata = {};
                    var convertUserguid;
                    keepInputfields.storeTrusteddata = {};
                    keepInputfields.storerolesdata.listroles = [];
                    $scope.selected = [];
                    $scope.limitOptions = [10, 25, 50, 100];
                    $scope.options = {
                        rowSelection: false,
                        multiSelect: false,
                        autoSelect: true,
                        decapitate: false,
                        largeEditDialog: true,
                        boundaryLinks: true,
                        limitSelect: true,
                        pageSelect: true
                    };
                    $scope.query = {
                        order: 'name',
                        limit: 10,
                        page: 1,
                        filter: ''
                    };
                    $scope.loadData = function (startrecord, endrecord) {
                        $rootScope.loaderCurrentStatus = 'true';
                        var listUser = baseUrl + '/users';
                        var userid = localStorage.getItem("userid");
                        $scope.adminid = userid;
                        var usertype = localStorage.getItem("usertype");
                        if (startrecord) {
                            var params = {
                                start: startrecord,
                                size: endrecord,

                            }
                        } else {
                            var params = {
                                start: 1,
                                size: 10,

                            }
                        }
                        var config = {
                            url: listUser,
                            method: "GET",
                            params: params,
                            headers: {
                                "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                                "cdt-loginguid": userid
                            }
                        }
                        $http(config)
                            .then(function success(response) {
                                $rootScope.loaderCurrentStatus = 'false';
                                $scope.userResponse = response.data.type;
                                if (response.data.type == 'success') {
                                    $scope.userList = [];
                                    $scope.duplicateUserList = [];
                                    $scope.userCount = response.data.records[0].count;
                                    angular.forEach(response.data.records[0].listusers, function (value, key) {
                                        convertUserguid = parseInt(value["guid"]);
                                        $scope.userList.push({ "guid": convertUserguid, "userName": value["username"], "ntwuserid": value["ntwuserid"], "emailid": value["emailid"], "employeeId": value["employeeid"], "managerName": value["managername"], "statusFlag": value["statusflag"] });
                                    });
                                    $scope.duplicateUserList = angular.copy($scope.userList);
                                } else if (response.data.type == "error") {
                                    $scope.toastMessage('toast-error', response.data.message);
                                } else if (response.data.type == "warning") {
                                    $scope.toastMessage('toast-warn', response.data.message);
                                } else {
                                    $scope.toastMessage('toast-error', response.data.message);
                                }
                            }, function error(response) {
                                $rootScope.loaderCurrentStatus = 'false';
                                $scope.errorHandler(response.config.url, response.status);
                            });
                    };

                    $scope.onPaginate = function () {
                        var startrecord = ($scope.query.page * $scope.query.limit) - $scope.query.limit + 1;
                        var endrecord = $scope.query.page * $scope.query.limit;
                        $scope.loadData(startrecord, endrecord);
                    }
                    /* it trigger seach field data for filtering list user*/
                    $scope.$watch('query.filter', function (newValue, oldValue) {
                        if (newValue == '') {
                            $scope.userList = $scope.duplicateUserList;
                        }
                        if (newValue) {
                            $scope.items = $filter('filter')($scope.duplicateUserList, newValue);
                            $scope.userList = $scope.items;
                        }
                    });
                    $scope.viewUser = function (usersId) {
                        localStorage.setItem('userGuid', usersId);
                        $state.go("viewuser.userbasicinformation");
                        $scope.addTab('View User', 'viewuser.userbasicinformation');
                    }
                    $scope.editUser = function (usersId) {
                        localStorage.setItem('userGuid', usersId);
                        $state.go("edituser.userinformation");
                        $scope.addTab('Edit User', 'edituser.userinformation');
                    }
                    $scope.toggleLimitOptions = function () {
                        $scope.limitOptions = $scope.limitOptions ? undefined : [10, 25, 50, 100];
                    };
                    $scope.logItem = function (userList) {
                        void 0;
                    };
                    $scope.logOrder = function (order) {
                        void 0;
                    };
                    $scope.logPagination = function (page, limit) {
                        void 0;
                        void 0;
                    }
                    /* it will ask confirm message to enable a user 
                        if you click yes it will proceed enabling a user
                        otherwise not
                    */
                    $scope.enableUser = function (enableUsername, enableUserid) {
                        $scope.enablecontent = 'Would you like to enable the user ' + enableUsername;
                        $scope.status = '  ';
                        $scope.customFullscreen = $mdMedia('xs') || $mdMedia('sm');
                        var confirm = $mdDialog.confirm()
                            .title('User Enable')
                            .textContent($scope.enablecontent)
                            .ariaLabel('Confirm')
                            .ok('Yes')
                            .cancel('No');
                        $mdDialog.show(confirm).then(function () {
                            $rootScope.loaderCurrentStatus = 'true';
                            var enableUser = baseUrl + '/users';
                            var config = {
                                url: enableUser,
                                method: "PUT",
                                headers: {
                                    "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                                    "cdt-guid": enableUserid,
                                    "cdt-flag": 'E'
                                }
                            }
                            $http(config)
                                .then(function success(response) {
                                    $rootScope.loaderCurrentStatus = 'false';
                                    if (response.data.type == "success") {
                                        $scope.loadData();
                                        $scope.toastMessage('toast-success', response.data.message);
                                    } else if (response.data.type == "error") {
                                        $scope.toastMessage('toast-error', response.data.message);
                                    } else if (response.data.type == "warning") {
                                        $scope.toastMessage('toast-warn', response.data.message);
                                    } else {
                                        $scope.toastMessage('toast-error', response.data.message);
                                    }
                                }, function error(response) {
                                    $rootScope.loaderCurrentStatus = 'false';
                                    $scope.errorHandler(response.config.url, response.status);
                                });
                        }, function () {
                        });

                    };
                    /* it will ask confirm message to disable a user 
                        if you click yes it will proceed disabling a user
                        otherwise not
                    */
                    $scope.disableUser = function (disableUsername, disableUserid) {
                        $scope.disablecontent = 'Would you like to disable the user ' + disableUsername;
                        $scope.status = '  ';
                        $scope.customFullscreen = $mdMedia('xs') || $mdMedia('sm');
                        var confirm = $mdDialog.confirm()
                            .title('User Disable')
                            .textContent($scope.disablecontent)
                            .ariaLabel('Confirm')
                            .ok('Yes')
                            .cancel('No');
                        $mdDialog.show(confirm).then(function () {
                            $rootScope.loaderCurrentStatus = 'true';
                            var disableUser = baseUrl + '/users';
                            var config = {
                                url: disableUser,
                                method: "PUT",
                                headers: {
                                    "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                                    "cdt-guid": disableUserid,
                                    "cdt-flag": 'D'
                                }
                            }
                            $http(config)
                                .then(function success(response) {
                                    $rootScope.loaderCurrentStatus = 'false';
                                    if (response.data.type == "success") {
                                        $scope.loadData();
                                        $scope.toastMessage('toast-success', response.data.message);
                                    } else if (response.data.type == "error") {
                                        $scope.toastMessage('toast-error', response.data.message);
                                    } else if (response.data.type == "warning") {
                                        $scope.toastMessage('toast-warn', response.data.message);
                                    } else {
                                        $scope.toastMessage('toast-error', response.data.message);
                                    }
                                }, function error(response) {
                                    $rootScope.loaderCurrentStatus = 'false';
                                    $scope.errorHandler(response.config.url, response.status);
                                });
                        }, function () {
                            void 0;
                        });

                    };
                    $scope.loadData();
                }
            } else {
                $rootScope.loaderCurrentStatus = 'false';
                $scope.errorHandler(response.message, response.status);
            }
        });
};