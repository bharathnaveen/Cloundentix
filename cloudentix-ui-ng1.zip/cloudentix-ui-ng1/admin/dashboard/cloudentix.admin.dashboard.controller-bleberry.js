angular
    .module('cloudentixApp')
	 .controller('dashboardController', dashboardCtrl)
	 .controller('dashboardaccesspolicyviolationissue', dashboardaccesspolicyviolationissueCtrl)
	 .controller('dashboarduserprovisioningissue', dashboarduserprovisioningissueissueCtrl)
	 .controller('dashboardaccesspolicyevaluationissue', dashboardaccesspolicyevaluationissueCtrl)
	 .controller('dashboardapprovalpolicyevaluationissue', dashboardapprovalpolicyevaluationissueCtrl)
	 dashboardCtrl.$inject = ['$rootScope', '$mdEditDialog', '$q', '$scope', '$timeout', '$http', '$state', 'SessionService'];
	 dashboardaccesspolicyviolationissueCtrl.$inject = ['$rootScope', '$scope', '$http', 'SessionService'];
	 dashboarduserprovisioningissueissueCtrl.$inject = ['$rootScope', '$mdEditDialog', '$q', '$scope', '$timeout', '$http', 'SessionService'];
	 dashboardaccesspolicyevaluationissueCtrl.$inject = ['$rootScope', '$mdEditDialog', '$q', '$scope', '$timeout', '$http', 'SessionService'];
	 dashboardapprovalpolicyevaluationissueCtrl.$inject = ['$rootScope', '$mdEditDialog', '$q', '$scope', '$timeout', '$http', 'SessionService'];
 
	 function dashboardCtrl($rootScope, $mdEditDialog, $q, $scope, $timeout, $http, $state, SessionService) {
		var baseUrl = sessionStorage.getItem("WS_BASE_URL");
		var userid = localStorage.getItem("userid");
		 $scope.dashboard = function(){
		  var checkResourceURL = baseUrl + '/resources?check=true';
			var config = {
				//url:"dashboard/data.json",
				url:checkResourceURL,
				method: "GET",
				headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
				}
			}
			   
			$http(config)
			.success(function(response) {
				if (response.data.login[0].trusted == 'N' || response.data.login[0].untrusted == 'N') {
                    if (response.data.login[0].trusted == 'N' && response.data.login[0].untrusted == 'N') {
                       $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure trusted and untrusted resources");
                    } else {
                        if (response.data.login[0].trusted == 'N') {
                            $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure the trusted resource");
                        } else if (response.data.login[0].untrusted === 'N') {
                            $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure an untrusted resource");
                        }
                    }
                }
                else if(response.data.login[0].trusted == 'Y' && response.data.login[0].untrusted == 'Y') {
	  $rootScope.loaderCurrentStatus = 'true';
	  
	  var dashboardURL = baseUrl + '/dashboard';
		var config = {
			//url:"dashboard/data.json",
			url:dashboardURL,
			method: "GET",
			cache: false,
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
				"cdt-userid":userid
			}
		}
		   
		$http(config)
		.success(function(response){ 
		$rootScope.dashboardRecords = [];
		$rootScope.dashboardRecords = response.records;
		
	$rootScope.loaderCurrentStatus = 'false';
		$scope.accesspolicyviolations = response.records[0].acpviolationissue.value;
	  $scope.userprovisioningissues = response.records[0].userprovissue.value;
	  $scope.accesspolicyevaluationissues = response.records[0].acpevalissue.value;
	  $scope.approvalpolicyevaluationissues = response.records[0].appevalissue.value;
	  
	  
	  $scope.accessrequestpending = response.records[0].myaccessrequestpending.value;
	  $scope.totalresources = response.records[0].numofresources.value;
	  $scope.totalusers = response.records[0].numofusers.value;
	  $scope.totalattestation = response.records[0].numofattest.value;
	  $scope.requestpending = response.records[0].numofreqpend.value;
	  $scope.requestpendingapproval = response.records[0].reqpending.value;
	  $scope.requestpendingattest = response.records[0].rolependingformyattest.value;
	   
	  	
		//console.log(response.message);
		//console.log(response.records.accpolicy.key);
		//console.log(response.records.accpolicy.uri);
//console.log(response.records.apppolicy.value);
			//$scope.desserts = response.data;
		//console.log(response.accpolicy.uri_data.method)
			$scope.userList = [];
			  //console.log(response.records.length)
			  
			angular.forEach(response.records, function(value, key) {
				$scope.userList.push({"guid" : value["count"],"userName" : value["uri"],"ntwuserid" : value["value"]});
			});
			//console.log($scope.userList);
		});
		/*
		*This method used for display the access policy violations report in a new tab. 
		*It function works on the value must be greater than 0.
		*if accesspolicy violation value 0 means its shows a toast message.
		*/
		$scope.accesspolicyviolation = function (){
			if($scope.dashboardRecords[0].acpviolationissue.value > 0){
                var reportDetails = new Object();
                reportDetails.reportKey = "1";
                reportDetails.reportValue = "Access Policy Violation Report";
                reportDetails.reportDescription = "Access Policy Violation Report";
                localStorage.setItem('selectedReportDetails', JSON.stringify(reportDetails)); $state.go("reportView");
                $scope.addTab('Report: View','reportView');
			}else{
			$scope.toastMessage('toast-info','No access policy violations found');
			}
		}
		/*
		*This method used for display the User provisioning issues report in a new tab. 
		*It function works on when the value is greater than 0.
		*if approval user provisioning issue value 0 means its shows a toast message.
		*/
		$scope.userprovisioningissue = function (){
			if($scope.dashboardRecords[0].userprovissue.value > 0){
			$state.go("userprovisioningissue");
			$scope.addTab('Userprovision_is..','userprovisioningissue');
			}else{
			$scope.toastMessage('toast-info','No user provisioning issues found');
			}
		}
		/*
		*This method used for display the access policy evaluations report in a new tab. 
		*It function works on when the value is greater than 0.
		*if access policy evaluations value 0 means its shows a toast message.
		*/
		$scope.accesspolicyevaluation = function (){
			if($scope.dashboardRecords[0].acpevalissue.value > 0){
			$state.go("accesspolicyevaluationissue");
			$scope.addTab('Acpolicy_evalua..','accesslpolicyevaluationissue');
			}else{
			$scope.toastMessage('toast-info','No access policy evaluations issues found');
			}
		}
		/*
		*This method used for display the approval policy evaluations report in a new tab. 
		*It function works on when the value is greater than 0.
		*if approval policy evaluations value 0 means its shows a toast message.
		*/
		$scope.approvalpolicyevaluation = function (){
			if($scope.dashboardRecords[0].appevalissue.value > 0){
			$state.go("approvalpolicyevaluationissue");
			$scope.addTab('Appolicy_evalua..','approvalpolicyevaluationissue');
			}else{
			$scope.toastMessage('toast-info','No approval policy evaluations issues found');
			}
		}
		
		/*
		*This method used for display the request pending approval page in a new tab. 
		*It function works on when the value is greater than 0.
		*if request pending approval value 0 means its shows a toast message.
		*/
		$scope.requestpendingapprovalfun = function (){
			if($scope.dashboardRecords[0].numofreqpend.value > 0){
			$state.go("myCloudentix.pendingapproval");
			$scope.addTab('Pending Approval','myCloudentix.pendingapproval');
			}else{
			$scope.toastMessage('toast-info','No request pending approval found');
			}
		}
		
		/*
		*This method used for display the request pending approval page in a new tab. 
		*It function works on when the value is greater than 0.
		*if request pending approval value 0 means its shows a toast message.
		*/
		$scope.requestpendingattestfun = function (){
			if($scope.dashboardRecords[0].rolependingformyattest.value > 0){
			$state.go("attestation.selfattestation");
			$scope.addTab('Self Attestation','attestation.selfattestation');
			}else{
			$scope.toastMessage('toast-info','No pending attestations available');
			}
		}
				}
			});
	  }
	  
  $scope.refreshDashboard = function(){
		$scope.dashboard();
		}
		 $scope.dashboard();			
  }

function dashboardaccesspolicyviolationissueCtrl($rootScope, $scope, $http, SessionService){
         
            var baseUrl = sessionStorage.getItem("WS_BASE_URL");
            var checkResourceURL = baseUrl + '/resources?check=true';
			var config = {
				//url:"dashboard/data.json",
				url:checkResourceURL,
				method: "GET",
				headers: {
					"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
				}
			}
			   
			$http(config)
			.success(function(response) {
				if (response.data.login[0].trusted == 'N' || response.data.login[0].untrusted == 'N') {
                    if (response.data.login[0].trusted == 'N' && response.data.login[0].untrusted == 'N') {
                       $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure trusted and untrusted resources");
                    } else {
                        if (response.data.login[0].trusted == 'N') {
                            $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure the trusted resource");
                        } else if (response.data.login[0].untrusted === 'N') {
                            $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure an untrusted resource");
                        }
                    }
                }
                else if(response.data.login[0].trusted == 'Y' && response.data.login[0].untrusted == 'Y') {
                    'use strict';
                    $rootScope.loaderCurrentStatus = 'true';
                    $scope.selected = [];
                    $scope.limitOptions = [10, 25, 50, 100];
                    $scope.options = {
                        rowSelection: false,
                        multiSelect: false,
                        autoSelect: true,
                        decapitate: false,
                        largeEditDialog: true,
                        boundaryLinks: true,
                        limitSelect: true,
                        pageSelect: true
                    };
                    $scope.query = {
                        order: 'name',
                        limit: 10,
                        page: 1
                    };
                    $scope.toggleLimitOptions = function () {
                    $scope.limitOptions = $scope.limitOptions ? undefined : [10, 25, 50, 100];
                };
                $scope.getTypes = function () {
                    return ['Candy', 'Ice cream', 'Other', 'Pastry'];
                };
                $scope.logItem = function (item) {
                    void 0;
                };
                $scope.logOrder = function (order) {
                    void 0;
                };
                  
                $scope.logPagination = function (page, limit) {
                    void 0;
                    void 0;
                }
                    var accesspolicy = baseUrl + '/reports/accesspolicyviolation';

                    var config = {
                        url: accesspolicy,
                        method: "GET",
                        headers: {
                            "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                        }
                    };
                    $http(config).success(function(response) {  
                        $scope.reportsResponse = response.type;
                        $rootScope.loaderCurrentStatus = 'false';
                        if(response.type === "success") { 
                            $scope.accesspolicydata = [];
                            angular.forEach(response.records[0].accesspolviorecords, function(value, key) {
                                $scope.accesspolicydata.push({'username': value['username'], 'resourcename': value['rscname'], 'rolename': value['rolename'], 'remarks': value['remarks']});
                            });
                        } else {
                           $scope.reportsErrorMessage = response.message;        
                        }            
                       
                    }).error(function(data) {
                        void 0;        
                    });	
                            }
                        });			
         }
   function dashboarduserprovisioningissueissueCtrl($rootScope, $mdEditDialog, $q, $scope, $timeout, $http, SessionService) {
   
    $scope.limitOptions = [10, 25, 50, 100];
  
  $scope.options = {
    rowSelection: false,
    multiSelect: false,
    autoSelect: false,
    decapitate: false,
    largeEditDialog: false,
    boundaryLinks: false,
    limitSelect: true,
    pageSelect: true
  };
  
  $scope.query = {
    order: 'name',
    limit: 10,
    page: 1
  };
		var userprovisioningissueURL = $rootScope.dashboardRecords[0].userprovissue.uri_data.uri;
		var userprovisioningissueMethod = $rootScope.dashboardRecords[0].userprovissue.uri_data.method;
		//console.log(approvalpolicyviolationsURL);
		
		var config = {
			//url:"dashboard/data.json",
			url:userprovisioningissueURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
				
			}
		}
		   
		$http(config)
		.success(function(response){ 
		$scope.userResponse = response.type;
		//console.log(response.records[0].appevalrecords)
		$scope.userprovisioningissueList = [];
		angular.forEach(response.records[0].appevalrecords, function(value, key) {
				$scope.userprovisioningissueList.push({"username" : value["username"],"rolename" : value["rolename"],"resourcename" : value["resourcename"],"remarks" : value["remarks"]});
			});
		});
		}
		/*End*/
		function dashboardaccesspolicyevaluationissueCtrl($rootScope, $mdEditDialog, $q, $scope, $timeout, $http) {
		
		 $scope.limitOptions = [10, 25, 50, 100];
  
  $scope.options = {
    rowSelection: false,
    multiSelect: false,
    autoSelect: false,
    decapitate: false,
    largeEditDialog: false,
    boundaryLinks: false,
    limitSelect: true,
    pageSelect: true
  };
  
  $scope.query = {
    order: 'name',
    limit: 10,
    page: 1
  };
		var accesspolicyevaluationURL = $rootScope.dashboardRecords[0].acpevalissue.uri_data.uri;
		var accesspolicyevaluationMethod = $rootScope.dashboardRecords[0].acpevalissue.uri_data.method;
		//console.log(approvalpolicyviolationsURL);
		
		var config = {
			//url:"dashboard/data.json",
			url:accesspolicyevaluationURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
				
			}
		}
		   
		$http(config)
		.success(function(response){ 
		$scope.userResponse = response.type;
		//console.log(response.records[0].appevalrecords)
		$scope.accesspolicyevaluationList = [];
		angular.forEach(response.records[0].acpevalrecords, function(value, key) {
				$scope.accesspolicyevaluationList.push({"username" : value["username"],"resourcename" : value["resourcename"],"remarks" : value["error"]});
			});
		});
		}
		 
function dashboardapprovalpolicyevaluationissueCtrl($rootScope, $mdEditDialog, $q, $scope, $timeout, $http, SessionService) {
   
    $scope.limitOptions = [10, 25, 50, 100];
  
  $scope.options = {
    rowSelection: false,
    multiSelect: false,
    autoSelect: false,
    decapitate: false,
    largeEditDialog: false,
    boundaryLinks: false,
    limitSelect: true,
    pageSelect: true
  };
  
  $scope.query = {
    order: 'name',
    limit: 10,
    page: 1
  };
		var approvalpolicyevaluationURL = $rootScope.dashboardRecords[0].appevalissue.uri_data.uri;
		var approvalpolicyevaluationMethod = $rootScope.dashboardRecords[0].appevalissue.uri_data.method;
		//console.log(approvalpolicyviolationsURL);
		
		var config = {
			//url:"dashboard/data.json",
			url:approvalpolicyevaluationURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
				
			}
		}
		   
		$http(config)
		.success(function(response){ 
		$scope.userResponse = response.type;
		//console.log(response.records[0].appevalrecords)
		$scope.approvalpolicyevaluationList = [];
		angular.forEach(response.records[0].appevalrecords, function(value, key) {
				$scope.approvalpolicyevaluationList.push({"username" : value["username"],"rolename" : value["rolename"],"resourcename" : value["resourcename"],"remarks" : value["remarks"]});
			});
		});
		}
		