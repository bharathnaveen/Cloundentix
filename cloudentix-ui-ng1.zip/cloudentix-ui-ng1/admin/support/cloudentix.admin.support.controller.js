angular.module('cloudentixApp')
    .controller('supportController', SupportController);

SupportController.$inject = ['$scope','$rootScope', 'SGtoastService', 'SGdataService'];

function SupportController($scope,$rootScope, SGtoastService, SGdataService) {

    var getIssuePage = function () {
        var issuepagesURL = '/issuepages';
        $rootScope.loaderCurrentStatus = 'true';
        SGdataService.getData(issuepagesURL).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.issuepages = response;
            $rootScope.loaderCurrentStatus = 'false';
        }
    }

    $scope.addSupport = function (ticketName, issue, description) {
        var supportURL = '/supportticket';
        $rootScope.loaderCurrentStatus = 'true';
        var headerObj = {
            ticket_name: ticketName,
            issue_page: issue,
            description: description,
            username: sessionStorage.getItem('cdt-uname')
        }
        SGdataService.saveData(supportURL, headerObj).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.support = response;
            $rootScope.loaderCurrentStatus = 'false';
            SGtoastService.toastmessage('toast-info', response.message);
        }
    }

    $scope.getTicketStatus = function () {
        var ticketstatusURL = '/ticketstatus';
        $rootScope.loaderCurrentStatus = 'true';
        var headerObj = {
            username: sessionStorage.getItem('cdt-uname')
        }
        SGdataService.saveData(ticketstatusURL, headerObj).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.ticketStatus = response.record;
            $rootScope.loaderCurrentStatus = 'false';
        }
    }
    $scope.getTicketStatus();

    function errorHandler(e) {
        console.log(e.toString());
    }
    getIssuePage();
}