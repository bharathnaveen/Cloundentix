angular.module('cloudentixApp')
    .controller('selfattestation', Self_attestation);
    Self_attestation.$inject = ['$rootScope', '$scope', '$log', '$location', '$window', '$http', '$mdDialog', '$mdMedia', '$mdToast', '$document', '$route', '$timeout', '$filter', 'SessionService'];        
    
	function Self_attestation($rootScope, $scope, $log, $location, $window, $http, $mdDialog, $mdMedia, $mdToast, $document, $route, $timeout, $filter, SessionService) {
		var baseUrl = sessionStorage.getItem("WS_BASE_URL");
		var checkResourceURL = baseUrl + '/resources?check=true';
        var userid = localStorage.getItem("userid");
		var config = {
			url: checkResourceURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
			}
		}  
		$http(config)
		.success(function(response) {
            if(response.type === 'success'){
                if (response.data.login[0].trusted == 'N' || response.data.login[0].untrusted == 'N') {
                    if (response.data.login[0].trusted == 'N' && response.data.login[0].untrusted == 'N') {
                           $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure trusted and untrusted resources");
                    } else {
                        if (response.data.login[0].trusted == 'N') {
                            $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure the trusted resource");
                        } else if (response.data.login[0].untrusted === 'N') {
                            $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure an untrusted resource");
                        }
                    }
                }
                else if(response.data.login[0].trusted == 'Y' && response.data.login[0].untrusted == 'Y') {
                    'use strict';
                    $scope.attestationMessage = '';
                    $scope.selected = [];
                    $scope.limitOptions = [10, 25, 50, 100];
                    $scope.options = {
                        rowSelection: true,
                        multiSelect: false,
                        autoSelect: true,
                        decapitate: false,
                        largeEditDialog: true,
                        boundaryLinks: true,
                        limitSelect: true,
                        pageSelect: true
                    };
                    $scope.query = {
                        order: 'name',
                        limit: 10,
                        page: 1,
                        filter: ''
                    };
                    
                    $scope.loadselfattest = function() {
                        $rootScope.loaderCurrentStatus = 'true';
                        $scope.selfuserid = localStorage.getItem("userid");
                        var selfURL = baseUrl +'/attestations/self';
                        var config = {
                            url: selfURL,
                            method: "GET",
                            headers: {
                                "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                                "cdt-guid" : $scope.selfuserid
                            }
                        }
                        $http(config).then(function success(response) {
                            $scope.attestationResponse = response.data.type;
                            $scope.cloud_selfattestation = [];
                            $scope.duplicateSelfattestation = [];
                            $rootScope.loaderCurrentStatus = 'false';
                            if (response.data.type == "success") {
                                angular.forEach(response.data.records[0].selfattest, function(value, key) {
                                    $scope.cloud_selfattestation.push({"userID" : value["usrid"],"resourceID" : value["rescid"],"roleID" : value["role_id"],"resourcename" : value["rescname"],"username" : value["username"],"rolename" : value["role_name"],"lastAttestationDate" : value["attestdue"],"attestationFrequency" : value["attestfreq"],"difference" : value["diffdays"]});
                                });
                                $scope.duplicateSelfattestation = angular.copy($scope.cloud_selfattestation);
                            } else {
                                $scope.attestationErrorMessage = response.data.message;
                            } 
                        },function error(response) {
                            $rootScope.loaderCurrentStatus = 'false';
                            $scope.errorHandler(response.config.url,response.status);
                        });
                    }
                    $scope.$watch('query.filter', function (newValue, oldValue) {
                        if(newValue == '') {
                            $scope.cloud_selfattestation = $scope.duplicateSelfattestation;
                        }
                        if(newValue){
                            $scope.items = $filter('filter')($scope.duplicateSelfattestation, newValue);
                            $scope.cloud_selfattestation = $scope.items;
                        }
                    });
                    $scope.attestUser = function(selfusername, selfrolename, selfuserid, selfresourceid, selfroleid) {
                        $scope.attestcontent = 'Would you like to attest the ' + selfusername + ' for the ' + selfrolename + ' role';
                        $scope.status = '  ';
                        $scope.customFullscreen = $mdMedia('xs') || $mdMedia('sm');
                        var confirm = $mdDialog.confirm()
                        .title('ATTEST')
                        .textContent($scope.attestcontent)
                        .ariaLabel('Confirm')
                        .ok('Yes')
                        .cancel('No');
                        $mdDialog.show(confirm).then(function() {
                            $rootScope.loaderCurrentStatus = 'true';
                            $scope.attestvalues = '{"records":[{"usrid":' + selfuserid + ',"resid":' + selfresourceid + ',"roleid":' + selfroleid + '}]}';
                            var attestURL = baseUrl + '/attestations';
                            var config = {
                                url: attestURL,
                                method: "POST",
                                headers: {
                                    "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                                    "cdt-status" : 'A',
                                    "cdt-val" : $scope.attestvalues,
                                    "cdt-loginguid" : userid,
                                }
                            }
                            $http(config).then(function success(response) {
                                $rootScope.loaderCurrentStatus = 'false';
                                if(response.data.type == "success") {
                                    $scope.showattestationToast('toast-success', response.data.message);
                                    $scope.loadselfattest();
                                } else if(response.data.type == "error") {
                                    $scope.toastMessage('toast-error',response.data.message);
                                } else if(response.data.type == "warning") {
                                    $scope.toastMessage('toast-warn',response.data.message);
                                } else {
                                    $scope.toastMessage('toast-error',response.data.message);
                                }
                            },function error(response) {
                                $rootScope.loaderCurrentStatus = 'false';
                                $scope.errorHandler(response.config.url,response.status);
                            });
                        }, function() {
                        });
                    };
                    $scope.revokeUser = function(revokeusername, revokerolename, revokeuserid, revokeresourceid, revokeroleid) {
                        $scope.revokecontent = 'Would you like to revoke the ' + revokeusername + ' for the ' + revokerolename + ' role';
                        $scope.status = '  ';
                        $scope.customFullscreen = $mdMedia('xs') || $mdMedia('sm');
                        var confirm = $mdDialog.confirm()
                        .title('REVOKE')
                        .textContent($scope.revokecontent)
                        .ariaLabel('Confirm')
                        .ok('Yes')
                        .cancel('No');
                        $mdDialog.show(confirm).then(function() {
                            $rootScope.loaderCurrentStatus = 'true';
                            $scope.revokeValues = '{"records":[{"usrid":' + revokeuserid + ',"resid":' + revokeresourceid + ',"roleid":' + revokeroleid + '}]}';
                            var revokeURL = baseUrl + '/attestations';
                            var config = {
                                url: revokeURL,
                                method: "POST",
                                headers: {
                                    "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                                    "cdt-status" : 'R',
                                    "cdt-val" : $scope.revokeValues,
                                    "cdt-loginguid" : userid,
                                }
                            }
                            $http(config).then(function success(response) {
                                $rootScope.loaderCurrentStatus = 'false';
                                if(response.data.type == "success") {
                                    $scope.showattestationToast('toast-success', response.data.message);
                                    $scope.loadselfattest();
                                } else if(response.data.type == "error") {
                                    $scope.toastMessage('toast-error',response.data.message);
                                } else if(response.data.type == "warning") {
                                    $scope.toastMessage('toast-warn',response.data.message);
                                } else {
                                    $scope.toastMessage('toast-error',response.data.message);
                                }
                            },function error(data) {
                                $rootScope.loaderCurrentStatus = 'false';
                                $scope.errorHandler(response.config.url,response.status);
                            });
                        }, function() {
                        });
                    };  
                    $scope.showattestationToast = function(type, msg) {
                        var icon;
                        if(type == 'toast-success'){
                            icon = 'done';
                        }  else if(type == 'toast-error'){
                            icon = 'error_outline';
                        } else if(type == 'toast-warn'){
                            icon = 'warning';
                        } else{
                            icon = 'info_outline';
                        }
                        $mdToast.show({
                            template: '<md-toast class="md-toast ' + type +'"><div class="md-toast-content"><i class="material-icons">'+icon+'</i>&nbsp;&nbsp;' + msg + '</div></md-toast>',
                            hideDelay: 3000,
                            position: 'top right'
                        });
                    };
                    $scope.toggleLimitOptions = function () {
                        $scope.limitOptions = $scope.limitOptions ? undefined : [10, 25, 50, 100];
                    };
                    $scope.getTypes = function () {
                        return ['Candy', 'Ice cream', 'Other', 'Pastry'];
                    };
                    $scope.loadAttestStuff = function () {
                        $scope.promise = $timeout(function () {
                            $scope.loadselfattest();
                        }, 100);
                    }
                    $scope.logItem = function (cloud_selfattestation) {
                        void 0;
                    };
                    $scope.logOrder = function (order) {
                        void 0;
                    };
                    $scope.logPagination = function (page, limit) {
                        void 0;
                        void 0;
                    }
                    $scope.loadselfattest();
                }
            } else {
                $rootScope.loaderCurrentStatus = 'false';
                $scope.errorHandler(response.message,response.status);
            }
		});
	};
	