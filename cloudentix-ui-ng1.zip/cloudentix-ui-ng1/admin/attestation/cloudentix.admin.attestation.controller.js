/*angular
    .module('cloudentixApp')
    .controller('listofattestation', Listof_attestation)
	function Listof_attestation($scope, $log, $location, $window, $http) {
		var attestationtabs = [
          { title: 'Self Attestion', tabLink: "attestation.selfattestion"},
		  { title: 'Pending Attestation', tabLink: "attestation.pendingattestation"},
		  { title: 'History Attestation', tabLink: "attestation.historyattestation"}
        ];
		$scope.attestationtabs = attestationtabs;
	}*/
	