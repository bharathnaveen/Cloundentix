angular.module('cloudentixApp')
    .controller('SGRoleManagerController', SGRoleManagerController);

SGRoleManagerController.$inject = ['$scope', '$rootScope', '$window', 'SGtoastService', 'SGdataService'];

function SGRoleManagerController($scope, $rootScope, $window, SGtoastService, SGdataService) {

    $scope.getManagerData = function () {
        var managerURL = '/manager';
        $rootScope.loaderCurrentStatus = 'true';
        SGdataService.getData(managerURL).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgManager = response.record;
            $rootScope.loaderCurrentStatus = 'false';
        }
    }

    $scope.getJobRole = function (manager) {
        var jobroleURL = '/rolejob';
        var headerObj = {
            managername: manager
        }
        $rootScope.loaderCurrentStatus = 'true';
        SGdataService.saveData(jobroleURL, headerObj).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgJobRole = response.record;
            $rootScope.loaderCurrentStatus = 'false';
        }
    }

    $scope.getStaffName = function (manager, jobrole) {
        var staffnameURL = '/rolestaff';
        var headerObj = {
            managername: manager,
            jobtitle: jobrole
        }
        $rootScope.loaderCurrentStatus = 'true';
        SGdataService.saveData(staffnameURL, headerObj).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgStaffName = response.record;
            $rootScope.loaderCurrentStatus = 'false';
        }
    }

    $scope.getRoleManagerList = function (manager, jobrole, staffname) {
        var rolemanagerlistURL = '/rolemanagerstaffcvuegroups';
        var headerObj = {
            managername: manager,
            jobtitle: jobrole,
            staffname: staffname
        }
        $rootScope.loaderCurrentStatus = 'true';
        SGdataService.saveData(rolemanagerlistURL, headerObj).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgroleManagerList = response.records;
            angular.forEach($scope.sgroleManagerList, function (value, key) {
                if (value.action == 'A') {
                    action: 'A'
                }
                if (value.action == 'R') {
                    action: 'R'
                }
            })
            $rootScope.loaderCurrentStatus = 'false';
        }
    }

    $scope.saveRoleManagerData = function (manager, jobrole, staffname, roleaction) {
        var addrolemanager = '/rolemanagerstaffcvuegroupssave';
        var jsonRecord = {
            records: [{
                managername: manager,
                jobtitle: jobrole,
                staffname: staffname,
                groups: roleaction
            }]
        }
        var headerObj = {
            json_data: JSON.stringify(jsonRecord)
        }
        $rootScope.loaderCurrentStatus = 'true';
        SGdataService.saveData(addrolemanager, headerObj).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgRoleManagerData = response;
            $rootScope.loaderCurrentStatus = 'false';
            SGtoastService.toastmessage('toast-info', response.message);
        }
    }

    $scope.query = {
        order: 'name'
    };

    $scope.getRejectedRoles = function () {
        var rejectedrolesURL = '/rejectedroles';
        $rootScope.loaderCurrentStatus = 'true';
        var headerObj = {
            username: sessionStorage.getItem('cdt-uname')
        }
        var params = {
            format: 'html'
        }
        SGdataService.getData(rejectedrolesURL, headerObj, params).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgRejectedRoles = response.record;
            $rootScope.loaderCurrentStatus = 'false';
        }
    }
    $scope.getRejectedRoles();

    $scope.getCSV = function () {
        var getPDFURL = '/rejectedroles';
        $rootScope.loaderCurrentStatus = 'true';
        var headerObj = {
            username: sessionStorage.getItem('cdt-uname')
        }
        var params = {
            format: 'csv'
        }

        SGdataService.getData(getPDFURL, headerObj, params).then(successHandler, errorHandler);

        function successHandler(response) {
            $scope.sgCSV = response;
            // var pathname = new URL($scope.sgCSV.url).pathname;
            // var path = pathname.substr(1, 100);
            // var fileName = path;
            // var a = document.createElement("a");
            // document.body.appendChild(a);
            // var file = new Blob([$scope.sgCSV.url], { type: 'application/pdf' });
            // var fileURL = $window.URL.createObjectURL(file);
            // a.href = fileURL;
            // a.download = fileName;
            // a.click();
            $rootScope.loaderCurrentStatus = 'false';
        }
    }
    $scope.getCSV();

    function errorHandler(e) {
        console.log(e.toString());
    }
    $scope.getManagerData();
}