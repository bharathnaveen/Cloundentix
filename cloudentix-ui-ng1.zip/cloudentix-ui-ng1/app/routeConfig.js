// JavaScript Document
cloudentixModule.config(function($routeProvider) {
		$routeProvider
        // route for the dashboard page
              .when('/', {
                templateUrl : 'dashboard.html',
               // controller  : 'dashboardController'
        })
        
        .when('/Dashboard', {
                templateUrl : 'dashboard.html',
                //controller  : 'dashboardController'
        })

        // route for the users page
        .when('/List Resources', {
                templateUrl : 'listResources.html',
               // controller  : 'listdata'
        })
		
				// route for the users page
        .when('/Users', {
                templateUrl : 'users.html',
               // controller  : 'listdata'
        })
		
		// route for the users page
        .when('/Role', {
                templateUrl : 'roles.html',
               // controller  : 'listdata'
        })
		
				// route for the users page
        .when('/Attestation', {
                templateUrl : 'attestation.html',
               // controller  : 'listdata'
        })
		
				// route for the users page
        .when('/My Cloudentix', {
                templateUrl : 'myCloudentix.html',
               // controller  : 'listdata'
        })
		
				// route for the users page
        .when('/Manage System', {
                templateUrl : 'manageSystems.html',
               // controller  : 'listdata'
        })
		
				// route for the users page
        .when('/Support', {
                templateUrl : 'support.html',
               // controller  : 'listdata'
        })

});
