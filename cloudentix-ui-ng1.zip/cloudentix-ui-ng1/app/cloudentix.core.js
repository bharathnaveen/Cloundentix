/*
 * Cloudentix Angular Library v1.4
 * http://cloudentix.com/
 *
 * Copyright 2016, Sennovate, Inc.
 * Released under the MIT license
 * http://sennovate.com/license
 *
 * Author : Balamurugan Ranganathan
 * Last Updated On : 2016-04-11
 */
// sessionStorage.setItem("WS_BASE_URL", "http://192.168.168.137:8080/api/v4");
sessionStorage.setItem('WS_BASE_URL', ' http://54.236.42.76:9797/api/v4');
var baseUrl = sessionStorage.getItem('WS_BASE_URL');
// module of cloudentix
angular
    .module('cloudentixApp', ['chart.js', 'ngMessages', 'ngMaterial', 'ngRoute', 'ui.router', 'oc.lazyLoad', 'ngAnimate', 'md.data.table', 'ngScrollable', 'mdo-angular-cryptography'])
    .controller('LoginCtrl', LoginCtrl)
    .controller('displayController', displayCtrl)
    .controller('ChangePasswordCtrl', changePasswordCtrl)
    .controller('ResetPasswordCtrl', resetPasswordCtrl)
    .controller('installController', installCtrl)
    .service('SessionService', SessionService)
    .service('InterceptorService', InterceptorService)
    .constant('SGURL', 'http://54.236.42.76:9797/api/v4/sg')
    .config(['$cryptoProvider', function ($cryptoProvider) {
        $cryptoProvider.setCryptographyKey('ABCD123');
    }]);

SessionService.$inject = ['$http'];
function SessionService($http) {
    this.defaultusername = 'cloudentixUI';
    this.defaultpassword = 'demoSecret';
    this.fetchToken = function (username, password) {
        var config = {
            method: 'POST',
            url: 'http://54.236.42.76:9797/api/oauth/token',
            dataType: 'json',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Authorization': 'Basic ' + btoa(`${this.defaultusername}:${this.defaultpassword}`),
            },
            transformRequest(obj) {
                var str = [];
                for (var p in obj)
                    str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
                return str.join("&");
            },
            data: {
                grant_type: 'password',
                username: username,
                password: password,
            },
        };
        return $http(config).then((response) => {
            console.log(response, "Success Response");
            sessionStorage.setItem("cdt_session", response.data.access_token);

        }, (response) => {
            console.log(response, "Error Response");
            sessionStorage.setItem("errorMessage", response.data.error_description)
        });

    };
}
InterceptorService.$inject = ['$window', '$crypto'];
function InterceptorService($window, $crypto) {
    this.response = function (responseInstance) {
        return responseInstance;
    };
    this.responseError = function (responseErrorInstance) {
        console.log(responseErrorInstance, 'responseErrorInstance');
        if (responseErrorInstance.data.error == 'invalid_token') {
            alert('Your session timed out, Please login again');
            $window.location.href = '../index.html';
            sessionStorage.removeItem('cdt-user-authenticated');
        }
        // if(responseErrorInstance.hasOwnProperty('error')){
        //     console.log("ERROR CHECK");
        //     if(responseErrorInstance.error.toLowerCase().trim() === "invalid_token"){

        //         // Redirect user to login page
        //        //$window.location.href = '../index.html';
        //         // Preferably $state.go('login');
        //         sessionStorage.removeItem('cdt-user-authenticated');
        //         $window.location.href = '../index.html';
        //     }
        // }
        return responseErrorInstance;
    };
    this.request = function (apiInstance) {
        var userName = sessionStorage.getItem('cdt-uname');
        var password = sessionStorage.getItem('cdt-pwd');
        var userPassword = $crypto.decrypt(password);
        var sessionToken = sessionStorage.getItem('cdt_session') || '';
        if (sessionToken && userName && userPassword) {
            // add Headers here
            apiInstance.headers['Content-Type'] = 'application/x-www-form-urlencoded',
                apiInstance.headers.Authorization = `Bearer ${sessionToken}`;
            // apiInstance.headers['cdt-uname'] = userName,
            // apiInstance.headers['cdt-pwd'] = password
        }
        return apiInstance;
    };
}

userName = '';
password = '';
forgetUserName = '';


/*
 *Login Controller begins
 */
LoginCtrl.$inject = ['$scope', '$log', '$location', '$window', '$http', '$rootScope', 'SessionService', '$crypto'];

function LoginCtrl($scope, $log, $location, $window, $http, $rootScope, SessionService, $crypto) {
    var vm = this;
    $scope.forgot = false;
    $scope.login = true;

    $scope.loginError = '';
    $scope.showForgot = function () {
        $scope.forgot = true;
        $scope.login = false;
    };
    $scope.showLogin = function () {
        $scope.forgot = false;
        $scope.login = true;
    };

    this.reset = function reset(form) {
        if (form) {
            form.$setPristine();
            form.$setUntouched();
            $scope.loginError = '';
            $scope.forgetPasswordError = '';
        }
        this.forgetUserName = '';
        this.userName = '';
        this.userPassword = '';
    };
    /*
       *Login Module Functionality begins
       */
    this.cloudentixLogin = function cloudentixLogin(isValid) {
        $scope.loginError = '';
        $scope.focus = function () {
            $scope.loginError = '';
            $scope.isDisabled = false;
        };
        // var userName = this.userName;

        var userName = this.userName;
        var password = this.userPassword;
        var encryptedValue = $crypto.encrypt(password);
        sessionStorage.setItem('cdt-uname', userName);
        sessionStorage.setItem('cdt-pwd', encryptedValue);
        SessionService.fetchToken(userName, password).then(() => {
            var sessionToken = sessionStorage.getItem('cdt_session') || "";
            // If the Login Form is valid means this function executed 
            if (isValid) {
                $scope.loginError = "";
                //Getting the Username and Password values in Login form  
                var loginURL = baseUrl + "/login";
                //Set the values for Passing JSON
                $scope.isDisabled = true;
                var loginConfig = {
                    method: "POST",
                    url: loginURL,
                    dataType: 'json',
                    async: false,
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        'Authorization': 'Bearer ' + sessionToken,
                        'cdt-uname': userName,
                        'cdt-pwd': password
                    }
                }
                $http(loginConfig)
                    .then(function success(response) {
                        if (response.data.type == 'success') {
                            $scope.loginError = " ";
                        } else {
                            $scope.loginError = response.data.message;
                        }
                        sessionStorage.setItem('cdt-user-authenticated', JSON.stringify(
                            {
                                isAuthenticatedUser: true
                            }
                        ));
                        sessionStorage.setItem("firstname", response.data.data['login']['0'].firstname);
                        localStorage.setItem("firstname", response.data.data['login']['0'].firstname);
                        sessionStorage.setItem("lastname", response.data.data['login']['0'].lastname);
                        sessionStorage.setItem("userid", response.data.data['login']['0'].guid);
                        localStorage.setItem("userid", response.data.data['login']['0'].guid);
                        sessionStorage.setItem("username", response.data.data['login']['0'].username);
                        localStorage.setItem("username", response.data.data['login']['0'].username);
                        sessionStorage.setItem("usertype", response.data.data['login']['0'].type);
                        localStorage.setItem("usertype", response.data.data['login']['0'].type);
                        var firstname = sessionStorage.getItem("firstname");
                        var lastname = sessionStorage.getItem("lastname");
                        var userid = sessionStorage.getItem("userid");
                        var usertype = sessionStorage.getItem("usertype");

                        var redirect = sessionStorage.getItem('url');
                        var emailURL = sessionStorage.getItem('mailurl');
                        var emailpath = sessionStorage.getItem('mailpath');

                        if ((emailpath != null) && (emailURL != null)) {
                            var last = emailpath.split("/");
                            var temp = emailURL.split(/[#/?&]/);
                            if ((temp != null) && (temp[1] == 'myCloudentix')) {
                                var tempmail = temp[8].split("=");
                                var emailUserid = tempmail[1];
                                //alert(emailUserid + ''+ userid)
                                var emailusertype = last[2].charAt(0).toUpperCase() + last[2].slice(1);
                            }
                        }
                        //Checking the User type for navigating the separate module
                        if (usertype == 'Admin') {

                            //alert( usertype + ' ' + emailusertype + ' ' + userid + ' '+ emailUserid + ' ' + emailURL)
                            if (redirect != null) {
                                $window.location.href = 'admin/#/' + redirect;
                            } else if ((usertype == emailusertype) && (userid == emailUserid) && (emailURL != null)) {
                                $window.location.href = 'admin/' + emailURL;
                            } else if ((usertype == emailusertype) && (userid != emailUserid) && (emailURL != null)) {
                                void 0;
                                sessionStorage.clear();
                                localStorage.clear();
                                vm.userName = "";
                                vm.userPassword = "";
                                //loginForm.$setPristine();
                                //loginForm.$setUntouched();
                            } else if ((usertype != emailusertype) && (userid != emailUserid) && (emailURL != null)) {
                                void 0;
                                sessionStorage.clear();
                                localStorage.clear();
                                vm.userName = "";
                                vm.userPassword = "";
                                //loginForm.$setPristine();
                                //loginForm.$setUntouched();
                            } else {
                                $window.location.href = 'admin/';
                            }
                        }
                        if (usertype == 'Manager') {
                            //alert( usertype + ' ' + emailusertype + ' ' + userid + ' '+ emailUserid + ' ' + emailURL)
                            if (redirect != null) {
                                $window.location.href = 'manager/#/' + redirect;
                            } else if ((usertype == emailusertype) && (userid == emailUserid) && (emailURL != null)) {
                                //alert('hi');
                                $window.location.href = 'manager/' + emailURL;
                            } else if ((usertype == emailusertype) && (userid != emailUserid) && (emailURL != null)) {
                                void 0;
                                sessionStorage.clear();
                                localStorage.clear();
                                vm.userName = "";
                                vm.userPassword = "";

                            } else if ((usertype != emailusertype) && (userid != emailUserid) && (emailURL != null)) {
                                void 0;
                                sessionStorage.clear();
                                localStorage.clear();
                                vm.userName = "";
                                vm.userPassword = "";

                            } else {
                                //alert('hello');
                                //alert(emailURL)
                                $window.location.href = 'manager/';
                            }
                        }
                        if (usertype == 'User') {
                            // alert( usertype + ' ' + emailusertype + ' ' + userid + ' '+ emailUserid + ' ' + emailURL)
                            if (redirect != null) {
                                $window.location.href = 'users/#/' + redirect;
                            } else if ((usertype == emailusertype) && (userid == emailUserid) && (emailURL != null)) {
                                $window.location.href = 'users/' + emailURL;
                            } else if ((usertype == emailusertype) && (userid != emailUserid) && (emailURL != null)) {
                                void 0;
                                sessionStorage.clear();
                                localStorage.clear();
                                vm.userName = "";
                                vm.userPassword = "";

                            } else if ((usertype != emailusertype) && (userid != emailUserid) && (emailURL != null)) {
                                void 0;
                                sessionStorage.clear();
                                localStorage.clear();
                                vm.userName = "";
                                vm.userPassword = "";

                            } else {
                                $window.location.href = 'users/';
                            }
                        }
                    }, function error(response) {
                        $scope.loginError = sessionStorage.getItem('errorMessage');
                    });
            }
        });


    };
    this.cloudentixforgotPassword = function cloudentixforgotPassword(isValid) {

        $scope.focus = function () {
            $scope.forgetPasswordError = '';
            $scope.isDisabled = false;
        };
        if (isValid) {

            var forgetUserName = this.forgetUserName;
            $scope.isDisabled = true;
            // window.alert(forgetUserName);
            var config = {
                url: `${baseUrl}/forgotpwd/`,
                method: 'GET',
                dataType: 'json',
                async: false,
                headers: {
                    Authorization: 'Basic ' + btoa(`${SessionService.defaultusername}:${SessionService.defaultpassword}`),
                    'cdt-mailid': forgetUserName,
                },
            };

            $http(config).then((response) => {

                $scope.forgetPasswordError = response.data.message;

            }, (response) => {
                // It will work when the server returns the status "500 - Internal server" or 400 series errors
                $rootScope.loaderCurrentStatus = 'false';
                $scope.errorHandler(response.config.url, response.status);
            });
        }

    };
}
changePasswordCtrl.$inject = ['$scope', '$log', '$location', '$window', '$http', 'SessionService'];
function changePasswordCtrl($scope, $log, $location, $window, $http, SessionService) {
    this.changePasswordReset = function changePasswordReset(form) {

        if (form) {
            form.$setPristine();
            form.$setUntouched();
            this.oldPassword = '';
            this.newPassword = '';
            this.confirmPassword = '';
            $scope.changePasswordStatus = '';
            $scope.changePasswordError = '';

            $scope.loading = false;
        }
    };
    this.cloudentixChangePassword = function cloudentixChangePassword(isValid) {
        $scope.focus = function () {
            $scope.changePasswordStatus = '';
            $scope.changePasswordError = '';
            $scope.isDisabled = false;
        };
        if (isValid) {
            var loginuser = localStorage.getItem('username');
            var oldpassword = this.oldPassword;
            var newpassword = this.newPassword;
            var confirmpassword = this.confirmPassword;
            var userid = localStorage.getItem('userid');

            $scope.isDisabled = true;
            $scope.loading = true;
            var config = {
                url: `${baseUrl}/changepwd`,
                method: 'PUT',
                dataType: 'json',
                async: false,
                headers: {
                    Authorization: 'Basic ' + btoa(`${SessionService.defaultusername}:${SessionService.defaultpassword}`),
                    'cdt-mailid': loginuser,
                    'cdt-oldpwd': oldpassword,
                    'cdt-newpwd': newpassword,
                    'cdt-confirmpwd': confirmpassword,
                    'cdt-loginguid': userid,
                },
            };

            $http(config).then((response) => {
                $scope.loading = false;

                if (response.data.type === "success") {
                    $scope.changePasswordStatus = response.data.message;
                    //$scope.toastMessage('toast-success',response.data.message);
                } else {
                    $scope.changePasswordError = response.data.message;
                }
            }, (response) => {
                $scope.loading = false;
                $scope.changePasswordError = response.data.message;
            });
        }
    };
}
resetPasswordCtrl.$inject = ['$scope', '$log', '$location', '$window', '$http', 'SessionService'];
function resetPasswordCtrl($scope, $log, $location, $window, $http, SessionService) {


    var getToken = (document.location.search).replace('?', '');
    var decoded_Token = decodeURIComponent(getToken);
    var getCompatibvaroken = decoded_Token.split('&');

    var token = getCompatibvaroken[0].split('token=');
    var mailid = getCompatibvaroken[1].split('email=');
    var tokenurl = `${baseUrl}/forgotpwd/token`;
    var updateURL = `${baseUrl}/forgotpwd/update`;

    var config = {
        url: tokenurl,
        method: 'GET',
        dataType: 'json',
        async: false,
        headers: {
            Authorization: 'Basic ' + btoa(`${SessionService.defaultusername}:${SessionService.defaultpassword}`),
            'cdt-mailid': mailid[1],
            'cdt-token': token[1],
            // "idt-newpwd": newpassword,
            // "idt-confirmpwd" : confirmpassword,
        },
    };

    $http(config).then((response) => {
        void 0;
        if (response.data.type == "success") {
            //alert("")

        }
        //$scope.loading = false;
        // $scope.changePasswordStatus = response.data.message;
    }, (response) => {
        //alert(response.data.type)

        //$scope.changePasswordStatus = response.data.message;
    });

    this.cloudentixResetPassword = function cloudentixResetPassword(isValid) {
        $scope.focus = function () {
            $scope.resetPasswordStatus = '';
            $scope.isDisabled = false;
        };
        if (isValid) {
            var userid = localStorage.getItem('userid');
            var resetNewPassword = this.resetNewPassword;
            var resetConfirmPassword = this.resetConfirmNewPassword;
            $scope.isDisabled = true;
            var config = {
                url: updateURL,
                method: 'PUT',
                dataType: 'json',
                async: false,
                headers: {
                    Authorization: 'Basic ' + btoa(`${SessionService.defaultusername}:${SessionService.defaultpassword}`),
                    'cdt-mailid': mailid[1],
                    'cdt-token': token[1],
                    'cdt-newpwd': resetNewPassword,
                    'cdt-confirmpwd': resetConfirmPassword,
                    'cdt-loginguid': userid,
                },
            };

            $http(config).then((response) => {
                //$scope.loading = false;
                $scope.resetPasswordStatus = response.data.message;
            }, (response) => {
                //$scope.changePasswordStatus = response.data.message;
            });

        }
    };
}

displayCtrl.$inject = ['$scope', '$location', '$window', '$http', 'SessionService'];
function displayCtrl($scope, $location, $window, $http, SessionService) {
    // logout function
    var logoutURL = `${baseUrl}/logout`;
    var loginuser = localStorage.getItem('username');
    $scope.logout = function () {
        var config = {
            url: logoutURL,
            method: 'GET',
            dataType: 'json',
            async: false,
            headers: {
                Authorization: 'Basic ' + btoa(`${SessionService.defaultusername}:${SessionService.defaultpassword}`),
                'cdt-uname': loginuser,
            },
        };
        $http(config).then((response) => {
            sessionStorage.clear();
            localStorage.clear();
            $window.location.href = '../index.html';
        }, (response) => {
            //$scope.changePasswordStatus = response.data.message;
        });
    };
}
installCtrl.$inject = ['$scope', '$window', '$http', '$mdToast', 'SessionService'];
function installCtrl($scope, $window, $http, $mdToast, SessionService) {
    $scope.form = {};
    angular.element(document).ready(() => {
        var installURL = baseUrl + "/install";
        var config = {
            url: installURL,
            method: "GET",
            dataType: 'json',
            headers: {
                "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
            }
        }
        $http(config).then(function success(response) {
            if (response.data.type == 'success') {
                if (response.data.records[0].count > 0) {
                    $window.location.href = 'login.html';
                } else {
                    $scope.showinstall = true;
                }
            } else {
                $scope.Toastmessage(response.data.type, response.data.message);
            }

        }, function error(response) {
            $scope.Toastmessage('error', response.statusText);
        });
    });
    $scope.clearForm = function () {
        $scope.form.adminusername = '';
        $scope.form.adminpassword = '';
        $scope.form.adminconfirmpassword = '';
        $scope.installform.$setUntouched();
        $scope.installform.$setPristine(true);
    };
    $scope.Toastmessage = function (type, msg) {
        var icon;
        if (type == 'success') {
            icon = 'done';
        } else if (type == 'error') {
            icon = 'error_outline';
        } else if (type == 'warning') {
            icon = 'warning';
        } else {
            icon = 'info';
        }
        $mdToast.show({
            template: `<md-toast class="md-toast ${type}"><div class="md-toast-content"><i class="material-icons">${icon}</i>&nbsp;&nbsp;${msg}</div></md-toast>`,
            hideDelay: 3000,
            position: 'top right',
        });
    };
    $scope.submitInstall = function (valid) {
        if (valid) {
            var submitinstallURL = `${baseUrl}/install`;
            var config = {
                url: submitinstallURL,
                method: 'POST',
                dataType: 'json',
                headers: {
                    'Authorization': 'Basic ' + btoa(`${SessionService.defaultusername}:${SessionService.defaultpassword}`),
                    'cdt-pwd': $scope.form.adminpassword,
                    'cdt-email': $scope.form.adminusername,
                },
            };
            $http(config).then((response) => {
                if (response.data.type == 'success') {
                    $window.location.href = 'login.html';
                } else {
                    $scope.Toastmessage(response.data.type, response.data.message);
                }
            }, (response) => {
                $scope.Toastmessage('error', response.statusText);
            });
        }
    };
    $scope.startinstallprocess = function () {
        $scope.showinstallprocess = true;
        $scope.showinstall = false;
    };
}
angular.module('datepickerBasicUsage', ['ngMaterial', 'ngMessages']).controller('AppCtrl', function () {
    this.myDate = new Date();
    this.isOpen = false;
});
