angular
  .module('cloudentixApp')
  .controller('sideToggle', sideToggle);

function sideToggle($scope) {
  // This will hide the DIV by default.
  $scope.IsHidden = true;
  $scope.reportHidden = true;
  $scope.dataHidden = true;
  $scope.domainHidden = true;
  $scope.roleHidden = true;
  $scope.adHidden = true;
  $scope.ShowHide = function () {
    // If DIV is hidden it will be visible and vice versa.
    $scope.IsHidden = !$scope.IsHidden;
  };

  $scope.ReportHide = function () {
    // If DIV is hidden it will be visible and vice versa.
    $scope.reportHidden = !$scope.reportHidden;
  };

  $scope.DataHide = function () {
    // If DIV is hidden it will be visible and vice versa.
    $scope.dataHidden = !$scope.dataHidden;
  };

  $scope.DomainHide = function () {
    // If DIV is hidden it will be visible and vice versa.
    $scope.domainHidden = !$scope.domainHidden;
  };

  $scope.RoleHide = function () {
    // If DIV is hidden it will be visible and vice versa.
    $scope.roleHidden = !$scope.roleHidden;
  };

  $scope.ADHide = function () {
    // If DIV is hidden it will be visible and vice versa.
    $scope.adHidden = !$scope.adHidden;
  };
}
