 angular
    .module('cloudentixApp')
    .controller('uiController', uiCtrl)
 function uiCtrl($scope, $window, $location) {
		
        win = angular.element($window);
		
		win.on('resize',function(){
			//alert($window.innerWidth);
			})
		
		$scope.sidebarHeight = window.innerHeight;
        //ng-style="{height: sidebarHeight + 'px'}"
        
        $scope.sidebarActive = function(activePath,defaultPath){
           activePath = activePath.replace('#','')
           locationPath = $location.path();
        
           if(locationPath === defaultPath){
               return 'sidebar-active';
           }else{
               locationPath = locationPath.replace('/','');
               if(activePath === locationPath){
                   return 'sidebar-active';
               }else{
                   return '';
               }
           }
        }
        
      var ScrollCtrl = function($scope) {   
        $scope.scrollTop = 0
        $scope.scrollHeight = 0
        $scope.onScroll = function (scrollTop, scrollHeight) {
            $scope.scrollTop = scrollTop
            $scope.scrollHeight = scrollHeight
        }
      };
        
	}