idleTimeListener.$inject = ["$document"];
function idleTimeListener($document) {
  // Holds last interacted time in MS
  var lastInteractionTime = Date.now(), // Value in MS
      interValToCheck = 5000;
  $document.find("body").on("mousemove keydown touchstart", function() {
    lastInteractionTime = Date.now();
  });
  setInterval(function() {
    // check lastInteractionTime here
    var currentTime = Date.now(),
      timeLapse = 3000, // In MS
      idleTime = currentTime - lastInteractionTime; // ms
    if (idleTime < timeLapse) {
      //console.log("Making keepalive call..");
    } else {
      //console.log("User is gone!");
    }
  }, interValToCheck);
}

angular.module("cloudentixApp").run(idleTimeListener);
