/*
 * Cloudentix Core JavaScript Library v1.0
 * http://cloudentix.com/
 *
 * Copyright 2016, Sennovate, Inc.
 * Released under the MIT license
 * http://sennovate.com/license
 *
 * Author : Kannan
 * Last Updated On : 2016-08-04
 */
angular
    .module('cloudentixApp')
    /*
        view user -> resource begins:
        *we defined selectedResourceControl name of controller function
        *then injected needful directives in controller function
    */
    .controller('selectedResourceControl', selectedresourceControl)
    selectedresourceControl.$inject = ['$rootScope', '$scope', '$log', '$location', '$window', '$http', '$mdDialog', '$mdMedia', '$mdToast', '$document', '$route', '$timeout', 'SessionService'];    
    function selectedresourceControl($rootScope, $scope, $log, $location, $window, $http, $mdDialog, $mdMedia, $mdToast, $document, $route, $timeout, SessionService) {
        var baseUrl = sessionStorage.getItem("WS_BASE_URL");
        var checkResourceURL = baseUrl + '/resources?check=true';
		var config = {
			url:checkResourceURL,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword)
			}
		}
		$http(config)
		.success(function(response) {
            if(response.type == 'success') {
                if (response.data.login[0].trusted == 'N' || response.data.login[0].untrusted == 'N') {
                    if (response.data.login[0].trusted == 'N' && response.data.login[0].untrusted == 'N') {
                           $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure trusted and untrusted resources");
                    } else {
                        if (response.data.login[0].trusted == 'N') {
                            $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure the trusted resource");
                        } else if (response.data.login[0].untrusted === 'N') {
                            $scope.resouceconfigureMessage("Cloudentix requires atleast one trusted and untrusted resource.Please configure an untrusted resource");
                        }
                    }
                }
                else if(response.data.login[0].trusted == 'Y' && response.data.login[0].untrusted == 'Y') {
                    /* it get user's resource details from sessionStorage
                    and get selected resource name for getting  appropriate details
                    */
                    $scope.userresource = localStorage.getItem('putuserresource');
                    $scope.selectedResource = localStorage.getItem('selectedResource');
                    var userkey;
                    if($scope.userresource != null && $scope.userresource != undefined && $scope.userresource != '') {
                        $scope.userresource = JSON.parse(localStorage.getItem('putuserresource'));
                        angular.forEach($scope.userresource, function(value, key) {
                            if(value.rescourcename == $scope.selectedResource) {
                                $scope.Untrustedtitle = value.rescourcename + " User Information";
                                $scope.userResourcefieldlist = [];
                                $scope.parsedata = JSON.parse(value.userinformation[0].columnvalue);
                                $scope.keyName = value.userinformation[0].columnname;
                                $scope.untrustedRole = value.userrole;
                                angular.forEach($scope.keyName, function(value, key) {
                                    userkey = value.replace(/_/g," ");
                                    $scope.userResourcefieldlist.push({'fieldname': userkey,'fieldvalue': $scope.parsedata.userdetails[value]});
                                });
                            }
                        });
                    }
                }
            } else {
                $rootScope.loaderCurrentStatus = 'false';
                $scope.errorHandler(response.message,response.status);
            }
		});
    };