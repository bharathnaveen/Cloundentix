/*
 * Cloudentix Core JavaScript Library v1.0
 * http://cloudentix.com/
 *
 * Copyright 2016, Sennovate, Inc.
 * Released under the MIT license
 * http://sennovate.com/license
 *
 * Author : Kannan
 * Last Updated On : 2016-08-04
 */
angular
    .module('cloudentixApp')
    .controller('listUserrole', listuserrole)
    listuserrole.$inject = ['$scope'];    
    function listuserrole($scope) {
        var sessionData =  localStorage.getItem('viewrole');
        if(sessionData != '') {
            $scope.viewrole = [];
            $scope.viewrole = sessionData.split(",");
            void 0;
        } else {
            $scope.viewrole = '';
        }
    };