/*
 * Cloudentix Core JavaScript Library v1.0
 * http://cloudentix.com/
 *
 * Copyright 2016, Sennovate, Inc.
 * Released under the MIT license
 * http://sennovate.com/license
 *
 * Author : Kannan
 * Last Updated On : 2016-08-04
 */
angular
    .module('cloudentixApp')
    .controller('listofUserresource', listUserresource)
    listUserresource.$inject = ['$rootScope', '$scope', '$log', '$location', '$window', '$http', '$mdDialog', '$mdMedia', '$mdToast', '$document', '$route', '$timeout', '$state'];    
    function listUserresource($rootScope, $scope, $log, $location, $window, $http, $mdDialog, $mdMedia, $mdToast, $document, $route, $timeout, $state) {
        $rootScope.loaderCurrentStatus = 'true';
        $scope.userresource = localStorage.getItem('putuserresource');
        /* it get list of resource name if user available in */
        $scope.selectedTabs.selectedIndex = 2;
        if($scope.userresource != null && $scope.userresource != undefined && $scope.userresource != '') {
            $scope.userresource = JSON.parse($scope.userresource);
            $scope.listResources = [];
            angular.forEach($scope.userresource, function(value, key) {
                $scope.listResources.push({'resourcename': value.rescourcename});
            })
        }
        $rootScope.loaderCurrentStatus = 'false';
        /* set use rselected resource name and navigated to selectedResource tab*/
        $scope.userSelectedResource = function(selectedResource) {
            localStorage.setItem('selectedResource', selectedResource);
            $state.go("viewuserResource");
            $scope.addTab('View UserResource','viewuserResource');
        }
    };