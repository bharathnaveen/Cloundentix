angular
    .module('cloudentixApp')
   .service('loaderService', function() {
		this.loadData= function (x) {
			return x;
		}
	})
	/*.factory('loaderService', function(){
	  var loadData = true;
	  return {
		loadData: function() { return loadData; },
		newLoadedData: function(newLoadData) { loadData = newLoadData; }
	  };
	})*/
 	.config(function ($mdThemingProvider) {
     
    $mdThemingProvider
    $mdThemingProvider
    .theme('default')
    .primaryPalette('indigo');
    /*.accentPalette('grey',{
		'default' : '700'
	})
    .warnPalette('red')*/
    //.backgroundPalette('blue-grey');
	})
 
      .controller('AppCtrl', AppCtrl)
	  .run(
      ['$rootScope', '$state', '$stateParams','$timeout', '$document', '$location','$window',
        function($rootScope, $state, $stateParams,$timeout, $document, $location, $window) {
                
  //         $rootScope.$state = $state;
  //         $rootScope.$stateParams = $stateParams;
	// 	 $rootScope.validatesessionTimedout = 0;
	// 		 void 0;

  //   // Timeout timer value
  //   var TimeOutTimerValue = 1000*60*5; // 3 minutes
  //   // Start a timeout
  //   var TimeOut_Thread = $timeout(function() {
  //     LogoutByTimer()
  //   }, TimeOutTimerValue);
  //   var bodyElement = angular.element($document);

  //   angular.forEach(['keydown', 'keyup', 'click', 'mousemove', 'DOMMouseScroll', 'mousewheel', 'mousedown', 'touchstart', 'touchmove', 'scroll', 'focus'],
  //     function(EventName) {
  //       bodyElement.bind(EventName, function(e) {
  //         TimeOut_Resetter(e)
  //       });
	
  //     });
		
  //   function LogoutByTimer() {
     
	//  //if( $rootScope.loaderCurrentStatus = 'false'){
	//  	 if($rootScope.loaderCurrentStatus == 'true'){
	//   bodyElement.bind('load', function(e) {
  //         TimeOut_Resetter(e)
  //       });
		
	//   }else{
	// 		void 0;
	// 		if ($rootScope.validatesessionTimedout == 0) {
	// 			$rootScope.autologoutMessage("For security reasons and protection of your personal data , your session has ended. \nPlease login again.");
	// 				//console.log('Logout');
	// 			}
	// 		}
  //   }

  //   function TimeOut_Resetter(e) {
  //     //console.log(' ' + e);

  //     //Stop the pending timeout
  //     $timeout.cancel(TimeOut_Thread);

  //     // Reset the timeout
  //     TimeOut_Thread = $timeout(function() {
  //       LogoutByTimer()
  //     }, TimeOutTimerValue);


  //   }
    $rootScope.$on('$stateChangeStart', stateChangeListener);
    function stateChangeListener(event, toState, toParams, fromState, fromParams, options){
var auth = JSON.parse(sessionStorage.getItem('cdt-user-authenticated')) || {};
if(auth.isAuthenticatedUser){
//$window.location.href = '../index.html';
// Redirect to Login page OR logout method here...
        }
    };
	
        }
      ]
    )
    .config(
      ['$ocLazyLoadProvider', '$stateProvider', '$urlRouterProvider', '$httpProvider',
        function($ocLazyLoadProvider, $stateProvider, $urlRouterProvider, $httpProvider) {

          $urlRouterProvider
            .when('/', '/dashboard')
            .otherwise('/dashboard');

                //Config For ocLazyLoading
                $ocLazyLoadProvider.config({
                  'debug': true, // For debugging 'true/false'
                  'events': true, // For Event 'true/false'
                  'modules': [{
                      name: 'dashboard', // dashboard module
                      files: ['dashboard/user.dashboard.controllers.js']
                  }, {
                      name: 'myCloudentix', // myCloudentix module
                      files: ['myCloudentix/user.myCloudentix.controllers.js']
                  }, {
                      name: 'users', // users module
                      files: ['users/user.users.controllers.js']
                  }]
              });

          $stateProvider
            .state('/', {
              abstract: true,
              url: '/dashboard',
              templateUrl: 'dashboard/cloudentix-user-dashboard.html',
              controller: function($scope) {
                $scope.$on('$stateChangeSuccess', function(event, toState, toParams, fromState, fromParams) {
                  $scope.currentTab = toState.data.selectedTab;
                });
              }
            })

          .state('dashboard', {
              url: '/dashboard',
             controller: function($scope) {

              },
              templateUrl: 'dashboard/cloudentix-user-dashboard.html',
              resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                  return $ocLazyLoad.load('dashboard'); // Resolve promise and load before view 
                }]
              }
            })
       .state('users', {
              url: '/users',
              onEnter: function() {
                void 0;
              },
              controller: function($scope) {

              },
              templateUrl: 'users/cloudentix-user-users.html',
              resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                  return $ocLazyLoad.load('users'); // Resolve promise and load before view 
                }]
              }
            })
        
        .state('myCloudentix', {
              url: '/myCloudentix',
              controller: function($scope) {

              },
              templateUrl: 'myCloudentix/cloudentix-user-myCloudentix.html',
              resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                  return $ocLazyLoad.load('myCloudentix'); // Resolve promise and load before view 
                }]
              }
            })
           .state('support', {
              url: '/support',
              controller: function($scope) {

              },
              templateUrl: 'support/cloudentix-user-support.html'
            })
            .state('changePassword', {
              url: '/changePassword',
              onEnter: function() {
               
              },
              controller: 'ChangePasswordCtrl',
              controllerAs:'changePasswordCtrl',
              templateUrl: '../change-password.html'
            })
			.state('viewuser', {
              url: '/viewuser',
             //controller: 'ViewResourceController',
              templateUrl: 'users/cloudentix-user-viewuser.html'
            })
			.state('viewuserResource', {
              url: '/viewuserResource',
             //controller: 'ViewResourceController',
              templateUrl: 'users/cloudentix-user-viewuserResource.html'
            })
			/* For Dashboard Reports */
				.state('accesspolicy', {
              url: '/accesspolicy',
             //controller: '',
              templateUrl: 'dashboard/cloudentix-user-accessPolicy.html'
            })
			.state('userprovisioningissue', {
              url: '/userprovisioningissue',
             //controller: '',
              templateUrl: 'dashboard/cloudentix-user-userprovisioningissue.html'
            })
			.state('accesspolicyevaluationissue', {
              url: '/accesspolicyevaluationissue',
             //controller: '',
              templateUrl: 'dashboard/cloudentix-user-accesspolicyevaluationissue.html'
            })
			.state('approvalpolicyevaluationissue', {
              url: '/approvalpolicyevaluationissue',
             //controller: '',
              templateUrl: 'dashboard/cloudentix-user-approvalpolicyevaluationissue.html'
            });
            $httpProvider.interceptors.push("InterceptorService");
        }
      ]
    );
    AppCtrl.$inject = ['$scope', '$log', '$location', '$mdSidenav', '$mdDialog', '$state', '$mdToast', '$document','loaderService', '$rootScope'];
    function AppCtrl ($scope, $log, $location, $mdSidenav, $mdDialog, $state,  $mdToast, $document,loaderService, $rootScope) {
		// $scope.loaderService = loaderService;
		$rootScope.loginuser = '';
		$rootScope.loadStatus = loaderService.loadData(false);
		
		//alert($scope.loadStatus);
		 var username = localStorage.getItem("firstname");
		 this.username = username;
	
	

$scope.toastMessage = function(type, msg) {
	var icon;
	if(type == 'toast-success'){
		icon = 'done';
	}  else if(type == 'toast-error'){
		icon = 'error_outline';
	} else if(type == 'toast-warn'){
		icon = 'warning';
	} else{
		icon = 'info_outline';
	}
    $mdToast.show({
        template: '<md-toast class="md-toast ' + type +'"><div class="md-toast-content"><i class="material-icons">'+icon+'</i>&nbsp;&nbsp;' + msg + '</div></md-toast>',
        hideDelay: 3000,
        position: 'top right'
    });
};

$scope.showSimpleToast = function() {
    $mdToast.show({
        template : '<md-toast class="md-toast toast-info"><div class="md-toast-content"><i class="material-icons">verified_user</i>&nbsp;&nbsp;Welcome '+ username + '!</div></md-toast>',
         hideDelay: 3000,
         position: 'top right'
    });
};
  

  
  $scope.showSimpleToast(this.click);
  //$scope.toastMessage('toast-error','Hi')	;
	 var originatorEv;
   
    this.openMenu = function($mdOpenMenu, ev) {
      originatorEv = ev;
      $mdOpenMenu(ev);
    };

    originatorEv = null;
	
	$scope.toggleSidenav = function(menuId) {
		$mdSidenav(menuId).toggle();
	};
	
	    $scope.sidebarActive = function(activePath,defaultPath){
           activePath = activePath.replace('#','')
           locationPath = $location.path();
        
           if(locationPath === defaultPath){
               return 'sidebar-active';
           }else{
               locationPath = locationPath.replace('/','');
               if(activePath === locationPath){
                   return 'sidebar-active';
               }else{
                   return '';
               }
           }
        }
	
     var redirect = sessionStorage.getItem('url');
    if(redirect == null){
        if(localStorage.getItem("selectedTab") == null){
            if(sessionStorage.getItem('mailurl') != null){
            var tabs = [];
            tabs.push({title:"My Cloudentix",tabLink:"myCloudentix.pendingapproval",disabled:false});
            }
            else if(sessionStorage.getItem('mailurl') == null){
            var tabs = [];
           tabs.push({title: 'Dashboard', tabLink: "dashboard", disabled: false});
            }
        }else{
         var tabs = [];
         tabs.push(JSON.parse(localStorage.getItem("selectedTab")));
        }
        }
        else{
        if(localStorage.getItem("autologout") == "true"){
             var tabs = [];
           tabs.push({title: 'Dashboard', tabLink: "dashboard", disabled: false});
            }
            else{
         var tabs = [];
         tabs.push(JSON.parse(localStorage.getItem("selectedTab")));
        }
        
        }
        var selected = null,
        previous = null;
    $scope.tabs = tabs;
    $scope.selectedIndex = 0;
    $scope.$watch('selectedIndex', function(current, old){
		//console.log( $scope.selectedIndex);
      previous = selected;
      selected = tabs[current];
      $rootScope.selectedtab = tabs[current];
	 localStorage.setItem('selectedTab', JSON.stringify($rootScope.selectedtab));
     /* if ( old + 1 && (old != current)) $log.debug('Goodbye ' + previous.title + '!');
      if ( current + 1 )                $log.debug('Hello ' + selected.title + '!');*/
    });
    $scope.addTab = function (title, view, userid, selectedtitle) {
		
		if(userid != undefined && userid != '') {
			 sessionStorage.setItem('userGuid', userid);
		}
		if(selectedtitle != undefined && selectedtitle != '') {
			 sessionStorage.setItem('selectedResource', selectedtitle);
		}
	  var tabLength = tabs.length;
	 
	  var tempTab = 0;
	  	for(var i = 0; i < tabLength; i++){
			//console.log(tabs[i].title);
			if((tabs[i].title == title) && (tabs[i].tabLink == view)){
				tempTab = 1;	
				 
			}
		}
		
		if(tempTab == 0){
			tabs.push({ title: title, tabLink: view, disabled: false});
			
		} else {
			
			var tabIndex = tabs.findIndex(tabArray => tabArray.title == title );
			$scope.selectedIndex = tabIndex;		
		}
		
    };
    $scope.removeTab = function (tab) {
      var index = tabs.indexOf(tab);
      var prevTab = index - 1;
	  var nextTab = index + 1;
	  
      if(index > 0){ 
		  var newUrl = tabs[prevTab].tabLink;
			$state.go(newUrl);
			$scope.selectedIndex = prevTab;
			tabs.splice(index, 1);
	  } else {
		  var newUrl = tabs[nextTab].tabLink;
			$state.go(newUrl);
			$scope.selectedIndex = index;
		    tabs.splice(index , 1);
	  }
    }
$rootScope.autologoutMessage = function(content1) {
		$mdDialog.show({
        controller: autologout,
        templateUrl: 'logout.html',
        parent: angular.element(document.body),
        clickOutsideToClose:false,
		locals: {
           autologoutMsg: content1
        },
    })
	};
  }
  autologout.$inject = ['$scope', '$state', '$mdDialog', '$rootScope', 'autologoutMsg', '$rootScope', '$http', '$window', '$location', 'SessionService'];
  function autologout($scope, $state, $mdDialog, $rootScope, autologoutMsg, $rootScope, $http, $window, $location, SessionService) {

	$scope.autologoutMessage = autologoutMsg;
	$rootScope.validatesessionTimedout = 1;
	if(localStorage.getItem("username") != null) {
		$rootScope.loginuser = localStorage.getItem("username");
        $rootScope.reLoginPath = $location.url().replace('/','');
	}
	sessionStorage.clear();
	localStorage.clear();
	$scope.closelogout = function() {
		var logoutURL = baseUrl + "/logout";
        var config = {
                                url: logoutURL, 
                                method: "GET",
                                 dataType: 'json',
                                async: false,
                                headers: {
                                    "Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
                                   "cdt-uname": $rootScope.loginuser
                                }
                             }
                    
                $http(config).then(function success(response) {
						$mdDialog.hide();
                        localStorage.setItem("autologout","true");
                        sessionStorage.setItem("url",$location.url().replace('/',''));
                         sessionStorage.setItem("TabDetails",JSON.stringify($rootScope.selectedtab));
                        $window.location.href = '../index.html';
                  }, function error(response) {
                });
	};
  }