angular.module('cloudentixApp')
.controller('accesspolicyReportController', accesspolicyReportController) 
accesspolicyReportController.$inject = ['$rootScope', '$scope', '$http', 'SessionService'];
function accesspolicyReportController($rootScope, $scope, $http, SessionService) {
		'use strict';
		$rootScope.loaderCurrentStatus = 'true';
		 var baseUrl = sessionStorage.getItem("WS_BASE_URL");
		$scope.selected = [];
		$scope.limitOptions = [10, 25, 50, 100];
		$scope.options = {
			rowSelection: false,
			multiSelect: false,
			autoSelect: true,
			decapitate: false,
			largeEditDialog: true,
			boundaryLinks: true,
			limitSelect: true,
			pageSelect: true
		};
		$scope.query = {
			order: 'name',
			limit: 10,
			page: 1
		};
		$scope.toggleLimitOptions = function () {
		$scope.limitOptions = $scope.limitOptions ? undefined : [10, 25, 50, 100];
	};
	$scope.getTypes = function () {
		return ['Candy', 'Ice cream', 'Other', 'Pastry'];
	};
	$scope.logItem = function (item) {
		void 0;
	};
	$scope.logOrder = function (order) {
		void 0;
	};
	  
	$scope.logPagination = function (page, limit) {
		void 0;
		void 0;
	}
		var accesspolicy = baseUrl + '/reports/accesspolicyviolation';

		var config = {
			url: accesspolicy,
			method: "GET",
			headers: {
				"Authorization": "Basic " + btoa(SessionService.defaultusername + ":" + SessionService.defaultpassword),
			}
		};
		$http(config).success(function(response) {  
			$scope.reportsResponse = response.type;
			$rootScope.loaderCurrentStatus = 'false';
            if(response.type === "success") { 
				$scope.accesspolicydata = [];
				angular.forEach(response.records[0].accesspolviorecords, function(value, key) {
					$scope.accesspolicydata.push({'username': value['username'], 'resourcename': value['rscname'], 'rolename': value['rolename'], 'remarks': value['remarks']});
				});
            } else {
               $scope.reportsErrorMessage = response.message;        
            }            
           
		}).error(function(data) {
            void 0;        
		});		    
}