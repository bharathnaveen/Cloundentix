This is Cloudentix Front-end Collaborate 17 conference release candidate

Completed API 

Security Governor Module

APIs
1. Dashborad 
    Endpoint - http://app-dev.cloudentix.com:9797/api/v4/sg/dashboard
    UI - http://localhost:2000/admin/#/securityGovernor/dashboard
2. Account Duplicate Employee Ids 
    Endpoint - http://app-dev.cloudentix.com:9797/api/v4/sg/duplicateemployeeids
    UI - http://localhost:2000/admin/#/securityGovernor/acc-duplicateemployeeid
3. Account Expiration 
    Endpoint - http://app-dev.cloudentix.com:9797/api/v4/sg/reportaccountsexpiration
    UI - http://localhost:2000/admin/#/securityGovernor/acc-expiration
4. Account Multiple Employee Ids 
    Endpoint - http://app-dev.cloudentix.com:9797/api/v4/sg/multipleemployeeids
    UI - http://localhost:2000/admin/#/securityGovernor/acc-multipleemployeeids
5. DataBase List 
    Endpoint - http://app-dev.cloudentix.com:9797/api/v4/sg/dblist
    UI - http://localhost:2000/admin/#/securityGovernor/cvuegroupjob - Select Database dropdown field
6. Job Title
    Endpoint - http://app-dev.cloudentix.com:9797/api/v4/sg/cvuegroupsforajobtitle
    UI - http://localhost:2000/admin/#/securityGovernor/cvuegroupjob - Select JobTitle dropdown field
7. Job Title for Business Unit
    Endpoint - http://app-dev.cloudentix.com:9797/api/v4/sg/bujobtitle
    UI - http://localhost:2000/admin/#/securityGovernor/bustaffjob - Select JobTitle for Business Unit dropdown field
8. Business Unit List
    Endpoint - http://app-dev.cloudentix.com:9797/api/v4/sg/bussinessunitrecords
    UI - http://localhost:2000/admin/#/securityGovernor/bustaffjob 
9. Attestation Review for Manager 
    Endpoint - http://app-dev.cloudentix.com:9797/api/v4/sg/manager
    UI - http://localhost:2000/admin/#/securityGovernor/attestationReview - Select JobTitle dropdown field
10. Attestation Review for Job Role
    Endpoint - http://app-dev.cloudentix.com:9797/api/v4/sg/attestationreviewjobrole
    UI - http://localhost:2000/admin/#/securityGovernor/attestationReview - Select JobTitle dropdown
11. Attestation Review for Staff Name
    Endpoint - http://app-dev.cloudentix.com:9797/api/v4/sg/attestationreviewstaffname
    UI - http://localhost:2000/admin/#/securityGovernor/attestationReview - Select JobTitle dropdown
12. Attestation Review for CVue Group List
    Endpoint - http://app-dev.cloudentix.com:9797/api/v4/sg/attestationreviewcvuegroup
    UI - http://localhost:2000/admin/#/securityGovernor/attestationReview